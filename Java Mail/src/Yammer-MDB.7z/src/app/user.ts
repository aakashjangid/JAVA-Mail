export class User{
    user_id:number;
    userImagePath:string;
    firstName:string;
	lastName:string;
	email:string;
}