import { Time } from "@angular/common";

export class Like{
    like_id:number;
    post_id:number;
    user_id:number;
    likeDate:Date;
    likeTime:Time;
}