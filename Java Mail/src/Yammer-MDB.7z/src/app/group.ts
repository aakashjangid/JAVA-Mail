export class Group {
    group_id: number;
    groupName: string;
    groupImage: string;
}