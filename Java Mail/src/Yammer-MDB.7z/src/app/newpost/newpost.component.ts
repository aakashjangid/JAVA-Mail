import { Component, OnInit } from '@angular/core';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-newpost',
  templateUrl: './newpost.component.html',
  styleUrls: ['./newpost.component.css']
})
export class NewpostComponent implements OnInit {

  postContent: string;
  fileList: FileList;
  image: boolean = false;
  progressBar:boolean = false;

  constructor(private postService: PostService) { }

  ngOnInit() {
  }

  fileChange(event) {
    this.fileList = event.target.files;
    let file = event.target.files[0].name;
    ((document.getElementById("imageTitle") as HTMLInputElement)).innerHTML = file;
    this.image = true;
  }

  uploadPost() {
    this.progressBar = true;
    if (this.image) {
      this.uploadWithImage();
    } else {
      this.uploadWithoutImage();
    }
  }

  uploadWithImage() {
    let file: File = this.fileList[0];
    this.postService.addPost(file, this.postContent).subscribe(
      data => { 
        console.log('success');
      },
      error => { 
        console.log(error) 
      },
      () =>{
        this.progressBar = false;
        window.location.reload();
      }
    )
  }

  uploadWithoutImage() {
    this.postService.addPostWithoutImage(this.postContent).subscribe(
      data => { 
        console.log('success');
        this.progressBar = false;
        window.location.reload();
      },
      error => { 
        console.log(error) 
      }
    )
  }
}