import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { MDBBootstrapModule } from 'angular-bootstrap-md';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FooterComponent } from './footer/footer.component';
import { Routes, RouterModule } from '@angular/router';

import { LoginService } from './services/login.service';
import {StoragePostService} from './services/storage-post.service';

import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './components/home/home.component';
import { NewpostComponent } from './newpost/newpost.component';
import { HeaderComponent } from './components/header/header.component';
import { PopularPostsComponent } from './components/popular-posts/popular-posts.component';
import { DatesAndEventsComponent } from './components/dates-and-events/dates-and-events.component';
import { GroupsListComponent } from './components/groups-list/groups-list.component';
import { RecentlyActiveUserComponent } from './components/recently-active-user/recently-active-user.component';
import { ShowOnePostComponent } from './components/show-one-post/show-one-post.component';
import { CelebrityComponent } from './components/celebrity/celebrity.component';
import { PeopleMayKnowComponent } from './components/people-may-know/people-may-know.component';
import { PublicComponent } from './components/public/public.component';
import { LocationStrategy } from '@angular/common';
import { HashLocationStrategy } from '@angular/common';
import { AboutUSComponent } from './components/about-us/about-us.component';
import { PrivacyComponent } from './components/privacy/privacy.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';

const appRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'home',  component: HomeComponent },
  { path: 'celebrity',  component: CelebrityComponent },
  { path: 'public',  component: PublicComponent },
  { path: 'post',  component: ShowOnePostComponent },
  { path: 'aboutUs',  component: AboutUSComponent },
  { path: 'privacy',  component: PrivacyComponent },
  { path: 'forgotPassword', component: ForgotPasswordComponent},
  { path: '',   redirectTo: '/login', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    FooterComponent,
    HomeComponent,
    NewpostComponent,
    HeaderComponent,
    PopularPostsComponent,
    DatesAndEventsComponent,
    GroupsListComponent,
    RecentlyActiveUserComponent,
    ShowOnePostComponent,
    CelebrityComponent,
    PeopleMayKnowComponent,
    PublicComponent,
    AboutUSComponent,
    PrivacyComponent,
    ForgotPasswordComponent
  ],
  imports: [
    BrowserModule,
    MDBBootstrapModule.forRoot(),
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy },
    LoginService, StoragePostService
  ],
  bootstrap: [AppComponent],
  schemas:[NO_ERRORS_SCHEMA ]
})
export class AppModule { }
