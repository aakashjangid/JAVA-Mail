import { Time } from "@angular/common";
import { CommentsLike } from "./commentsLike";

export class Comment{
    comment_id:number;
    content:string;
    user_id:number;
    commentDate:Date;
    commentTime:Time;
    commentsLikes:CommentsLike[];
}