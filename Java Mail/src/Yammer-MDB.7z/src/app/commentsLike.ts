export class CommentsLike{
    commentsLike_id:number;
    comment_id:number;
    user_id:number;
    post_id:number;
}