import { Component, OnInit } from '@angular/core';
import { Post } from '../../post';
import { PostService } from '../../services/post.service';
import { StoragePostService } from '../../services/storage-post.service';

@Component({
  selector: 'app-dates-and-events',
  templateUrl: './dates-and-events.component.html',
  styleUrls: ['./dates-and-events.component.css']
})
export class DatesAndEventsComponent implements OnInit {
  
  datesAndEventsPosts:Post[] = [];
  objectKeys = Object.keys;
  popularPostsIds: Number[];

  constructor(private postService: PostService, private storagePostService: StoragePostService) { }

  ngOnInit() {
    this.getAllPopularPosts();
  }

  getAllPopularPosts(){
    this.postService.getAllPopularPosts().subscribe(
      data => {
        this.popularPostsIds = data as Number[];
      }, error => {
        console.log("Error in fetching data", error);
      },
      () => {
        var allPosts: Post[] = this.storagePostService.getAllPosts();
        for (let id of this.popularPostsIds) {
          for (let post of allPosts) {
            if (post.post_id == id) {
              this.datesAndEventsPosts.push(post);
            }
          }
        }
      }
    );

  }

  openPost(post_id:number){
    console.log(post_id);
  }

}
