import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatesAndEventsComponent } from './dates-and-events.component';

describe('DatesAndEventsComponent', () => {
  let component: DatesAndEventsComponent;
  let fixture: ComponentFixture<DatesAndEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatesAndEventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatesAndEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
