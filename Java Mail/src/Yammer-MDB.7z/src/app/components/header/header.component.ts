import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { User } from '../../user';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  currentUser;

  constructor(private router:Router, private location: Location) {
    this.currentUser = localStorage.getItem('user');
   }

  ngOnInit() {
  }

  doLogout(){
    localStorage.removeItem('cUserId');
    localStorage.removeItem('user');
    this.location.replaceState('/');
    this.router.navigate(['/']);
  }

}
