import { Component, OnInit } from '@angular/core';
import { Post } from '../../post';
import { PostService } from '../../services/post.service';
import { StoragePostService } from '../../services/storage-post.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-popular-posts',
  templateUrl: './popular-posts.component.html',
  styleUrls: ['./popular-posts.component.css']
})
export class PopularPostsComponent implements OnInit {

  popularPosts: Post[] = [];
  objectKeys = Object.keys;
  popularPostsIds: Number[];
  allPosts:Post[] = [];

  constructor(private postService: PostService, private storagePostService: StoragePostService, private router: Router) { }

  ngOnInit() {
    this.getAllPopularPosts();
  }

  getAllPopularPosts() {
    this.postService.getAllPopularPosts().subscribe(
      data => {
        this.popularPostsIds = data as Number[];
      }, error => {
        console.log("Error in fetching data", error);
      },
      () => {
        this.allPosts = this.storagePostService.getAllPosts();
        console.log(this.allPosts)
        for (let id of this.popularPostsIds) {
          for (let post of this.allPosts) {
            if (post.post_id == id) {
              this.popularPosts.push(post);
            }
          }
        }
      }
    );

  }

  openPost(indexOfPost: number) {
    this.storagePostService.selectedPost = this.popularPosts[indexOfPost];
    localStorage.setItem('currentPost', JSON.stringify(this.popularPosts[indexOfPost]));
    console.log(window.location.href);
    if (window.location.href == "http://localhost:8181/#/post") {
      window.location.reload();
    } else {
      this.router.navigate(['/post']);
    }
  }

}
