import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentlyActiveUserComponent } from './recently-active-user.component';

describe('RecentlyActiveUserComponent', () => {
  let component: RecentlyActiveUserComponent;
  let fixture: ComponentFixture<RecentlyActiveUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecentlyActiveUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentlyActiveUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
