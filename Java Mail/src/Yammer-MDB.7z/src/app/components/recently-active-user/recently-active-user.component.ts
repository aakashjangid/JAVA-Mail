import { Component, OnInit } from '@angular/core';
import { User } from '../../user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-recently-active-user',
  templateUrl: './recently-active-user.component.html',
  styleUrls: ['./recently-active-user.component.css']
})
export class RecentlyActiveUserComponent implements OnInit {

  users:User[];

  constructor(private userService:UserService) { }

  ngOnInit() {
    this.getAllRecentActiveUsers();
  }

  getAllRecentActiveUsers(){
    this.userService.getAllRecentActiveUsers().subscribe(
      data =>{
        this.users = data as any;
        console.log(data);
      },
      error =>{
        console.log("Error in fetching Recent Users", error);
      }
    );
  }

}
