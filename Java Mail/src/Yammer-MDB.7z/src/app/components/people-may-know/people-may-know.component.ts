import { Component, OnInit } from '@angular/core';
import { GroupService } from '../../services/group.service';
import { Group } from '../../group';
import { User } from '../../user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-people-may-know',
  templateUrl: './people-may-know.component.html',
  styleUrls: ['./people-may-know.component.css']
})
export class PeopleMayKnowComponent implements OnInit {

  allUsers:User[];

  constructor(private userService:UserService) { }

  ngOnInit() {
    this.getAllUsers();
  }

  getAllUsers(){
    this.userService.getAllUsers().subscribe(
      data =>{
        this.allUsers = data as any;
        console.log(data);
      },
      error =>{
        console.log('Error getting Groups', error);
      }
    );
  }

}
