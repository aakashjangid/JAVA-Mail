import { Component, OnInit } from '@angular/core';
import { PostService } from '../../services/post.service';
import { Post } from '../../post';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { HostListener } from '@angular/core';
import { Like } from '../../like';
import { CommentsLike } from '../../commentsLike';

@Component({
  selector: 'app-public',
  templateUrl: './public.component.html',
  styleUrls: ['./public.component.css']
})
export class PublicComponent implements OnInit {

  allPosts: Post[];
  somePosts: Post[];
  i: number = 3;
  j: number = 6;
  objectKeys = Object.keys;
  newComment: string;
  cUserId: any;
  toggleLike: boolean = false;
  modalPost: Post = new Post();
  shareContent: string;

  constructor(private postService: PostService, private router: Router, private location: Location) {
    if (!localStorage.getItem("user")) {
      location.replaceState('/');
      router.navigate(['/'])
    }
    this.cUserId = +localStorage.getItem('cUserId');
  }

  @HostListener("window:scroll", [])
  onScroll(): void {
    if (this.bottomReached()) {
      for (; this.i <= this.j; this.i++) {
        this.somePosts.push(this.allPosts[this.i]);
      }
      if (this.j < this.allPosts.length) {
        this.j = this.j + 3;
      }
      if (this.j > this.allPosts.length) {
        this.j = this.allPosts.length - 1;
      }
    }
  }

  bottomReached(): boolean {
    return (window.innerHeight + window.scrollY) >= document.body.offsetHeight;
  }

  ngOnInit() {
    this.getAllPosts();
  }

  checkLike(likes: Like[]): boolean {
    for (let i = 0; i < likes.length; i++) {
      if (likes[i].user_id === this.cUserId) {
        return true;
      }
    }
    return false;
  }

  checkLikeOnComment(likes: CommentsLike[]): boolean {
    for (let i = 0; i < likes.length; i++) {
      if (likes[i].user_id === this.cUserId) {
        return true;
      }
    }
    return false;
  }

  getAllPosts() {
    this.postService.getAllPosts().subscribe(
      data => {
        this.allPosts = data as any;
        console.log(data);
        this.somePosts = this.allPosts.splice(0, this.i);
      },
      error => {
        console.log("Error in fetching data", error);
      }
    );
  }

  doSharePost(post_id: number) {
    console.log(post_id)
    this.postService.doSharePost(post_id, this.shareContent).subscribe(
      data => {
        window.location.reload();
      },
      error => {
        console.log('Error in Sharing post', error);
      }
    )
  }

  sharePost(postIndex: number) {
    console.log('12345');
    this.modalPost = this.somePosts[postIndex];
  }

  doLikePost(post_id: number) {
    console.log(post_id);
    this.postService.doLikeOnPost(post_id).subscribe(
      data => {
        console.log("Like Success");
        this.toggleLike = true;
        location.reload();
      },
      error => {
        console.log("error in like");
        this.toggleLike = false;
      }
    )
  }

  doLikeComment(comment_id: number, post_id: number) {
    console.log(comment_id);
    this.postService.doLikeOnComment(comment_id, post_id).subscribe(
      data => {
        console.log("Like Success on Comment");
        this.toggleLike = true;
        location.reload();
      },
      error => {
        console.log("error in like on comment");
        this.toggleLike = false;
      }
    )
  }

  doUnLikePost(post_id: number) {
    console.log(post_id);
    this.postService.doUnLikeOnPost(post_id).subscribe(
      data => {
        console.log("UnLike Success");
        this.toggleLike = false;
        location.reload();
      },
      error => {
        console.log("error in Unlike");
        this.toggleLike = true;
      }
    )
  }

  doUnLikeComment(comment_id: number, post_id) {
    console.log(comment_id);
    this.postService.doUnLikeOnComment(comment_id, post_id).subscribe(
      data => {
        console.log("UnLike Success on Comment");
        this.toggleLike = false;
        location.reload();
      },
      error => {
        console.log("error in Unlike on Comment");
        this.toggleLike = true;
      }
    )
  }

  doCommentOnPost(post_id: number) {
    this.postService.doCommentOnPost(post_id, this.newComment).subscribe(
      data => {
        window.location.reload();
      },
      error => {
        console.log("Error in Comments ", error);
      }
    )
  }

}