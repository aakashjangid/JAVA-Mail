import { Component, OnInit } from '@angular/core';
import { PostService } from '../../services/post.service';
import { Post } from '../../post';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { HostListener } from '@angular/core';
import { Like } from '../../like';
import { CommentsLike } from '../../commentsLike';
import { StoragePostService } from '../../services/storage-post.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  allPosts: Post[];
  somePosts: Post[];
  i: number = 3;
  j: number = 6;
  objectKeys = Object.keys;
  newComment: string;
  cUserId: any;
  toggleLike: boolean = false;
  modalPost: Post = new Post();
  shareContent: string;
  dataLoaded: boolean = false;

  constructor(private postService: PostService, private router: Router, private location: Location, private storageService: StoragePostService) {
    if (!localStorage.getItem("user")) {
      location.replaceState('/');
      router.navigate(['/'])
    }
    this.cUserId = +localStorage.getItem('cUserId');
  }

  @HostListener("window:scroll", [])
  onScroll(): void {
    if (this.bottomReached()) {
      for (this.i; this.i <= this.j; this.i++) {
        this.somePosts.push(this.allPosts[this.i]);
      }
      if (this.j < this.allPosts.length) {
        this.j = this.j + 3;
      }
      if (this.j > this.allPosts.length) {
        this.j = this.allPosts.length - 1;
      }
    }
  }

  bottomReached(): boolean {
    return (window.innerHeight + window.scrollY) >= document.body.offsetHeight;
  }

  ngOnInit() {
    this.getAllPosts();
  }

  checkLike(likes: Like[]): boolean {
    for (let i = 0; i < likes.length; i++) {
      if (likes[i].user_id === this.cUserId) {
        return true;
      }
    }
    return false;
  }

  checkLikeOnComment(likes: CommentsLike[]): boolean {
    for (let i = 0; i < likes.length; i++) {
      if (likes[i].user_id === this.cUserId) {
        return true;
      }
    }
    return false;
  }

  getAllPosts() {
    this.postService.getAllPosts().subscribe(
      data => {
        this.allPosts = data as any;
        console.log('Home', data);
        this.storageService.allPosts = JSON.parse(JSON.stringify(data));
        this.somePosts = this.allPosts.slice(0, this.i);
      },
      error => {
        console.log("Error in fetching data", error);
      },
      () => {
        this.dataLoaded = true;
      }
    );
  }

  doSharePost(post_id: number) {
    console.log(post_id)
    this.postService.doSharePost(post_id, this.shareContent).subscribe(
      data => {
        window.location.reload();
      },
      error => {
        console.log('Error in Sharing post', error);
      }
    )
  }

  sharePost(postIndex: number) {
    console.log('12345');
    this.modalPost = this.somePosts[postIndex];
  }

  doLikePost(post_id: number) {
    console.log(post_id);
    this.postService.doLikeOnPost(post_id).subscribe(
      data => {
        let Apost: Post = data as any;
        console.log("Like Success");
        this.toggleLike = true;
        for (let post of this.somePosts) {
          if (post.post_id == Apost.post_id) {
            var index = this.somePosts.indexOf(post);
            this.somePosts[index] = Apost;
          }
        }
      },
      error => {
        console.log("error in like");
        this.toggleLike = false;
      }
    )
  }

  doUnLikePost(post_id: number) {
    console.log(post_id);
    this.postService.doUnLikeOnPost(post_id).subscribe(
      data => {
        let Apost: Post = data as any;
        console.log("UnLike Success");
        this.toggleLike = false;
        for (let post of this.somePosts) {
          if (post.post_id == Apost.post_id) {
            var index = this.somePosts.indexOf(post);
            this.somePosts[index] = Apost;
          }
        }
      },
      error => {
        console.log("error in Unlike");
        this.toggleLike = true;
      }
    )
  }

  doLikeComment(comment_id: number, post_id: number) {
    console.log(comment_id);
    this.postService.doLikeOnComment(comment_id, post_id).subscribe(
      data => {
        let Apost: Post = data as any;
        console.log("Like Success on Comment");
        this.toggleLike = true;
        for (let post of this.somePosts) {
          if (post.post_id == Apost.post_id) {
            var index = this.somePosts.indexOf(post);
            this.somePosts[index] = Apost;
          }
        }
      },
      error => {
        console.log("error in like on comment");
        this.toggleLike = false;
      }
    )
  }

  doUnLikeComment(comment_id: number, post_id) {
    console.log(comment_id);
    this.postService.doUnLikeOnComment(comment_id, post_id).subscribe(
      data => {
        let Apost: Post = data as any;
        console.log("UnLike Success on Comment");
        this.toggleLike = false;
        for (let post of this.somePosts) {
          if (post.post_id == Apost.post_id) {
            var index = this.somePosts.indexOf(post);
            this.somePosts[index] = Apost;
          }
        }
      },
      error => {
        console.log("error in Unlike on Comment");
        this.toggleLike = true;
      }
    )
  }

  doCommentOnPost(post_id: number) {
    var newComment = ((document.getElementById("newComment" + post_id) as HTMLInputElement).value);
    this.postService.doCommentOnPost(post_id, newComment).subscribe(
      data => {
        let Apost: Post = data as any;
        for (let post of this.somePosts) {
          if (post.post_id == Apost.post_id) {
            var index = this.somePosts.indexOf(post);
            this.somePosts[index] = Apost;
          }
        }
      },
      error => {
        console.log("Error in Comments ", error);
      }
    )
  }

}
