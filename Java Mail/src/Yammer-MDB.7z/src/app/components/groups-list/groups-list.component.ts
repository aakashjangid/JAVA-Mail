import { Component, OnInit } from '@angular/core';
import { Group } from '../../group';
import { GroupService } from '../../services/group.service';

@Component({
  selector: 'app-groups-list',
  templateUrl: './groups-list.component.html',
  styleUrls: ['./groups-list.component.css']
})
export class GroupsListComponent implements OnInit {

  allGroups:Group[];

  constructor(private groupService:GroupService) { }

  ngOnInit() {
    this.getAllGroups();
  }

  getAllGroups(){
    this.groupService.getAllGroups().subscribe(
      data =>{
        this.allGroups = data as any;
        console.log(data);
      },
      error =>{
        console.log('Error getting Groups', error);
      }
    );
  }

  joinGroup(group_id:number){
    console.log(group_id);
    this.groupService.joinGroup(group_id).subscribe(
      data =>{
        this.allGroups = data as any;
        console.log(data);
      },
      error =>{
        console.log('Error getting Groups', error);
      }
    );
  }

}
