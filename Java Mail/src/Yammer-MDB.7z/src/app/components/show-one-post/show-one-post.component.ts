import { Component, OnInit } from '@angular/core';
import { Post } from '../../post';
import { Like } from '../../like';
import { PostService } from '../../services/post.service';
import { Router } from '@angular/router';
import { CommentsLike } from '../../commentsLike';
import { StoragePostService } from '../../services/storage-post.service';

@Component({
  selector: 'app-show-one-post',
  templateUrl: './show-one-post.component.html',
  styleUrls: ['./show-one-post.component.css']
})
export class ShowOnePostComponent implements OnInit {

  currentPost: Post;
  objectKeys = Object.keys;
  newComment: string;
  cUserId: any;
  toggleLike: boolean = false;
  modalPost: Post = new Post();
  shareContent: string;

  constructor(private postService: PostService, private router: Router, private storagePostService: StoragePostService) {
    if (!localStorage.getItem("user")) {
      router.navigate(['/'])
    }
    this.cUserId = +localStorage.getItem('cUserId');
  }

  ngOnInit() {
    // this.currentPost = JSON.parse(localStorage.getItem('currentPost'));
    this.currentPost = this.storagePostService.getSelected();
  }

  checkLike(likes: Like[]): boolean {
    for (let i = 0; i < likes.length; i++) {
      if (likes[i].user_id === this.cUserId) {
        return true;
      }
    }
    return false;
  }

  checkLikeOnComment(likes: CommentsLike[]): boolean {
    for (let i = 0; i < likes.length; i++) {
      if (likes[i].user_id === this.cUserId) {
        return true;
      }
    }
    return false;
  }

  doSharePost(post_id: number) {
    console.log(post_id)
    this.postService.doSharePost(post_id, this.shareContent).subscribe(
      data => {
        window.location.reload();
      },
      error => {
        console.log('Error in Sharing post', error);
      }
    )
  }

  sharePost(postIndex: number) {
    console.log('12345');
    // this.modalPost = this.somePosts[postIndex];
  }

  doLikePost(post_id: number) {
    this.postService.doLikeOnPost(post_id).subscribe(
      data => {
        console.log("Like Success");
        this.currentPost = data as any;
        var post: Post = data as any;
        // localStorage.setItem('currentPost', JSON.stringify(post));
        this.toggleLike = true;
        // location.reload();
      },
      error => {
        console.log("error in like");
        this.toggleLike = false;
      }
    )
  }

  doLikeComment(comment_id: number, post_id: number) {
    console.log(comment_id);
    this.postService.doLikeOnComment(comment_id, post_id).subscribe(
      data => {
        this.currentPost = data as any;
        console.log("Like Success on Comment");
        this.toggleLike = true;
        // location.reload();
      },
      error => {
        console.log("error in like on comment");
        this.toggleLike = false;
      }
    )
  }

  doUnLikePost(post_id: number) {
    console.log(post_id);
    this.postService.doUnLikeOnPost(post_id).subscribe(
      data => {
        this.currentPost = data as any;
        console.log("UnLike Success");
        this.toggleLike = false;
        // location.reload();
      },
      error => {
        console.log("error in Unlike");
        this.toggleLike = true;
      }
    )
  }

  doUnLikeComment(comment_id: number, post_id) {
    console.log(comment_id);
    this.postService.doUnLikeOnComment(comment_id, post_id).subscribe(
      data => {
        this.currentPost = data as any;
        console.log("UnLike Success on Comment");
        this.toggleLike = false;
        // location.reload();
      },
      error => {
        console.log("error in Unlike on Comment");
        this.toggleLike = true;
      }
    )
  }

  doCommentOnPost(post_id: number) {
    this.postService.doCommentOnPost(post_id, this.newComment).subscribe(
      data => {
        this.currentPost = data as any;
        // window.location.reload();
      },
      error => {
        console.log("Error in Comments ", error);
      }
    )
  }


}
