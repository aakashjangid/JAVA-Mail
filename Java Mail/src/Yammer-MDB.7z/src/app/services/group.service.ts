import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
};

@Injectable({
  providedIn: 'root'
})
export class GroupService {
  
  url = "http://localhost:8080/yammer";

  constructor(private http: HttpClient) { }

  getAllGroups(){
    let user={
      'user_id':localStorage.getItem("cUserId")
    }
    return this.http.post(this.url + "/group/all",user, httpOptions).pipe();
  }

  joinGroup(group_id){
    let userGroup={
      'user_id':localStorage.getItem("cUserId"),
      'group_id':group_id
    }
    return this.http.post(this.url+"/group/joinGroup", userGroup).pipe();
  }
}
