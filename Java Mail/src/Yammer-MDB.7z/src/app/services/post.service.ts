import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
};

@Injectable({
  providedIn: 'root'
})
export class PostService {

  url = "http://localhost:8080/yammer";

  constructor(private http: HttpClient) { }

  getAllPosts() {
    return this.http.get(this.url + "/post/all", httpOptions).pipe();
  }

  getAllPopularPosts(){
    return this.http.get(this.url+"/post/popular", httpOptions).pipe();
  }

  addPost(file: File, postContent: string) {
    let formData: FormData = new FormData();
    formData.append('file', file, Math.floor(Math.random() * (999999 - 100000)) + 100000+file.name);
    formData.append('title', postContent);
    formData.append('userId',localStorage.getItem("cUserId"))
    return this.http.post(this.url + "/post/addPost", formData).pipe();
  }

  addPostWithoutImage(postContent:string){
    let post={
      'content':postContent,
      'user_id':localStorage.getItem("cUserId")
    }
    return this.http.post(this.url + "/post/addPostWithoutImage", post).pipe();
  }

  doCommentOnPost(post_id:number, content:string){
    let comment={
      'post_id':post_id,
      'content':content,
      'user_id':localStorage.getItem("cUserId")
    }
    return this.http.post(this.url+"/post/addComment", comment).pipe();
  }

  doLikeOnPost(post_id:number){
    let like={
      'post_id':post_id,
      'user_id':localStorage.getItem("cUserId")
    }
    return this.http.post(this.url+"/post/addLike", like).pipe();
  }

  doUnLikeOnPost(post_id:number){
    let like={
      'post_id':post_id,
      'user_id':localStorage.getItem("cUserId")
    }
    return this.http.post(this.url+"/post/removeLike", like).pipe();
  }

  doLikeOnComment(comment_id:number, post_id:number){
    let commentsLike={
      'post_id':post_id,
      'comment_id':comment_id,
      'user_id':localStorage.getItem("cUserId")
    }
    return this.http.post(this.url+"/post/comment/addLike", commentsLike).pipe();
  }

  doUnLikeOnComment(comment_id:number, post_id:number){
    let commentsLike={
      'post_id':post_id,
      'comment_id':comment_id,
      'user_id':localStorage.getItem("cUserId")
    }
    return this.http.post(this.url+"/post/comment/removeLike", commentsLike).pipe();
  }

  doSharePost(post_id:number, shareContent:string){
    let post={
      'post_id':post_id,
      'user_id':localStorage.getItem("cUserId"),
      'shareContent':shareContent
    }
    return this.http.post(this.url+"/post/sharePost", post).pipe();
  }

}
