import { TestBed, inject } from '@angular/core/testing';

import { StoragePostService } from './storage-post.service';

describe('StoragePostService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StoragePostService]
    });
  });

  it('should be created', inject([StoragePostService], (service: StoragePostService) => {
    expect(service).toBeTruthy();
  }));
});
