import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators'

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' })
};

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url = "http://localhost:8080/yammer";

  constructor(private http:HttpClient) { }

  getAllRecentActiveUsers(){
    return this.http.get(this.url+"/user/recentActive", httpOptions).pipe();
  }

  getAllUsers(){
    return this.http.get(this.url+"/user/recentActive", httpOptions).pipe();
  }
}
