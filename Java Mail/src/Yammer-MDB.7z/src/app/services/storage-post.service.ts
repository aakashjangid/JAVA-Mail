import { Injectable } from '@angular/core';
import { Post } from '../post';

@Injectable({
  providedIn: 'root'
})
export class StoragePostService {

  selectedPost:Post;
  allPosts:Post[];

  constructor() { }

  getSelected(){
    return this.selectedPost;
  }

  getAllPosts(){
    return this.allPosts;
  }
}
