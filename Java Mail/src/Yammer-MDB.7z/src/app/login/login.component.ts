import { Component, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email: string;
  password: string;
  firstName: string;
  lastName: string;
  confirmPassword: string;
  formValue: Number = 1;

  registrationSuccess: boolean = false;
  emailExists: boolean = false;
  invalidUser: boolean = false;
  passwordNotMathced: boolean = false;
  notActive: boolean = false;
  invalidEmail: boolean = false;
  passwordUpdate: boolean = false;

  constructor(private loginService: LoginService, private router: Router) {
    if (localStorage.getItem("user")) {
      this.router.navigate(['/home']);
    }
    this.passwordUpdate = JSON.parse(localStorage.getItem('pasUpd'));
  }

  ngOnInit() {
    localStorage.removeItem('pasUpd');
  }

  doAuthenticate() {
    this.loginService.authenticateUser(this.email, this.password).subscribe(
      data => {
        if (data == 1) {
          this.doLogin();
        } else if (data == 0) {
          this.notActive = true;
          this.invalidUser = false;
          this.registrationSuccess = false;
        } else {
          this.invalidUser = true;
          this.notActive = false;
          this.registrationSuccess = false;
        }
      }
    );
  }

  doLogin() {

    this.loginService.login(this.email, this.password).subscribe(
      data => {
        localStorage.setItem("cUserId", data.user_id);
        localStorage.setItem("user", data);
        this.router.navigate(['/home']);
      },
      error => {
        this.invalidUser = true;
        this.registrationSuccess = false;
      });
  }

  sendOTP() {
    this.loginService.sendOTP(this.email).subscribe(
      data => {
        if (data == true) {
          localStorage.setItem('forEmail',this.email);
          this.router.navigate(['/forgotPassword']);
        } else {
          this.invalidEmail = true;
        }
      },
      error => {
      }
    );
  }

  loginForm() {
    this.invalidEmail = false;
    this.formValue = 1;
  }

  registrationForm() {
    this.formValue = 2;
  }

  forgotForm() {
    this.formValue = 3;
  }

  doRegister() {
    if (this.password == this.confirmPassword) {
      this.loginService.register(this.firstName, this.lastName, this.email, this.password).subscribe(
        data => {
          if (data == true) {
            this.formValue = 1;
            this.registrationSuccess = true;
            this.emailExists = false;
            this.password = "";
            this.confirmPassword = "";

          } else {
            this.emailExists = true;
            this.registrationSuccess = false;
            this.password = "";
            this.confirmPassword = "";
          }
        }, error => {
        }
      )
    }
    else {
      this.passwordNotMathced = true;
      this.registrationSuccess = false;
      this.emailExists = false;
      this.password = "";
      this.confirmPassword = "";
    }
  }

  goAboutUs() {
    this.router.navigate(['/aboutUs']);
  }

  goPrivacy() {
    this.router.navigate(['/privacy']);
  }

  goHome() {
    this.router.navigate(['/login']);
  }

}
