import { Comment } from "./comment";
import { Time } from "@angular/common";
import { Like } from "./like";

export class Post{
    post_id:number;
    content:string;
    uploadTime:Date;
    uploadDate:Time;
    user_id:number;
    comments:Comment[];
    imagePath:string;
    userImagePath:string;
    userName:string;
    likes:Like[];
    shareContent:string;
    postStatus:number
}