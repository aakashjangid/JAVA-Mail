/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.5.27 : Database - brand_advocate
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`brand_advocate` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `brand_advocate`;

/*Table structure for table `brand_advocate_details` */

DROP TABLE IF EXISTS `brand_advocate_details`;

CREATE TABLE `brand_advocate_details` (
  `brand_advocate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `affiliation_description` varchar(255) DEFAULT NULL,
  `brand_advocate_status` varchar(255) DEFAULT NULL,
  `building_name` varchar(255) DEFAULT NULL,
  `comments` longtext,
  `cup_id` varchar(255) DEFAULT NULL,
  `cws_user_id` varchar(255) DEFAULT NULL,
  `facility_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `is_active` char(1) DEFAULT 'Y',
  `job_keywords` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `managed_by` varchar(255) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `notes` longtext,
  `organization_name` varchar(255) DEFAULT NULL,
  `preferred_first_name` varchar(255) DEFAULT NULL,
  `primary_email` varchar(255) DEFAULT NULL,
  `registered_by` varchar(255) DEFAULT NULL,
  `registered_via` varchar(255) DEFAULT NULL,
  `registration_date` datetime DEFAULT NULL,
  `secondary_email` varchar(255) DEFAULT NULL,
  `country_id` bigint(20) DEFAULT NULL,
  `inactive_date` datetime DEFAULT NULL,
  `affiliation_description_ui` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`brand_advocate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=439 DEFAULT CHARSET=latin1;

/*Table structure for table `clues_details` */

DROP TABLE IF EXISTS `clues_details`;

CREATE TABLE `clues_details` (
  `cup_id` varchar(255) DEFAULT NULL,
  `brand_advocate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `affiliation_description` varchar(255) DEFAULT NULL,
  `brand_advocate_status` varchar(255) DEFAULT NULL,
  `building_name` varchar(255) DEFAULT NULL,
  `comments` longtext,
  `cws_user_id` varchar(255) DEFAULT NULL,
  `country_code` varchar(20) DEFAULT NULL,
  `facility_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `is_active` char(1) DEFAULT 'Y',
  `job_keywords` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `managed_by` varchar(255) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `notes` longtext,
  `organization_name` varchar(255) DEFAULT NULL,
  `preferred_first_name` varchar(255) DEFAULT NULL,
  `primary_email` varchar(255) DEFAULT NULL,
  `secondary_email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`brand_advocate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Table structure for table `country_tbl` */

DROP TABLE IF EXISTS `country_tbl`;

CREATE TABLE `country_tbl` (
  `country_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(255) DEFAULT NULL,
  `country_name` varchar(255) DEFAULT NULL,
  `region_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`country_id`),
  KEY `fk_country_region` (`region_id`),
  CONSTRAINT `fk_country_region` FOREIGN KEY (`region_id`) REFERENCES `region_tbl` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=latin1;

/*Table structure for table `facility_tbl` */

DROP TABLE IF EXISTS `facility_tbl`;

CREATE TABLE `facility_tbl` (
  `facility_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `facility_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`facility_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `frequency_tbl` */

DROP TABLE IF EXISTS `frequency_tbl`;

CREATE TABLE `frequency_tbl` (
  `frequency_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `frequency_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`frequency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `preferences_tbl` */

DROP TABLE IF EXISTS `preferences_tbl`;

CREATE TABLE `preferences_tbl` (
  `preference_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `preference_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`preference_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Table structure for table `region_tbl` */

DROP TABLE IF EXISTS `region_tbl`;

CREATE TABLE `region_tbl` (
  `region_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Table structure for table `registration_status_tbl` */

DROP TABLE IF EXISTS `registration_status_tbl`;

CREATE TABLE `registration_status_tbl` (
  `reg_status_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `reg_status_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reg_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `status_tbl` */

DROP TABLE IF EXISTS `status_tbl`;

CREATE TABLE `status_tbl` (
  `status_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Table structure for table `user_preferences_tbl` */

DROP TABLE IF EXISTS `user_preferences_tbl`;

CREATE TABLE `user_preferences_tbl` (
  `upa_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `preference_id` bigint(20) DEFAULT NULL,
  `record_id` bigint(20) DEFAULT NULL,
  `brand_advocate_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`upa_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;


/*Table structure for table `affiliation_desc_tbl` */

DROP TABLE IF EXISTS `affiliation_desc_tbl`;

CREATE TABLE `affiliation_desc_tbl` (
  `affiliation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `affiliation_desc` varchar(255) DEFAULT NULL,
  `affiliation_name` varchar(255) DEFAULT NULL,
  `affiliation_name_ui` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`affiliation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
