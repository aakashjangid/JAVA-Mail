
/*Data for the table `region` */

INSERT  INTO `region_tbl`(`region_id`,`region_name`) VALUES (1,'Americas South'),(2,'Americas North'),(3,'EAME'),(4,'Asia Pacific');

/*Data for the table `country` */

INSERT  INTO `country_tbl`(`country_id`,`country_code`,`country_name`,`region_id`) VALUES (1,'AF','Afghanistan',1),(2,'AL','Albania',1),(3,'DZ','Algeria',1),(4,'AS','American Samoa',1),(5,'AD','Andorra',2),(6,'AO','Angola',2),(7,'AI','Anguilla',2);

/*Data for the table `preferences` */

INSERT  INTO `preferences_tbl`(`preference_id`,`preference_name`) VALUES (1,'Webinar invitations'),(2,'Brand event communications'),(3,'Newsletters');

