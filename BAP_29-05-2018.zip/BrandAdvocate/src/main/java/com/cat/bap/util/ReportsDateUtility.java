package com.cat.bap.util;

import java.util.Calendar;
import java.util.Date;

import com.cat.bap.common.BrandAdvocateConstant;

public class ReportsDateUtility {
	
	private ReportsDateUtility(){
		
	}

	/** Logic for YTD starts.......................... */
	public static Date getCurrentYearStartDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, cal.get(Calendar.YEAR));
		cal.set(Calendar.DAY_OF_YEAR, 1);
		return cal.getTime();
	}

	public static Date getPreviousYearStartDate() {
		Calendar cal2 = Calendar.getInstance();
		cal2.set(Calendar.YEAR, cal2.get(Calendar.YEAR) - 1);
		cal2.set(Calendar.DAY_OF_YEAR, 1);
		return cal2.getTime();
	}

	/** Logic for YTD ends.......................... */

	/** Logic for QTD starts.......................... */
	public static Date getCurrentYearCurrentQuarterStartDate() {
		Calendar cal4 = Calendar.getInstance();
		cal4.setTime(new Date());
		cal4.set(Calendar.MONTH, cal4.get(Calendar.MONTH) / 3 * 3);
		cal4.set(Calendar.DAY_OF_MONTH, 1);
		return cal4.getTime();
	}

	public static Date getPreviousYearCurrentQuarterStartDate() {
		Calendar cal5 = Calendar.getInstance();
		cal5.setTime(new Date());
		cal5.set(Calendar.YEAR, cal5.get(Calendar.YEAR) - 1);
		cal5.set(Calendar.MONTH, cal5.get(Calendar.MONTH) / 3 * 3);
		cal5.set(Calendar.DAY_OF_MONTH, 1);
		return cal5.getTime();
	}

	/** Logic for QTD ends.......................... */

	/** Logic for Q1,Q2,Q3,Q4 starts......... */

	public static Date getSelectedQuarterStartDateOfCurrentYear(String quarter) {
		switch (quarter) {
		case BrandAdvocateConstant.Q1_TY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q1, BrandAdvocateConstant.CURRENT_YEAR));
		case BrandAdvocateConstant.Q2_TY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q2, BrandAdvocateConstant.CURRENT_YEAR));
		case BrandAdvocateConstant.Q3_TY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q3, BrandAdvocateConstant.CURRENT_YEAR));
		case BrandAdvocateConstant.Q4_TY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q4, BrandAdvocateConstant.CURRENT_YEAR));
		default:
			return null;
		}
	}

	public static Date getSelectedQuarterEndDateOfCurrentYear(String quarter) {
		switch (quarter) {
		case BrandAdvocateConstant.Q1_TY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q1, BrandAdvocateConstant.CURRENT_YEAR));
		case BrandAdvocateConstant.Q2_TY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q2, BrandAdvocateConstant.CURRENT_YEAR));
		case BrandAdvocateConstant.Q3_TY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q3, BrandAdvocateConstant.CURRENT_YEAR));
		case BrandAdvocateConstant.Q4_TY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q4, BrandAdvocateConstant.CURRENT_YEAR));
		default:
			return null;
		}
	}

	public static Date getSelectedQuarterStartDateOfPreviousYear(String quarter) {
		switch (quarter) {
		case BrandAdvocateConstant.Q1_LY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q1, BrandAdvocateConstant.PREVIOUS_YEAR));
		case BrandAdvocateConstant.Q2_LY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q2, BrandAdvocateConstant.PREVIOUS_YEAR));
		case BrandAdvocateConstant.Q3_LY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q3, BrandAdvocateConstant.PREVIOUS_YEAR));
		case BrandAdvocateConstant.Q4_LY:
			return getFirstDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q4, BrandAdvocateConstant.PREVIOUS_YEAR));
		default:
			return null;
		}
	}

	public static Date getSelectedQuarterEndDateOfPreviousYear(String quarter) {
		switch (quarter) {
		case BrandAdvocateConstant.Q1_LY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q1, BrandAdvocateConstant.PREVIOUS_YEAR));
		case BrandAdvocateConstant.Q2_LY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q2, BrandAdvocateConstant.PREVIOUS_YEAR));
		case BrandAdvocateConstant.Q3_LY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q3, BrandAdvocateConstant.PREVIOUS_YEAR));
		case BrandAdvocateConstant.Q4_LY:
			return getLastDayOfQuarter(getDateByCurrentQuarter(BrandAdvocateConstant.Q4, BrandAdvocateConstant.PREVIOUS_YEAR));
		default:
			return null;
		}
	}

	/** Logic for Q1,Q2,Q3,Q4 ends......... */

	/** common Logic starts.......................... */
	public static Date getCurrentDateOfCurrentYear() {
		Calendar cal3 = Calendar.getInstance();
		return cal3.getTime();
	}

	public static Date getCurrentDateOfPreviousYear() {
		Calendar cal3 = Calendar.getInstance();
		cal3.add(Calendar.YEAR, -1);
		return cal3.getTime();
	}
	/** common Logic ends.......................... */
	
	
	
	
	
	
	
	/**Internally used by methods starts.....................*/
	private static Date getFirstDayOfQuarter(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) / 3 * 3);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		return cal.getTime();
	}

	private static Date getLastDayOfQuarter(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) / 3 * 3 + 2);
		cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		return cal.getTime();
	}

	private static Date getDateByCurrentQuarter(String quarterName, String year) {
		int calObj = 0;
		if (quarterName.equalsIgnoreCase(BrandAdvocateConstant.Q1)) {
			calObj = Calendar.JANUARY;
		}
		if (quarterName.equalsIgnoreCase(BrandAdvocateConstant.Q2)) {
			calObj = Calendar.APRIL;
		}
		if (quarterName.equalsIgnoreCase(BrandAdvocateConstant.Q3)) {
			calObj = Calendar.JULY;
		}
		if (quarterName.equalsIgnoreCase(BrandAdvocateConstant.Q4)) {
			calObj = Calendar.OCTOBER;
		}
		Calendar calendar = Calendar.getInstance();
		if (year.equalsIgnoreCase("currentYear")) {
			calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR));
		}
		if (year.equalsIgnoreCase("previousYear")) {
			calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) - 1);
		}
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.MONTH, calObj);
		return calendar.getTime();
	}
	/**Internally used by methods ends.....................*/
	

}
