package com.cat.bap.common;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose This class is used as enum for manage admin.
 */
public interface UserMasterConstant {

  public static final String ASC="ASC";
  public static final String DESC="DESC";
  public static final String LIST="LIST";
  public static final String COUNT="COUNT"; 
  public static final String MANAGE_ADMIN_DETAILS_DTO="userMasterDto";
  public static final String FLAG_N="N";
  public static final String FLAG_Y="Y"; 
  public static final String COOKIE="cookie";
  public static final String ADMIN_TOKEN="adminToken";
  public static final String DATE_FORMAT="MM/dd/yyyy";
  public static final String FORMATE_2="h'h'-m'm'-a-yyyy-MM-dd";
  public static final String RECORD_ID="record_id"; 
  public static final String BRAND_ADVOCATE_ID = "brand_advocate_id";
  public static final String CUP_ID = "user_cup_id";
  public static final String CWS_USER_ID="cws_user_id";
  public static final String BA_SINCE="ba_since";
  public static final String LAST_NAME="last_name";
  public static final String FIRST_NAME="first_name"; 
  public static final String PREFERRED_FIRST_NAME="preferred_first_name"; 
  public static final String ORG_UNIT="org_unit"; 
  public static final String SECONDARY_EMAIL="secondary_email"; 
  public static final String REGION="region"; 
  public static final String FACILITY_NAME="facility_name"; 
  public static final String COMMON_BUILDING="common_building"; 
  public static final String COMMON_BA_STATUS="brand_advocate_status"; 
  public static final String JOB_KEYWORDS="job_keywords"; 
  public static final String AFFILIATION_DESCRIPTION="affiliation_description"; 
  public static final String BRAND_ADVOCATE_STATUS="brand_advocate_status"; 
  public static final String COMMON_COMMENTS="common_comments"; 
  public static final String QUESTIONS_COMMENTS = "questions_comments";
  public static final String COMMON_NOTES="common_notes"; 
  public static final String COMMON_REGISTERED_VIA="common_registered_via"; 
  public static final String COMMON_REGISTRATION_DATE="common_registration_date"; 
  public static final String COMMON_REGISTERED_BY="common_registered_by"; 
  public static final String COMMON_MODIFIED_DATE="common_modified_date"; 
  public static final String COMMON_MODIFIED_BY="common_modified_by"; 
  public static final String COMMON_MANAGED_BY="common_managed_by"; 
  public static final String DIVISION="division"; 
  public static final String WORK_LOCATION="work_location";
  public static final String COUNTRY="country";
  public static final String EMAIL="email";
  public static final String ADMIN_EXCEL_SHEET_NAME="Brand Advocate Worksheet";
  public static final String MAIL_STMP_USER="mail.stmp.user";
  public static final String MAIL_SMTP_PORT="mail.smtp.port";
  public static final String MAIL_SMTP_HOST="mail.smtp.host";
  public static final String MESSAGE_BODY="body";
  public static final String MAIL_FROM="from";
  public static final String DO_NOT_REPLY="doNotReply";
  public static final String MESSAGE_SENT="Message is sent";
  public static final String TEAM_BRAND_ADVOCATE="teamBrandAdvocate"; 
  public static final String FIRST_NAME_MAIL="firstName";
  public static final String LAST_NAME_MAIL="lastName";
  public static final String MANAGE_CLUES_DETAILS_DTO="CluesDataDetailDto";
  public static final String URL_PATTERN_COMMON="/*";
  public static final String CLUES_POOL_NAME="clues-pool";
  public static final String SUB_PREFERENCES = "sub_preferences";

  /* Admin group name */
  public static final String BAP_ADMIN="BAP-ADMIN";
  public static final String UPLOAD_SUCCESS="Buld upload successfully done.";
  public static final String UPLOAD_FAILED="Bulk upload failed.";
  
  /* DB constants */
  public static final String CLUES_DB_SCHEMA = "Z1FZ001$";
  public static final String BRAND_ADVOCATE = "Brand Advocate";
  public static final String MANAGEDBY_SYSTEM = "System";
  public static final String ACTIVE_HR_RETIRED = "Active-HR Retired";
  public static final String ACTIVE_HR_TERMINATED = "Active-HR Terminated";
  public static final String ACTIVE_INVALID = "Active - Invalid";
  public static final String INACTIVE = "Inactive";
  public static final String CONTENT = "contents";
  public static final String DOCUMENTS = "documents";
  public static final String SUBJECT = "subject";
  public static final String USER_NAME_LIST = "userNameList";
  public static final String ORGANIZATION_LIST = "organizationList";
  public static final String REGION_LIST = "regionList";
  public static final String COUNTRY_LIST = "countryList";
  public static final String BRAND_EVENT_COMMUNICATIONS = "Brand event communications";
  public static final String WEBINAR_INVITATIONS = "Webinar invitations";
  public static final String NEWSLETTERS = "Newsletters";
  public static final String WEBINAR = "Webinar";
  public static final String EVENT = "Event";
  public static final String NEWSLETTER = "Newsletter";
  
  public static final String ASIA_PACIFIC    = "Asia Pacific";
  public static final String AMERICAS_NORTH  = "Americas North";
  public static final String AMERICAS_SOUTH  = "Americas South";
  public static final String EAME = "EAME";

  public static final String CHANGE_PERCENTAGE ="% Change";
  public static final String PERCENTAGE ="%";
  
  public static final int BATCH_EXECUTION_HOUR 	= 00;
  public static final int BATCH_EXECUTION_MIN 	= 05;
  public static final int THIRTY_MINS 			= 1800000;
  
  public static final String LAST_YEAR 		= " LY";
  public static final String THIS_YEAR 		= " TY";
  public static final String LABEL_TOTAL 	= "Total";
/*  public static final String LABEL_TOTAL_TY = "Total TY";
  public static final String LABEL_TOTAL_LY = "Total LY";*/
  public static final String SYNC_SCHEDULER = "Scheduler";
  public static final String SYNC_MANUAL 	= "Manual";
  public static final String SYSTEM			= "System";
  public static final String SELF			= "Self";
  public static final String ADMIN			= "Admin";

  public static final String INPROGRESS 	= "In-Progress";
  public static final int NO_OF_DIGIT_CODE 	= 12;
  public static final String FAILED 		= "Failed";
  public static final String COMPLETED 		= "Completed";
  
  //keys for reports
  public static final String ETE_AMERICAS_N = "reports_americas_n";
  public static final String ETE_AMERICAS_S = "reports_americas_s";
  public static final String ETE_EAME = "reports_eame";
  public static final String ETE_AP = "reports_ap";
  public static final String ETE_TOTAL = "reports_total";
  public static final String ETE_AMERICAS_NORTH = "reports_americas_north";
  public static final String ETE_AMERICAS_SOUTH = "reports_americas_south";
  
  
}
