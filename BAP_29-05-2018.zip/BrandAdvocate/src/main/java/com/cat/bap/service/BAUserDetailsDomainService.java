package com.cat.bap.service;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.SchedulerDetailsDto;
import com.cat.bap.dto.UserMasterRequest;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.Country;
import com.cat.bap.entity.Documents;
import com.cat.bap.entity.Preferences;
import com.cat.bap.entity.Region;
import com.cat.bap.entity.SchedulerDetail;
import com.cat.bap.entity.Templates;
import com.cat.bap.entity.UserPreferences;
import com.cat.bap.helper.UserMasterHelper;
import com.cat.bap.repository.AffilationDescRepository;
import com.cat.bap.repository.BAUserDetailsRepository;
import com.cat.bap.repository.BAUserDetailsRepositoryCustom;
import com.cat.bap.repository.CountryRepository;
import com.cat.bap.repository.DocumentsRepository;
import com.cat.bap.repository.SchedulerDetailRepository;
import com.cat.bap.repository.TemplatesRepository;
import com.cat.bap.repository.UserPreferencesRepository;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose This class is used as domain service for manage admin.
 */
@Service
public class BAUserDetailsDomainService {

	@Inject
	private BAUserDetailsRepository userMasterRepository;

	@Inject
	private BAUserDetailsRepositoryCustom detailsRepositoryCustom;

	@Inject
	private UserPreferencesRepository userPreferencesRepository;

	@Inject
	private DocumentsRepository documentsRepository;

	@Inject
	private TemplatesRepository templatesRepository;

	@Inject
	private CountryRepository countryRepository;

	@Inject
	private AffilationDescRepository affilationDescRepository;

	@Inject
	private SchedulerDetailRepository schedulerDetailRepository;

	@Transactional
	public Map<String, Object> getAllAdminDetails(UserMasterRequest manageAdminRequest) {

		return detailsRepositoryCustom.getAllAdminDetails(manageAdminRequest);
	}

	@Transactional
	public BAUserDetails findRecordBasedOnId(Long id) {
		BAUserDetails adminDetails = userMasterRepository.findOne(id);
		return adminDetails;
	}

	@Transactional
	public BAUserDetails findBADetails(BAUserDetailsDto baDto) {

		if (null != baDto) {
			String cupId = baDto.getCupId();
			String cwsUserId = baDto.getCwsUserId();
			String primaryEmail = baDto.getPrimaryEmail();

			if (null != cupId) {
				return userMasterRepository.findBAUserByCupId(cupId);
			} else {
				return userMasterRepository.findBAUserByEmailIdcwsId(primaryEmail, cwsUserId);
			}
		}
		return null;
	}

	@Transactional
	public BAUserDetails addOrUpdateAdminDetails(BAUserDetailsDto userMasterDto) throws ParseException {

		String affiliationName = "";
		BAUserDetails userMasterEntity = UserMasterHelper.convertDtoToEntity(userMasterDto);

		if (null == userMasterDto.getBrandAdvocateId()) {
			affiliationName = affilationDescRepository.getAffiliationNameByDesc(userMasterEntity.getAffiliationDescription());
			userMasterEntity.setMappedAffType(affiliationName);
		}

		if (null == userMasterEntity.getBrandAdvocateId()) {
			userMasterEntity.setRegistrationDate(new Date());
			userMasterEntity.setRegisteredBy(userMasterDto.getLoggedInUserName());
		} else {
			userMasterEntity.setModifiedDate(new Date());
			
			if(null!=userMasterDto.getIsAdmin() && userMasterDto.getIsAdmin()){
				userMasterEntity.setModifiedBy(UserMasterConstant.ADMIN);
			}else{
				userMasterEntity.setModifiedBy(UserMasterConstant.SELF);
			}
			
		}
		BAUserDetails userMasterResponse = userMasterRepository.save(userMasterEntity);
		if (null != userMasterDto.getPreferences()) {
			List<UserPreferences> userPreferencesAccessList = new ArrayList<>();
			for (Preferences preference : userMasterDto.getPreferences()) {
				UserPreferences userPreferencesAccess = new UserPreferences();
				BAUserDetails baUserDetailsTemp = new BAUserDetails();
				baUserDetailsTemp.setBrandAdvocateId(userMasterEntity.getBrandAdvocateId());
				Preferences preferencesTemp = new Preferences();
				preferencesTemp.setPreferenceId(preference.getPreferenceId());
				userPreferencesAccess.setUserMaster(baUserDetailsTemp);
				userPreferencesAccess.setPreference(preferencesTemp);
				userPreferencesAccessList.add(userPreferencesAccess);
			}

			List<Preferences> preferences = userPreferencesRepository
					.getPreferencesDetailsById(userMasterEntity.getBrandAdvocateId());
			if (!preferences.isEmpty()) {
				userPreferencesRepository.deleteRecordByBaId(userMasterEntity.getBrandAdvocateId());
			}
			userPreferencesRepository.save(userPreferencesAccessList);
		}

		return userMasterResponse;
	}

	@Transactional
	public BAUserDetails updateBASyncData(List<BAUserDetailsDto> notEqualBADataList, StringBuilder loggedInUserName,
			String executionMode) throws ParseException {

		BAUserDetails userMasterResponse = null;

		for (BAUserDetailsDto userMasterDto : notEqualBADataList) {

			Country countryDetails = countryRepository.getCountryByCountryCode(userMasterDto.getCountryCode());

			BAUserDetails userMasterEntity = UserMasterHelper.convertDtoToEntityForSync(userMasterDto, countryDetails);

			userMasterEntity.setModifiedDate(new java.sql.Timestamp(new Date().getTime()));

			if (executionMode.equals(UserMasterConstant.SYNC_SCHEDULER)) {
				userMasterEntity.setModifiedBy(UserMasterConstant.SYSTEM);
			} else if (executionMode.equals(UserMasterConstant.SYNC_MANUAL)) {
				userMasterEntity.setModifiedBy(loggedInUserName.toString());
			}

			userMasterResponse = userMasterRepository.save(userMasterEntity);
		}
		return userMasterResponse;
	}

	@Transactional
	public void addNotes(BAUserDetailsDto userMasterDTO) {
		String notes = userMasterDTO.getNotes();
		Long brandAdvocateId = userMasterDTO.getBrandAdvocateId();
		Date modifiedDate = new Date();
		String modifiedBy = userMasterDTO.getLoggedInUserName();
		userMasterRepository.addNotes(notes, brandAdvocateId, modifiedDate, UserMasterConstant.ADMIN);
	}

	@Transactional
	public void addCommentsQuestions(BAUserDetailsDto userMasterDTO) {
		String comments = userMasterDTO.getComments();
		Long brandAdvocateId = userMasterDTO.getBrandAdvocateId();
		Date modifiedDate = new Date();
		String modifiedBy = userMasterDTO.getLoggedInUserName();
		userMasterRepository.addCommentsQuestions(comments, brandAdvocateId, modifiedDate, UserMasterConstant.ADMIN);
	}

	@Transactional
	public void updateSecondaryMail(BAUserDetailsDto userMasterDTO) {
		String secondaryEmail = userMasterDTO.getSecondaryEmail();
		Long brandAdvocateId = userMasterDTO.getBrandAdvocateId();
		Date modifiedDate = new Date();
		String modifiedBy = userMasterDTO.getLoggedInUserName();
		userMasterRepository.updateSecondaryEmail(secondaryEmail, brandAdvocateId, modifiedDate, UserMasterConstant.ADMIN);
	}

	/**
	 * This method is used to get user email based on email and flag.
	 * 
	 * @param email
	 * @param isDeleted
	 * @return
	 * @throws SQLException 
	 */
	/*
	 * @Transactional public List<String> findUserEmail(String email, Boolean
	 * isDeleted) { return userMasterRepository.findUserEmail(email); }
	 */

	/*
	 * @Transactional public void deleteRecordBasedOnId(Long id){ Boolean
	 * isDeleted = Boolean.TRUE;
	 * //userMasterRepository.deleteRecordBasedOnId(id); }
	 */

	@Transactional
	public boolean changeActiveStatus(Long brandAdvocateId, Boolean activeStatus) throws SQLException {
		Date inactiveDate = new Date();
		Date modifiedDate = new Date();
		String yesNo = activeStatus==true ? "Y" : "N";
		
		return detailsRepositoryCustom.updateDataToInActiveState(brandAdvocateId, activeStatus,inactiveDate, modifiedDate);
	}
/*	
	@Transactional
	public void changeActiveStatus(Long brandAdvocateId, Boolean activeStatus, String loggedInUserName) {
		Date inactiveDate = new Date();
		Date modifiedDate = new Date();
		String modifiedBy = loggedInUserName;
		if (activeStatus) {
			userMasterRepository.changeActiveStatusWithModifiedDate(brandAdvocateId, activeStatus, modifiedDate,
					modifiedBy);
		} else {
			userMasterRepository.changeActiveStatusWithInactiveAndModifiedDate(brandAdvocateId, activeStatus,inactiveDate, modifiedDate, modifiedBy);
		}
		
	}
*/
	/* *//**
			 * This method is used for refresh the cache.
			 *//*
			 * public void refresh() { entityManager.flush();
			 * entityManager.clear(); }
			 */

	@Transactional
	public void deleteUserInfo(Long brandAdvocateId) {
		userPreferencesRepository.deleteRecordByBaId(brandAdvocateId);
		userMasterRepository.delete(brandAdvocateId);
	}

	@Transactional
	public List<Documents> saveDocument(List<Documents> docList) {
		return documentsRepository.save(docList);

	}

	@Transactional
	public void saveTinyMceTemplate(Templates templates) {
		templatesRepository.save(templates);
	}

	@Transactional
	public List<Templates> getAllTemplates() {
		List<Templates> templates = new ArrayList<>();
		templates = templatesRepository.findAll();
		return templates;
	}

	public Templates getTemplateDetailsByTemplateId(Long templateId) {
		Templates templates = templatesRepository.findOne(templateId);
		return templates;
	}

	@Transactional
	public List<String> getDbUserNameByPreferenceForFindBA() {
		return detailsRepositoryCustom
				.getDbUserNameByPreferenceForFindBA(UserMasterConstant.BRAND_EVENT_COMMUNICATIONS);
	}

	@Transactional
	public List<String> getDbOrganizationByPreferenceForFindBA() {
		return detailsRepositoryCustom
				.getDbOrganizationByPreferenceForFindBA(UserMasterConstant.BRAND_EVENT_COMMUNICATIONS);
	}

	@Transactional
	public List<Region> getDbRegionByPreferenceForFindBA() {
		return detailsRepositoryCustom.getDbRegionByPreferenceForFindBA(UserMasterConstant.BRAND_EVENT_COMMUNICATIONS);
	}

	@Transactional
	public List<Country> getDbCountryByPreferenceForFindBA() {
		return detailsRepositoryCustom.getDbCountryByPreferenceForFindBA(UserMasterConstant.BRAND_EVENT_COMMUNICATIONS);
	}

	/**
	 * @param long1 
	 * @param jobGenerateCode
	 * @param maintainSyncSchedulerInfo 
	 * @param jobStatusInProgressLog 
	 * @param jobStatusFailed
	 * @param executionTime
	 * @param executedBy
	 * @param message
	 */
	@Transactional
	public SchedulerDetail maintainSyncSchedulerInfo(Long jobId, String jobGenerateCode, 
				String jobStatus,					String jobExecutedBy,
				Timestamp jobExecutionStartDate,	Timestamp jobExecutionEndDate, 
				String jobStatusLog) {

		SchedulerDetail schedulerDetail = new SchedulerDetail();
		
		if(null!=jobId){

			schedulerDetail = new SchedulerDetail();
			schedulerDetail.setJobId(jobId);
			schedulerDetail.setJobExecutedBy(jobExecutedBy);
			schedulerDetail.setJobExecutionStartDate(jobExecutionStartDate);
			schedulerDetail.setJobExecutionEndDate(jobExecutionEndDate);
			schedulerDetail.setJobGenerateCode(jobGenerateCode);
			schedulerDetail.setJobStatus(jobStatus);
			schedulerDetail.setJobStatusLog(jobStatusLog);
			
		}else{
			schedulerDetail = new SchedulerDetail();
			schedulerDetail.setJobExecutedBy(jobExecutedBy);
			schedulerDetail.setJobExecutionStartDate(jobExecutionStartDate);
			schedulerDetail.setJobExecutionEndDate(jobExecutionEndDate);
			schedulerDetail.setJobGenerateCode(jobGenerateCode);
			schedulerDetail.setJobStatus(jobStatus);
			schedulerDetail.setJobStatusLog(jobStatusLog);
		}
		
		return schedulerDetailRepository.save(schedulerDetail);
	}

}
