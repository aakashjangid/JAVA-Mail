package com.cat.bap.dto;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 23-Feb-2018
 * @purpose
 */
public class BARegistrationViaDto {

	private Long regId;
	private String registrationStatusName;

	/**
	 * @return the regId
	 */
	public Long getRegId() {
		return regId;
	}

	/**
	 * @param regId
	 *            the regId to set
	 */
	public void setRegId(Long regId) {
		this.regId = regId;
	}

	/**
	 * @return the registrationStatusName
	 */
	public String getRegistrationStatusName() {
		return registrationStatusName;
	}

	/**
	 * @param registrationStatusName
	 *            the registrationStatusName to set
	 */
	public void setRegistrationStatusName(String registrationStatusName) {
		this.registrationStatusName = registrationStatusName;
	}

}
