package com.cat.bap.util;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.AffiliationDetailsDto;
import com.cat.bap.dto.ReportsRequest;


/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
public class ExportToExcelUtilityForReports {

  private XSSFWorkbook workbook;
  private XSSFCellStyle dataStyle;
  
  private static final String THIRDREPORT = "thirdReport";
  
  private static final String CHANGE = "% Change";

  @Transactional(readOnly=true)
  public XSSFWorkbook generateExcel(List<AffiliationDetailsDto> list1,List<AffiliationDetailsDto> list2, ReportsRequest reportsRequest)
      throws IOException {

    workbook = null;

    Properties prop = new Properties();
    String propFileName = "properties/locale_" + reportsRequest.getLang() + ".properties";

    InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

    if (inputStream != null) {
      Reader reader = new InputStreamReader(inputStream, "UTF-8");
      prop.load(reader);
    } else {
      throw new FileNotFoundException(
          "property file '" + propFileName + "' not found in the classpath");
    }
    workbook = new XSSFWorkbook();
    XSSFSheet worksheet = workbook.createSheet(UserMasterConstant.ADMIN_EXCEL_SHEET_NAME);
    XSSFRow row = worksheet.createRow((short) 2);
    XSSFCellStyle style = ExcelUtil.getStyle(workbook);
    dataStyle = ExcelUtil.getDataStyle(workbook);
    XSSFCell cell;
    AffiliationDetailsDto affiliationDetailsDto;
    XSSFCell tempCell;

    List<String> headerNames = new ArrayList<>();
      headerNames.add("");
      headerNames.add(prop.getProperty(UserMasterConstant.ETE_AMERICAS_NORTH));
      headerNames.add(prop.getProperty(UserMasterConstant.ETE_AMERICAS_SOUTH));
      headerNames.add(prop.getProperty(UserMasterConstant.ETE_EAME));
      headerNames.add(prop.getProperty(UserMasterConstant.ETE_AP));
      headerNames.add(prop.getProperty(UserMasterConstant.ETE_TOTAL));
      
      
      if(!list1.isEmpty()){
    	     XSSFRow row1 = worksheet.createRow((short) 0);
    	      cell = row1.createCell(0);
    	      if(reportsRequest.getReportName().equalsIgnoreCase("firstReport")){
    	    	  cell.setCellValue("Active Brand Advocates on "+reportsRequest.getMonthForFirstReport()+" 1, "+reportsRequest.getYearForFirstReport()+"");
    	      }else if(reportsRequest.getReportName().equalsIgnoreCase("secondReport")){
    	    	  cell.setCellValue("Active Brand Advocates from "+reportsRequest.getMonthFromForSecondReport()+" 1, "+reportsRequest.getYearFromForSecondReport()+" to "+reportsRequest.getMonthToForSecondReport()+" 1, "+reportsRequest.getYearToForSecondReport()+"");
    	      }else if(reportsRequest.getReportName().equalsIgnoreCase(THIRDREPORT) && reportsRequest.isFlagForHeader1ThirdReport()){
    	    	  cell.setCellValue("Active Brand Advocates "+reportsRequest.getSelectedXToDateForThirdReport()+" as of "+reportsRequest.getCurrentDateForThirdReport()+"");
    	      }else if(reportsRequest.getReportName().equalsIgnoreCase(THIRDREPORT) && reportsRequest.isFlagForHeader2ThirdReport()){
    	    	  cell.setCellValue("Active Brand Advocates "+reportsRequest.getComapreNameForGridThird()+" Vs. "+reportsRequest.getAgainstNameForGridThird()+"");
    	      }
    	      cell.setCellStyle(style);
    	      worksheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 5));
    	      
    	      setBordersToMergedRegion(CellStyle.BORDER_THIN, new CellRangeAddress(0, 0, 0, 5), worksheet, workbook);

    	    for (int headerIndex = 0; headerIndex < headerNames.size(); headerIndex++) {
    	      cell = row.createCell(headerIndex);
    	      cell.setCellValue(headerNames.get(headerIndex));
    	      cell.setCellStyle(style);
    	    }

    	    for (int rowIndex = 0; rowIndex < list1.size(); rowIndex++) {
    	      row = worksheet.createRow((short) rowIndex+2 + 1);
    	      affiliationDetailsDto = list1.get(rowIndex);
    	      int colIndex = 0;
    	      
    	         String affTypeName = affiliationDetailsDto.getAffiliationTypeName();
    	         tempCell = createCell(row, colIndex);
    	         if (!BrandAdvocateUtility.isEmptyString(affTypeName)) {
    	             tempCell.setCellValue(affTypeName);
    	         }
    	          
    	        colIndex++;

    	        Long anCnt = affiliationDetailsDto.getAnCnt();
    	        tempCell = createCell(row, colIndex);
    	        if (null!=anCnt) {
    	            if(affTypeName.equalsIgnoreCase(CHANGE)){
    	            	setCellColorForNegativeValue(anCnt,tempCell);		//set cell color to RED for negative values
    	            	tempCell.setCellValue(anCnt+"%");
    	            }else{
    	            	tempCell.setCellValue(anCnt);
    	            }
    	         }
    	         
    	        colIndex++;
    	        
    	        Long asCnt = affiliationDetailsDto.getAsCnt();
    	        tempCell = createCell(row, colIndex);
    	        if (null!=asCnt) {
    	            if(affTypeName.equalsIgnoreCase(CHANGE)){
    	            	setCellColorForNegativeValue(asCnt,tempCell);		//set cell color to RED for negative values
    	            	tempCell.setCellValue(asCnt+"%");
    	            }else{
    	            	tempCell.setCellValue(asCnt);
    	            }
    	         }
    	         
    	        colIndex++;
    	        
    	        Long eameCnt = affiliationDetailsDto.getEameCnt();
    	        tempCell = createCell(row, colIndex);
    	        if (null!=eameCnt) {
    	            if(affTypeName.equalsIgnoreCase(CHANGE)){
    	            	setCellColorForNegativeValue(eameCnt,tempCell);		//set cell color to RED for negative values
    	            	tempCell.setCellValue(eameCnt+"%");
    	            }else{
    	            	tempCell.setCellValue(eameCnt);
    	            }
    	         }
    	         
    	        colIndex++;
    	        
    	        Long apCnt = affiliationDetailsDto.getApCnt();
    	        tempCell = createCell(row, colIndex);
    	        if (null!=apCnt) {
    	        	if(affTypeName.equalsIgnoreCase(CHANGE)){
    	        		setCellColorForNegativeValue(apCnt,tempCell);		//set cell color to RED for negative values
     	            	tempCell.setCellValue(apCnt+"%");
     	            }else{
     	            	tempCell.setCellValue(apCnt);
     	            }
    	         }
    	         
    	        colIndex++;
    	        
    	        Long totalRegionCnt = affiliationDetailsDto.getTotalRegionRecordCnt();
    	        tempCell = createCell(row, colIndex);
    	        if (null!=totalRegionCnt) {
    	        	if(affTypeName.equalsIgnoreCase(CHANGE)){
    	        		setCellColorForNegativeValue(totalRegionCnt,tempCell);		//set cell color to RED for negative values
     	            	tempCell.setCellValue(totalRegionCnt+"%");
     	            }else{
     	            	tempCell.setCellValue(totalRegionCnt);
     	            }
    	            
    	         }
    	         
    	        
    	    }
      }
      
      
      
      if(!list2.isEmpty()){
    	  XSSFRow row1 = worksheet.createRow((short) list1.size()+8);
	      cell = row1.createCell(0);
	      if(reportsRequest.getReportName().equalsIgnoreCase("firstReport")){
	    	  cell.setCellValue("Inactive Brand Advocates on "+reportsRequest.getMonthForFirstReport()+" 1, "+reportsRequest.getYearForFirstReport()+"");
	      }else if(reportsRequest.getReportName().equalsIgnoreCase("secondReport")){
	    	  cell.setCellValue("Inactive Brand Advocates from "+reportsRequest.getMonthFromForSecondReport()+" 1, "+reportsRequest.getYearFromForSecondReport()+" to "+reportsRequest.getMonthToForSecondReport()+" 1, "+reportsRequest.getYearToForSecondReport()+"");
	      }else if(reportsRequest.getReportName().equalsIgnoreCase(THIRDREPORT) && reportsRequest.isFlagForHeader1ThirdReport()){
	    	  cell.setCellValue("Inactive Brand Advocates "+reportsRequest.getSelectedXToDateForThirdReport()+" as of "+reportsRequest.getCurrentDateForThirdReport()+"");
	      }else if(reportsRequest.getReportName().equalsIgnoreCase(THIRDREPORT) && reportsRequest.isFlagForHeader2ThirdReport()){
	    	  cell.setCellValue("Inactive Brand Advocates "+reportsRequest.getComapreNameForGridThird()+" Vs. "+reportsRequest.getAgainstNameForGridThird()+"");
	      }
	      cell.setCellStyle(style);
	      worksheet.addMergedRegion(new CellRangeAddress(list1.size()+8, list1.size()+8, 0, 5));
	      
	      setBordersToMergedRegion(CellStyle.BORDER_THIN, new CellRangeAddress(list1.size()+8, list1.size()+8, 0, 5), worksheet, workbook);

	    XSSFRow row2 = worksheet.createRow((short) list1.size()+10);
	    for (int headerIndex = 0; headerIndex < headerNames.size(); headerIndex++) {
	      cell = row2.createCell(headerIndex);
	      if (headerNames.get(headerIndex).length() > 15) {
	        worksheet.setColumnWidth(headerIndex, 20 * 256);
	      } else {
	        worksheet.setColumnWidth(headerIndex, 15 * 256);
	      }
	      cell.setCellValue(headerNames.get(headerIndex));
	      cell.setCellStyle(style);
	    }

	    for (int rowIndex = 0; rowIndex < list2.size(); rowIndex++) {
	      row = worksheet.createRow((short) list1.size()+10+rowIndex + 1);
	      affiliationDetailsDto = list2.get(rowIndex);
	      int colIndex = 0;
	      
	         String affTypeName = affiliationDetailsDto.getAffiliationTypeName();
	         tempCell = createCell(row, colIndex);
	         if (!BrandAdvocateUtility.isEmptyString(affTypeName)) {
	             tempCell.setCellValue(affTypeName);
	         }
	          
	        colIndex++;

	        Long anCnt = affiliationDetailsDto.getAnCnt();
	        tempCell = createCell(row, colIndex);
	        if (null!=anCnt) {
	        	if(affTypeName.equalsIgnoreCase(CHANGE)){
	        		setCellColorForNegativeValue(anCnt,tempCell);		//set cell color to RED for negative values
 	            	tempCell.setCellValue(anCnt+"%");
 	            }else{
 	            	tempCell.setCellValue(anCnt);
 	            }
	         }
	         
	        colIndex++;
	        
	        Long asCnt = affiliationDetailsDto.getAsCnt();
	        tempCell = createCell(row, colIndex);
	        if (null!=asCnt) {
	        	if(affTypeName.equalsIgnoreCase(CHANGE)){
	        		setCellColorForNegativeValue(asCnt,tempCell);		//set cell color to RED for negative values
 	            	tempCell.setCellValue(asCnt+"%");
 	            }else{
 	            	tempCell.setCellValue(asCnt);
 	            }
	         }
	         
	        colIndex++;
	        
	        Long eameCnt = affiliationDetailsDto.getEameCnt();
	        tempCell = createCell(row, colIndex);
	        if (null!=eameCnt) {
	        	if(affTypeName.equalsIgnoreCase(CHANGE)){
	        		setCellColorForNegativeValue(eameCnt,tempCell);		//set cell color to RED for negative values
 	            	tempCell.setCellValue(eameCnt+"%");
 	            }else{
 	            	 tempCell.setCellValue(eameCnt);
 	            }
	         }
	         
	        colIndex++;
	        
	        Long apCnt = affiliationDetailsDto.getApCnt();
	        tempCell = createCell(row, colIndex);
	        if (null!=apCnt) {
	        	if(affTypeName.equalsIgnoreCase(CHANGE)){
	        		setCellColorForNegativeValue(apCnt,tempCell);		//set cell color to RED for negative values
 	            	tempCell.setCellValue(apCnt+"%");
 	            }else{
 	            	tempCell.setCellValue(apCnt);
 	            }
	         }
	         
	        colIndex++;
	        
	        Long totalRegionCnt = affiliationDetailsDto.getTotalRegionRecordCnt();
	        tempCell = createCell(row, colIndex);
	        if (null!=totalRegionCnt) {
	        	if(affTypeName.equalsIgnoreCase(CHANGE)){
	        		setCellColorForNegativeValue(totalRegionCnt,tempCell);		//set cell color to RED for negative values
 	            	tempCell.setCellValue(totalRegionCnt+"%");
 	            }else{
 	            	tempCell.setCellValue(totalRegionCnt);
 	            }
	         }
	    }
      }
      
      for (int i=0; i<10; i++){
    	   worksheet.autoSizeColumn(i); 			// used to auto-resize columns
    	}
      

    return workbook;
  }

  private void setBordersToMergedRegion(short borderThin, CellRangeAddress cellRangeAddress, XSSFSheet worksheet2,
		XSSFWorkbook workbook2) {
	  // Sets the borders to the merged cell
      RegionUtil.setBorderTop(borderThin, cellRangeAddress, worksheet2, workbook2);
      RegionUtil.setBorderLeft(borderThin, cellRangeAddress, worksheet2, workbook2);
      RegionUtil.setBorderRight(borderThin, cellRangeAddress, worksheet2, workbook2);
      RegionUtil.setBorderBottom(borderThin, cellRangeAddress, worksheet2, workbook2);
	
}

private void setCellColorForNegativeValue(Long anCnt, XSSFCell tempCell) {
	  if(Math.signum(anCnt) == -1.0){
  		XSSFCellStyle cellStyle = workbook.createCellStyle();
      	cellStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
      	cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
      	cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
      	cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
      	cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
      	tempCell.setCellStyle(cellStyle);
      	
      	XSSFFont font = workbook.createFont();
      	font.setColor(IndexedColors.RED.getIndex());
      	cellStyle.setFont(font);
  	}
	
}

/**
   * This method will create empty cell
   * 
   * @param row
   * @param colIndex
   * @return {@link XSSFCell}
   */
  public XSSFCell createCell(XSSFRow row, int colIndex) {
    XSSFCell cell = row.createCell(colIndex);
    cell.setCellStyle(dataStyle);
    return cell;
  }

}
