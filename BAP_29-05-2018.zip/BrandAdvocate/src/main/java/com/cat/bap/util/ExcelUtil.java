package com.cat.bap.util;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.cat.bap.common.UserMasterConstant;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 16-Feb-2018
 * @purpose
 */
public class ExcelUtil {
	
	private ExcelUtil(){
		
	}

  /**
   * This method is used to get the data style for excel
   * 
   * @param workbook
   * @return XSSFCellStyle
   */
  public static XSSFCellStyle getDataStyle(XSSFWorkbook workbook) {
    XSSFCellStyle dataStyle = workbook.createCellStyle();
    dataStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
    dataStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
    dataStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
    dataStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
    dataStyle.setAlignment(XSSFCellStyle.ALIGN_RIGHT);
    return dataStyle;
  }

  /**
   * This is the class used for the get date cell style
   * 
   * @param workbook
   * @return XSSFCellStyle
   */
  public static XSSFCellStyle getDateCellStyle(XSSFWorkbook workbook) {
    XSSFCellStyle dateCellStyle = workbook.createCellStyle();
    XSSFCreationHelper createHelper = workbook.getCreationHelper();
    dateCellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
    dateCellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
    dateCellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
    dateCellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
    dateCellStyle
        .setDataFormat(createHelper.createDataFormat().getFormat(UserMasterConstant.DATE_FORMAT));
    return dateCellStyle;
  }

  /**
   * This method is used to get Style
   * 
   * @param workbook
   * 
   * @return XSSFCellStyle
   */
  public static XSSFCellStyle getStyle(XSSFWorkbook workbook) {
    XSSFCellStyle style = workbook.createCellStyle();
    XSSFFont font = workbook.createFont();
    font.setFontName(XSSFFont.DEFAULT_FONT_NAME);
    font.setFontHeightInPoints((short) 11);
    font.setBoldweight(Font.BOLDWEIGHT_BOLD);
    style.setFont(font);
    style.setWrapText(true);
    style.setBorderBottom(XSSFCellStyle.BORDER_THIN);
    style.setBorderTop(XSSFCellStyle.BORDER_THIN);
    style.setBorderRight(XSSFCellStyle.BORDER_THIN);
    style.setBorderLeft(XSSFCellStyle.BORDER_THIN);
    style.setAlignment(CellStyle.ALIGN_LEFT);
    style.setVerticalAlignment(CellStyle.VERTICAL_TOP);
    style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
    style.setFillPattern(CellStyle.SOLID_FOREGROUND);
    return style;
  }
}
