package com.cat.bap.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "templates_tbl")
public class Templates {

	@Id
	@Column(name = "template_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long templateId;

	@Column(name = "template_name")
	private String templateName;

	@Column(name = "template_path")
	private String templatePath;
	
	@Column(name = "template_subject")
	private String templateSubject;
	
	@OneToMany(cascade = CascadeType.ALL,orphanRemoval = true)
	private List<Documents> documents = new ArrayList<>();
	

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplatePath() {
		return templatePath;
	}

	public void setTemplatePath(String templatePath) {
		this.templatePath = templatePath;
	}

	public List<Documents> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Documents> documents) {
		this.documents = documents;
	}
	
	public String getTemplateSubject() {
		return templateSubject;
	}

	public void setTemplateSubject(String templateSubject) {
		this.templateSubject = templateSubject;
	}

}
