package com.cat.bap.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author rathor
 */

@Entity
@Table(name = "scheduler_detail_tbl")
public class SchedulerDetail {

	@Id
	@Column(name = "job_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long jobId;

	@Column(name = "job_gen_id")
	private String jobGenerateCode;

	@Column(name = "job_status")
	private String jobStatus;
	
	@Column(name = "job_status_log")
	private String jobStatusLog;
	
	@Column(name = "job_executed_by")
	private String jobExecutedBy;
	
	@Column(name = "job_execution_start_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date jobExecutionStartDate;

	@Column(name = "job_execution_end_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date jobExecutionEndDate;
	
	/**
	 * @return the jobId
	 */
	public Long getJobId() {
		return jobId;
	}

	/**
	 * @param jobId the jobId to set
	 */
	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	/**
	 * @return the jobGenerateCode
	 */
	public String getJobGenerateCode() {
		return jobGenerateCode;
	}

	/**
	 * @param jobGenerateCode the jobGenerateCode to set
	 */
	public void setJobGenerateCode(String jobGenerateCode) {
		this.jobGenerateCode = jobGenerateCode;
	}

	/**
	 * @return the jobStatus
	 */
	public String getJobStatus() {
		return jobStatus;
	}

	/**
	 * @param jobStatus the jobStatus to set
	 */
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	/**
	 * @return the jobStatusLog
	 */
	public String getJobStatusLog() {
		return jobStatusLog;
	}

	/**
	 * @param jobStatusLog the jobStatusLog to set
	 */
	public void setJobStatusLog(String jobStatusLog) {
		this.jobStatusLog = jobStatusLog;
	}
	
	/**
	 * @return the jobExecutedBy
	 */
	public String getJobExecutedBy() {
		return jobExecutedBy;
	}

	/**
	 * @param jobExecutedBy the jobExecutedBy to set
	 */
	public void setJobExecutedBy(String jobExecutedBy) {
		this.jobExecutedBy = jobExecutedBy;
	}

	/**
	 * @return the jobExecutionStartDate
	 */
	public Date getJobExecutionStartDate() {
		return jobExecutionStartDate;
	}

	/**
	 * @param jobExecutionStartDate the jobExecutionStartDate to set
	 */
	public void setJobExecutionStartDate(Date jobExecutionStartDate) {
		this.jobExecutionStartDate = jobExecutionStartDate;
	}

	/**
	 * @return the jobExecutionEndDate
	 */
	public Date getJobExecutionEndDate() {
		return jobExecutionEndDate;
	}

	/**
	 * @param jobExecutionEndDate the jobExecutionEndDate to set
	 */
	public void setJobExecutionEndDate(Date jobExecutionEndDate) {
		this.jobExecutionEndDate = jobExecutionEndDate;
	}


}
