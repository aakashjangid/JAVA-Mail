/**
 * 
 */
package com.cat.bap.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.dto.AffiliationDetailsDto;
import com.cat.bap.service.ReportsDataService;
import com.cat.bap.util.BrandAdvocateUtility;
import com.cat.bap.util.ReportsDateUtility;

import cat.cis.tuf.common.persistence.PersistenceException;

/**
 * @author rathor
 *
 */
@RestController
@RequestMapping(value = "/reports/details/v1")
public class ReportsDetailsController {

	@Autowired
	ReportsDataService reportsDataService;
	
	private static final String THISYEAR = "This Year";
	private static final String LASTYEAR = "Last Year";
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsDetailsController.class);

	/**
	 * @param fromDate
	 * @param toDate
	 * @param isActive
	 * @return Response containing active/inactive data report
	 * @throws PersistenceException
	 * @throws SQLException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/getactiveinactivedatareport", method = RequestMethod.GET)
	@ResponseBody
	public ResponseWrapper<Map<String, List<AffiliationDetailsDto>>> getActiveInActiveDataReport(
			@RequestParam("fromDate") Long fromDate, @RequestParam("toDate") Long toDate,
			@RequestParam("isActive") Boolean isActive) throws SQLException, ParseException {

		LOGGER.debug("getActiveInActiveDataReport() Begin.");
		
		String startDate = BrandAdvocateUtility.convertDateInYYYMMDD(new Date(fromDate));
		String endDate = BrandAdvocateUtility.convertDateInYYYMMDD(new Date(toDate));

		/**Actual method for Active/Inactive report  **/
		List<AffiliationDetailsDto> reportsActiveInActiveDataList = reportsDataService.getReportActiveInActiveCount(isActive, startDate, endDate);
		
		Map<String, List<AffiliationDetailsDto>> reportsDataMap = new HashMap<>();
		reportsDataMap.put("reportsActiveInActiveDataList", reportsActiveInActiveDataList);

		return new ResponseWrapper<>(null, HttpStatus.OK, "", reportsDataMap);
	}
	
	/**
	 * @param fromDate
	 * @param toDate
	 * @param isActive
	 * @return Response containing gain(all)/lost(inactive) records
	 * @throws PersistenceException
	 * @throws SQLException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/getgainedlostdatareport", method = RequestMethod.GET)
	@ResponseBody
	public ResponseWrapper<Map<String, List<AffiliationDetailsDto>>> getGainedLostDataReport(
			@RequestParam("fromDate") Long fromDate, @RequestParam("toDate") Long toDate,
			@RequestParam("isActive") Boolean isActive) throws SQLException, ParseException {
		
		String startDate 	= BrandAdvocateUtility.convertDateInYYYMMDD(new Date(fromDate));
		String endDate 		= BrandAdvocateUtility.convertDateInYYYMMDD(new Date(toDate));
		
		if(isActive) {
			/** FOR TESTING PURPOSE, CHECKING RESPONSE FOR GAIN COUNT **/
			List<AffiliationDetailsDto> reportsGainedDataList = reportsDataService.getReportGainedUserCount(startDate, endDate);
		
			Map<String, List<AffiliationDetailsDto>> reportsDataMap = new HashMap<>();
			reportsDataMap.put("reportsGainedLostDataList", reportsGainedDataList);

			return new ResponseWrapper<>(null, HttpStatus.OK, "", reportsDataMap);
		}else {
			/** FOR TESTING PURPOSE, CHECKING RESPONSE FOR LOST COUNT **/
			List<AffiliationDetailsDto> reportsLostDataList = reportsDataService.getReportActiveInActiveCount(false, startDate, endDate);
			
			Map<String, List<AffiliationDetailsDto>> reportsDataMap = new HashMap<>();
			reportsDataMap.put("reportsGainedLostDataList", reportsLostDataList);

			return new ResponseWrapper<>(null, HttpStatus.OK, "", reportsDataMap);
			
		}
	}
	
	/**
	 * @param fromDate
	 * @param toDate
	 * @param isActive
	 * @return
	 * @throws PersistenceException
	 * @throws SQLException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/getyearqtddatareport", method = RequestMethod.GET)
	@ResponseBody
	public ResponseWrapper<Map<String, List<AffiliationDetailsDto>>> getYearQTDDataReport(@RequestParam("xtodate") String xToDate,@RequestParam("qoqfrom") String qoQFrom,
			@RequestParam("qoqto") String qoQTo,@RequestParam("isActive") Boolean isActive,@RequestParam("dropdownvalue1") String dropDownValue1,@RequestParam("dropdownvalue2") String dropDownValue2) throws PersistenceException, SQLException, ParseException {
		
		LOGGER.debug("getthisyearlastyeardatareport() Begin."); 
		
		Date firstDate = null;
		Date secondDate = null;
		Date thirdDate = null;
		Date fourthDate = null;
		if(!BrandAdvocateUtility.isEmptyString(xToDate)){
			if(xToDate.equalsIgnoreCase("Year to Date")){
				Date currentYearStartDate = ReportsDateUtility.getCurrentYearStartDate();
				Date currentDateOfCurrentYear = ReportsDateUtility.getCurrentDateOfCurrentYear();
				Date previousYearStartDate = ReportsDateUtility.getPreviousYearStartDate();
				Date currentDateOfPreviousYear = ReportsDateUtility.getCurrentDateOfPreviousYear();
				
				firstDate = currentYearStartDate;
				secondDate = currentDateOfCurrentYear;
				thirdDate = previousYearStartDate;
				fourthDate = currentDateOfPreviousYear;
				
			}else if(xToDate.equalsIgnoreCase("Quarter to Date")){
				Date currentYearCurrentQuarterStartDate = ReportsDateUtility.getCurrentYearCurrentQuarterStartDate();
				Date currentDateOfCurrentYear = ReportsDateUtility.getCurrentDateOfCurrentYear();
				Date previousYearCurrentQuarterStartDate = ReportsDateUtility.getPreviousYearCurrentQuarterStartDate();
				Date currentDateOfPreviousYear = ReportsDateUtility.getCurrentDateOfPreviousYear();
				
				firstDate = currentYearCurrentQuarterStartDate;
				secondDate = currentDateOfCurrentYear;
				thirdDate = previousYearCurrentQuarterStartDate;
				fourthDate = currentDateOfPreviousYear;
				
			}
		}else{
			
		if(qoQFrom.contains(THISYEAR) && qoQTo.contains(LASTYEAR)){
			Date selectedQuarterStartDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterStartDateOfCurrentYear(qoQFrom);
			Date selectedQuarterEndDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterEndDateOfCurrentYear(qoQFrom);
			thirdDate = selectedQuarterStartDateOfCurrentYear;
			fourthDate = selectedQuarterEndDateOfCurrentYear;
			
			Date selectedQuarterStartDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterStartDateOfPreviousYear(qoQTo);
			Date selectedQuarterEndDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterEndDateOfPreviousYear(qoQTo);
			firstDate = selectedQuarterStartDateOfPreviousYear;
			secondDate = selectedQuarterEndDateOfPreviousYear;
		}else if(qoQFrom.contains(LASTYEAR) && qoQTo.contains(THISYEAR)){
			Date selectedQuarterStartDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterStartDateOfPreviousYear(qoQFrom);
			Date selectedQuarterEndDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterEndDateOfPreviousYear(qoQFrom);
			firstDate = selectedQuarterStartDateOfPreviousYear;
			secondDate = selectedQuarterEndDateOfPreviousYear;
			
			Date selectedQuarterStartDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterStartDateOfCurrentYear(qoQTo);
		    Date selectedQuarterEndDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterEndDateOfCurrentYear(qoQTo);
		    thirdDate = selectedQuarterStartDateOfCurrentYear;
		    fourthDate = selectedQuarterEndDateOfCurrentYear;
		}else if(qoQFrom.contains(THISYEAR) && qoQTo.contains(THISYEAR)){
			String qoQFromQuarterNumberStr = qoQFrom.replaceAll("\\D+","");
			Long qoQFromQuarterNumber = Long.parseLong(qoQFromQuarterNumberStr);
			
			String qoQToQuarterNumberStr = qoQTo.replaceAll("\\D+","");
			Long qoQToQuarterNumber = Long.parseLong(qoQToQuarterNumberStr);
			
			if(qoQFromQuarterNumber>qoQToQuarterNumber){
				Date selectedQuarterStartDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterStartDateOfCurrentYear(qoQFrom);
				Date selectedQuarterEndDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterEndDateOfCurrentYear(qoQFrom);
				thirdDate = selectedQuarterStartDateOfCurrentYear;
				fourthDate = selectedQuarterEndDateOfCurrentYear;
				
				Date selectedQuarterStartDateOfCurrentYear2 = ReportsDateUtility.getSelectedQuarterStartDateOfCurrentYear(qoQTo);
			    Date selectedQuarterEndDateOfCurrentYear2 = ReportsDateUtility.getSelectedQuarterEndDateOfCurrentYear(qoQTo);
			    firstDate = selectedQuarterStartDateOfCurrentYear2;
			    secondDate = selectedQuarterEndDateOfCurrentYear2;
			}else{
				Date selectedQuarterStartDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterStartDateOfCurrentYear(qoQFrom);
				Date selectedQuarterEndDateOfCurrentYear = ReportsDateUtility.getSelectedQuarterEndDateOfCurrentYear(qoQFrom);
				firstDate = selectedQuarterStartDateOfCurrentYear;
				secondDate = selectedQuarterEndDateOfCurrentYear;
				
				Date selectedQuarterStartDateOfCurrentYear2 = ReportsDateUtility.getSelectedQuarterStartDateOfCurrentYear(qoQTo);
			    Date selectedQuarterEndDateOfCurrentYear2 = ReportsDateUtility.getSelectedQuarterEndDateOfCurrentYear(qoQTo);
			    thirdDate = selectedQuarterStartDateOfCurrentYear2;
			    fourthDate = selectedQuarterEndDateOfCurrentYear2;
			}
		}else if(qoQFrom.contains(LASTYEAR) && qoQTo.contains(LASTYEAR)){
			String qoQFromQuarterNumberStr = qoQFrom.replaceAll("\\D+","");
			Long qoQFromQuarterNumber = Long.parseLong(qoQFromQuarterNumberStr);
			
			String qoQToQuarterNumberStr = qoQTo.replaceAll("\\D+","");
			Long qoQToQuarterNumber = Long.parseLong(qoQToQuarterNumberStr);
			
			if(qoQFromQuarterNumber>qoQToQuarterNumber){
				Date selectedQuarterStartDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterStartDateOfPreviousYear(qoQFrom);
				Date selectedQuarterEndDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterEndDateOfPreviousYear(qoQFrom);
				thirdDate = selectedQuarterStartDateOfPreviousYear;
				fourthDate = selectedQuarterEndDateOfPreviousYear;
				
				Date selectedQuarterStartDateOfPreviousYear2 = ReportsDateUtility.getSelectedQuarterStartDateOfPreviousYear(qoQTo);
				Date selectedQuarterEndDateOfPreviousYear2 = ReportsDateUtility.getSelectedQuarterEndDateOfPreviousYear(qoQTo);
				firstDate = selectedQuarterStartDateOfPreviousYear2;
				secondDate = selectedQuarterEndDateOfPreviousYear2;
			}else{
				Date selectedQuarterStartDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterStartDateOfPreviousYear(qoQFrom);
				Date selectedQuarterEndDateOfPreviousYear = ReportsDateUtility.getSelectedQuarterEndDateOfPreviousYear(qoQFrom);
				firstDate = selectedQuarterStartDateOfPreviousYear;
				secondDate = selectedQuarterEndDateOfPreviousYear;
				
				Date selectedQuarterStartDateOfPreviousYear2 = ReportsDateUtility.getSelectedQuarterStartDateOfPreviousYear(qoQTo);
				Date selectedQuarterEndDateOfPreviousYear2 = ReportsDateUtility.getSelectedQuarterEndDateOfPreviousYear(qoQTo);
				thirdDate = selectedQuarterStartDateOfPreviousYear2;
				fourthDate = selectedQuarterEndDateOfPreviousYear2;
			}
		}			
		}
		
		
		
		if(isActive) {
			/** Get all user count for given TY/LY **/
			List<AffiliationDetailsDto> reportsTYLYGainedDataList = reportsDataService.getReportTYLYUserCount(isActive,BrandAdvocateUtility.convertDateInYYYMMDD(firstDate),BrandAdvocateUtility.convertDateInYYYMMDD(secondDate),BrandAdvocateUtility.convertDateInYYYMMDD(thirdDate),BrandAdvocateUtility.convertDateInYYYMMDD(fourthDate), qoQFrom, qoQTo, dropDownValue1, dropDownValue2);
			
			Map<String, List<AffiliationDetailsDto>> reportsDataMap = new HashMap<>();
			reportsDataMap.put("reportsTYLYGainedDataList", reportsTYLYGainedDataList);
			
			return new ResponseWrapper<>(null, HttpStatus.OK, "", reportsDataMap);
		}else {
			/** Get InActive user count for given TY/LY **/
			List<AffiliationDetailsDto> reportsTYLYLostDataList = reportsDataService.getReportTYLYUserCount(isActive,BrandAdvocateUtility.convertDateInYYYMMDD(firstDate),BrandAdvocateUtility.convertDateInYYYMMDD(secondDate),BrandAdvocateUtility.convertDateInYYYMMDD(thirdDate),BrandAdvocateUtility.convertDateInYYYMMDD(fourthDate), qoQFrom, qoQTo, dropDownValue1, dropDownValue2);
			
			Map<String, List<AffiliationDetailsDto>> reportsDataMap = new HashMap<>();
			reportsDataMap.put("reportsTYLYGainedDataList", reportsTYLYLostDataList);
			
			return new ResponseWrapper<>(null, HttpStatus.OK, "", reportsDataMap);
		}
	}
	
	@RequestMapping(value = "/exporttoexcel", method = RequestMethod.POST)
	public void exportToExcel(HttpServletResponse response,@RequestHeader HttpHeaders requestHeader,@RequestBody String reportsRequest)
			throws NoSuchFieldException, IOException, ParseException {
		reportsDataService.exportToExcelFromJson(response, requestHeader,reportsRequest);
	}

}