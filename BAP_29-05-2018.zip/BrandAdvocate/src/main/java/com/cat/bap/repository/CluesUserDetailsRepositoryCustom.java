package com.cat.bap.repository;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;

public interface CluesUserDetailsRepositoryCustom {
	
		
	public Map<String, Object> getCluesUserDetailsByCupId(String cupId) throws SQLException;
	
	public Map<String, Object> getCluesUserDetailsByCwsUserId(String cwsUserId) throws SQLException;
	
	public Map<String, Object> getCluesUserDetailsByEmailId(String emailId) throws SQLException;

	public Map<String, Object> getCluesUserDetailsBasedOnCwsIdOrEmailId(String cwsUserId, String emailId) throws SQLException;

	public Map<String, Object> getCluesUserDetailsBasedOnIds(String cwsUserId, String emailId, String cupId) throws SQLException;

	/**
	 * @param cwsUserIds
	 * @return list of uploaded cws/email Ids
	 * @throws SQLException
	 */
	public Map<String, List<BAUserDetailsDto>> uploadBulkUploadForEmailsOrCWSIds(String cwsUserIds) throws SQLException;

	/**
	 * @param checkUsersInClue
	 * @param isCWS 
	 * @return
	 * @throws SQLException 
	 */
	public List<CluesDataDetailDto> getValidCluesUsers(List<String> checkUsersInClue, boolean isCWS) throws SQLException;

	/**
	 * @param cwsOrEmailIds
	 * @param isCWS 
	 * @return
	 */
	public List<BAUserDetailsDto> getAllBAUsersList(String cwsOrEmailIds, boolean isCWS);
	
	
	/**
	 * @param baObjList
	 * @return
	 * @throws SQLException
	 */
	List<CluesDataDetailDto> getAllCluesUserForCupIds(List<String> baObjList) throws SQLException;
	
}
