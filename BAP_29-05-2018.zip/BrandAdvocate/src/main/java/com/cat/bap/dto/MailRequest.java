package com.cat.bap.dto;

import java.io.Serializable;
import java.util.List;

import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.Documents;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
public class MailRequest implements Serializable{

  private static final long serialVersionUID = -5923436225957169206L;
  
  private Long templateId;
  
  private String subject;
  
  private String messageBody;
  
  private transient List<BAUserDetails> baUserDetailsList;
  
  private transient List<Documents> documentsList;
  
  
  public Long getTemplateId() {
	return templateId;
  }
  public void setTemplateId(Long templateId) {
	this.templateId = templateId;
  }
  public String getSubject() {
    return subject;
  }
  public void setSubject(String subject) {
    this.subject = subject;
  }
  public String getMessageBody() {
    return messageBody;
  }
  public void setMessageBody(String messageBody) {
    this.messageBody = messageBody;
  }
  public List<BAUserDetails> getBaUserDetailsList() {
	return baUserDetailsList;
  }
  public void setBaUserDetailsList(List<BAUserDetails> baUserDetailsList) {
	this.baUserDetailsList = baUserDetailsList;
  }
  public List<Documents> getDocumentsList() {
	return documentsList;
  }
  public void setDocumentsList(List<Documents> documentsList) {
	this.documentsList = documentsList;
  }
  
}
