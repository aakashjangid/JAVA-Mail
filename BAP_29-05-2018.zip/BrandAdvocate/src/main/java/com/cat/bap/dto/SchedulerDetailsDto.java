package com.cat.bap.dto;

import java.util.Date;

/**
 * @author rathor
 */
public class SchedulerDetailsDto {

	private Long 	jobId;
	private String 	jobGenerateCode;
	private String 	jobStatus;
	private String 	jobStatusLog;
	private String 	jobExecutedBy;
	private Date 	jobExecutionDate;

	/**
	 * @return the jobId
	 */
	public Long getJobId() {
		return jobId;
	}

	/**
	 * @param jobId
	 *            the jobId to set
	 */
	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	/**
	 * @return the jobGenerateCode
	 */
	public String getJobGenerateCode() {
		return jobGenerateCode;
	}

	/**
	 * @param jobGenerateCode
	 *            the jobGenerateCode to set
	 */
	public void setJobGenerateCode(String jobGenerateCode) {
		this.jobGenerateCode = jobGenerateCode;
	}

	/**
	 * @return the jobStatus
	 */
	public String getJobStatus() {
		return jobStatus;
	}

	/**
	 * @param jobStatus
	 *            the jobStatus to set
	 */
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	/**
	 * @return the jobStatusLog
	 */
	public String getJobStatusLog() {
		return jobStatusLog;
	}

	/**
	 * @param jobStatusLog
	 *            the jobStatusLog to set
	 */
	public void setJobStatusLog(String jobStatusLog) {
		this.jobStatusLog = jobStatusLog;
	}

	/**
	 * @return the jobExecutedBy
	 */
	public String getJobExecutedBy() {
		return jobExecutedBy;
	}

	/**
	 * @param jobExecutedBy
	 *            the jobExecutedBy to set
	 */
	public void setJobExecutedBy(String jobExecutedBy) {
		this.jobExecutedBy = jobExecutedBy;
	}

	/**
	 * @return the jobExecutionDate
	 */
	public Date getJobExecutionDate() {
		return jobExecutionDate;
	}

	/**
	 * @param jobExecutionDate
	 *            the jobExecutionDate to set
	 */
	public void setJobExecutionDate(Date jobExecutionDate) {
		this.jobExecutionDate = jobExecutionDate;
	}
}
