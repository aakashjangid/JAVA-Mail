package com.cat.bap.repository;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cat.bap.common.UserMasterConstant;

@Repository
public class ReportsDetailRepositoryCustomImpl implements ReportsDetailRepositoryCustom {

	@PersistenceContext
	private EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getReportActiveInActiveCount(List<String> affiliationDesc,boolean isActive, String startDate, String endDate) throws SQLException {

			String isActiveFlag;
			
			if(isActive){
				isActiveFlag = UserMasterConstant.FLAG_Y;
			}else{
				isActiveFlag = UserMasterConstant.FLAG_N;
			}
		
			StringBuilder createQuery = new StringBuilder();

			createQuery.append("SELECT  "
						+ "reg.region_name,  "
						+ "COUNT(ba.brand_advocate_id) totalCnt " 
						+ "FROM brand_advocate_details ba "
						+ "INNER JOIN country_tbl cntry ON cntry.country_id = ba.country_id "
						+" INNER JOIN region_tbl reg    ON reg.region_id = cntry.region_id "
						+" WHERE ba.is_active='"+isActiveFlag+"' "
						+ "AND ( ba.registration_date >= '"+startDate+"' AND  ba.registration_date <= '"+endDate+" 23:59:59') "
						+ "GROUP BY "
						+ "ba.affiliation_description,	"
						+ "reg.region_name "
						+ "HAVING UPPER(affiliation_description) IN(");

				StringBuilder preparedValues = new StringBuilder();
				
				for (String baCwsIdEmailString : affiliationDesc) {
					
					preparedValues.append("UPPER('");
					preparedValues.append(baCwsIdEmailString);
					preparedValues.append("'),");
				}
				String preparedValue = (preparedValues.length()>0) ? preparedValues.substring(0, preparedValues.length() - 1): "";
				
				createQuery.append(preparedValue);
				createQuery.append(")");
			
				Query query = entityManager.createNativeQuery(createQuery.toString());
				
				return query.getResultList();
	}				
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getReportGainLostCount(List<String> affiliationDesc, String startDate, String endDate) throws SQLException {
		
		StringBuilder createQuery = new StringBuilder();
		
		createQuery.append("SELECT  "
				+ "reg.region_name,  "
				+ "COUNT(ba.brand_advocate_id) totalCnt " 
				+ "FROM brand_advocate_details ba "
				+ "INNER JOIN country_tbl cntry ON cntry.country_id = ba.country_id "
				+ "INNER JOIN region_tbl reg    ON reg.region_id = cntry.region_id "
				+ "WHERE ( ba.registration_date >= '"+startDate+"' AND  ba.registration_date <= '"+endDate+" 23:59:59') "
				+ "GROUP BY "
				+ "ba.affiliation_description,	"
				+ "reg.region_name "
				+ "HAVING UPPER(affiliation_description) IN(");
		
		StringBuilder preparedValues = new StringBuilder();
		
		for (String baCwsIdEmailString : affiliationDesc) {
			
			preparedValues.append("UPPER('");
			preparedValues.append(baCwsIdEmailString);
			preparedValues.append("'),");
		}
		String preparedValue = (preparedValues.length()>0) ? preparedValues.substring(0, preparedValues.length() - 1): "";
		
		createQuery.append(preparedValue);
		createQuery.append(")");
		
		Query query = entityManager.createNativeQuery(createQuery.toString());
		
		return query.getResultList();
	}
}