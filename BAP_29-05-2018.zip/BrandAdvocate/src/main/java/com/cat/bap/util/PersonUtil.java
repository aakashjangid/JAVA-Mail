package com.cat.bap.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import com.cat.bap.common.UserMasterConstant;

import cat.cis.tuf.common.adhoc.ldap.SimpleLDAPFilter;
import cat.cis.tuf.common.directory.CGDS;
import cat.cis.tuf.common.directory.DirectoryException;
import cat.cis.tuf.common.directory.DirectorySearch;
import cat.cis.tuf.common.directory.Group;
import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.directory.PersonFactory;
import cat.cis.tuf.common.directory.Schema;
import cat.cis.tuf.common.logging.InformationalEvent;
import cat.cis.tuf.common.persistence.PersistenceException;
import cat.cis.tuf.server.security.SecurityWrapper;

/**
 * PersonUtil - People/CUPID/and CGDS functions
 * 
 * @author foutsc
 * 
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public class PersonUtil {

	private static PersonUtil instance = new PersonUtil();
	private static Map personMap = new HashMap();
	
	private static final String PERSON_UTIL = "PersonUtil";
	
	private static List peopleWithPrintAdminPermission = null;
	
	public static PersonUtil getInstance() {
		return instance;
	}

	/**
	 * @author thotanr
	 * @since 1.0.0 (Mar 31, 2004 3:46:08 PM)
	 * @param cupid
	 *            java.lang.String
	 * @return CWSPerson
	 */
	public static Person getPerson(String cupid) {
		if (cupid == null) {
			return null;
		}
		Person person = (Person) personMap.get(cupid);
		if (person == null) {

			try {
				DirectorySearch ds = new DirectorySearch();
				ds.setSchema(Schema.CGDS);
				
				ds.addField(CGDS.FIRST_NAME);
				ds.addField(CGDS.MIDDLE_INITIAL);
				ds.addField(CGDS.ORGANIZATION);
				ds.addField(CGDS.OFFICE_TELEPHONE_NUMBER);
				ds.addField(CGDS.MAIL);
				ds.addField(CGDS.AFFILIATION_CODE);
				
				ds.addField(CGDS.LAST_NAME); 						//Last Name
				ds.addField(CGDS.REGISTERED_NAME); 					//First Name [PREFERRED NAME]
				ds.addField(CGDS.PREFERRED_FIRST_NAME);				//Preferred First Name
				ds.addField(CGDS.ADMINISTRATIVE_CODE_DESCRIPTION); 	//Organization / Division
				ds.addField(CGDS.WORK_LOC_DESC); 					//Facility
				ds.addField(CGDS.WORK_BUILDING);					//Building (ex: AB, LC)
				ds.addField(CGDS.JOB_CODE);							//Job Keywords
				ds.addField(CGDS.COUNTRY);							//Country
				ds.addField(CGDS.EMAIL_ID);							//Email [what is -External Email Address- field of CLUES] ???
				
				
				ds.addFilter(new SimpleLDAPFilter(CGDS.CUPID, cupid.trim()));
				ds.setMaxResults(1);
				person = PersonFactory.getInstance().getPerson(ds);
				personMap.put(cupid, person);

			} catch (DirectoryException de) {
				new InformationalEvent("SRM", 0, PERSON_UTIL,
						"getPerson - cupid " + cupid, de.getMessage());
			} catch (Exception e) {
				new InformationalEvent("SRM", 0, PERSON_UTIL,
						"getPerson - Last, First Name" + cupid, e.getMessage());
			}
		}
		return person;
	}

	/**
	 * @param cupid
	 * @return
	 * @throws DirectoryException
	 */
	public static String getPersonName(String cupid) {
		Person person = getPerson(cupid);
		try {
			List ipUsers = getpeopleWithPrintAdminPermission();
			ipUsers.contains(person);
		} catch (PersistenceException e) {
			new InformationalEvent("SRM", 0, PERSON_UTIL,
					"check person role " + cupid, e.getMessage());
		}
		if (person != null) {
			return person.getProperty(CGDS.FIRST_NAME);
		} else {
			return "";
		}
	}

	/**
	 * @return
	 */
	public static String getCurrentUserCupid(HttpServletRequest request) {
		Person p = getCurrentUser(request);
		if (p == null) {
			return null;
		}
		return getCurrentUser(request).getCUPID();
	}

	/**
	 * @return
	 */
	public static String getCurrentUserLogOnId(HttpServletRequest request) {
		Person p = getCurrentUser(request);
		if (p == null) {
			return null;
		}
		return getCurrentUser(request).getLogonId();
	}

	/**
	 * @param request
	 * @return
	 */
	public static Person getCurrentUser(HttpServletRequest request) {

		return instance.getPersonFromRequest(request);
	}

	/**
	 * @param request
	 * @return
	 */
	public Person getPersonFromRequest(HttpServletRequest request) {
		SecurityWrapper wrapper = SecurityWrapper.getInstance();
		Cookie[] cookies = request.getCookies();
		return wrapper.getRemoteUser(cookies);

	}

	/**
	 * @param request
	 * @return
	 */
	public static String getCurrentUserName(HttpServletRequest request) {
		return getPersonName(getCurrentUserCupid(request));
	}

	/**
	 * @param request
	 * @return
	 * @throws PersistenceException
	 */
	public static boolean isAdminCWSPerson(HttpServletRequest request)
			throws PersistenceException {
		Person p = getPerson(getCurrentUserCupid(request));
		List ipUsers = getpeopleWithPrintAdminPermission();
		return ipUsers.contains(p);
	}
	
	public static List getAdminGroupUsers() throws PersistenceException{
		return getpeopleWithPrintAdminPermission();
	}
	
	protected static List getpeopleWithPrintAdminPermission()
			throws PersistenceException {
		if (peopleWithPrintAdminPermission == null) {
			peopleWithPrintAdminPermission = new ArrayList<Person>();

			Group grp = new Group(UserMasterConstant.BAP_ADMIN);
			peopleWithPrintAdminPermission.addAll(grp.getMembers());
		}
		return peopleWithPrintAdminPermission;
	}
	
	/**
	 * @param request
	 * @return
	 * @throws PersistenceException
	 */
	public static boolean isAdminPerson(HttpServletRequest request)
			throws PersistenceException {

		if (isAdminCWSPerson(request)) {
			return true;
		} else {
			clearPersonUtilCaches();
			if (isAdminCWSPerson(request)) {
				return true;
			}
		}

		return false;
	}

	public static void clearPersonUtilCaches() {
		personMap = new HashMap();
		peopleWithPrintAdminPermission = null;
	}
}
