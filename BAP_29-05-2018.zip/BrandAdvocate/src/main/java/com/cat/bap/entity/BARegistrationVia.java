package com.cat.bap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rohan.rathore
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rohan.rathore@yash.com
 * @date 20-Mar-2018
 * @purpose This class is used as dto for manage BA Registration status details.
 */

@Entity
@Table(name = "registration_status_tbl")
public class BARegistrationVia {

	@Id
	@Column(name = "reg_status_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long registrationId;

	@Column(name = "reg_status_name")
	private String registrationStatusName;


	/**
	 * @return the registrationId
	 */
	public Long getRegistrationId() {
		return registrationId;
	}

	/**
	 * @param registrationId the registrationId to set
	 */
	public void setRegistrationId(Long registrationId) {
		this.registrationId = registrationId;
	}

	/**
	 * @return the registrationStatusName
	 */
	public String getRegistrationStatusName() {
		return registrationStatusName;
	}

	/**
	 * @param registrationStatusName
	 *            the registrationStatusName to set
	 */
	public void setRegistrationStatusName(String registrationStatusName) {
		this.registrationStatusName = registrationStatusName;
	}
}
