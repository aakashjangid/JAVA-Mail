package com.cat.bap.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cat.bap.entity.Country;
import com.cat.bap.entity.Region;

/**
 * @author rohan.rathore
 *
 */
public interface CountryRepository extends JpaRepository<Country, Long>{
	
  @Query("SELECT c.region FROM Country c WHERE c.countryId =:countryId")
  public List<Region> getRegionsByCountryId(@Param("countryId") Long countryId);
  
  @Query("FROM Country c WHERE c.countryCode =:country_code")
  public Country getCountryByCountryCode(@Param("country_code") String countrCode);

  
  @Query("FROM Country c WHERE c.countryId =:country_id")
  public Country getCountryByCountryId(@Param("country_id") Long countryId);
  
  
}
