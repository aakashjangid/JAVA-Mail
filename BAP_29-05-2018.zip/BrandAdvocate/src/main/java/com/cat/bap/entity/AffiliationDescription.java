package com.cat.bap.entity;
	
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
	
/**
 * @author rathor
 */

@Entity
@Table(name = "affiliation_desc_tbl")
@NamedNativeQueries({ 
	@NamedNativeQuery(name = "getAllAffiliationNames", 
					 query = "SELECT distinct(ad.affiliation_name) FROM affiliation_desc_tbl ad ORDER BY FIELD(ad.affiliation_name,'Employees','Dealers','Others')")})
public class AffiliationDescription {

	@Id
	@Column(name = "affiliation_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long affiliationId;

	@Column(name = "affiliation_name")
	private String affiliationName;
	
	@Column(name = "affiliation_desc")
	private String affiliationDesc;
	
	@Column(name = "affiliation_name_ui")
	private String affiliationNameUI;


	/**
	 * @return the affiliationNameUI
	 */
	public String getAffiliationNameUI() {
		return affiliationNameUI;
	}

	/**
	 * @param affiliationNameUI the affiliationNameUI to set
	 */
	public void setAffiliationNameUI(String affiliationNameUI) {
		this.affiliationNameUI = affiliationNameUI;
	}

	/**
	 * @return the affiliationId
	 */
	public Long getAffiliationId() {
		return affiliationId;
	}

	/**
	 * @param affiliationId the affiliationId to set
	 */
	public void setAffiliationId(Long affiliationId) {
		this.affiliationId = affiliationId;
	}

	/**
	 * @return the affiliationName
	 */
	public String getAffiliationName() {
		return affiliationName;
	}

	/**
	 * @param affiliationName the affiliationName to set
	 */
	public void setAffiliationName(String affiliationName) {
		this.affiliationName = affiliationName;
	}

	/**
	 * @return the affiliationDesc
	 */
	public String getAffiliationDesc() {
		return affiliationDesc;
	}

	/**
	 * @param affiliationDesc the affiliationDesc to set
	 */
	public void setAffiliationDesc(String affiliationDesc) {
		this.affiliationDesc = affiliationDesc;
	}

}
