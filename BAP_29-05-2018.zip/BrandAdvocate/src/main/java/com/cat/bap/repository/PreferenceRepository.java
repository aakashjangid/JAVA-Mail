package com.cat.bap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cat.bap.entity.Preferences;

public interface PreferenceRepository extends JpaRepository<Preferences, Long>{

}
