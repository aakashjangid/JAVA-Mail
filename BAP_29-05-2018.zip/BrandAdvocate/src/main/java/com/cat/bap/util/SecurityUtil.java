/*
 *
 * Copyright (c) 2005 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
package com.cat.bap.util;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import cat.cis.tuf.security.pub.webservices.auth.soap.AuthenticatorSoapBindingStub;

/**
 * SecurityUtil - Security functions called by actions, setup of test to
 * interact with cookies.
 * 
 * @author foutsc
 * 
 */
public class SecurityUtil {
	private static SecurityUtil instance = new SecurityUtil();

	private SecurityUtil() {
		
	}
	
	/**
	 * @param user
	 * @param password
	 * @return String
	 * @throws MalformedURLException
	 * @throws RemoteException
	 */
	public static String generateSSOCookie(String user, String password)
			throws RemoteException {
		AuthenticatorSoapBindingStub webservice = new AuthenticatorSoapBindingStub();
		return webservice.authenticate(user, password);
	}

	/**
	 * @return
	 */
	public static SecurityUtil getINSTANCE() {
		return instance;
	}

}
