package com.cat.bap.repository;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.dto.UserMasterRequest;
import com.cat.bap.entity.AffiliationDescription;
import com.cat.bap.entity.Country;
import com.cat.bap.entity.Region;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
public interface BAUserDetailsRepositoryCustom {

	public Map<String, Object> getAllAdminDetails(UserMasterRequest manageAdminRequest);
  
	public List<BAUserDetailsDto> getAllActiveBADetails();
	
	public List<CluesDataDetailDto> getCWSIDFromBADetils();
	
	public Map<String, Object> getBAUserDetailsByCupId(String cupId) throws SQLException;
	
	public Map<String, Object> getBAUserDetailsByCwsUserId(String cwsUserId) throws SQLException;
	
	public Map<String, Object> getBAUserDetailsByEmailId(String emailId) throws SQLException;
	
	public Map<String, Object> getBAUserDetailsBasedOnIds(String cwsUserId, String emailId, String cupId);
	
	/**
	 * @return last execution time to show on UI
	 */
	public String getLastExecutionDateTime();

	
	/**
	 * @param validCluesUsers
	 * @param userName
	 * @param baVia
	 * @param jvList 
	 * @param supplierList 
	 * @param agencyList 
	 * @param custList 
	 * @param listOfAllAffDesc 
	 * @throws SQLException 
	 */
	public void executeBatchNewUserNativeSQLBatch(List<CluesDataDetailDto> validCluesUsers, String userName,
			String baVia,List<AffiliationDescription> listAffiliationDescription) throws SQLException;
	/**
	 * @param allExistingUsers
	 * @param userName
	 * @param isCWS
	 * @throws SQLException 
	 */
	public void executeBatchExistingUserNativeSQLBatch(List<BAUserDetailsDto> allExistingUsers, String userName,
			boolean isCWS) throws SQLException;

	/**
	 * @param adminLastName 
	 * @param adminFirstName 
	 * @param executionMode 
	 * @param allExistingUsers
	 * @param userName
	 * @param isCWS
	 * @return
	 * @throws SQLException
	 */
	int updateBAPStatusInactiveForCupIDs(List<String> cupIdsToInactivate, String adminFirstName, String adminLastName, String executionMode)
			throws SQLException;

	/**
	 * @param userMasterRequest
	 * @return
	 */
	public List<BAUserDetailsDto> getMailIdListByBaId(UserMasterRequest userMasterRequest);

	/**
	 * @param validCluesUsers
	 * @param isCWS 
	 * @throws SQLException 
	 */
	public void executeBatchNewUserPreferencesNativeSQLBatch(List<CluesDataDetailDto> validCluesUsers, boolean isCWS) throws SQLException;

	public List<String> getDbUserNameByPreferenceForFindBA(String brandEventCommunication);

	public List<String> getDbOrganizationByPreferenceForFindBA(String brandEventCommunication);

	public List<Region> getDbRegionByPreferenceForFindBA(String brandEventCommunication);

	public List<Country> getDbCountryByPreferenceForFindBA(String brandEventCommunication);
	

	/**
	 * @param brandAdvocateId
	 * @param isActive
	 * @param inActiveDate
	 * @param modifiedDate
	 * @throws SQLException
	 */
	public boolean updateDataToInActiveState(long brandAdvocateId, boolean isActive, Date inActiveDate, Date modifiedDate) throws SQLException;


}
