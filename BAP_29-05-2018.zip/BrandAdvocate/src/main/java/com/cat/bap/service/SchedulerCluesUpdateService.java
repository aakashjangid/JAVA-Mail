package com.cat.bap.service;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cat.bap.common.BrandAdvocateConstant;
import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.SchedulerDetail;
import com.cat.bap.repository.BAUserDetailsRepositoryCustom;
import com.cat.bap.repository.CluesUserDetailsRepositoryCustom;
import com.cat.bap.util.BrandAdvocateEmailUtility;
import com.cat.bap.util.BrandAdvocateUtility;

import cat.cis.tuf.common.email.EMailException;
import cat.cis.tuf.common.util.Counter;

@Service
public class SchedulerCluesUpdateService implements Runnable {

	private static final Logger LOGGER = LoggerFactory.getLogger(BAUserDetailsService.class);

	@Inject
	private BAUserDetailsRepositoryCustom bAUserDetailsRepositoryCustom;
		
	@Inject
	private CluesUserDetailsRepositoryCustom cluesUserDetailsRepositoryCustom;
	
	@Inject
	private BrandAdvocateEmailUtility brandAdvocateEmailUtility;
	
	@Inject
	private BAUserDetailsDomainService baUserDetailsDomainService;

	private final int idx;

	public SchedulerCluesUpdateService() {
		this(Counter.getNext());
	}

	public SchedulerCluesUpdateService(int paramInt) {
		idx = paramInt;
	}

	public void run() {

		LOGGER.info("Scheduler Batch run() : START");
		
		Long jobId=0L;
		Timestamp executionStartTime = new Timestamp(new Date().getTime());
		String executedBy 		= UserMasterConstant.SYSTEM;
		String jobGenerateCode 	= BrandAdvocateUtility.randomString(UserMasterConstant.NO_OF_DIGIT_CODE);
		
		String jobStatusInProgress  	= UserMasterConstant.INPROGRESS;
		String jobStatusFailed  		= UserMasterConstant.FAILED;
		String jobStatusCompleted 		= UserMasterConstant.COMPLETED;
		String jobStatusInProgressLog 	= BrandAdvocateConstant.SYNC_INPROGRESS;
		String jobStatusCompletedLog 	= BrandAdvocateConstant.SYNC_COMPLETED;
		
		try {
			
			LOGGER.info("Sync process started : START");
			
			SchedulerDetail maintainSyncSchedulerInfo = baUserDetailsDomainService.maintainSyncSchedulerInfo(null, jobGenerateCode, jobStatusInProgress, executedBy, executionStartTime, null,jobStatusInProgressLog);

			/** Call sync process **/
			syncCluesData("Admin", "", "admin@brandadvocate.com", UserMasterConstant.SYNC_SCHEDULER);
			
			/** Update sync process value in databases - STARTED  **/
			Timestamp executionEndTime = new Timestamp(new Date().getTime());
			
			jobId = maintainSyncSchedulerInfo.getJobId();
			
			if(null!=jobId){
				baUserDetailsDomainService.maintainSyncSchedulerInfo(jobId, jobGenerateCode, jobStatusCompleted, executedBy, executionStartTime, executionEndTime, jobStatusCompletedLog);
			}
			LOGGER.info("Sync process completed : END");
			
		} catch (EMailException | SQLException | IOException | ParseException e) {
			
			LOGGER.error("Error occurred while batch execution. ", e );
			
			Timestamp executionFailedTime = new Timestamp(new Date().getTime());
			baUserDetailsDomainService.maintainSyncSchedulerInfo(jobId, jobGenerateCode, jobStatusFailed, executedBy,executionStartTime, executionFailedTime, e.getMessage());
		} 
		
		LOGGER.info("Scheduler Batch run() : END");
	}
	
	public boolean syncCluesData(String adminFirstName, String adminLastName, String adminEmailId, String executionMode) throws SQLException, EMailException, IOException, ParseException{
		
		/** Get all active/non-null cupids data **/
		List<BAUserDetailsDto>  baUserDetailsList  = bAUserDetailsRepositoryCustom.getAllActiveBADetails();
		
		/** Get list of all CupIds from BA list **/
		List<String> baCupIdList = getCupIdList(baUserDetailsList);
		
		/** Get clues data based on CupIds **/
		List<CluesDataDetailDto> allCluesUserForCupIds = cluesUserDetailsRepositoryCustom.getAllCluesUserForCupIds(baCupIdList);

		/** Get list of all CupIds from clues list **/
		List<String> clueCupIdList = getCluesCupIdList(allCluesUserForCupIds);
		
		/** Compare data and figure out difference. Hold BA data to be updated **/
		List<BAUserDetailsDto> notEqualBADataList = compareBADataWithCluesData(baUserDetailsList,allCluesUserForCupIds);
		
		if(null!=notEqualBADataList && !notEqualBADataList.isEmpty()){
			
			StringBuilder fullName = new StringBuilder();
			fullName = fullName.append(adminFirstName).append(adminLastName);
			
			/** update different values in BAP DB **/
			updateBADataForCluesData(notEqualBADataList, fullName, executionMode);
			
			/** Send email to updated users service **/
			for (BAUserDetailsDto baUser : notEqualBADataList) {
				if(null!=baUser.getPrimaryEmail() && !baUser.getPrimaryEmail().equals("")){
					
					brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL,  BrandAdvocateConstant.SUBJECT_SYNC_EMAIL,  BrandAdvocateConstant.MSGBODY_SYNC_SERVICE.concat(baUser.getPrimaryEmail()), baUser.getFirstName(), baUser.getLastName(), BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
/**					brandAdvocateEmailUtility.sendMail(baUser.getPrimaryEmail(),  BrandAdvocateConstant.SUBJECT_SYNC_EMAIL,  BrandAdvocateConstant.MSGBODY_SYNC_SERVICE, adminFirstName, adminLastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE); **/
				}
			}			
		}
		
		/** Prepare a list of data (CUPID) that does not exist in Clues, make them inactive in DB. **/
		List<String> cupIdsToInactivate = prepareListOfNonCluesCUPIds(baCupIdList, clueCupIdList, allCluesUserForCupIds);
		
		/** Updating BA data making inActive for CupID doesn't exist in Clues **/
		if(!cupIdsToInactivate.isEmpty()){
			updateBAPStatusInactiveForCupIDs(cupIdsToInactivate, adminFirstName, adminLastName,executionMode);
		}
		
		brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL,  BrandAdvocateConstant.SUBJECT_SYNC_EMAIL_ADMIN,  BrandAdvocateConstant.MSGBODY_SYNC_SERVICE_ADMIN.concat(adminEmailId), adminFirstName, adminLastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
/**		brandAdvocateEmailUtility.sendMail(adminEmailId,  BrandAdvocateConstant.SUBJECT_SYNC_EMAIL_ADMIN,  BrandAdvocateConstant.MSGBODY_SYNC_SERVICE_ADMIN, adminFirstName, adminLastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE); **/
		
		return false; 
	}

	/**
	 * @param notEqualBADataList
	 * @param loggedInUserName
	 * @param executionMode 
	 * @return
	 * @throws ParseException
	 */
	private BAUserDetails updateBADataForCluesData(List<BAUserDetailsDto> notEqualBADataList, StringBuilder loggedInUserName, String executionMode) throws ParseException {
		
		return baUserDetailsDomainService.updateBASyncData(notEqualBADataList,loggedInUserName, executionMode);
	}

	/**
	 * @param cupIdsToInactivate
	 * @param adminFirstName
	 * @param adminLastName
	 * @param executionMode 
	 * @return
	 * @throws SQLException
	 */
	private int updateBAPStatusInactiveForCupIDs(List<String> cupIdsToInactivate, String adminFirstName, String adminLastName, String executionMode) throws SQLException {
		
		return bAUserDetailsRepositoryCustom.updateBAPStatusInactiveForCupIDs(cupIdsToInactivate, adminFirstName, adminLastName, executionMode);
	}

	/**
	 * @param baCupIdList
	 * @param clueCupIdList 
	 * @param allCluesUserForCupIds
	 * @return
	 */
	private List<String> prepareListOfNonCluesCUPIds(List<String> baCupIdList,
			List<String> clueCupIdList, List<CluesDataDetailDto> allCluesUserForCupIds) {
		
		/**InActive status list**/
		List<String>inActiveStatusToCompare = new ArrayList<>();
		List<String> cupIdListToInactivate =  null; 
		cupIdListToInactivate = new ArrayList<>();
		
		inActiveStatusToCompare.add(UserMasterConstant.ACTIVE_HR_RETIRED);
		inActiveStatusToCompare.add(UserMasterConstant.ACTIVE_HR_TERMINATED);
		inActiveStatusToCompare.add(UserMasterConstant.ACTIVE_INVALID);
		inActiveStatusToCompare.add(UserMasterConstant.INACTIVE);
		
		for (String baCupId : baCupIdList) {
			if(!clueCupIdList.contains(baCupId)){
				cupIdListToInactivate.add(baCupId);
			}
		} 
		
		/** Add CLUES inactive data **/
		if(!allCluesUserForCupIds.isEmpty() && !baCupIdList.isEmpty()){
			for (CluesDataDetailDto cluesData : allCluesUserForCupIds) {
				//cluesData.setGlobalDirectoryStatus("inactive"); FOR TESTING Inactive records
				for (String baData : baCupIdList) {
					if(cluesData.getCupId().equals(baData) && inActiveStatusToCompare.contains(cluesData.getGlobalDirectoryStatus()) && (!cupIdListToInactivate.contains(baData)))
						cupIdListToInactivate.add(baData);
				}
			} 
		}
/*		List<String> cupIdListToInactivate = new ArrayList<>();
		if(!allCluesUserForCupIds.isEmpty() && !baCupIdList.isEmpty()){
			for (CluesDataDetailDto cluesData : allCluesUserForCupIds) {
				for (String baData : baCupIdList) {
					if((baData.equals(cluesData.getCupId()) && !cupIdListToInactivate.contains(baData)) || 
							inActiveStatusToCompare.contains(cluesData.getGlobalDirectoryStatus()))
						cupIdListToInactivate.add(baData);
				}
			} 
		}
*/		
		return cupIdListToInactivate;
	}

	/**
	 * @param baUserDetailsList
	 * @param allCluesUserForCupIds
	 * @return
	 */
	private List<BAUserDetailsDto> compareBADataWithCluesData(List<BAUserDetailsDto> baUserDetailsList,
			List<CluesDataDetailDto> allCluesUserForCupIds) {
	
		List<BAUserDetailsDto> baListToSync = new ArrayList<>();
				
		for (CluesDataDetailDto cluesDataDetailDto : allCluesUserForCupIds) {
			 for (BAUserDetailsDto baUser : baUserDetailsList) {
				 
				 if((baUser.getCupId().equals(cluesDataDetailDto.getCupId()))
					 && (	
							 !baUser.getCwsUserId().equals(cluesDataDetailDto.getCwsUserId()) 							|| 
							 !baUser.getLastName().equals(cluesDataDetailDto.getLastName()) 							|| 
							 !baUser.getFirstName().equals(cluesDataDetailDto.getFirstName()) 							|| 
							 !baUser.getPreferredFirstName().equals(cluesDataDetailDto.getPreferredFirstName()) 		||
							 !baUser.getOrganizationName().equals(cluesDataDetailDto.getOrganizationName()) 			||
							 !baUser.getPrimaryEmail().equals(cluesDataDetailDto.getPrimaryEmail()) 					||
							 !baUser.getCountryCode().equals(cluesDataDetailDto.getCountryCode()) 						||
							 !baUser.getFacilityName().equals(cluesDataDetailDto.getFacilityName())						||
							 !baUser.getAffiliationDescription().equals(cluesDataDetailDto.getAffiliationDescription()))
						)
				 	{
						BAUserDetailsDto baUserSyncClues = null; 
						baUserSyncClues	= new BAUserDetailsDto();
						
						baUserSyncClues.setCwsUserId(cluesDataDetailDto.getCwsUserId());
					      baUserSyncClues.setCupId(cluesDataDetailDto.getCupId());
					      baUserSyncClues.setFirstName(cluesDataDetailDto.getFirstName());
					      baUserSyncClues.setLastName(cluesDataDetailDto.getLastName());
					      baUserSyncClues.setPreferredFirstName(cluesDataDetailDto.getPreferredFirstName());
					      baUserSyncClues.setOrganizationName(cluesDataDetailDto.getOrganizationName());
					      baUserSyncClues.setPrimaryEmail(cluesDataDetailDto.getPrimaryEmail());
					      baUserSyncClues.setCountryCode(cluesDataDetailDto.getCountryCode());
					      baUserSyncClues.setFacilityName(cluesDataDetailDto.getFacilityName());
					      baUserSyncClues.setAffiliationDescription(cluesDataDetailDto.getAffiliationDescription());
					      
					      /**Holding existing information intact **/
					      baUserSyncClues.setBrandAdvocateId(baUser.getBrandAdvocateId());
					      baUserSyncClues.setSecondaryEmail(baUser.getSecondaryEmail());
					      baUserSyncClues.setComments(baUser.getComments());
					      baUserSyncClues.setNotes(baUser.getNotes());
					      baUserSyncClues.setRegisteredVia(baUser.getRegisteredVia());
					      baUserSyncClues.setJobKeywords(baUser.getJobKeywords());
					      baUserSyncClues.setBrandAdvocateStatus(baUser.getBrandAdvocateStatus());
					      baUserSyncClues.setBuildingName(baUser.getBuildingName());
					      baUserSyncClues.setRegisteredBy(baUser.getRegisteredBy());
					      baUserSyncClues.setRegistrationDate(baUser.getRegistrationDate());
					      baUserSyncClues.setManagedBy(baUser.getManagedBy());
						
						baListToSync.add(baUserSyncClues);
				 	}
			 }
		}
		 return baListToSync;
	}

	/**
	 * @param baUserDetailsList
	 * @return
	 */
	private List<String> getCupIdList(List<BAUserDetailsDto> baUserDetailsList) {
		
		List<String> cupIds = new ArrayList<>();
		
		for (BAUserDetailsDto baUserDetailsDto : baUserDetailsList) {
			cupIds.add(baUserDetailsDto.getCupId());
		}
		return cupIds;
	}
	
	/**
	 * @param allCluesUserForCupIds
	 * @return
	 */
	private List<String> getCluesCupIdList(List<CluesDataDetailDto> allCluesUserForCupIds) {
		
		List<String> cupIds = new ArrayList<>();
		
		for (CluesDataDetailDto baUserDetailsDto : allCluesUserForCupIds) {
			cupIds.add(baUserDetailsDto.getCupId());
		}
		return cupIds;
	}
	
/*	
	public void executeSyncService(String adminFirstName, String adminLastName, String adminEmailId, String syncManual) {
		
		LOGGER.info(" executeSyncService() : START");
		
		Timestamp executionStartTime = new Timestamp(new Date().getTime());
		String executedBy 		= UserMasterConstant.SYSTEM;
		String jobGenerateCode 	= BrandAdvocateUtility.randomString(UserMasterConstant.NO_OF_DIGIT_CODE);
		
		String jobStatusInProgress  	= UserMasterConstant.INPROGRESS;
		String jobStatusFailed  		= UserMasterConstant.FAILED;
		String jobStatusCompleted 		= UserMasterConstant.COMPLETED;
		String jobStatusInProgressLog 	= BrandAdvocateConstant.SYNC_INPROGRESS;
		String jobStatusCompletedLog 	= BrandAdvocateConstant.SYNC_COMPLETED;

		SchedulerDetail maintainSyncSchedulerInfo = baUserDetailsDomainService.maintainSyncSchedulerInfo(null, jobGenerateCode, jobStatusInProgress, syncManual, executionStartTime, null, jobStatusInProgressLog);
		
		*//** Manual sync process **//*
		try {
			
			schedulerCluesUpdateService.syncCluesData(adminFirstName,adminLastName,adminEmailId,UserMasterConstant.SYNC_MANUAL);
		
		} catch (EMailException | SQLException | IOException | ParseException e) {
			
			LOGGER.error("Error occurred while manul sync service execution. ", e );
			
			Timestamp executionFailedTime = new Timestamp(new Date().getTime());
			baUserDetailsDomainService.maintainSyncSchedulerInfo(maintainSyncSchedulerInfo.getJobId(), jobGenerateCode, jobStatusFailed, syncManual,executionStartTime, executionFailedTime, e.getMessage());
		} 

		*//** Update sync process value in databases - STARTED  **//*
		Timestamp executionEndTime = new Timestamp(new Date().getTime());
		
		if(null!=maintainSyncSchedulerInfo.getJobId()){
			baUserDetailsDomainService.maintainSyncSchedulerInfo(maintainSyncSchedulerInfo.getJobId(), jobGenerateCode, jobStatusCompleted, syncManual, executionStartTime, executionEndTime, jobStatusCompletedLog);
		}

		
		LOGGER.info(" executeSyncService() : END");
	}	
*/}
