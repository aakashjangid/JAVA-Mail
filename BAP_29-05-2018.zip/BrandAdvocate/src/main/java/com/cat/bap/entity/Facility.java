package com.cat.bap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rohan.rathore
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rohan.rathore@yash.com
 * @date 20-Mar-2018
 * @purpose This class is used as dto for manage facility details.
 */

@Entity
@Table(name = "facility_tbl")
public class Facility {

	@Id
	@Column(name = "facility_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long facilityId;

	@Column(name = "facility_name")
	private String facilityName;

	/**
	 * @return the facilityId
	 */
	public Long getFacilityId() {
		return facilityId;
	}

	/**
	 * @param facilityId
	 *            the facilityId to set
	 */
	public void setFacilityId(Long facilityId) {
		this.facilityId = facilityId;
	}

	/**
	 * @return the facilityName
	 */
	public String getFacilityName() {
		return facilityName;
	}

	/**
	 * @param facilityName
	 *            the facilityName to set
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

}
