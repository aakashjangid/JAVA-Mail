package com.cat.bap.util;

import java.util.Properties;

import javax.mail.Session;

import com.cat.bap.common.UserMasterConstant;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
public class BrandAdocateEmailSession {

  private static Properties props;
  private static Session ssn;

  private BrandAdocateEmailSession() {

  }

  /**
   * This method is used to get Session
   * 
   * @return {@link Session}
   */
  public static Session getSession() {
    if (null == ssn)
      ssn = Session.getInstance(props, null);
    return ssn;
  }

  /**
   * This method is used to set properties
   * 
   */
  public static void setProperties(BrandAdvocateEmailPropertyReader brandAdvocateEmailPropertyReader) {
    if (null == props) {
      props = System.getProperties();
      props.put(UserMasterConstant.MAIL_SMTP_HOST, brandAdvocateEmailPropertyReader.getHost());
      props.put(UserMasterConstant.MAIL_SMTP_PORT, brandAdvocateEmailPropertyReader.getPort());
      props.put(UserMasterConstant.MAIL_STMP_USER, brandAdvocateEmailPropertyReader.getEmailid());
    }
  }
}
