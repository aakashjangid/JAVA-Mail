package com.cat.bap.service;


import java.sql.SQLException;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cat.bap.repository.BAUserDetailsRepositoryCustom;

@Service
public class SyncDataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SyncDataService.class);
	
	@Inject
	private BAUserDetailsRepositoryCustom bAUserDetailsRepositoryCustom;

	public String getLastSchedulerExecutionTime() throws SQLException {

		LOGGER.info("getLastSchedulerExecutionTime(). START");
		
		String lastExecutionTime = bAUserDetailsRepositoryCustom.getLastExecutionDateTime();
		
		LOGGER.info("getLastSchedulerExecutionTime(). END");
		
		return lastExecutionTime;
	}
}

/*
 * public List<AffiliationDetailsDto> getAffiliationTypeDataNewApproach() throws
 * SQLException {
 * 
 * List<AffiliationDetailsDto> listOfDTOs = new
 * ArrayList<AffiliationDetailsDto>(); List<String> affNames =
 * reportsDataDomainService.getAllAffiliationNames();
 * 
 * for (String affName : affNames) {
 * 
 * AffiliationDetailsDto affDetailDto = null; affDetailDto = new
 * AffiliationDetailsDto(); long regionRecordCount = 0;
 * 
 * List<AffiliationRegionDto> listOfAffiliationRegionDto = new
 * ArrayList<AffiliationRegionDto>();
 * 
 * List<String> affiliationDesc =
 * reportsDataDomainService.getAffiliationDescByName(affName); List<Object[]>
 * dataList = reportsDetailRepositoryCustomImpl.getAffiliationDescByTypeName(
 * affiliationDesc);
 * 
 * for (Object[] record : dataList) {
 * 
 * AffiliationRegionDto affRegionDto = null; affRegionDto = new
 * AffiliationRegionDto();
 * 
 * String affiliationRegionName = record[0] != null ? "" + (String) record[0] :
 * ""; long recordCount = record[1] != null ? ((BigInteger)
 * record[1]).longValue() : null;
 * 
 * regionRecordCount += recordCount;
 * 
 * //affRegionDto.setTotalRegionRecordCnt(regionRecordCount);
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.AMERICAS_NORTH)){
 * affDetailDto.setAnCnt(recordCount); }
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.AMERICAS_SOUTH)){
 * affDetailDto.setAsCnt(recordCount); }
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.ASIA_PACIFIC)){
 * affDetailDto.setApCnt(recordCount); }
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.EAME)){
 * affDetailDto.setEameCnt(recordCount); }
 * 
 * affRegionDto.setAffiliationRegionName(affiliationRegionName);
 * affRegionDto.setRecordCount(recordCount);
 * 
 * listOfAffiliationRegionDto.add(affRegionDto); }
 * affDetailDto.setAffiliationTypeName(affName);
 * affDetailDto.setListOfAffRegion(listOfAffiliationRegionDto);
 * 
 * listOfDTOs.add(affDetailDto); } return listOfDTOs; }
 */