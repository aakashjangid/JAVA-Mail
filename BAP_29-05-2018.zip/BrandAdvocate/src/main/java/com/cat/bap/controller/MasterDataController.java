package com.cat.bap.controller;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.service.MasterDataApplicationService;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 23-Feb-2018
 * @purpose
 */
@RestController
@RequestMapping(value = "/masterdata/v1/")
public class MasterDataController {

	@Inject
	private MasterDataApplicationService masterDataApplicationService;

	private static final Logger LOGGER = LoggerFactory.getLogger(MasterDataController.class);

	@RequestMapping(value = "/getcountries", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getAllCountries() {
		LOGGER.info("MasterDataController.getAllCountries()");
		return new ResponseWrapper<>(null, HttpStatus.OK, "", masterDataApplicationService.getAllCountries());
	}

	@RequestMapping(value = "/getregions", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getAllRegions() {
		LOGGER.info("MasterDataController.getAllRegions()");
		return new ResponseWrapper<>(null, HttpStatus.OK, "", masterDataApplicationService.getAllRegions());
	}

	@RequestMapping(value = "/getpreferences", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getAllPreferences() {
		LOGGER.info("MasterDataController.getAllPreferences()");
		return new ResponseWrapper<>(null, HttpStatus.OK, "", masterDataApplicationService.getAllPreferences());
	}

	@RequestMapping(value = "/getregionsbycountryid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getRegionsByCountryId(@RequestParam("countryid") Long countryId) {
		LOGGER.info("MasterDataController.getRegionsByCountryId()");
		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				masterDataApplicationService.getRegionsByCountryId(countryId));
	}

	@RequestMapping(value = "/getcountriesbyregionid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getCountriesByRegionId(@RequestParam("regionid") Long regionId) {
		LOGGER.info("MasterDataController.getCountriesByRegionId()");
		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				masterDataApplicationService.getCountriesByRegionId(regionId));
	}
	
	@RequestMapping(value = "/getallaffiliationnameui", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, List<String>>> getAllAffiliationNameUI() {
		LOGGER.info("MasterDataController.getAllAffiliationNameUI()");
		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				masterDataApplicationService.getAllAffiliationNameUI());
	}

}
