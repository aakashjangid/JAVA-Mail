package com.cat.bap.common;

/**
 * Creates and stores the 'UserContext' object in Threadlocal. Used by UserContextFilter.
 * WARNING: The release() method should be called to cleanup the memory.
 * 
 * @author guntav
 * 
 */
public class UserContext {
	private final User user;

	private static ThreadLocal<UserContext> instance = new ThreadLocal<UserContext>();

	private UserContext(String cupid, String cwsId, String ipAddress, String remoteHost) {
		this.user = new User(cupid, cwsId, ipAddress, remoteHost);
	}

	
	/**
	 * Use ELPSUtils.getCurrentUser() to get the current logged-in user
	 * This method will return a null value for a webservice call.
	 * 
	 * @return Returns an instance of UserContext stored in the LocalThread 
	 */
	protected static UserContext getCurrentInstance() {
		return instance.get();
	}

	public static UserContext newInstance(String cupid, String cwsId,
			String ipAddress, String remoteHost) {
		UserContext context = new UserContext(cupid, cwsId, ipAddress, remoteHost);
		instance.remove();
		instance.set(context);
		return context;
	}

	public static void release() {
		instance.remove();
	}

	/**
	 * @return the user
	 */
	public User getUser() {
		return user;
	}

	@Override
	public String toString() {
		return this.user.toString();
	}
}
