package com.cat.bap.common;

import org.apache.commons.lang.StringUtils;

import com.cat.bap.util.PersonUtil;



/**
 * @author guntav
 * 
 *         Bean to hold logged-in user information. Should be instantiated using
 *         UserContext.
 */
public class User {
	private final String cupid;
	private final String cwsId;
	private final String ipAddress;
	private final String userName;
	private final String remoteHost;

	protected User(String cupid, String cwsId, String ipAddress,
			String remoteHost) {
		this.cupid = cupid;
		this.cwsId = cwsId;
		this.ipAddress = ipAddress;
		this.remoteHost = remoteHost;
		this.userName = StringUtils.isNotBlank(cupid) ? PersonUtil
				.getPersonName(cupid) : null;
	}

	/**
	 * @return the cupid
	 */
	public String getCupid() {
		return cupid;
	}

	/**
	 * @return the cwsId
	 */
	public String getCwsId() {
		return cwsId;
	}

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return the remoteHost
	 */
	public String getRemoteHost() {
		return remoteHost;
	}

	@Override
	public String toString() {
		return "\ncupid :" + this.cupid + "\n" + "cwsid :" + this.cwsId + "\n"
				+ "ipAddress :" + this.ipAddress + "\n" + "userName :"
				+ this.userName + "\n" + "remoteHost :" + this.remoteHost;
	}

	/**
	 * @return Returns an empty User object. 
	 */
	public static User getNullUser() {
		User nullUser = new User(null, null, null, null) {

			@Override
			public String toString() {
				return "";
			}
		};

		return nullUser;
	}
}
