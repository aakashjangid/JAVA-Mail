package com.cat.bap.dto;

import java.io.Serializable;
import java.util.List;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose This class is used as request for manage admin.
 */
public class UserMasterRequest implements Serializable {

  private static final long serialVersionUID = 1L;
  private Integer pageNumber;
  private Integer records;
  private String sortOrder;
  private String globalSearch;
  private String lang;
  private String isActive;
  private Boolean criteriaFlag;
  private Long regionId;
  private Long countryId;
  private String preferenceName;
  private String emailId;
  private String fullName;
  private String organizationName;
  private transient List<BAUserDetailsDto> selectedRecordsListForExportToExcel;
  private String brandAdvocateIds;
  
  public Integer getPageNumber() {
    return pageNumber;
  }
  public void setPageNumber(Integer pageNumber) {
    this.pageNumber = pageNumber;
  }
  public Integer getRecords() {
    return records;
  }
  public void setRecords(Integer records) {
    this.records = records;
  }
  public String getSortOrder() {
    return sortOrder;
  }
  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }
  public String getGlobalSearch() {
    return globalSearch;
  }
  public void setGlobalSearch(String globalSearch) {
    this.globalSearch = globalSearch;
  }
  
  public String getLang() {
    return lang;
  }
  public void setLang(String lang) {
    this.lang = lang;
  }
  
  public String getIsActive() {
	return isActive;
  }
  public void setIsActive(String isActive) {
	this.isActive = isActive;
  }
  
  public Boolean getCriteriaFlag() {
	return criteriaFlag;
  }
  public void setCriteriaFlag(Boolean criteriaFlag) {
	this.criteriaFlag = criteriaFlag;
  }
  
  public Long getRegionId() {
	return regionId;
  }
  public void setRegionId(Long regionId) {
	this.regionId = regionId;
  }
  public Long getCountryId() {
	return countryId;
  }
  public void setCountryId(Long countryId) {
	this.countryId = countryId;
  }
  public String getPreferenceName() {
	return preferenceName;
  }
  public void setPreferenceName(String preferenceName) {
	this.preferenceName = preferenceName;
  }
  public String getEmailId() {
	return emailId;
  }
  public void setEmailId(String emailId) {
	this.emailId = emailId;
  }
  public String getFullName() {
	return fullName;
  }
  public void setFullName(String fullName) {
	this.fullName = fullName;
  }
  public String getOrganizationName() {
	return organizationName;
  }
  public void setOrganizationName(String organizationName) {
	this.organizationName = organizationName;
  }
  public List<BAUserDetailsDto> getSelectedRecordsListForExportToExcel() {
	return selectedRecordsListForExportToExcel;
  }
  public void setSelectedRecordsListForExportToExcel(List<BAUserDetailsDto> selectedRecordsListForExportToExcel) {
	this.selectedRecordsListForExportToExcel = selectedRecordsListForExportToExcel;
  }
 
  public String getBrandAdvocateIds() {
	return brandAdvocateIds;
  }
  public void setBrandAdvocateIds(String brandAdvocateIds) {
	this.brandAdvocateIds = brandAdvocateIds;
  }
@Override
public String toString() {
	return "UserMasterRequest [pageNumber=" + pageNumber + ", records=" + records + ", sortOrder=" + sortOrder
			+ ", globalSearch=" + globalSearch + ", lang=" + lang + ", isActive=" + isActive + ", criteriaFlag="
			+ criteriaFlag + ", regionId=" + regionId + ", countryId=" + countryId + ", preferenceName="
			+ preferenceName + ", emailId=" + emailId + ", fullName=" + fullName + ", organizationName="
			+ organizationName + ", selectedRecordsListForExportToExcel=" + selectedRecordsListForExportToExcel
			+ ", brandAdvocateIds=" + brandAdvocateIds + "]";
}

}
