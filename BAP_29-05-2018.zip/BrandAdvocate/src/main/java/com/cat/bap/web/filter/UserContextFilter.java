package com.cat.bap.web.filter;

import java.io.IOException;
import java.net.InetAddress;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cat.bap.common.UserContext;
import com.cat.bap.util.PersonUtil;

public class UserContextFilter implements Filter {

	private static final Logger logger = LoggerFactory
			.getLogger(WebFilter.class);

	@Override
	public void init(FilterConfig config) throws ServletException {
		ServletContext context = config.getServletContext();
		context.log("UserContextFilter initialized");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain next) throws IOException, ServletException {

		String currentUserLogOnId = PersonUtil
				.getCurrentUserLogOnId((HttpServletRequest) request);

		String currentUserCupid = PersonUtil
				.getCurrentUserCupid((HttpServletRequest) request);

		final String remoteAddr = request.getRemoteAddr();
		String remoteHost = request.getRemoteHost();

		if (StringUtils.equals(remoteAddr, remoteHost)) {
			remoteHost = getRemoteHostNameFromIPAddress(remoteAddr);
		}

		UserContext.newInstance(currentUserCupid, currentUserLogOnId,
				remoteAddr, remoteHost);

		try {
			next.doFilter(request, response);
		} finally {
			UserContext.release();
		}

	}

	public void destroy() {
		// Lines Added to remove SonarLint Errors.
	}
	
	public static String getRemoteHostNameFromIPAddress(String ipAddress) {
		try {
			final InetAddress inet = InetAddress.getByName(ipAddress);

			return inet.getHostName();

		} catch (Exception e) {
			logger.error("UserContextFilter.getRemoteHostNameFromIPAddress() ", e);
		}

		return StringUtils.EMPTY;
	}
}
