package com.cat.bap.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date Apr 17, 2018
 * @purpose This class is used to handle all property file related operations.
 */
public class PropertyFileUtility {

  private static final Logger LOGGER = LoggerFactory.getLogger(PropertyFileUtility.class);

  /**
   * This is the class used for load property file.
   * 
   * @param propFileName
   * @return {@link Properties}
   * @throws IOException
   */
  public Properties loadPropertyFile(String propFileName) throws IOException {
    LOGGER
        .info("PropertyFileUtility's loadPropertyFile method");
    InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
    Properties properties = new Properties();
    if (inputStream != null) {
      Reader reader = new InputStreamReader(inputStream, "utf-8");
      properties.load(reader);
    } else {
      throw new FileNotFoundException(
    		 );
    }
    return properties;
  }
}
