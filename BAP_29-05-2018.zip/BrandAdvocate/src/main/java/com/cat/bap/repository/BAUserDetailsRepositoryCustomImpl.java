package com.cat.bap.repository;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.engine.spi.SessionImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.dto.UserMasterRequest;
import com.cat.bap.entity.AffiliationDescription;
import com.cat.bap.entity.Country;
import com.cat.bap.entity.Preferences;
import com.cat.bap.entity.Region;
import com.cat.bap.service.UserPreferencesDomainService;
import com.cat.bap.util.BrandAdvocateUtility;


/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
public class BAUserDetailsRepositoryCustomImpl implements BAUserDetailsRepositoryCustom {

	private static final Logger LOGGER = LoggerFactory.getLogger(BAUserDetailsRepositoryCustomImpl.class);
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Inject
	private UserPreferencesDomainService userPreferencesDomainService;
	
	@Override
	@SuppressWarnings("unchecked")
	public Map<String, Object> getAllAdminDetails(UserMasterRequest manageAdminRequest){

		Map<String, Object> response = new HashMap<>();
			
			List<BAUserDetailsDto> userMasterDTOs = new ArrayList<>();
			StringBuilder createQuery = new StringBuilder();
			
			
			if(manageAdminRequest.getCriteriaFlag()){
				
				createQuery
				.append("SELECT "
						+ "ba.brand_advocate_id,"
						+ "ba.cws_user_id,"
						+ "ba.last_name,"
						+ "ba.first_name,"
						+ "ba.preferred_first_name,"
						+ "ba.organization_name,"
						+ "ba.primary_email,"
						+ "ba.secondary_email,"
						+ "c.country_id,"
						+ "c.country_name,"
						+ "ba.facility_name,"
						+ "ba.building_name,"
						+ "ba.job_keywords,"
						+ "ba.affiliation_description_ui,"
//						+ "ba.affiliation_description,"
						+ "ba.brand_advocate_status,"
						+ "ba.comments,"
						+ "ba.notes,"
						+ "ba.registered_via,"
						+ "ba.registration_date,"
						+ "ba.registered_by,"
						+ "ba.modified_date,"
						+ "ba.modified_by,"
						+ "ba.managed_by, "
						+ "r.region_id,"
						+ "r.region_name, "
						+ "ba.cup_id "
						+ "FROM brand_advocate_details ba "
						+ "LEFT JOIN country_tbl c "
						+ "ON ba.country_id = c.country_id "
						+ "LEFT JOIN region_tbl r "
						+ "ON c.region_id = r.region_id "
						+ "LEFT JOIN user_preferences_tbl upt ON upt.brand_advocate_id = ba.brand_advocate_id LEFT JOIN preferences_tbl pt ON pt.preference_id = upt.preference_id "
						+ "WHERE ba.is_active = '"+ manageAdminRequest.getIsActive() + "' ");
				
				if(null!=manageAdminRequest.getRegionId()){
					createQuery.append(" AND r.region_id = "+manageAdminRequest.getRegionId());
				}
				if(null!=manageAdminRequest.getCountryId()){
					createQuery.append(" AND c.country_id = "+manageAdminRequest.getCountryId());
				}
				if(!BrandAdvocateUtility.isEmptyString(manageAdminRequest.getPreferenceName())){
					createQuery.append(" AND pt.preference_name = '"+manageAdminRequest.getPreferenceName()+"' ");
				}
				
				if(!BrandAdvocateUtility.isEmptyString(manageAdminRequest.getFullName())){
					String firstName = "";
					String[] fullNameStr = manageAdminRequest.getFullName().trim().split("\\s");//splits the string based on whitespace
					String lastName = fullNameStr[0];
					if(fullNameStr.length > 1){
						firstName = fullNameStr[1];
					}
					if(!BrandAdvocateUtility.isEmptyString(firstName)){
						createQuery.append(" AND ba.first_name LIKE '%"+firstName+"%' ");
					}
					if(!BrandAdvocateUtility.isEmptyString(lastName)){
						createQuery.append(" AND ba.last_name LIKE '%"+lastName+"%' ");
					}
				}
				if(!BrandAdvocateUtility.isEmptyString(manageAdminRequest.getOrganizationName())){
					createQuery.append(" AND ba.organization_name = '"+manageAdminRequest.getOrganizationName()+"' ");
				}
				
				if (!BrandAdvocateUtility.isEmptyString(manageAdminRequest.getSortOrder()) && UserMasterConstant.DESC.equalsIgnoreCase(manageAdminRequest.getSortOrder())){
					createQuery.append(" ORDER BY CASE WHEN ba.cws_user_id is null or ba.cws_user_id ='' then 1 else 0 end, ba.cws_user_id "+ manageAdminRequest.getSortOrder());
				}else{
					createQuery.append(" ORDER BY CASE WHEN ba.cws_user_id is null or ba.cws_user_id ='' then 1 else 0 end, ba.cws_user_id ");
				}
				
			}else{
				
				createQuery
				.append("SELECT "
						+ "ba.brand_advocate_id,"
						+ "ba.cws_user_id,"
						+ "ba.last_name,"
						+ "ba.first_name,"
						+ "ba.preferred_first_name,"
						+ "ba.organization_name,"
						+ "ba.primary_email,"
						+ "ba.secondary_email,"
						+ "c.country_id,"
						+ "c.country_name,"
						+ "ba.facility_name,"
						+ "ba.building_name,"
						+ "ba.job_keywords,"
						+ "ba.affiliation_description_ui,"
//						+ "ba.affiliation_description,"
						+ "ba.brand_advocate_status,"
						+ "ba.comments,"
						+ "ba.notes,"
						+ "ba.registered_via,"
						+ "ba.registration_date,"
						+ "ba.registered_by,"
						+ "ba.modified_date,"
						+ "ba.modified_by,"
						+ "ba.managed_by, "
						+ "r.region_id,"
						+ "r.region_name, "
						+ "ba.cup_id, "
						+ "ba.inactive_date "
						+ "FROM brand_advocate_details ba "
						+ "LEFT JOIN country_tbl c "
						+ "ON ba.country_id = c.country_id "
						+ "LEFT JOIN region_tbl r "
						+ "ON c.region_id = r.region_id "
						+ "WHERE ba.is_active = '"+ manageAdminRequest.getIsActive() + "' ");
				
				if (!BrandAdvocateUtility.isEmptyString(manageAdminRequest.getSortOrder()) && UserMasterConstant.DESC.equalsIgnoreCase(manageAdminRequest.getSortOrder())){
					createQuery.append(" ORDER BY CASE WHEN ba.modified_date is null then 1 else 0 end, ba.modified_date "+ manageAdminRequest.getSortOrder());
				}else{
					createQuery.append(" ORDER BY CASE WHEN ba.modified_date is null then 1 else 0 end, ba.modified_date ");
				}
			}

			Query query = entityManager.createNativeQuery(createQuery.toString());
			List<Object[]> dataList = query.getResultList();

			if (!BrandAdvocateUtility.isEmptyString(manageAdminRequest.getGlobalSearch())) {
				dataList = BrandAdvocateUtility.searchStringInList(dataList, manageAdminRequest.getGlobalSearch());
				response.put(UserMasterConstant.COUNT, dataList.size());
				if (null != manageAdminRequest.getPageNumber()
						&& null != manageAdminRequest.getRecords() && -1 != manageAdminRequest.getPageNumber()
						&& -1 != manageAdminRequest.getRecords()) {
					int fromIndex = manageAdminRequest.getPageNumber() * manageAdminRequest.getRecords();
					int toIndex = dataList.size() < (fromIndex + manageAdminRequest.getRecords()) ? dataList.size()
							: (fromIndex + manageAdminRequest.getRecords());
					dataList = dataList.subList(fromIndex, toIndex);
				}
			} else {
				response.put(UserMasterConstant.COUNT, dataList.size());
				if (null != manageAdminRequest.getPageNumber()
						&& null != manageAdminRequest.getRecords() && -1 != manageAdminRequest.getPageNumber()
						&& -1 != manageAdminRequest.getRecords()) {
					query.setFirstResult(manageAdminRequest.getPageNumber() * manageAdminRequest.getRecords());
					query.setMaxResults(manageAdminRequest.getRecords());
					dataList = query.getResultList();
				}
			}

			dataList.stream().forEach(record -> {
				BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
				if(!manageAdminRequest.getCriteriaFlag()){
				bAUserDetailsDto.setPreferencesStr(getPreferencesDataString(record[0] != null ? ((BigInteger) record[0]).longValue() : null,bAUserDetailsDto,manageAdminRequest.getIsActive()));
				//bAUserDetailsDto.setPreferences(userPreferencesDomainService.getPreferencesDetailsById(record[0] != null ? ((BigInteger) record[0]).longValue() : null));
				}
				bAUserDetailsDto.setBrandAdvocateId(record[0] != null ? ((BigInteger) record[0]).longValue() : null);
				bAUserDetailsDto.setCwsUserId(record[1] != null ? "" + (String) record[1] : "");
				bAUserDetailsDto.setLastName(record[2] != null ? "" + (String) record[2] : "");
				bAUserDetailsDto.setFirstName(record[3] != null ? "" + (String) record[3] : "");
				bAUserDetailsDto.setPreferredFirstName(record[4] != null ? "" + (String) record[4] : "");
				bAUserDetailsDto.setOrganizationName(record[5] != null ? "" + (String) record[5] : "");
				bAUserDetailsDto.setPrimaryEmail(record[6] != null ? "" + (String) record[6] : "");
				bAUserDetailsDto.setSecondaryEmail(record[7] != null ? "" + (String) record[7] : "");
				bAUserDetailsDto.setCountryId(record[8] != null ? ((BigInteger) record[8]).longValue() : null);
				bAUserDetailsDto.setCountryName(record[9] != null ? "" + (String) record[9] : "");
				bAUserDetailsDto.setFacilityName(record[10] != null ? "" + (String) record[10] : "");
				bAUserDetailsDto.setBuildingName(record[11] != null ? "" + (String) record[11] : "");
				bAUserDetailsDto.setJobKeywords(record[12] != null ? "" + (String) record[12] : "");
				bAUserDetailsDto.setAffiliationDescription(record[13] != null ? "" + (String) record[13] : "");
				bAUserDetailsDto.setBrandAdvocateStatus(record[14] != null ? "" + (String) record[14] : "");
				bAUserDetailsDto.setComments(record[15] != null ? "" + (String) record[15] : "");
				bAUserDetailsDto.setNotes(record[16] != null ? "" + (String) record[16] : "");
				bAUserDetailsDto.setRegisteredVia(record[17] != null ? "" + (String) record[17] : "");
				bAUserDetailsDto.setRegistrationDate(record[18] != null ? (Date) record[18] : null);
				bAUserDetailsDto.setCustomRegistrationDate(record[18] != null ? BrandAdvocateUtility.convertObjectToCustomDate(record[18]) : null);
				bAUserDetailsDto.setRegisteredBy(record[19] != null ? "" + (String) record[19] : "");
				bAUserDetailsDto.setModifiedDate(record[20] != null ? (Date) record[20] : null);
				bAUserDetailsDto.setCustomModifiedDate(record[20] != null ? BrandAdvocateUtility.convertObjectToCustomDate(record[20]) : null);
				bAUserDetailsDto.setModifiedBy(record[21] != null ? "" + (String) record[21] : "");
				bAUserDetailsDto.setManagedBy(record[22] != null ? "" + (String) record[22] : "");
				bAUserDetailsDto.setRegionId(record[23] != null ? ((BigInteger) record[23]).longValue() : null);
				bAUserDetailsDto.setRegionName(record[24] != null ? "" + (String) record[24] : "");
				bAUserDetailsDto.setCupId(record[25] != null ? "" + (String) record[25] : "");
				if(!manageAdminRequest.getCriteriaFlag()){
				bAUserDetailsDto.setCustomInactiveDate(record[26] != null ? BrandAdvocateUtility.convertObjectToCustomDate(record[26]) : null);
				}
				userMasterDTOs.add(bAUserDetailsDto);
			});
			
			response.put(UserMasterConstant.LIST, userMasterDTOs);

			return response;
	}
	
	public String getPreferencesDataString(Long brandAdvocateId,BAUserDetailsDto bAUserDetailsDto,String isActive){
		StringBuilder prefencesCreateQuery = new StringBuilder();
		prefencesCreateQuery.append("SELECT p.`preference_name` FROM `brand_advocate_details` ba INNER JOIN `user_preferences_tbl` up "
		+"ON ba.`brand_advocate_id` = up.`brand_advocate_id` INNER JOIN `preferences_tbl` p ON p.`preference_id` = up.`preference_id` WHERE ba.is_active = '"+ isActive + "' AND ba.`brand_advocate_id` = "+brandAdvocateId+"");
		Query preferencesQuery = entityManager.createNativeQuery(prefencesCreateQuery.toString());
		List<String> dataListForPreferences = preferencesQuery.getResultList();
		StringBuffer preferencesStr = new StringBuffer();
		String prefix = "";
		for(String str : dataListForPreferences){
			preferencesStr.append(prefix+" ");
			prefix = ",";
			if(str.trim().equalsIgnoreCase(UserMasterConstant.WEBINAR_INVITATIONS)){
				str = UserMasterConstant.WEBINAR;
			}else if(str.trim().equalsIgnoreCase(UserMasterConstant.BRAND_EVENT_COMMUNICATIONS)){
				str = UserMasterConstant.EVENT;
			}else if(str.trim().equalsIgnoreCase(UserMasterConstant.NEWSLETTERS)){
				str = UserMasterConstant.NEWSLETTER;
			}
			preferencesStr.append(str);
		}
		return preferencesStr.toString();
	}

/*	@Override
	@SuppressWarnings("unchecked")
	public Map<String, Object> getAllActiveBADetails() {

		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> userMasterDTOs = new ArrayList<>();

		String isActive = UserMasterConstant.FLAG_Y;

		StringBuilder createQuery = new StringBuilder();
		createQuery.append("SELECT ba.brand_advocate_id,ba.cws_user_id,ba.last_name,ba.first_name,ba.preferred_first_name,ba.organization_name,ba.primary_email,"
				+ "ba.secondary_email,c.country_id,c.country_name,ba.facility_name,ba.building_name,ba.job_keywords,ba.affiliation_description,ba.brand_advocate_status,ba.comments,"
				+ "ba.notes,ba.registered_via,ba.registration_date,ba.registered_by,ba.modified_date,ba.modified_by,ba.managed_by,ba.cup_id,r.region_id,r.region_name FROM brand_advocate_details ba LEFT JOIN country_tbl c "
				+ "ON ba.country_id = c.country_id LEFT JOIN region_tbl r ON c.region_id = r.region_id  WHERE ba.is_active = '"
				+ isActive + "' ");
		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();
		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		dataList.stream().forEach(record -> {
			bAUserDetailsDto.setBrandAdvocateId(record[0] != null ? ((BigInteger) record[0]).longValue() : null);
			bAUserDetailsDto.setCwsUserId(record[1] != null ? "" + (String) record[1] : "");
			bAUserDetailsDto.setLastName(record[2] != null ? "" + (String) record[2] : "");
			bAUserDetailsDto.setFirstName(record[3] != null ? "" + (String) record[3] : "");
			bAUserDetailsDto.setPreferredFirstName(record[4] != null ? "" + (String) record[4] : "");
			bAUserDetailsDto.setOrganizationName(record[5] != null ? "" + (String) record[5] : "");
			bAUserDetailsDto.setPrimaryEmail(record[6] != null ? "" + (String) record[6] : "");
			bAUserDetailsDto.setSecondaryEmail(record[7] != null ? "" + (String) record[7] : "");
			bAUserDetailsDto.setCountryId(record[8] != null ? ((BigInteger) record[8]).longValue() : null);
			bAUserDetailsDto.setCountryName(record[9] != null ? "" + (String) record[9] : "");
			bAUserDetailsDto.setFacilityName(record[10] != null ? "" + (String) record[10] : "");
			// bAUserDetailsDto.setBuildingName(record[11] != null ? "" +
			// (String) record[11] : "");
			bAUserDetailsDto.setJobKeywords(record[12] != null ? "" + (String) record[12] : "");
			bAUserDetailsDto.setAffiliationDescription(record[13] != null ? "" + (String) record[13] : "");
			bAUserDetailsDto.setBrandAdvocateStatus(record[14] != null ? "" + (String) record[14] : "");
			bAUserDetailsDto.setCupId(record[23] != null ? "" + (String) record[23] : "");
			bAUserDetailsDto.setRegionId(record[24] != null ? ((BigInteger) record[24]).longValue() : null);
			bAUserDetailsDto.setRegionName(record[25] != null ? "" + (String) record[25] : "");

			userMasterDTOs.add(bAUserDetailsDto);
		});

		response.put(UserMasterConstant.LIST, userMasterDTOs);
		return response;
	}*/

	
	@Override
	public List<BAUserDetailsDto> getAllActiveBADetails() {
		
		List<BAUserDetailsDto> baUserDtoList = new ArrayList<>();
		StringBuilder createQuery = new StringBuilder();

			createQuery.append("SELECT "
					+ "ba.brand_advocate_id,"
					+ "ba.cws_user_id,"
					+ "ba.last_name,"
					+ "ba.first_name,"
					+ "ba.preferred_first_name,"
					+ "ba.organization_name,"
					+ "ba.primary_email,"
					+ "c.country_id,"
					+ "c.country_name, "
					+ "c.country_code, "
					+ "ba.facility_name,"
					+ "ba.building_name,"
//					+ "ba.affiliation_description_ui,"
					+ "ba.affiliation_description,"
					+ "ba.cup_id,"
					+ "secondary_email,"
					+ "ba.comments,"
					+ "ba.notes,"
					+ "ba.job_keywords,"
					+ "ba.registered_via,"
					+ "ba.registration_date,"
					+ "ba.registered_by, "
					+ "brand_advocate_status, " 
					+ "ba.modified_date, "
					+ "ba.modified_by, "
					+ "ba.managed_by "
					+ "FROM "
					+ "brand_advocate_details ba LEFT JOIN country_tbl c "
					+ "ON ba.country_id = c.country_id where is_active='"
					+ UserMasterConstant.FLAG_Y
					+ "' and ba.cup_id <> ''");	
			
			Query query = entityManager.createNativeQuery(createQuery.toString());
			
			List<Object[]> dataList = query.getResultList();
			
			dataList.stream().forEach(record -> {
				
				BAUserDetailsDto bAUserDetailsDto = null;
				bAUserDetailsDto = new BAUserDetailsDto();
				
				bAUserDetailsDto.setBrandAdvocateId(record[0] != null ? ((BigInteger) record[0]).longValue() : null);
				bAUserDetailsDto.setCwsUserId(record[1] != null ? "" + (String) record[1] : "");
				bAUserDetailsDto.setLastName(record[2] != null ? "" + (String) record[2] : "");
				bAUserDetailsDto.setFirstName(record[3] != null ? "" + (String) record[3] : "");
				bAUserDetailsDto.setPreferredFirstName(record[4] != null ? "" + (String) record[4] : "");
				bAUserDetailsDto.setOrganizationName(record[5] != null ? "" + (String) record[5] : "");
				bAUserDetailsDto.setPrimaryEmail(record[6] != null ? "" + (String) record[6] : "");
				bAUserDetailsDto.setCountryId(record[7] != null ? ((BigInteger) record[7]).longValue() : null);
				bAUserDetailsDto.setCountryName(record[8] != null ? "" + (String) record[8] : "");
				bAUserDetailsDto.setCountryCode(record[9] != null ? "" + (String) record[9] : "");
				bAUserDetailsDto.setFacilityName(record[10] != null ? "" + (String) record[10] : "");
				bAUserDetailsDto.setBuildingName(record[11] != null ? "" + (String) record[11] : "");
				bAUserDetailsDto.setAffiliationDescription(record[12] != null ? "" + (String) record[12] : "");
				bAUserDetailsDto.setCupId(record[13] != null ? "" + (String) record[13] : "");
				
				bAUserDetailsDto.setSecondaryEmail(record[14] != null ? "" + (String) record[14] : "");
				bAUserDetailsDto.setComments(record[15] != null ? "" + (String) record[15] : "");
				bAUserDetailsDto.setNotes(record[16] != null ? "" + (String) record[16] : "");
				bAUserDetailsDto.setJobKeywords(record[17] != null ? "" + (String) record[17] : "");
				bAUserDetailsDto.setRegisteredVia(record[18] != null ? "" + (String) record[18] : "");
				bAUserDetailsDto.setRegistrationDate(record[19] != null ?  (Date) record[19] : null);
				bAUserDetailsDto.setRegisteredBy(record[20] != null ? "" + (String) record[20] : "");
				
				bAUserDetailsDto.setBrandAdvocateStatus(record[21] != null ? "" + (String) record[21] : "");
				bAUserDetailsDto.setModifiedDate(record[22] != null ?  (Date) record[22] : null);
				bAUserDetailsDto.setModifiedBy(record[23] != null ? "" + (String) record[23] : "");
				bAUserDetailsDto.setManagedBy(record[24] != null ? "" + (String) record[24] : "");
				
				baUserDtoList.add(bAUserDetailsDto);
			});		
			
		return baUserDtoList;
	}	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CluesDataDetailDto> getCWSIDFromBADetils() {

		StringBuilder createQuery = new StringBuilder();
		createQuery.append("select cws_User_Id FROM brand_advocate_details WHERE cup_Id = ' ' ");
		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<CluesDataDetailDto> dataList = query.getResultList();
		return dataList;
	}



/*	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getBAUserDetailsBasedOnCwsIdOrEmailId(String cwsUserId , String emailId) {

		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();

		StringBuilder createQuery = new StringBuilder();
		createQuery
				.append("select affiliation_description,last_name,first_name,preferred_first_name,organization_name,facility_name,country_id,primary_email,brand_advocate_id,registered_via,building_name,job_keywords,secondary_email,notes FROM brand_advocate_details WHERE");

		if (!BrandAdvocateUtility.isEmptyString(cwsUserId))
			createQuery.append("cws_User_Id = '"+ cwsUserId+ "' ");
		
		if (!BrandAdvocateUtility.isEmptyString(emailId))
			createQuery.append("primary_email = '"+ emailId+ "' ");
		
		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		dataList.stream().forEach(record -> {

			bAUserDetailsDto.setAffiliationDescription(record[0] != null ? "" + (String) record[0] : "");
			bAUserDetailsDto.setLastName(record[1] != null ? "" + (String) record[1] : "");
			bAUserDetailsDto.setFirstName(record[2] != null ? "" + (String) record[2] : "");
			bAUserDetailsDto.setPreferredFirstName(record[3] != null ? "" + (String) record[3] : "");
			bAUserDetailsDto.setOrganizationName(record[4] != null ? "" + (String) record[4] : "");
			bAUserDetailsDto.setFacilityName(record[5] != null ? "" + (String) record[5] : "");
			bAUserDetailsDto.setCountryId(record[6] != null ? ((BigInteger) record[6]).longValue() : null);
			bAUserDetailsDto.setPrimaryEmail(record[7] != null ? "" + (String) record[7] : "");
			bAUserDetailsDto.setBrandAdvocateId(record[8] != null ? ((BigInteger) record[8]).longValue() : null);
			bAUserDetailsDto.setRegisteredVia(record[9] != null ? "" + (String) record[9] : "");
			bAUserDetailsDto.setBuildingName(record[10] != null ? "" + (String) record[10] : "");
			bAUserDetailsDto.setJobKeywords(record[11] != null ? "" + (String) record[11] : "");
			bAUserDetailsDto.setSecondaryEmail(record[12] != null ? "" + (String) record[12] : "");
			bAUserDetailsDto.setNotes(record[13] != null ? "" + (String) record[13] : "");

			bAUserDetailsDtos.add(bAUserDetailsDto);
		});
		List<Preferences> preferences = userPreferencesDomainService.getPreferencesDetailsById(bAUserDetailsDto.getBrandAdvocateId());
		bAUserDetailsDto.setPreferences(preferences);
		if(!bAUserDetailsDtos.isEmpty()){
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos.get(0));
		}else{
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos);
		}
		return response;

	}*/
	
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getBAUserDetailsBasedOnIds(String cwsUserId , String emailId , String cupId) {

		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();

		StringBuilder createQuery = new StringBuilder();
		createQuery
				.append("select "
						+ "affiliation_description_ui,"
						+ "last_name,"
						+ "first_name,"
						+ "preferred_first_name,"
						+ "organization_name,"
						+ "facility_name,"
						+ "country_id,"
						+ "primary_email,"
						+ "brand_advocate_id,"
						+ "registered_via,"
						+ "building_name,"
						+ "job_keywords,"
						+ "secondary_email,"
						+ "notes,cup_id,"
						+ "registration_date,"
						+ "registered_by,"
						+ "brand_advocate_status,"
						+ "comments,"
						+ "cws_user_id, "
						+ "affiliation_description "						
						+ "FROM brand_advocate_details WHERE ");

		if (!BrandAdvocateUtility.isEmptyString(cwsUserId))
			createQuery.append("cws_user_id = '"+ cwsUserId+ "' ");
		
		if (!BrandAdvocateUtility.isEmptyString(emailId))
			createQuery.append("primary_email = '"+ emailId+ "' ");
		
		if (!BrandAdvocateUtility.isEmptyString(cupId))
			createQuery.append("cup_id = '"+ cupId+ "' ");
		
		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		dataList.stream().forEach(record -> {

			bAUserDetailsDto.setMappedAffiliationName(record[0] != null ? "" + (String) record[0] : "");
//			bAUserDetailsDto.setAffiliationDescription(record[0] != null ? "" + (String) record[0] : "");
			bAUserDetailsDto.setLastName(record[1] != null ? "" + (String) record[1] : "");
			bAUserDetailsDto.setFirstName(record[2] != null ? "" + (String) record[2] : "");
			bAUserDetailsDto.setPreferredFirstName(record[3] != null ? "" + (String) record[3] : "");
			bAUserDetailsDto.setOrganizationName(record[4] != null ? "" + (String) record[4] : "");
			bAUserDetailsDto.setFacilityName(record[5] != null ? "" + (String) record[5] : "");
			bAUserDetailsDto.setCountryId(record[6] != null ? ((BigInteger) record[6]).longValue() : null);
			bAUserDetailsDto.setPrimaryEmail(record[7] != null ? "" + (String) record[7] : "");
			bAUserDetailsDto.setBrandAdvocateId(record[8] != null ? ((BigInteger) record[8]).longValue() : null);
			bAUserDetailsDto.setRegisteredVia(record[9] != null ? "" + (String) record[9] : "");
			bAUserDetailsDto.setBuildingName(record[10] != null ? "" + (String) record[10] : "");
			bAUserDetailsDto.setJobKeywords(record[11] != null ? "" + (String) record[11] : "");
			bAUserDetailsDto.setSecondaryEmail(record[12] != null ? "" + (String) record[12] : "");
			bAUserDetailsDto.setNotes(record[13] != null ? "" + (String) record[13] : "");
			bAUserDetailsDto.setCupId(record[14] != null ? "" + (String) record[14] : "");
			bAUserDetailsDto.setRegistrationDate(record[15] != null ? (Date) record[15] : null);
			bAUserDetailsDto.setRegisteredBy(record[16] != null ? (String) record[16] : "");
			bAUserDetailsDto.setBrandAdvocateStatus(record[17] != null ? (String) record[17] : "");
			bAUserDetailsDto.setComments(record[18] != null ? (String) record[18] : "");
			bAUserDetailsDto.setCwsUserId(record[19] != null ? (String) record[19] : "");
			bAUserDetailsDto.setAffiliationDescription(record[20] != null ? "" + (String) record[20] : "");

			bAUserDetailsDtos.add(bAUserDetailsDto);
		});
		List<Preferences> preferences = userPreferencesDomainService.getPreferencesDetailsById(bAUserDetailsDto.getBrandAdvocateId());
		bAUserDetailsDto.setPreferences(preferences);
		if(!bAUserDetailsDtos.isEmpty()){
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos.get(0));
		}else{
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos);
		}
		return response;

	}
	

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getBAUserDetailsByCupId(String cupId) {

		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();

		StringBuilder createQuery = new StringBuilder();
		createQuery
		.append("select "
				+ "affiliation_description_ui,"
//				+ "affiliation_description,"
				+ "last_name,"
				+ "first_name,"
				+ "preferred_first_name,"
				+ "organization_name,"
				+ "facility_name,"
				+ "country_id,"
				+ "primary_email,"
				+ "brand_advocate_id,"
				+ "registered_via,"
				+ "building_name,"
				+ "job_keywords,"
				+ "secondary_email,"
				+ "notes "
				+ "FROM brand_advocate_details WHERE cup_id = '"
				+ cupId +"' ");

		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		dataList.stream().forEach(record -> {

			bAUserDetailsDto.setAffiliationDescription(record[0] != null ? "" + (String) record[0] : "");
			bAUserDetailsDto.setLastName(record[1] != null ? "" + (String) record[1] : "");
			bAUserDetailsDto.setFirstName(record[2] != null ? "" + (String) record[2] : "");
			bAUserDetailsDto.setPreferredFirstName(record[3] != null ? "" + (String) record[3] : "");
			bAUserDetailsDto.setOrganizationName(record[4] != null ? "" + (String) record[4] : "");
			bAUserDetailsDto.setFacilityName(record[5] != null ? "" + (String) record[5] : "");
			bAUserDetailsDto.setCountryId(record[6] != null ? ((BigInteger) record[6]).longValue() : null);
			bAUserDetailsDto.setPrimaryEmail(record[7] != null ? "" + (String) record[7] : "");
			bAUserDetailsDto.setBrandAdvocateId(record[8] != null ? ((BigInteger) record[8]).longValue() : null);
			bAUserDetailsDto.setRegisteredVia(record[9] != null ? "" + (String) record[9] : "");
			bAUserDetailsDto.setBuildingName(record[10] != null ? "" + (String) record[10] : "");
			bAUserDetailsDto.setJobKeywords(record[11] != null ? "" + (String) record[11] : "");
			bAUserDetailsDto.setSecondaryEmail(record[12] != null ? "" + (String) record[12] : "");
			bAUserDetailsDto.setNotes(record[13] != null ? "" + (String) record[13] : "");

			bAUserDetailsDtos.add(bAUserDetailsDto);
		});
		List<Preferences> preferences = userPreferencesDomainService.getPreferencesDetailsById(bAUserDetailsDto.getBrandAdvocateId());
		bAUserDetailsDto.setPreferences(preferences);
		if(!bAUserDetailsDtos.isEmpty()){
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos.get(0));
		}else{
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos);
		}
		return response;

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getBAUserDetailsByCwsUserId(String cwsUserId) {

		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();

		StringBuilder createQuery = new StringBuilder();
		createQuery
				.append("select "
						+ "affiliation_description_ui,"
//						+ "affiliation_description,"
						+ "last_name,"
						+ "first_name,"
						+ "preferred_first_name,"
						+ "organization_name,"
						+ "facility_name,"
						+ "country_id,"
						+ "primary_email,"
						+ "brand_advocate_id,"
						+ "registered_via,"
						+ "building_name,"
						+ "job_keywords,"
						+ "secondary_email,"
						+ "notes "
						+ "FROM brand_advocate_details WHERE cws_User_Id = '"
						+ cwsUserId +"' ");

		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		dataList.stream().forEach(record -> {

			bAUserDetailsDto.setAffiliationDescription(record[0] != null ? "" + (String) record[0] : "");
			bAUserDetailsDto.setLastName(record[1] != null ? "" + (String) record[1] : "");
			bAUserDetailsDto.setFirstName(record[2] != null ? "" + (String) record[2] : "");
			bAUserDetailsDto.setPreferredFirstName(record[3] != null ? "" + (String) record[3] : "");
			bAUserDetailsDto.setOrganizationName(record[4] != null ? "" + (String) record[4] : "");
			bAUserDetailsDto.setFacilityName(record[5] != null ? "" + (String) record[5] : "");
			bAUserDetailsDto.setCountryId(record[6] != null ? ((BigInteger) record[6]).longValue() : null);
			bAUserDetailsDto.setPrimaryEmail(record[7] != null ? "" + (String) record[7] : "");
			bAUserDetailsDto.setBrandAdvocateId(record[8] != null ? ((BigInteger) record[8]).longValue() : null);
			bAUserDetailsDto.setRegisteredVia(record[9] != null ? "" + (String) record[9] : "");
			bAUserDetailsDto.setBuildingName(record[10] != null ? "" + (String) record[10] : "");
			bAUserDetailsDto.setJobKeywords(record[11] != null ? "" + (String) record[11] : "");
			bAUserDetailsDto.setSecondaryEmail(record[12] != null ? "" + (String) record[12] : "");
			bAUserDetailsDto.setNotes(record[13] != null ? "" + (String) record[13] : "");

			bAUserDetailsDtos.add(bAUserDetailsDto);
		});
		List<Preferences> preferences = userPreferencesDomainService.getPreferencesDetailsById(bAUserDetailsDto.getBrandAdvocateId());
		bAUserDetailsDto.setPreferences(preferences);
		if(!bAUserDetailsDtos.isEmpty()){
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos.get(0));
		}else{
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos);
		}
		return response;

	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> getBAUserDetailsByEmailId(String emailId) {

		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();

		StringBuilder createQuery = new StringBuilder();
		createQuery
				.append("select "
						+ "affiliation_description_ui,"
//						+ "affiliation_description,"
						+ "last_name,"
						+ "first_name,"
						+ "preferred_first_name,"
						+ "organization_name,"
						+ "facility_name,"
						+ "country_id,"
						+ "primary_email,"
						+ "brand_advocate_id,"
						+ "registered_via,"
						+ "building_name,"
						+ "job_keywords,"
						+ "secondary_email,"
						+ "notes "
						+ "FROM brand_advocate_details WHERE primary_email = '"
						+ emailId +"' ");

		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		dataList.stream().forEach(record -> {

			bAUserDetailsDto.setAffiliationDescription(record[0] != null ? "" + (String) record[0] : "");
			bAUserDetailsDto.setLastName(record[1] != null ? "" + (String) record[1] : "");
			bAUserDetailsDto.setFirstName(record[2] != null ? "" + (String) record[2] : "");
			bAUserDetailsDto.setPreferredFirstName(record[3] != null ? "" + (String) record[3] : "");
			bAUserDetailsDto.setOrganizationName(record[4] != null ? "" + (String) record[4] : "");
			bAUserDetailsDto.setFacilityName(record[5] != null ? "" + (String) record[5] : "");
			bAUserDetailsDto.setCountryId(record[6] != null ? ((BigInteger) record[6]).longValue() : null);
			bAUserDetailsDto.setPrimaryEmail(record[7] != null ? "" + (String) record[7] : "");
			bAUserDetailsDto.setBrandAdvocateId(record[8] != null ? ((BigInteger) record[8]).longValue() : null);
			bAUserDetailsDto.setRegisteredVia(record[9] != null ? "" + (String) record[9] : "");
			bAUserDetailsDto.setBuildingName(record[10] != null ? "" + (String) record[10] : "");
			bAUserDetailsDto.setJobKeywords(record[11] != null ? "" + (String) record[11] : "");
			bAUserDetailsDto.setSecondaryEmail(record[12] != null ? "" + (String) record[12] : "");
			bAUserDetailsDto.setNotes(record[13] != null ? "" + (String) record[13] : "");

			bAUserDetailsDtos.add(bAUserDetailsDto);
		});
		List<Preferences> preferences = userPreferencesDomainService.getPreferencesDetailsById(bAUserDetailsDto.getBrandAdvocateId());
		bAUserDetailsDto.setPreferences(preferences);
		if(!bAUserDetailsDtos.isEmpty()){
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos.get(0));
		}else{
			response.put(UserMasterConstant.LIST, bAUserDetailsDtos);
		}
		return response;

	}

/*	@Transactional
	public int executeBatchNewUsers(List<CluesDataDetailDto> validCluesUsers, String userName, String baVia) {

		*//*************** Batch Insert start ***************//*
			int i=0;
			int batchSize=30;
			
			
//			EntityManager entityManager = emf.createEntityManager();
			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			
			for (CluesDataDetailDto cluesDataDetailDto : validCluesUsers) {
		        	BAUserDetails baUser = null;
		        	baUser = new BAUserDetails();
		        	
		        	Country country = null;
		        	country = new Country();
		        	country.setCountryId(cluesDataDetailDto.getCountryId());
		        	country.setCountryCode(cluesDataDetailDto.getCountryCode());
		        	country.setCountryName(cluesDataDetailDto.getCountryName());
		        	
		        	baUser.setCwsUserId(cluesDataDetailDto.getCwsUserId());
		        	baUser.setLastName(cluesDataDetailDto.getLastName());
		        	baUser.setFirstName(cluesDataDetailDto.getFirstName());
		        	baUser.setPreferredFirstName(cluesDataDetailDto.getPreferredFirstName());
		        	baUser.setOrganizationName(cluesDataDetailDto.getOrganizationName());
		        	baUser.setPrimaryEmail(cluesDataDetailDto.getSecondaryEmail());
		        	baUser.setSecondaryEmail(cluesDataDetailDto.getPrimaryEmail());
		        	baUser.setCountry(country);
		        	baUser.setFacilityName(cluesDataDetailDto.getFacilityName());
		        	baUser.setJobKeywords(cluesDataDetailDto.getJobKeywords());
		        	baUser.setAffiliationDescription(cluesDataDetailDto.getAffiliationDescription());
		        	baUser.setBrandAdvocateStatus(UserMasterConstant.BRAND_ADVOCATE);
		        	
		        	baUser.setRegistrationDate(new java.sql.Timestamp(new java.util.Date().getTime()));
		        	baUser.setRegisteredBy(userName);
		        	baUser.setRegisteredVia(baVia);
		        	baUser.setManagedBy(UserMasterConstant.MANAGEDBY_SYSTEM);
		        	
//		        	entityManager.persist(baUser);
		        	baUserDetailsRepository.save(baUser);
		        	
		            if (i % batchSize == 0 && i > 0) {
		            	entityManager.flush();
		            	entityManager.clear();
		            }
		            i++;
			}
			//entityManager.getTransaction().commit();
			
			*//*************** Batch Insert end ***************//*

		return 0;
	}	
 */
/*	@Transactional
	public int executeBatchForExistingUsers(List<BAUserDetailsDto> existingBAPUsers, String userName, String baVia) {
		
		*//*************** Batch Insert start ***************//*
		int i=0;
		int batchSize=30;
		
//		EntityManager entityManager = emf.createEntityManager();
		//EntityTransaction transaction = entityManager.getTransaction();
		//transaction.begin();
			
			for (BAUserDetailsDto existingBAPUser : existingBAPUsers) {
				
				BAUserDetails baUser = null;
	        	baUser = new BAUserDetails();
	        	
	        	Country country = null;
	        	country = new Country();
	        	country.setCountryId(existingBAPUser.getCountryId());
//	        	country.setCountryCode(existingBAPUser.getCountryCode());
//	        	country.setCountryName(existingBAPUser.getCountryName());
				
	        	baUser.setCwsUserId(existingBAPUser.getCwsUserId());
	        	baUser.setLastName(existingBAPUser.getLastName());
	        	baUser.setFirstName(existingBAPUser.getFirstName());
	        	baUser.setPreferredFirstName(existingBAPUser.getPreferredFirstName());
	        	baUser.setOrganizationName(existingBAPUser.getOrganizationName());
	        	baUser.setPrimaryEmail(existingBAPUser.getSecondaryEmail());
	        	baUser.setSecondaryEmail(existingBAPUser.getPrimaryEmail());
	        	baUser.setCountry(country);
	        	baUser.setFacilityName(existingBAPUser.getFacilityName());
	        	baUser.setJobKeywords(existingBAPUser.getJobKeywords());
	        	baUser.setAffiliationDescription(existingBAPUser.getAffiliationDescription());
	        	baUser.setBrandAdvocateStatus(UserMasterConstant.BRAND_ADVOCATE);
	        	
	        	baUser.setRegistrationDate(new java.sql.Timestamp(new java.util.Date().getTime()));
	        	baUser.setRegisteredBy(userName);
	        	baUser.setRegisteredVia(baVia);
	        	
	        	
	        	baUser.setBrandAdvocateId(existingBAPUser.getBrandAdvocateId());;
	        	baUser.setModifiedBy(userName);
	        	baUser.setModifiedDate(new java.sql.Timestamp(new java.util.Date().getTime()));
	        	baUser.setIsActive(true);
		        	
//				entityManager.merge(baUser);
	        	baUserDetailsRepository.save(baUser);
	        	
	            if (i % batchSize == 0 && i > 0) {
	            	entityManager.flush();
	            	entityManager.clear();
	            }
	            i++;
		}
		///entityManager.getTransaction().commit();
			
			*//*************** Batch Insert end ***************//*
			
		return 0;
	}*/
	
	public void executeBatchNewUserNativeSQLBatch(List<CluesDataDetailDto> validCluesUsers, String userName, String baVia, List<AffiliationDescription> listAffiliationDescriptio) throws SQLException {
		
		/*************** SqL Batch Insert start ***************/

		PreparedStatement ps = null;
		Connection connection= null;
		
		try {
		
        SessionImplementor si = (SessionImplementor) entityManager.unwrap(Session.class);
        connection= si.getJdbcConnectionAccess().obtainConnection();			
       				
		StringBuilder createQuery = new StringBuilder("insert into brand_advocate_details  "
				+ "("
				+ "cws_user_id,"			
				+ "last_name,"
				+ "first_name,"
				+ "preferred_first_name,"
				+ "organization_name,"
				+ "primary_email,"
				+ "secondary_email,"
				+ "country_id,"
				+ "facility_name,"
				+ "building_name,"
				+ "job_keywords,"
				+ "affiliation_description,"
				+ "affiliation_description_ui,"
				+ "brand_advocate_status,"
				+ "registered_via,"
				+ "registration_date,"
				+ "registered_by,"
				+ "managed_by,"
				+ "cup_id"
				+ ") values (?,?,?,		?,?,?,		?,?,?,		?,?,?,		?,?,?,		?,?,?,	?)");
				
				ps = connection.prepareStatement(createQuery.toString());
				
				for (CluesDataDetailDto cluesDataDetailDto : validCluesUsers) {
//		        	Country country = null;
//		        	country = new Country();
//		        	country.setCountryId(cluesDataDetailDto.getCountryId());
//		        	country.setCountryCode(cluesDataDetailDto.getCountryCode());
//		        	country.setCountryName(cluesDataDetailDto.getCountryName());

					ps.setString(1, cluesDataDetailDto.getCwsUserId());
					ps.setString(2, cluesDataDetailDto.getLastName()); 
					ps.setString(3, cluesDataDetailDto.getFirstName());
					ps.setString(4, cluesDataDetailDto.getPreferredFirstName()); 
					ps.setString(5, cluesDataDetailDto.getOrganizationName());
					ps.setString(6,	cluesDataDetailDto.getPrimaryEmail());
					ps.setString(7, cluesDataDetailDto.getSecondaryEmail());
					if(null!=cluesDataDetailDto.getCountryId()){
						ps.setLong(8, cluesDataDetailDto.getCountryId());
					}else {
						ps.setNull(8, java.sql.Types.BIGINT);
					}
					ps.setString(9,cluesDataDetailDto.getFacilityName());
					ps.setString(10, cluesDataDetailDto.getWorkLocation());
					ps.setString(11, cluesDataDetailDto.getJobKeywords());
					ps.setString(12, cluesDataDetailDto.getAffiliationDescription());
					
					String affName = getAffiliationNameOnDesc( listAffiliationDescriptio, cluesDataDetailDto.getAffiliationDescription());
					ps.setString(13, affName);
					
					ps.setString(14, UserMasterConstant.BRAND_ADVOCATE);
					ps.setString(15,baVia);
					ps.setTimestamp(16, new java.sql.Timestamp(new Date().getTime()));
					ps.setString(17,userName);
					ps.setString(18, UserMasterConstant.MANAGEDBY_SYSTEM);
					ps.setString(19, cluesDataDetailDto.getCupId());
				    
					ps.addBatch();
				}
				ps.executeBatch();
				
				
			} catch (Exception e) {
				//Logger.getInstance(getClass()).error(e.getMessage());
				LOGGER.error("Error while Batch insertion. ",e);
			} finally {
				if(null!=ps)
					ps.close();
				if(null!=connection)
					connection.close();
			}
	}


	/**
	 * @param listAffiliationDescription
	 * @param affiliationDescription
	 * @return
	 */
	private String getAffiliationNameOnDesc(List<AffiliationDescription> listAffiliationDescription, String affiliationDescription) {
	
		for (AffiliationDescription affDescObj : listAffiliationDescription) {
			if(affDescObj.getAffiliationDesc().equals(affiliationDescription)){
				return affDescObj.getAffiliationNameUI();
			}
		}
		
	return "";
}
/*	private String getAffiliationNameOnDesc(List<String> dealerList,List<String> empList,List<String> otherList, String affiliationDescription) {
		
		if(dealerList.contains(affiliationDescription)){
			return UserMasterConstant.AFF_TYPE_DEALER;	
		}
		
		if(empList.contains(affiliationDescription)){
			return UserMasterConstant.AFF_TYPE_EMPLOYEE;	
		}
		
		if(otherList.contains(affiliationDescription)){
			return UserMasterConstant.AFF_TYPE_OTHER;	
		}
		return "";
	}
*/
	public void executeBatchNewUserPreferencesNativeSQLBatch(List<CluesDataDetailDto> validCluesUsers, boolean isCWS) throws SQLException{
		
		/*************** SqL Batch Insert start ***************/

		PreparedStatement preStmt = null;
		Connection connection= null;
		
		try {
		
        SessionImplementor si = (SessionImplementor) entityManager.unwrap(Session.class);
        connection= si.getJdbcConnectionAccess().obtainConnection();			
        
        /** Prepare a query to fetch newly added CWSIDs/EmailsIds 
         * ***************************************************** **/
        StringBuilder queryForIDs = new StringBuilder("select brand_advocate_id from brand_advocate_details  "
        		+ "where ");
        		
        if(isCWS){
        	queryForIDs.append("cws_user_id IN (");
        }else{
        	queryForIDs.append("primary_email IN (");
        }
        
        StringBuilder queryForIDs1 = new StringBuilder();
        
		 for (CluesDataDetailDto cluesDataDetailDto : validCluesUsers) {
	        	
			 queryForIDs1.append("'");
			 if(isCWS){
				 queryForIDs1.append(cluesDataDetailDto.getCwsUserId());
			 }
			 if(!isCWS){
				 queryForIDs1.append(cluesDataDetailDto.getPrimaryEmail());
			 }
			 queryForIDs1.append("',");
			 	
	        }
		 
		 String commSepratedValue = queryForIDs1.substring(0, queryForIDs1.length() - 1);
			
		 queryForIDs.append(commSepratedValue).append(")");
		        		
		 preStmt = connection.prepareStatement(queryForIDs.toString());
        
        ResultSet result = preStmt.executeQuery();
        List<String> listOfBAIds = new ArrayList<>();
        
        while (result.next()) {
        	listOfBAIds.add(result.getString("brand_advocate_id"));
			
		}
        /*if(null!=preStmt){
			preStmt.close();
        }*/
        
        /** Prepare a query to fetch all preferences added CWSIDs/EmailsIds 
         * ***************************************************** **/
        StringBuilder queryFetchUserPref = new StringBuilder("select preference_id from preferences_tbl");
        		
		preStmt = connection.prepareStatement(queryFetchUserPref.toString());
        
        ResultSet resultData = preStmt.executeQuery();
        List<Long> listOfPrefIds = new ArrayList<>();
        
        while (resultData.next()) {
        	listOfPrefIds.add(resultData.getLong("preference_id"));
		}
        
        /** Prepare a query to insert into user preference table for uploaded CWS/EmailsIds 
         * ***************************************************** **/
        
        StringBuilder createQuery = new StringBuilder("insert into user_preferences_tbl  "
				+ "("
				+ "brand_advocate_id,"			
				+ "preference_id"
				+ ") values (?,?)");
				
				preStmt = connection.prepareStatement(createQuery.toString());
				
				for (Long prefs : listOfPrefIds) {
					for (String cluesDataDetailDto : listOfBAIds) {

						preStmt.setString(1, cluesDataDetailDto);
						preStmt.setLong(2, prefs); 
					    
						preStmt.addBatch();
					}
				}
				
				preStmt.executeBatch();
				preStmt.close();
			} catch (Exception e) {
				LOGGER.error("Error while Batch insertion. ",e);
			} finally {
				if(null!=preStmt)
					preStmt.close();
				if(null!=connection)
					connection.close();
			}		
	}
	
	
	@Override
	public void executeBatchExistingUserNativeSQLBatch(List<BAUserDetailsDto> allExistingUsers, String userName,
			boolean isCWS) throws SQLException {
		/*************** SqL Batch Insert start ***************/
		//PreparedStatement ps = null;
		//Connection connection =null;
		//Statement stmt =null;
		
		
		try {
	        //SessionImplementor si = (SessionImplementor) entityManager.unwrap(Session.class);
	        //connection = si.getJdbcConnectionAccess().obtainConnection();			
	       				
	        StringBuilder userValues = new StringBuilder();
	        
			StringBuilder createQuery = new StringBuilder("update brand_advocate_details ba "
					+ "set ba.modified_date = '"+ new java.sql.Timestamp(new Date().getTime()) +"', "
					+ "ba.modified_by =  '"+UserMasterConstant.ADMIN +"' where ");
//					+ "ba.modified_by =  '"+userName +"', is_active= 'Y' where ");
					
			if (isCWS){
				createQuery.append("upper(ba.cws_user_id)  IN (");
			}else {
				createQuery.append("upper(ba.primary_email)  IN (");
			}
			
			for (BAUserDetailsDto baDetailDto : allExistingUsers) {
				if(isCWS)
					userValues.append("UPPER('").append(baDetailDto.getCwsUserId()).append("'),");
				else
					userValues.append("UPPER('").append(baDetailDto.getPrimaryEmail()).append("'),");
			}
			
			String commSepratedValue = userValues.substring(0, userValues.length() - 1);
			
			createQuery.append(commSepratedValue);
			createQuery.append(")");
			
//			stmt = connection.createStatement();
//			int execute = stmt.executeUpdate(createQuery.toString());
			
			entityManager.createNativeQuery(createQuery.toString()).executeUpdate();
	
		} catch (Exception e) {
			LOGGER.error("Error while Batch insertion. ",e);
		} finally {
			/*if(null!=ps)
				ps.close();
			if(null!=connection)
				connection.close();
			if(null!=stmt)
				stmt.close();*/
		}
		
	}
	
	
	
	
	@Override
	@Transactional
	public int updateBAPStatusInactiveForCupIDs(List<String> allExistingUsers, String adminFirstName, String adminLastName, String executionMode) throws SQLException {
		/*************** SqL Batch Insert start ***************/
		StringBuilder fullName = new StringBuilder();
		
		if(executionMode.equals(UserMasterConstant.SYNC_MANUAL)){
			//fullName.append(adminFirstName).append(adminLastName);
			fullName.append(UserMasterConstant.ADMIN);
		}else if(executionMode.equals(UserMasterConstant.SYNC_SCHEDULER)){
			fullName.append(UserMasterConstant.SYSTEM);
		}
		
		PreparedStatement ps = null;
		Connection connection =null;
		int updateCount =0;
		
		try {
			SessionImplementor si = (SessionImplementor) entityManager.unwrap(Session.class);
			connection = si.getJdbcConnectionAccess().obtainConnection();			
			
			StringBuilder userValues = new StringBuilder();
			
			StringBuilder createQuery = new StringBuilder(""
					+ "update brand_advocate_details ba "
					+ "set is_active= 'N', "
					+ "ba.modified_date = '"+ new java.sql.Timestamp(new Date().getTime()) +"',"
					+ "ba.inactive_date = '"+ new java.sql.Timestamp(new Date().getTime()) +"', "
					+ "ba.modified_by =  '"+fullName +"' "
					+ "ba.cws_user_id='', "
			 		+ "ba.last_name='', "
			 		+ "ba.first_name='', "
			 		+ "ba.preferred_first_name='', "
			 		+ "ba.primary_email='', "
			 		+ "ba.secondary_email='', "
			 		+ "ba.cup_id='' "
					+ "where  "
					+ "upper(ba.cup_id) IN (");
			
			for (String baDetailDto : allExistingUsers) {
					userValues.append("UPPER('").append(baDetailDto).append("'),");
			}
			
			String commSepratedValue = userValues.substring(0, userValues.length() - 1);
			
			createQuery.append(commSepratedValue);
			createQuery.append(")");
			
			Statement stmt = connection.createStatement();
			updateCount = stmt.executeUpdate(createQuery.toString());
			
			
		} catch (Exception e) {
			LOGGER.error("Error while Batch insertion. ",e);
		} finally {
			if(null!=ps)
				ps.close();
			if(null!=connection)
				connection.close();
		}
		return updateCount;
	}
	
	@SuppressWarnings("unchecked")
	public List<BAUserDetailsDto> getMailIdListByBaId(UserMasterRequest userMasterRequest){

		StringBuilder createQuery = new StringBuilder();
		createQuery
				.append("SELECT ba.brand_advocate_id,ba.primary_email,ba.secondary_email,ba.first_name,ba.last_name FROM brand_advocate_details ba LEFT JOIN user_preferences_tbl upt ON  ba.brand_advocate_id= upt.brand_advocate_id "
		+"WHERE  ba.`brand_advocate_id` IN ("+userMasterRequest.getBrandAdvocateIds()+") ");
		
		createQuery.append("AND upt.`preference_id` IN ( ");
		
		if(userMasterRequest.getPreferenceName().trim().equalsIgnoreCase("Webinar invitations")){
			createQuery.append("SELECT p.preference_id FROM preferences_tbl p WHERE p.preference_name = '"+userMasterRequest.getPreferenceName()+"' ");
		}else if(userMasterRequest.getPreferenceName().trim().equalsIgnoreCase("Brand event communications")){
			createQuery.append("SELECT p.preference_id FROM preferences_tbl p WHERE p.preference_name = '"+userMasterRequest.getPreferenceName()+"' ");
		}else if(userMasterRequest.getPreferenceName().trim().equalsIgnoreCase("Newsletters")){
			createQuery.append("SELECT p.preference_id FROM preferences_tbl p WHERE p.preference_name = '"+userMasterRequest.getPreferenceName()+"' ");
		}				
		
		createQuery.append(")");

		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();
		
		List<BAUserDetailsDto> baUserDetailsDtos = new ArrayList<>();
		
		dataList.stream().forEach(record -> {
			BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
			bAUserDetailsDto.setBrandAdvocateId(record[0] != null ? ((BigInteger) record[0]).longValue() : null);
			bAUserDetailsDto.setPrimaryEmail(record[1] != null ? "" + (String) record[1] : "");
			bAUserDetailsDto.setSecondaryEmail(record[2] != null ? "" + (String) record[2] : "");
			bAUserDetailsDto.setFirstName(record[3] != null ? "" + (String) record[3] : "");
			bAUserDetailsDto.setLastName(record[4] != null ? "" + (String) record[4] : "");
			baUserDetailsDtos.add(bAUserDetailsDto);
		});
		return baUserDetailsDtos;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDbUserNameByPreferenceForFindBA(String brandEventCommunication) {
		StringBuilder createQuery = new StringBuilder();
		
		String isActive = UserMasterConstant.FLAG_Y;
		
		createQuery.append("SELECT DISTINCT ba.last_name,ba.first_name FROM brand_advocate_details ba LEFT JOIN user_preferences_tbl upt "
		+"ON upt.brand_advocate_id = ba.brand_advocate_id LEFT JOIN preferences_tbl p ON p.preference_id = upt.preference_id WHERE "
				+" p.preference_name = '"+brandEventCommunication+"' AND ba.is_active = '"+isActive+"' ");
		
		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		List<String> fullNameList = new ArrayList<>();
		dataList.stream().forEach(record -> {
			StringJoiner joiner = new StringJoiner(", ");
			if(!BrandAdvocateUtility.isEmptyString((String)record[0])){
				joiner.add(record[0] != null ? "" + (String) record[0] : "");
			}
			
			if(!BrandAdvocateUtility.isEmptyString((String)record[1])){
				joiner.add(record[1] != null ? "" + (String) record[1] : "");
			}
			String fullName = joiner.toString();
			fullNameList.add(fullName);
		});
		
		return fullNameList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDbOrganizationByPreferenceForFindBA(String brandEventCommunication) {
		StringBuilder createQuery = new StringBuilder();
		
		String isActive = UserMasterConstant.FLAG_Y;
		
		createQuery.append("SELECT DISTINCT ba.organization_name FROM brand_advocate_details ba LEFT JOIN user_preferences_tbl upt "
		+"ON upt.brand_advocate_id = ba.brand_advocate_id LEFT JOIN preferences_tbl p ON p.preference_id = upt.preference_id WHERE "
				+" p.preference_name = '"+brandEventCommunication+"' AND ba.is_active = '"+isActive+"' ");
		
		Query query = entityManager.createNativeQuery(createQuery.toString());
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Region> getDbRegionByPreferenceForFindBA(String brandEventCommunication) {
		StringBuilder createQuery = new StringBuilder();
		
		String isActive = UserMasterConstant.FLAG_Y;
		
		createQuery.append("SELECT DISTINCT r.region_id,r.region_name FROM region_tbl r LEFT JOIN country_tbl c ON r.region_id = c.region_id WHERE c.country_id IN ("
				+" SELECT DISTINCT ba.country_id FROM brand_advocate_details ba LEFT JOIN user_preferences_tbl upt ON upt.brand_advocate_id = ba.brand_advocate_id"
				+" LEFT JOIN preferences_tbl p ON p.preference_id = upt.preference_id WHERE p.preference_name = '"+brandEventCommunication+"' AND ba.is_active = '"+isActive+"') ");
		
		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		List<Region> regionsList = new ArrayList<>();
		dataList.stream().forEach(record -> {
			Region region = new Region();
			region.setRegionId(record[0] != null ? ((BigInteger) record[0]).longValue() : null);
			region.setRegionName(record[1] != null ? "" + (String) record[1] : "");
			regionsList.add(region);
		});
		
		return regionsList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Country> getDbCountryByPreferenceForFindBA(String brandEventCommunication) {
		StringBuilder createQuery = new StringBuilder();
		
		String isActive = UserMasterConstant.FLAG_Y;
		
		createQuery.append("SELECT DISTINCT c.country_id,c.country_name FROM country_tbl c WHERE c.country_id IN ("
				+" SELECT DISTINCT ba.country_id FROM brand_advocate_details ba LEFT JOIN user_preferences_tbl upt ON upt.brand_advocate_id = ba.brand_advocate_id"
				+" LEFT JOIN preferences_tbl p ON p.preference_id = upt.preference_id WHERE p.preference_name = '"+brandEventCommunication+"' AND ba.is_active = '"+isActive+"') ");
		
		Query query = entityManager.createNativeQuery(createQuery.toString());
		List<Object[]> dataList = query.getResultList();

		List<Country> countriesList = new ArrayList<>();
		dataList.stream().forEach(record -> {
			Country country = new Country();
			country.setCountryId(record[0] != null ? ((BigInteger) record[0]).longValue() : null);
			country.setCountryName(record[1] != null ? "" + (String) record[1] : "");
			countriesList.add(country);
		});
		
		return countriesList;
	}
	
	/* (non-Javadoc)
	 * @see com.cat.bap.repository.BAUserDetailsRepositoryCustom#getLastExecutionDateTime()
	 */
	@SuppressWarnings("unchecked")
	public String getLastExecutionDateTime(){
		
		Query query = entityManager.createQuery("SELECT sd.jobExecutionEndDate FROM SchedulerDetail sd ORDER BY jobExecutionEndDate DESC");
		query.setMaxResults(1);
		List<Timestamp> resultList = query.getResultList();	
		
		Timestamp lastExecutionTime = resultList.get(0);
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy:hh:mm:ss");
		return dateFormatter.format(lastExecutionTime);
	}

	@Override
	public boolean updateDataToInActiveState(long brandAdvocateId, boolean isActive, Date inActiveDate, Date modifiedDate)
			throws SQLException {
		
		LOGGER.info("updateDataToInActiveState() : START");
/*		
		 Query query = entityManager.createQuery( " UPDATE brand_advocate_details ba SET "
		 		+ "ba.cws_user_id='', "
		 		+ "ba.last_name='', "
		 		+ "ba.first_name='', "
		 		+ "ba.preferred_first_name='', "
		 		+ "ba.primary_email='', "
		 		+ "ba.secondary_email='', "
		 		+ "ba.cup_id='', "
		 		+ "ba.isActive ='"+isActive+"',"
		 		+ "ba.inActiveDate ='"+inActiveDate+"'," 
		 		+ "ba.modifiedDate ='"+modifiedDate+"',"
		 		+ "ba.modifiedBy ='"+UserMasterConstant.ADMIN+"' "
		 		+ "WHERE ba.brandAdvocateId ="+brandAdvocateId);*/
		 
		 Query query = entityManager.createQuery( " UPDATE BAUserDetails ba SET "
				 +" ba.cwsUserId='', "
				 + "ba.lastName ='', "
				 + "ba.firstName ='', "
				 + "ba.preferredFirstName ='',"
				 + "ba.primaryEmail ='',"
				 + "ba.secondaryEmail='', "
				 + "ba.cupId='', "
				 + "ba.isActive ='N',"
				 + "ba.inActiveDate ='"+new java.sql.Timestamp(new Date().getTime())+"'," 
				 + "ba.modifiedDate ='"+new java.sql.Timestamp(new Date().getTime())+"',"
				 + "ba.modifiedBy ='"+UserMasterConstant.ADMIN+"' "
				 + "WHERE ba.brandAdvocateId ="+brandAdvocateId);

		 int updateCount = query.executeUpdate();
		 
		 LOGGER.info("updateDataToInActiveState() : END");
		 
		return updateCount>0 ? true : false;
		
	}
}
