package com.cat.bap.common;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose
 */
public class RejectValues {

  private String field;
  private String reasionHeader;
  private String reason;


  public RejectValues(String field, String reasionHeader, String reason) {
    super();
    this.field = field;
    this.reasionHeader = reasionHeader;
    this.reason = reason;
  }

  public String getField() {
    return field;
  }

  public void setField(String field) {
    this.field = field;
  }

  public String getReasionHeader() {
    return reasionHeader;
  }

  public void setReasionHeader(String reasionHeader) {
    this.reasionHeader = reasionHeader;
  }

  public String getReason() {
    return reason;
  }

  public void setReason(String reason) {
    this.reason = reason;
  }

  @Override
  public String toString() {
    return "RejectValues [field:" + field + ", reasionHeader=" + reasionHeader + ", reason="
        + reason + "]";
  }


}
