package com.cat.bap.repository;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cat.bap.entity.BAUserDetails;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose This interface is used as repository for manage admin.
 */

public interface BAUserDetailsRepository extends JpaRepository<BAUserDetails, Long> {

  @Query("FROM BAUserDetails md WHERE md.cupId =:cupId")
  public BAUserDetails findBAUserByCupId(@Param("cupId") String cupId);
  
  @Query("FROM BAUserDetails md WHERE md.primaryEmail =:emailId and md.cwsUserId=:cwsUserId ")
  public BAUserDetails findBAUserByEmailIdcwsId(@Param("emailId") String emailId, @Param("cwsUserId") String cwsId);
  
  @Modifying
  @Query("UPDATE BAUserDetails md SET md.notes =:notes,md.modifiedDate =:modifiedDate,md.modifiedBy =:modifiedBy WHERE md.brandAdvocateId =:brandAdvocateId")
  public void addNotes(@Param("notes") String notes, @Param("brandAdvocateId") Long brandAdvocateId,@Param("modifiedDate") Date modifiedDate,@Param("modifiedBy") String modifiedBy);

  @Modifying
  @Query("UPDATE BAUserDetails md SET md.comments =:comments,md.modifiedDate =:modifiedDate,md.modifiedBy =:modifiedBy WHERE md.brandAdvocateId =:brandAdvocateId")
  public void addCommentsQuestions(@Param("comments") String comments, @Param("brandAdvocateId") Long brandAdvocateId,@Param("modifiedDate") Date modifiedDate,@Param("modifiedBy") String modifiedBy);
  
  @Modifying
  @Query("UPDATE BAUserDetails md SET md.secondaryEmail =:secondaryEmail,md.modifiedDate =:modifiedDate,md.modifiedBy =:modifiedBy WHERE md.brandAdvocateId =:brandAdvocateId")
  public void updateSecondaryEmail(@Param("secondaryEmail") String secondaryEmail, @Param("brandAdvocateId") Long brandAdvocateId,@Param("modifiedDate") Date modifiedDate,@Param("modifiedBy") String modifiedBy);
  
  @Modifying
  @Query("UPDATE BAUserDetails um SET um.isActive =:isActive,um.inActiveDate =:inActiveDate,um.modifiedDate =:modifiedDate,um.modifiedBy =:modifiedBy WHERE um.brandAdvocateId =:brandAdvocateId")
  public void changeActiveStatusWithInactiveAndModifiedDate(@Param("brandAdvocateId") Long brandAdvocateId,@Param("isActive") Boolean isActive,@Param("inActiveDate") Date inActiveDate,@Param("modifiedDate") Date modifiedDate,@Param("modifiedBy") String modifiedBy);

  @Modifying
  @Query("UPDATE BAUserDetails um SET um.isActive =:isActive,um.modifiedDate =:modifiedDate,um.modifiedBy =:modifiedBy WHERE um.brandAdvocateId =:brandAdvocateId")
  public void changeActiveStatusWithModifiedDate(@Param("brandAdvocateId") Long brandAdvocateId,@Param("isActive") Boolean isActive,@Param("modifiedDate") Date modifiedDate,@Param("modifiedBy") String modifiedBy);
  
}
