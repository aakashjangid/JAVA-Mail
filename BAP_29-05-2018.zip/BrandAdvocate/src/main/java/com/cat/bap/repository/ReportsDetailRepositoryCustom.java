package com.cat.bap.repository;

import java.sql.SQLException;
import java.util.List;

public interface ReportsDetailRepositoryCustom {
	
		
	/**
	 * @param affiliationDesc
	 * @param isActive
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws SQLException
	 */
	public List<Object[]> getReportActiveInActiveCount(List<String> affiliationDesc, boolean isActive, String startDate, String endDate) throws SQLException;

	/**
	 * @param affiliationDesc
	 * @param isActive
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws SQLException
	 */
	public List<Object[]> getReportGainLostCount(List<String> affiliationDesc, String startDate, String endDate) throws SQLException;
	

	
}
