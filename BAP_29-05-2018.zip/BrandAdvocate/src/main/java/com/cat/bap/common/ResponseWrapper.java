package com.cat.bap.common;

import org.springframework.http.HttpStatus;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose
 */
public class ResponseWrapper<T> {
  @SuppressWarnings("unused")
  private static final long serialVersionUID = 1L;
  private BrandAdvocateException brandAdvocateError;
  private HttpStatus statusCode;
  private String message;
  private T data;

  public ResponseWrapper() {
    // Default constructor
  }

  public ResponseWrapper(BrandAdvocateException brandAdvocateError, HttpStatus statusCode, String message,
      T data) {
    super();
    this.brandAdvocateError = brandAdvocateError;
    this.statusCode = statusCode;
    this.message = message;
    this.data = data;
  }

  public BrandAdvocateException getbrandAdvocateError() {
    return brandAdvocateError;
  }

  public void setbrandAdvocateError(BrandAdvocateException brandAdvocateError) {
    this.brandAdvocateError = brandAdvocateError;
  }

  public HttpStatus getStatusCode() {
    return statusCode;
  }

  public void setStatusCode(HttpStatus statusCode) {
    this.statusCode = statusCode;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public T getData() {
    return data;
  }

  public void setData(T data) {
    this.data = data;
  }
}
