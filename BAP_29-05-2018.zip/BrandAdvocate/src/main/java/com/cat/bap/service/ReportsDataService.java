package com.cat.bap.service;


import java.io.IOException;
import java.math.BigInteger;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.AffiliationDetailsDto;
import com.cat.bap.dto.ReportsRequest;
import com.cat.bap.repository.ReportsDetailRepositoryCustomImpl;
import com.cat.bap.util.BrandAdvocateUtility;
import com.cat.bap.util.ExportToExcelUtilityForReports;
import com.google.gson.Gson;

@Service
public class ReportsDataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsDataService.class);

	@Inject
	private ReportsDataDomainService reportsDataDomainService;

	@Inject
	private ReportsDetailRepositoryCustomImpl reportsDetailRepositoryCustomImpl;
	
	@Inject
	private Environment environment;

	/**
	 * @param isActive
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws SQLException
	 */
	public List<AffiliationDetailsDto> getReportActiveInActiveCount(boolean isActive, String startDate,
			String endDate) throws SQLException {

		LOGGER.debug("getReportActiveInActiveCount() : START");
		
		List<AffiliationDetailsDto> listOfDTOs = new ArrayList<AffiliationDetailsDto>();
		List<String> affNames = reportsDataDomainService.getAllAffiliationNames();

		long regionANtotalCnt = 0;
		long regionAStotalCnt = 0;
		long regionAPtotalCnt = 0;
		long regionEAMEtotalCnt = 0;

		long totalRegionRecordCount = 0;

		for (String affName : affNames) {

			long regionANCnt = 0;
			long regionASCnt = 0;
			long regionAPCnt = 0;
			long regionEAMECnt = 0;

			AffiliationDetailsDto affDetailDto = null;
			affDetailDto = new AffiliationDetailsDto();

			List<String> affiliationDesc= reportsDataDomainService.getAffiliationDescByName(affName);
			List<Object[]> dataList 	= reportsDetailRepositoryCustomImpl.getReportActiveInActiveCount(affiliationDesc, isActive, startDate, endDate);

			long regionRecordCount = 0;

			for (Object[] record : dataList) {

				String affiliationRegionName = record[0] != null ? "" + (String) record[0] : "";
				long recordCount = record[1] != null ? ((BigInteger) record[1]).longValue() : null;
				regionRecordCount += recordCount;

				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_NORTH)) {
					regionANtotalCnt += recordCount;
					regionANCnt += recordCount;
					affDetailDto.setAnCnt(regionANCnt);
				}

				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_SOUTH)) {
					regionAStotalCnt += recordCount;
					regionASCnt += recordCount;
					affDetailDto.setAsCnt(regionASCnt);
				}

				if (affiliationRegionName.equals(UserMasterConstant.ASIA_PACIFIC)) {
					regionAPtotalCnt += recordCount;
					regionAPCnt += recordCount;
					affDetailDto.setApCnt(regionAPCnt);
				}

				if (affiliationRegionName.equals(UserMasterConstant.EAME)) {
					regionEAMEtotalCnt += recordCount;
					regionEAMECnt += recordCount;
					affDetailDto.setEameCnt(regionEAMECnt);
				}

			}
			totalRegionRecordCount += regionRecordCount;

			affDetailDto.setAffiliationTypeName(affName);
			affDetailDto.setTotalRegionRecordCnt(regionRecordCount);

			listOfDTOs.add(affDetailDto);
		}

		AffiliationDetailsDto affDetailDto = null;
		affDetailDto = new AffiliationDetailsDto();

		affDetailDto.setAffiliationTypeName("Total");
		affDetailDto.setAnCnt(regionANtotalCnt);
		affDetailDto.setApCnt(regionAPtotalCnt);
		affDetailDto.setAsCnt(regionAStotalCnt);
		affDetailDto.setEameCnt(regionEAMEtotalCnt);
		affDetailDto.setTotalRegionRecordCnt(totalRegionRecordCount);

		listOfDTOs.add(affDetailDto);
		
		LOGGER.debug("getReportActiveInActiveCount() : END");

		return listOfDTOs;
	}
	
	/**
	 * @param typeName
	 * @return
	 * @throws SQLException
	 */
	public List<AffiliationDetailsDto> getReportGainedUserCount(String startDate, String endDate) throws SQLException {
		
		LOGGER.debug("getReportGainedUserCount() : START");
		
		List<AffiliationDetailsDto> listOfDTOs = new ArrayList<AffiliationDetailsDto>();
		List<String> affNames = reportsDataDomainService.getAllAffiliationNames();
		
		long regionANtotalCnt = 0;
		long regionAStotalCnt = 0;
		long regionAPtotalCnt = 0;
		long regionEAMEtotalCnt = 0;
		
		long totalRegionRecordCount = 0;
		
		for (String affName : affNames) {
			
			long regionANCnt = 0;
			long regionASCnt = 0;
			long regionAPCnt = 0;
			long regionEAMECnt = 0;
			
			AffiliationDetailsDto affDetailDto = null;
			affDetailDto = new AffiliationDetailsDto();
			
			List<String> affiliationDesc= reportsDataDomainService.getAffiliationDescByName(affName);
			List<Object[]> dataList 	= reportsDetailRepositoryCustomImpl.getReportGainLostCount(affiliationDesc, startDate, endDate);
			
			long regionRecordCount = 0;
			
			for (Object[] record : dataList) {
				
				String affiliationRegionName = record[0] != null ? "" + (String) record[0] : "";
				long recordCount = record[1] != null ? ((BigInteger) record[1]).longValue() : null;
				regionRecordCount += recordCount;
				
				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_NORTH)) {
					regionANtotalCnt += recordCount;
					regionANCnt += recordCount;
					affDetailDto.setAnCnt(regionANCnt);
				}
				
				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_SOUTH)) {
					regionAStotalCnt += recordCount;
					regionASCnt += recordCount;
					affDetailDto.setAsCnt(regionASCnt);
				}
				
				if (affiliationRegionName.equals(UserMasterConstant.ASIA_PACIFIC)) {
					regionAPtotalCnt += recordCount;
					regionAPCnt += recordCount;
					affDetailDto.setApCnt(regionAPCnt);
				}
				
				if (affiliationRegionName.equals(UserMasterConstant.EAME)) {
					regionEAMEtotalCnt += recordCount;
					regionEAMECnt += recordCount;
					affDetailDto.setEameCnt(regionEAMECnt);
				}
				
			}
			totalRegionRecordCount += regionRecordCount;
			
			affDetailDto.setAffiliationTypeName(affName);
			affDetailDto.setTotalRegionRecordCnt(regionRecordCount);
			
			listOfDTOs.add(affDetailDto);
		}
		
		AffiliationDetailsDto affDetailDto = null;
		affDetailDto = new AffiliationDetailsDto();
		
		affDetailDto.setAffiliationTypeName(UserMasterConstant.LABEL_TOTAL);
		affDetailDto.setAnCnt(regionANtotalCnt);
		affDetailDto.setApCnt(regionAPtotalCnt);
		affDetailDto.setAsCnt(regionAStotalCnt);
		affDetailDto.setEameCnt(regionEAMEtotalCnt);
		affDetailDto.setTotalRegionRecordCnt(totalRegionRecordCount);
		
		listOfDTOs.add(affDetailDto);
		
		LOGGER.debug("getReportGainedUserCount() : END");
		
		return listOfDTOs;
	}

	/**
	 * @param isActive
	 * @param startDateTY
	 * @param endDateTY
	 * @param startDateLY
	 * @param endDateLY
	 * @param thisYearQoQ
	 * @param lastYearQoQ
	 * @return
	 * @throws SQLException
	 */
	public List<AffiliationDetailsDto> getReportTYLYUserCount(boolean isActive, String startDateTY, String endDateTY, String startDateLY, String endDateLY, String thisYearQoQ, String lastYearQoQ, String dropDownValue1, String dropDownValue2)
			throws SQLException {

		LOGGER.debug("getReportTYLYUserCount() : START");
		
		long regionANtotalCntTY 	= 0;
		long regionAStotalCntTY 	= 0;
		long regionAPtotalCntTY 	= 0;
		long regionEAMEtotalCntTY 	= 0;
		long totalRegionRecordCntTY = 0;
		
		long regionANtotalCntLY 	= 0;
		long regionAStotalCntLY 	= 0;
		long regionAPtotalCntLY 	= 0;
		long regionEAMEtotalCntLY 	= 0;
		long totalRegionRecordCntLY = 0;
		
		List<AffiliationDetailsDto> listOfDTOs = new ArrayList<AffiliationDetailsDto>();
		List<String> affNames = reportsDataDomainService.getAllAffiliationNames();

		for (String affName : affNames) {
			
			long regionANCntTY 		= 0;
			long regionASCntTY 		= 0;
			long regionAPCntTY 		= 0;
			long regionEAMECntTY 	= 0;
			long regionRecordCountTY= 0;
			
			AffiliationDetailsDto affUserDetailsTY = null;
			affUserDetailsTY = new AffiliationDetailsDto();

			List<String> affiliationDesc = reportsDataDomainService.getAffiliationDescByName(affName);
			
			List<Object[]> dataListTY = null;
			List<Object[]> dataListLY = null;
			
			
			if(!isActive){
				/**Lost Data for This Year **/
				dataListTY = reportsDetailRepositoryCustomImpl.getReportActiveInActiveCount(affiliationDesc, false, startDateTY, endDateTY);
				
				/**Lost Data for Last Year **/
				dataListLY = reportsDetailRepositoryCustomImpl.getReportActiveInActiveCount(affiliationDesc, false, startDateLY, endDateLY);
			}else{
				/**Gained Data for This Year **/
				dataListTY = reportsDetailRepositoryCustomImpl.getReportGainLostCount(affiliationDesc, startDateTY, endDateTY);
				
				/**Gained Data for Last Year **/
				dataListLY = reportsDetailRepositoryCustomImpl.getReportGainLostCount(affiliationDesc, startDateLY, endDateLY);
			}

			for (Object[] record : dataListTY) {

				String affiliationRegionName = record[0] != null ? "" + (String) record[0] 				: "";
				long recordCount 			 = record[1] != null ? ((BigInteger) record[1]).longValue() : null;
				
				regionRecordCountTY += recordCount;

				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_NORTH)) {
					regionANtotalCntTY += recordCount;
					regionANCntTY += recordCount;
					affUserDetailsTY.setAnCnt(regionANCntTY);
				}

				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_SOUTH)) {
					regionAStotalCntTY += recordCount;
					regionASCntTY += recordCount;
					affUserDetailsTY.setAsCnt(regionASCntTY);
				}

				if (affiliationRegionName.equals(UserMasterConstant.ASIA_PACIFIC)) {
					regionAPtotalCntTY += recordCount;
					regionAPCntTY += recordCount;
					affUserDetailsTY.setApCnt(regionAPCntTY);
				}

				if (affiliationRegionName.equals(UserMasterConstant.EAME)) {
					regionEAMEtotalCntTY += recordCount;
					regionEAMECntTY += recordCount;
					affUserDetailsTY.setEameCnt(regionEAMECntTY);
				}

			}
			totalRegionRecordCntTY += regionRecordCountTY;

			affUserDetailsTY.setAffiliationTypeName(affName.concat(" ").concat(dropDownValue1));
//			affUserDetailsTY.setAffiliationTypeName(affName.concat(UserMasterConstant.THIS_YEAR));
			affUserDetailsTY.setTotalRegionRecordCnt(regionRecordCountTY);

			listOfDTOs.add(affUserDetailsTY);
			
			long regionANCntLY 		= 0;
			long regionASCntLY 		= 0;
			long regionAPCntLY 		= 0;
			long regionEAMECntLY 	= 0;
			long regionRecordCountLY= 0;
			
			AffiliationDetailsDto affUserDetailsLY = null;
			affUserDetailsLY = new AffiliationDetailsDto();

			for (Object[] record : dataListLY) {

				String affiliationRegionName = record[0] != null ? "" + (String) record[0] 				: "";
				long recordCount 			 = record[1] != null ? ((BigInteger) record[1]).longValue() : null;
				
				regionRecordCountLY += recordCount;

				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_NORTH)) {
					regionANtotalCntLY += recordCount;
					regionANCntLY += recordCount;
					affUserDetailsLY.setAnCnt(regionANCntLY);
				}

				if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_SOUTH)) {
					regionAStotalCntLY += recordCount;
					regionASCntLY += recordCount;
					affUserDetailsLY.setAsCnt(regionASCntLY);
				}

				if (affiliationRegionName.equals(UserMasterConstant.ASIA_PACIFIC)) {
					regionAPtotalCntLY += recordCount;
					regionAPCntLY += recordCount;
					affUserDetailsLY.setApCnt(regionAPCntLY);
				}

				if (affiliationRegionName.equals(UserMasterConstant.EAME)) {
					regionEAMEtotalCntLY += recordCount;
					regionEAMECntLY += recordCount;
					affUserDetailsLY.setEameCnt(regionEAMECntLY);
				}

			}
			totalRegionRecordCntLY += regionRecordCountLY;

			affUserDetailsLY.setAffiliationTypeName(affName.concat(" ").concat(dropDownValue2));
//			affUserDetailsLY.setAffiliationTypeName(affName.concat(UserMasterConstant.LAST_YEAR));
			affUserDetailsLY.setTotalRegionRecordCnt(regionRecordCountLY);
			listOfDTOs.add(affUserDetailsLY);
			
			/**get the percentage value **/
			AffiliationDetailsDto changePercentagesDetailsTYLY = getPercentagForTYLY(affUserDetailsTY,affUserDetailsLY);
			listOfDTOs.add(changePercentagesDetailsTYLY);
		}
		
		/**Add total count if TY**/
		AffiliationDetailsDto totalCountTY = null;
		totalCountTY = new AffiliationDetailsDto();
		
		totalCountTY.setAffiliationTypeName(UserMasterConstant.LABEL_TOTAL.concat(" ").concat(dropDownValue1));
		totalCountTY.setAnCnt(regionANtotalCntTY);
		totalCountTY.setApCnt(regionAPtotalCntTY);
		totalCountTY.setAsCnt(regionAStotalCntTY);
		totalCountTY.setEameCnt(regionEAMEtotalCntTY);
		totalCountTY.setTotalRegionRecordCnt(totalRegionRecordCntTY);
		
		listOfDTOs.add(totalCountTY);
		
		/**Add total count if LY**/
		AffiliationDetailsDto totalCountLY = null;
		totalCountLY = new AffiliationDetailsDto();
		
		totalCountLY.setAffiliationTypeName(UserMasterConstant.LABEL_TOTAL.concat(" ").concat(dropDownValue2));
		totalCountLY.setAnCnt(regionANtotalCntLY);
		totalCountLY.setApCnt(regionAPtotalCntLY);
		totalCountLY.setAsCnt(regionAStotalCntLY);
		totalCountLY.setEameCnt(regionEAMEtotalCntLY);
		totalCountLY.setTotalRegionRecordCnt(totalRegionRecordCntLY);
		
		listOfDTOs.add(totalCountLY);

		/**get the percentage value **/
		AffiliationDetailsDto changePercentagesDetailsTYLY = getPercentagForTYLY(totalCountTY,totalCountLY);
		listOfDTOs.add(changePercentagesDetailsTYLY);
		
		LOGGER.debug("getReportTYLYUserCount() : END");
		
		return listOfDTOs;
	}

	private AffiliationDetailsDto getPercentagForTYLY(AffiliationDetailsDto gainedDetailCountTY,
			AffiliationDetailsDto lostDetailsCountLY) {
		
		LOGGER.debug("getPercentagForTYLY() : START");
		
		AffiliationDetailsDto affDetailDto = null;
		affDetailDto = new AffiliationDetailsDto();
		
		affDetailDto.setAffiliationTypeName(UserMasterConstant.CHANGE_PERCENTAGE);
		
		/** Region percentage count **/
		if(null!=gainedDetailCountTY && null!=lostDetailsCountLY){
			
			/** AN percentage count **/
			long anCnt 	= calculatePercentage(lostDetailsCountLY.getAnCnt(), gainedDetailCountTY.getAnCnt());
			affDetailDto.setAnCnt(anCnt);
			
			/** AS region percentage count **/
			long asCnt 	= calculatePercentage(lostDetailsCountLY.getAsCnt(), gainedDetailCountTY.getAsCnt());
			affDetailDto.setAsCnt(asCnt);
			
			/** AP region percentage count **/
			long apCnt 	= calculatePercentage(lostDetailsCountLY.getApCnt(), gainedDetailCountTY.getApCnt());
			affDetailDto.setApCnt(apCnt);
			
			/** EAME region percentage count **/
			long eameCnt = calculatePercentage(lostDetailsCountLY.getEameCnt(), gainedDetailCountTY.getEameCnt());
			affDetailDto.setEameCnt(eameCnt);
			
			/** Total region percentage count **/
			long totalRegionCnt = calculatePercentage(lostDetailsCountLY.getTotalRegionRecordCnt(), gainedDetailCountTY.getTotalRegionRecordCnt());
			affDetailDto.setTotalRegionRecordCnt(totalRegionCnt);
		}
		
		LOGGER.debug("getPercentagForTYLY() : START");
		
		return affDetailDto;
	}

	private AffiliationDetailsDto getAffDetailsUserCountLY(String affName, List<Object[]> dataListLY) {

		LOGGER.debug("getAffDetailsUserCountLY() : START");
		
		long regionANCnt = 0;
		long regionASCnt = 0;
		long regionAPCnt = 0;
		long regionEAMECnt = 0;
		long regionRecordCount = 0;
		
		AffiliationDetailsDto affUserDetailLY = null;
		affUserDetailLY = new AffiliationDetailsDto();

		for (Object[] record : dataListLY) {

			String affiliationRegionName = record[0] != null ? "" + (String) record[0] : "";
			long recordCount = record[1] != null ? ((BigInteger) record[1]).longValue() : null;
			regionRecordCount += recordCount;

			if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_NORTH)) {
				regionANCnt += recordCount;
				affUserDetailLY.setAnCnt(regionANCnt);
			}

			if (affiliationRegionName.equals(UserMasterConstant.AMERICAS_SOUTH)) {
				regionASCnt += recordCount;
				affUserDetailLY.setAsCnt(regionASCnt);
			}

			if (affiliationRegionName.equals(UserMasterConstant.ASIA_PACIFIC)) {
				regionAPCnt += recordCount;
				affUserDetailLY.setApCnt(regionAPCnt);
			}

			if (affiliationRegionName.equals(UserMasterConstant.EAME)) {
				regionEAMECnt += recordCount;
				affUserDetailLY.setEameCnt(regionEAMECnt);
			}

		}

		affUserDetailLY.setAffiliationTypeName(affName.concat(UserMasterConstant.LAST_YEAR));
		affUserDetailLY.setTotalRegionRecordCnt(regionRecordCount);

		LOGGER.debug("getAffDetailsUserCountLY() : END");		
		
		return affUserDetailLY;

	}
	
	public long calculatePercentage(double lastYearValue, double thisYearValue){
		
			double profit = thisYearValue - lastYearValue;
			float percentage = (float) ((profit / lastYearValue) * 100);
			
			if(Float.isNaN(percentage)){
				return 0;
			}
			
			if(Float.isInfinite(percentage)){
				return 100;
			}
			
			return Math.round(percentage);
	}

	public void exportToExcelFromJson(HttpServletResponse response,HttpHeaders requestHeader,String reportsRequest) throws IOException, SecurityException, NoSuchFieldException, ParseException {
		Gson gson = new Gson();
		ReportsRequest requestReport = gson.fromJson(reportsRequest, ReportsRequest.class);
		this.generateXLS(response,requestHeader,requestReport);
		
	}
	
	@Transactional(readOnly = true)
	public void generateXLS(HttpServletResponse response, HttpHeaders requestHeader,ReportsRequest requestReport) throws IOException, SecurityException, NoSuchFieldException, ParseException {
		XSSFWorkbook aXSSFWorkbook = exportToExcelAsOfGivenDate(BrandAdvocateUtility.getCookieFromHeader(requestHeader,environment.getProperty("app.sessionIdentifier")),requestReport);
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=BrandAdvocateDetails_"
				+ BrandAdvocateUtility.getDateStringByDateFormat(UserMasterConstant.FORMATE_2) + ".xlsx");
		aXSSFWorkbook.write(response.getOutputStream());
		response.getOutputStream().close();
		
	}

	@Transactional(readOnly = true)
	public XSSFWorkbook exportToExcelAsOfGivenDate(String cookieValue,ReportsRequest reportRequest) throws IOException{
		List<AffiliationDetailsDto> firstDataList =  reportRequest.getFirstDataList();
		List<AffiliationDetailsDto> secondDataList =  reportRequest.getSecondDataList();
		ExportToExcelUtilityForReports excelUtilityForReports = new ExportToExcelUtilityForReports();
		return excelUtilityForReports.generateExcel(firstDataList,secondDataList,reportRequest);
	}
}

/*
 * public List<AffiliationDetailsDto> getAffiliationTypeDataNewApproach() throws
 * SQLException {
 * 
 * List<AffiliationDetailsDto> listOfDTOs = new
 * ArrayList<AffiliationDetailsDto>(); List<String> affNames =
 * reportsDataDomainService.getAllAffiliationNames();
 * 
 * for (String affName : affNames) {
 * 
 * AffiliationDetailsDto affDetailDto = null; affDetailDto = new
 * AffiliationDetailsDto(); long regionRecordCount = 0;
 * 
 * List<AffiliationRegionDto> listOfAffiliationRegionDto = new
 * ArrayList<AffiliationRegionDto>();
 * 
 * List<String> affiliationDesc =
 * reportsDataDomainService.getAffiliationDescByName(affName); List<Object[]>
 * dataList = reportsDetailRepositoryCustomImpl.getAffiliationDescByTypeName(
 * affiliationDesc);
 * 
 * for (Object[] record : dataList) {
 * 
 * AffiliationRegionDto affRegionDto = null; affRegionDto = new
 * AffiliationRegionDto();
 * 
 * String affiliationRegionName = record[0] != null ? "" + (String) record[0] :
 * ""; long recordCount = record[1] != null ? ((BigInteger)
 * record[1]).longValue() : null;
 * 
 * regionRecordCount += recordCount;
 * 
 * //affRegionDto.setTotalRegionRecordCnt(regionRecordCount);
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.AMERICAS_NORTH)){
 * affDetailDto.setAnCnt(recordCount); }
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.AMERICAS_SOUTH)){
 * affDetailDto.setAsCnt(recordCount); }
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.ASIA_PACIFIC)){
 * affDetailDto.setApCnt(recordCount); }
 * 
 * if(affiliationRegionName.equals(UserMasterConstant.EAME)){
 * affDetailDto.setEameCnt(recordCount); }
 * 
 * affRegionDto.setAffiliationRegionName(affiliationRegionName);
 * affRegionDto.setRecordCount(recordCount);
 * 
 * listOfAffiliationRegionDto.add(affRegionDto); }
 * affDetailDto.setAffiliationTypeName(affName);
 * affDetailDto.setListOfAffRegion(listOfAffiliationRegionDto);
 * 
 * listOfDTOs.add(affDetailDto); } return listOfDTOs; }
 */