package com.cat.bap.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

/**
 * This is the entity class which is used to carry the information related to webinar invitation.
 * 
 * @author rathor(aakash.jangid)
 *
 */
@Entity
@Table(name="invitations")
@EntityListeners(AuditingEntityListener.class)
public class Invitation {

	@Column(name="invitation_id")
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(name="sendTo")
	@NotBlank
	private String sendTo;
	
	@Column(name="subject")
	private String subject;
	
	@Column(name="location")
	private String location;
	
	@Column(name="timezone")
	private String timezone;
	
	@Column(name="description")
	private String description;
	
	@Column(name="startDateTime")
	private Date startDateTime;
	
	@Column(name="endDateTime")
	private Date endDateTime;
	
	@Column(name="UID")
	private String uId;
	
	@Column(name="attachmentPath")
	private String attachmentPath;
	
	@CreatedDate
	@Column(updatable=false)
	private Date createdDate;
	
	@LastModifiedDate
	private Date modifiedDate;
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSendTo() {
		return sendTo;
	}
	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTimezone() {
		return timezone;
	}
	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getStartDateTime() {
		return startDateTime;
	}
	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}
	public Date getEndDateTime() {
		return endDateTime;
	}
	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}
	public String getuId() {
		return uId;
	}
	public void setuId(String uId) {
		this.uId = uId;
	}
	public String getAttachmentPath() {
		return attachmentPath;
	}
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
		
}