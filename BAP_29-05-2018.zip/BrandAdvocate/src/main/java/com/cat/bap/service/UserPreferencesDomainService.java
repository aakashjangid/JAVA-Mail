package com.cat.bap.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.entity.Preferences;
import com.cat.bap.repository.UserPreferencesRepository;

@Service
public class UserPreferencesDomainService {

  @Inject
  private UserPreferencesRepository preferencesAccessRepository;
  
  @Transactional
  public List<Preferences> getPreferencesDetailsById(Long brandAdvocateId){
    List<Preferences> preferencesList = preferencesAccessRepository.getPreferencesDetailsById(brandAdvocateId);
    return preferencesList;
  }
  
}
