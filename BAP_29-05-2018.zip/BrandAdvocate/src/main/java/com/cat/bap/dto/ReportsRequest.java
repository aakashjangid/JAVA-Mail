package com.cat.bap.dto;

import java.io.Serializable;
import java.util.List;


/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose This class is used as request for reports.
 */
public class ReportsRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String lang;
	private transient List<AffiliationDetailsDto> firstDataList;
	private transient List<AffiliationDetailsDto> secondDataList;
	private String reportName;
	private String monthForFirstReport;
	private String yearForFirstReport;
	private String monthFromForSecondReport;
	private String yearFromForSecondReport;
	private String monthToForSecondReport;
	private String yearToForSecondReport;
	private String selectedXToDateForThirdReport;
	private String currentDateForThirdReport;
	private String comapreNameForGridThird;
	private String againstNameForGridThird;
	private boolean flagForHeader1ThirdReport;
	private boolean flagForHeader2ThirdReport;
	
	
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public List<AffiliationDetailsDto> getFirstDataList() {
		return firstDataList;
	}
	public void setFirstDataList(List<AffiliationDetailsDto> firstDataList) {
		this.firstDataList = firstDataList;
	}
	public List<AffiliationDetailsDto> getSecondDataList() {
		return secondDataList;
	}
	public void setSecondDataList(List<AffiliationDetailsDto> secondDataList) {
		this.secondDataList = secondDataList;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getMonthForFirstReport() {
		return monthForFirstReport;
	}
	public void setMonthForFirstReport(String monthForFirstReport) {
		this.monthForFirstReport = monthForFirstReport;
	}
	public String getYearForFirstReport() {
		return yearForFirstReport;
	}
	public void setYearForFirstReport(String yearForFirstReport) {
		this.yearForFirstReport = yearForFirstReport;
	}
	public String getMonthFromForSecondReport() {
		return monthFromForSecondReport;
	}
	public void setMonthFromForSecondReport(String monthFromForSecondReport) {
		this.monthFromForSecondReport = monthFromForSecondReport;
	}
	public String getYearFromForSecondReport() {
		return yearFromForSecondReport;
	}
	public void setYearFromForSecondReport(String yearFromForSecondReport) {
		this.yearFromForSecondReport = yearFromForSecondReport;
	}
	public String getMonthToForSecondReport() {
		return monthToForSecondReport;
	}
	public void setMonthToForSecondReport(String monthToForSecondReport) {
		this.monthToForSecondReport = monthToForSecondReport;
	}
	public String getYearToForSecondReport() {
		return yearToForSecondReport;
	}
	public void setYearToForSecondReport(String yearToForSecondReport) {
		this.yearToForSecondReport = yearToForSecondReport;
	}
	public String getSelectedXToDateForThirdReport() {
		return selectedXToDateForThirdReport;
	}
	public void setSelectedXToDateForThirdReport(String selectedXToDateForThirdReport) {
		this.selectedXToDateForThirdReport = selectedXToDateForThirdReport;
	}
	public String getCurrentDateForThirdReport() {
		return currentDateForThirdReport;
	}
	public void setCurrentDateForThirdReport(String currentDateForThirdReport) {
		this.currentDateForThirdReport = currentDateForThirdReport;
	}
	public String getComapreNameForGridThird() {
		return comapreNameForGridThird;
	}
	public void setComapreNameForGridThird(String comapreNameForGridThird) {
		this.comapreNameForGridThird = comapreNameForGridThird;
	}
	public String getAgainstNameForGridThird() {
		return againstNameForGridThird;
	}
	public void setAgainstNameForGridThird(String againstNameForGridThird) {
		this.againstNameForGridThird = againstNameForGridThird;
	}
	public boolean isFlagForHeader1ThirdReport() {
		return flagForHeader1ThirdReport;
	}
	public void setFlagForHeader1ThirdReport(boolean flagForHeader1ThirdReport) {
		this.flagForHeader1ThirdReport = flagForHeader1ThirdReport;
	}
	public boolean isFlagForHeader2ThirdReport() {
		return flagForHeader2ThirdReport;
	}
	public void setFlagForHeader2ThirdReport(boolean flagForHeader2ThirdReport) {
		this.flagForHeader2ThirdReport = flagForHeader2ThirdReport;
	}
	
	
	@Override
	public String toString() {
		return "ReportsRequest [lang=" + lang + ", firstDataList=" + firstDataList + ", secondDataList="
				+ secondDataList + ", reportName=" + reportName + ", monthForFirstReport=" + monthForFirstReport
				+ ", yearForFirstReport=" + yearForFirstReport + ", monthFromForSecondReport="
				+ monthFromForSecondReport + ", yearFromForSecondReport=" + yearFromForSecondReport
				+ ", monthToForSecondReport=" + monthToForSecondReport + ", yearToForSecondReport="
				+ yearToForSecondReport + ", selectedXToDateForThirdReport=" + selectedXToDateForThirdReport
				+ ", currentDateForThirdReport=" + currentDateForThirdReport + ", comapreNameForGridThird="
				+ comapreNameForGridThird + ", againstNameForGridThird=" + againstNameForGridThird
				+ ", flagForHeader1ThirdReport=" + flagForHeader1ThirdReport + ", flagForHeader2ThirdReport="
				+ flagForHeader2ThirdReport + "]";
	}

}