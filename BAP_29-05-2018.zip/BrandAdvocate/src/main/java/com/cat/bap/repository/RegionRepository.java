package com.cat.bap.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cat.bap.entity.Country;
import com.cat.bap.entity.Region;

public interface RegionRepository extends JpaRepository<Region, Long>{

  @Query("SELECT r.countries FROM Region r WHERE r.regionId =:regionId")
  public List<Country> getCountriesByRegionId(@Param("regionId") Long regionId);
  
}
