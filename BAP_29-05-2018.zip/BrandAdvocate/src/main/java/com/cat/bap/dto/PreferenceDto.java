package com.cat.bap.dto;

public class PreferenceDto {

  private Long preferenceId;
  private String preferenceName;
  
  
  public Long getPreferenceId() {
    return preferenceId;
  }
  public void setPreferenceId(Long preferenceId) {
    this.preferenceId = preferenceId;
  }
  public String getPreferenceName() {
    return preferenceName;
  }
  public void setPreferenceName(String preferenceName) {
    this.preferenceName = preferenceName;
  }
  
  @Override
  public String toString() {
    return "PreferenceDto [preferenceId=" + preferenceId + ", preferenceName=" + preferenceName
        + "]";
  }
  
}
