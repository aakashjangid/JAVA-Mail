package com.cat.bap.dto;


/**
 * @author rathor
 *
 */
public class AffiliationDetailsDto {

	private String affiliationTypeName;
	private long apCnt;
	private long anCnt;
	private long asCnt;
	private long eameCnt;
	private long totalAffiliationTypeRecordCnt;
	private long regionAPtotalCnt;
	private long regionAStotalCnt;
	private long regionANtotalCnt;
	private long regionEAMEtotalCnt;
	private long totalRegionRecordCnt;
	
	/**
	 * @return the regionAPtotalCnt
	 */
	public long getRegionAPtotalCnt() {
		return regionAPtotalCnt;
	}
	/**
	 * @param regionAPtotalCnt the regionAPtotalCnt to set
	 */
	public void setRegionAPtotalCnt(long regionAPtotalCnt) {
		this.regionAPtotalCnt = regionAPtotalCnt;
	}
	/**
	 * @return the regionAStotalCnt
	 */
	public long getRegionAStotalCnt() {
		return regionAStotalCnt;
	}
	/**
	 * @param regionAStotalCnt the regionAStotalCnt to set
	 */
	public void setRegionAStotalCnt(long regionAStotalCnt) {
		this.regionAStotalCnt = regionAStotalCnt;
	}
	/**
	 * @return the regionANtotalCnt
	 */
	public long getRegionANtotalCnt() {
		return regionANtotalCnt;
	}
	/**
	 * @param regionANtotalCnt the regionANtotalCnt to set
	 */
	public void setRegionANtotalCnt(long regionANtotalCnt) {
		this.regionANtotalCnt = regionANtotalCnt;
	}
	/**
	 * @return the regionEAMEtotalCnt
	 */
	public long getRegionEAMEtotalCnt() {
		return regionEAMEtotalCnt;
	}
	/**
	 * @param regionEAMEtotalCnt the regionEAMEtotalCnt to set
	 */
	public void setRegionEAMEtotalCnt(long regionEAMEtotalCnt) {
		this.regionEAMEtotalCnt = regionEAMEtotalCnt;
	}
	
	/**
	 * @return the affiliationTypeName
	 */
	public String getAffiliationTypeName() {
		return affiliationTypeName;
	}
	/**
	 * @param affiliationTypeName the affiliationTypeName to set
	 */
	public void setAffiliationTypeName(String affiliationTypeName) {
		this.affiliationTypeName = affiliationTypeName;
	}

	/**
	 * @return the apCnt
	 */
	public long getApCnt() {
		return apCnt;
	}
	/**
	 * @param apCnt the apCnt to set
	 */
	public void setApCnt(long apCnt) {
		this.apCnt = apCnt;
	}
	/**
	 * @return the anCnt
	 */
	public long getAnCnt() {
		return anCnt;
	}
	/**
	 * @param anCnt the anCnt to set
	 */
	public void setAnCnt(long anCnt) {
		this.anCnt = anCnt;
	}
	/**
	 * @return the asCnt
	 */
	public long getAsCnt() {
		return asCnt;
	}
	/**
	 * @param asCnt the asCnt to set
	 */
	public void setAsCnt(long asCnt) {
		this.asCnt = asCnt;
	}
	/**
	 * @return the eameCnt
	 */
	public long getEameCnt() {
		return eameCnt;
	}
	/**
	 * @param eameCnt the eameCnt to set
	 */
	public void setEameCnt(long eameCnt) {
		this.eameCnt = eameCnt;
	}
	
	public long getTotalRegionRecordCnt() {
		return totalRegionRecordCnt;
	}
	public void setTotalRegionRecordCnt(long totalRegionRecordCnt) {
		this.totalRegionRecordCnt = totalRegionRecordCnt;
	}
	public long getTotalAffiliationTypeRecordCnt() {
		return totalAffiliationTypeRecordCnt;
	}
	public void setTotalAffiliationTypeRecordCnt(long totalAffiliationTypeRecordCnt) {
		this.totalAffiliationTypeRecordCnt = totalAffiliationTypeRecordCnt;
	}
}
