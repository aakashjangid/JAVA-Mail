package com.cat.bap.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
@Component
public class BrandAdvocateEmailPropertyReader {

  @Value("${app.emailHost}")
  private String host;

  @Value("${app.emailPort}")
  private String port;

  @Value("${app.fromEmailId}")
  private String emailid;

  @Value("${app.emailUsername}")
  private String username;

  @Value("${app.emailPassword}")
  private String password;

  @Value("${app.doNotReply}")
  private String doNotReply;

  /**
   * @return the host
   */
  public String getHost() {
    return host;
  }

  /**
   * @param host the host to set
   */
  public void setHost(String host) {
    this.host = host;
  }

  /**
   * @return the port
   */
  public String getPort() {
    return port;
  }

  /**
   * @param port the port to set
   */
  public void setPort(String port) {
    this.port = port;
  }

  /**
   * @return the emailid
   */
  public String getEmailid() {
    return emailid;
  }

  /**
   * @param emailid the emailid to set
   */
  public void setEmailid(String emailid) {
    this.emailid = emailid;
  }

  /**
   * @return the username
   */
  public String getUsername() {
    return username;
  }

  /**
   * @param username the username to set
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }

  /**
   * @param password the password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }


  /**
   * @return the doNotReply
   */
  public String getDoNotReply() {
	return doNotReply;
  }
	
  /**
   * @param doNotReply the doNotReply to set
   */
  public void setDoNotReply(String doNotReply) {
	this.doNotReply = doNotReply;
  }
	  
}
