package com.cat.bap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cat.bap.entity.Documents;

public interface DocumentsRepository extends JpaRepository<Documents, Long>{

}
