package com.cat.bap.util;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.CommandMap;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.MailcapCommandMap;
import javax.activation.MimetypesFileTypeMap;
import javax.inject.Inject;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.exception.VelocityException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.cat.bap.common.BrandAdvocateConstant;
import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.Invitation;
import com.cat.bap.helper.UserMasterHelper;
import com.cat.bap.repository.InvitationRepository;

import cat.cis.tuf.common.email.EMailDocument;
import cat.cis.tuf.common.email.EMailException;

/**
 * @author Rani.Agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 16-March-2018
 * @purpose
 */

@Component
public class BrandAdvocateCalendarUtility extends EMailDocument {

	private static final Logger LOGGER = LoggerFactory.getLogger(BrandAdvocateCalendarUtility.class);

	@Inject
	private BrandAdvocateEmailPropertyReader brandAdvocateEmailPropertyReader;

	@Inject
	private Environment environment;
	
	@Inject
	private InvitationRepository invitationRepository;

	public void prepareCalendarInviteToSend(List<BAUserDetails> baUserDetailsList, String subjectTitle,
			String emailMessage, String startDatetime, String endDatetime, String location, Boolean isAttachment,
			String timeZone, Date startDate, Date endDate, Long invitationId) {
		try {
			sendCalendarInvite(baUserDetailsList, subjectTitle, emailMessage, startDatetime, endDatetime, location,
					isAttachment, timeZone, startDate, endDate, invitationId);
		} catch (Exception exception) {
			LOGGER.info("\n<=========== Brand Advocate ===========>" + exception);
		}
	}

	public boolean sendCalendarInvite(List<BAUserDetails> baUserDetailsList, String subject, String msg,
			String startDateTime, String endDateTime, String location, Boolean isAttachment, String timeZone,
			Date startDate, Date endDate, Long invitationId)
			throws MessagingException, VelocityException, IOException, EMailException {
		LOGGER.info("\n<=========== Brand Advocate ===========>" + "BrandAdvocateEmailUtility's sendMessage method");

		boolean isSent = false;
		String uid = null;
		if (invitationId != null) {
			Invitation invitation = invitationRepository.findOne(invitationId);
			uid = invitation.getuId();
		} else {
			uid = Math.random() + "" + startDateTime;
		}

		//String emailsAddresses = "";
		StringBuffer emailsAddresses = new StringBuffer();
		String prefix = "";

		for (BAUserDetails baUserDetails : baUserDetailsList) {

			String userPrimaryEmail = (null != baUserDetails.getPrimaryEmail()
					&& !baUserDetails.getPrimaryEmail().equals("")) ? baUserDetails.getPrimaryEmail() : "";
			String userSecondaryEmail = (null != baUserDetails.getSecondaryEmail()
					&& !baUserDetails.getSecondaryEmail().equals("")) ? baUserDetails.getSecondaryEmail() : "";

			String userEmail = !userPrimaryEmail.equals("") ? userPrimaryEmail : userSecondaryEmail;

			if (!userEmail.equals("")) {
				String emailAddress = userEmail;
				Properties properties = new Properties();
				properties.setProperty("resource.loader", "class");
				properties.setProperty("class.resource.loader.class",
						"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
				Velocity.init(properties);
				Template template = Velocity.getTemplate("templates/suggestPodcastNotificationMessage.vm", "UTF-8");
				VelocityContext velocityContext = getVelocityContext(msg);

				StringWriter stringWriter = new StringWriter();

				/** comment if wants to send calender invite */
				template.merge(velocityContext, stringWriter);
				if (!isAttachment) {
					isSent = send(emailAddress, subject, msg, startDateTime, endDateTime, location, timeZone, uid);
				} else {
					isSent = sendWithAttachment(emailAddress, subject, msg, startDateTime, endDateTime, location,
							timeZone, uid);
				}

				LOGGER.info("\n<=========== Brand Advocate ===========>send()" + UserMasterConstant.MESSAGE_SENT);

			}
			//emailsAddresses += userEmail + ",";
			emailsAddresses.append(prefix+" ");
			prefix = ",";
			emailsAddresses.append(userEmail);
		}

		if (invitationId != null) {
			Invitation invitation = UserMasterHelper.convertDtoToEntity(emailsAddresses.toString(), subject, msg, startDate,
					endDate, location, timeZone);
			invitation.setId(invitationId);
			invitationRepository.save(invitation);
		}else{
			Invitation invitation = UserMasterHelper.convertDtoToEntity(emailsAddresses.toString(), subject, msg, startDate,
					endDate, location, timeZone);
			invitation.setuId(uid);
			invitationRepository.save(invitation);
		}

		/** Logic to delete files from folder after mail sending starts */
		File[] listOfFiles = null;
		String attachmentPath = environment.getProperty("app.commonFilePath") + "/massmail/";
		File attachmentFolder = new File(attachmentPath);
		listOfFiles = attachmentFolder.listFiles();
		if (isAttachment && null != listOfFiles) {
			for (int j = 0; j < listOfFiles.length; j++) {
				if (listOfFiles[j].isFile()) {
					listOfFiles[j].getAbsoluteFile().delete();
				}
			}
		}
		/*
		 * for (int j = 0; j < listOfFiles.length; j++) { if
		 * (listOfFiles[j].isDirectory()) { listOfFiles[j].delete(); } }
		 */
		/** Logic to delete files from folder afetr mail sending ends */

		return isSent;
	}

	public boolean send(String emailAddress, String subject, String msg, String startDateTime, String endDateTime,
			String location, String timeZone, String uid) throws EMailException, IOException {
		emailAddress = BrandAdvocateConstant.USER_TESTER_EMAIL;
		boolean isSent = false;
		try {
			MimetypesFileTypeMap mimetypes = (MimetypesFileTypeMap) MimetypesFileTypeMap.getDefaultFileTypeMap();
			mimetypes.addMimeTypes("text/calendar ics ICS");
			MailcapCommandMap mailcap = (MailcapCommandMap) MailcapCommandMap.getDefaultCommandMap();
			mailcap.addMailcap("text/calendar;; x-java-content-handler=com.sun.mail.handlers.text_plain");

			Properties props = System.getProperties();
			props.put("mail.smtp.host", "intramail.cis.cat.com");
			Session session = Session.getDefaultInstance(props, null);
			BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);
			String fromMail = brandAdvocateEmailPropertyReader.getEmailid();

			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress(fromMail));
			message.addRecipients(Message.RecipientType.TO, emailAddress);
			message.setHeader("Errors-To", emailAddress);
			message.setSubject(subject);

			String buffer = "BEGIN:VCALENDAR\n" + "PRODID:-//Microsoft Corporation//Outlook 16.0 MIMEDIR//EN\n"
					+ "VERSION:2.0\n" + "METHOD:REQUEST\n" + "X-WR-TIMEZONE:" + timeZone + "\n" + "BEGIN:VEVENT\n"
					+ "ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=FALSE:MAILTO:" + emailAddress + "\n"
					+ "ORGANIZER:MAILTO:" + fromMail + "\n" + "DTSTART:" + startDateTime + "Z\n" + "DTEND:"
					+ endDateTime + "Z\n" + "LOCATION:" + location + "\n" + "TRANSP:OPAQUE\n" + "SEQUENCE:0\n" + "UID:"
					+ uid + "\n" + "DESCRIPTION:" + "test meeting invite" + "\n\n" + "SUMMARY:" + "" + "\n"
					+ "PRIORITY:5\n" + "CLASS:PUBLIC\n" + "STATUS:CONFIRMED\n" + "BEGIN:VALARM\n"
					+ "TRIGGER;RELATED=START:-PT00H15M00S\n" + "ACTION:DISPLAY\n" + "DESCRIPTION:REMINDER\n"
					+ "END:VALARM\n" + "END:VEVENT\n" + "END:VCALENDAR";

			Multipart multipart = new MimeMultipart("mixed");

			Multipart mpMixedAlternative = newChild(multipart, "alternative");

			msg = getHtmlWithEncodedImages(multipart, msg);

			// Add part one, HTML part
			BodyPart messageBodyPart = buildHtmlTextPart(msg);

			mpMixedAlternative.addBodyPart(messageBodyPart);

			BodyPart calendarPart = new MimeBodyPart();
			calendarPart.addHeader("Content-Class", "urn:content-classes:calendarmessage");
			calendarPart.setContent(buffer, "text/calendar;method=REQUEST");
			calendarPart.setDisposition(BodyPart.INLINE);
			multipart.addBodyPart(calendarPart);

			// Put the multipart in message
			message.setContent(multipart);

			// send the message
			Transport transport = session.getTransport("smtp");
			transport.connect();
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
			isSent = true;
		} catch (MessagingException sfe) {
			LOGGER.info("\n<=========== Brand Advocate ===========>SendFailedException" + sfe);
			throw new EMailException(sfe);
		}
		return isSent;
	}

	public boolean sendWithAttachment(String emailAddress, String subject, String msg, String startDateTime,
			String endDateTime, String location, String timeZone, String uid) throws EMailException {
		emailAddress = BrandAdvocateConstant.USER_TESTER_EMAIL;
		boolean isSent = false;
		try {
			MimetypesFileTypeMap mimetypes = (MimetypesFileTypeMap) MimetypesFileTypeMap.getDefaultFileTypeMap();
			mimetypes.addMimeTypes("text/calendar ics ICS");
			MailcapCommandMap mailcap = (MailcapCommandMap) MailcapCommandMap.getDefaultCommandMap();
			mailcap.addMailcap("text/calendar;; x-java-content-handler=com.sun.mail.handlers.text_plain");

			Properties props = System.getProperties();
			props.put("mail.smtp.host", "intramail.cis.cat.com");
			Session session = Session.getDefaultInstance(props, null);
			BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);
			String fromMail = brandAdvocateEmailPropertyReader.getEmailid();

			MimeMessage message = new MimeMessage(session);

			message.setFrom(new InternetAddress(fromMail));
			message.addRecipients(Message.RecipientType.TO, emailAddress);
			message.setHeader("Errors-To", emailAddress);
			message.setSubject(subject);

			String buffer = "BEGIN:VCALENDAR\n" + "PRODID:-//Microsoft Corporation//Outlook 16.0 MIMEDIR//EN\n"
					+ "VERSION:2.0\n" + "METHOD:REQUEST\n" + "X-WR-TIMEZONE:" + timeZone + "\n" + "BEGIN:VEVENT\n"
					+ "ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=FALSE:MAILTO:" + emailAddress + "\n"
					+ "ORGANIZER:MAILTO:" + fromMail + "\n" + "DTSTART:" + startDateTime + "Z\n" + "DTEND:"
					+ endDateTime + "Z\n" + "LOCATION:" + location + "\n" + "TRANSP:OPAQUE\n" + "SEQUENCE:0\n" + "UID:"
					+ uid + "\n" + "DESCRIPTION:" + "test meeting invite" + "\n\n" + "SUMMARY:" + "" + "\n"
					+ "PRIORITY:5\n" + "CLASS:PUBLIC\n" + "STATUS:CONFIRMED\n" + "BEGIN:VALARM\n"
					+ "TRIGGER;RELATED=START:-PT00H15M00S\n" + "ACTION:DISPLAY\n" + "DESCRIPTION:REMINDER\n"
					+ "END:VALARM\n" + "END:VEVENT\n" + "END:VCALENDAR";

			// Create an alternative Multipart
			Multipart multipart = new MimeMultipart("mixed");

			Multipart mpMixedAlternative = newChild(multipart, "alternative");

			msg = getHtmlWithEncodedImages(multipart, msg);

			// Add part one, HTML part
			BodyPart messageBodyPart = buildHtmlTextPart(msg);

			mpMixedAlternative.addBodyPart(messageBodyPart);

			// Add part two, the calendar
			BodyPart calendarPart = new MimeBodyPart();
			calendarPart.addHeader("Content-Class", "urn:content-classes:calendarmessage");
			calendarPart.setContent(buffer, "text/calendar;method=REQUEST");
			calendarPart.setDisposition(BodyPart.INLINE);

			mpMixedAlternative.addBodyPart(calendarPart);

			/** Add attachment code starts */
			File[] listOfFiles = null;
			String attachmentPath = environment.getProperty("app.commonFilePath") + "/massmail/";
			File attachmentFolder = new File(attachmentPath);
			listOfFiles = attachmentFolder.listFiles();
			for (int k = 0; k < listOfFiles.length; k++) {
				if (listOfFiles[k].isFile()) {
					MimeBodyPart mbpAttachment = new MimeBodyPart();
					DataSource source = new FileDataSource(attachmentPath + "/" + listOfFiles[k].getName());
					mbpAttachment.setDataHandler(new DataHandler(source));
					mbpAttachment.setFileName(attachmentPath + "/" + listOfFiles[k].getName());
					mbpAttachment.setDisposition(BodyPart.ATTACHMENT);
					multipart.addBodyPart(mbpAttachment);
				}
			}
			/** Add attachment code ends */
			// Put the multipart in message

			message.setContent(multipart);

			// Put the multipart in message
			// message.setContent(multipart);

			// File[] listOfFiles = null;
			// String attachmentPath =
			// environment.getProperty("app.commonFilePath") + "/massmail/";
			// File attachmentFolder = new File(attachmentPath);
			// listOfFiles = attachmentFolder.listFiles();
			// for (int k = 0; k < listOfFiles.length; k++) {
			// if (listOfFiles[k].isFile()) {
			// BodyPart messageBodyPart2 = new MimeBodyPart();
			// DataSource source = new FileDataSource(attachmentPath + "/" +
			// listOfFiles[k].getName());
			// messageBodyPart2.setDataHandler(new DataHandler(source));
			// messageBodyPart2.setFileName(listOfFiles[k].getName());
			// multipart.addBodyPart(messageBodyPart2);
			// message.setContent(multipart);
			// }
			//
			// }
			// send the message

			/*
			 * ExecutorService executor = Executors.newFixedThreadPool(1); //
			 * used to get future value of Asyc task. Future<?> future = null;
			 * 
			 * try { future = executor.submit(() -> {
			 */
			try {
				Transport transport = session.getTransport("smtp");
				transport.connect();
				transport.sendMessage(message, message.getAllRecipients());
				transport.close();
				isSent = true;
			} catch (MessagingException e) {
				e.printStackTrace();
			}
			isSent = true;
			/* }); */
		} catch (Exception exception) {
			LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + exception + " : "
					+ BrandAdvocateConstant.SENDING_FAILED_TO_MAILID + emailAddress);
		}

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + BrandAdvocateConstant.MESSAGE_SENT);

		/*
		 * if(future.isDone()){ if (null != listOfFiles) { for (int j = 0; j <
		 * listOfFiles.length; j++) { if (listOfFiles[j].isFile()) {
		 * listOfFiles[j].getAbsoluteFile().delete(); } } } String massMail =
		 * environment.getProperty("app.commonFilePath") + "/massmail"; File
		 * massMailFolder = new File(massMail); File[] listFolder =
		 * massMailFolder.listFiles(); for (int j = 0; j < listFolder.length;
		 * j++) { if (listFolder[j].isDirectory()) { listFolder[j].delete(); } }
		 * } // Boolean deleted=sendWithAttachment(); } catch
		 * (MessagingException sfe) { LOGGER.
		 * info("\n<=========== Brand Advocate ===========>SendFailedException"
		 * + sfe); throw new EMailException(sfe); }
		 */

		// File[] listOfFiles = null;
		// String attachmentPath = environment.getProperty("app.commonFilePath")
		// + "/massmail/";
		// File attachmentFolder = new File(attachmentPath);
		// listOfFiles = attachmentFolder.listFiles();
		//
		// if (null != listOfFiles) {
		// for (int j = 0; j < listOfFiles.length; j++) {
		// if (listOfFiles[j].isFile()) {
		// listOfFiles[j].getAbsoluteFile().delete();
		// }
		// }
		// }

		return isSent;
	}

	private BodyPart buildHtmlTextPart(String description) throws MessagingException {

		MimeBodyPart descriptionPart = new MimeBodyPart();
		descriptionPart.setContent(description, "text/html; charset=utf-8");

		return descriptionPart;

	}

	private Multipart newChild(Multipart parent, String alternative) throws MessagingException {

		MimeMultipart child = new MimeMultipart(alternative);
		MimeBodyPart mbp = new MimeBodyPart();
		parent.addBodyPart(mbp);
		mbp.setContent(child);

		return child;

	}

	public String getHtmlWithEncodedImages(Multipart parent, String msg) {

		String temp = msg;
		String html = "<html><body>" + msg + "</body></html>";
		Document document = Jsoup.parse(html);
		Elements allElements = document.body().getElementsByTag("img");
		for (Element element : allElements) {
			String elementstring = element.toString();
			String tempfilename = elementstring.substring(elementstring.indexOf("file"));
			String filename = tempfilename.substring(0, tempfilename.indexOf('"'));
			temp = temp.replace(elementstring.substring(elementstring.indexOf('"'), elementstring.lastIndexOf('"')),
					"\"cid:" + filename);

			addImages(parent, filename);
		}
		return temp;
	}

	private void addImages(Multipart parent, String filename) {

		MimeBodyPart mbpAttachment = new MimeBodyPart();

		try {
			String path = System.getProperty("tuf.appFiles.rootDirectory");
			File file = new File(path + "/template-images/" + filename);
			FileDataSource ds = new FileDataSource(file);
			mbpAttachment.setDataHandler(new DataHandler(ds));
			mbpAttachment.setDisposition(BodyPart.INLINE);
			mbpAttachment.setHeader("Content-ID", "<" + filename + ">");
			mbpAttachment.setFileName(filename);
			parent.addBodyPart(mbpAttachment);
		} catch (Exception e) {
			LOGGER.error("<=========== Brand Advocate ===========>" + "BrandAdvocateEmailUtility's addImage "
					+ e.getMessage());
		}
	}

	protected Message getMessage(String emailAddress, String subject, String msg, String startDateTime,
			String endDateTime, String location, String timeZone) throws EMailException {
		Message msg1 = null;
		try {
			msg1 = getMessageHeaders(emailAddress, subject);
			msg1.setContent(getMessageBody(emailAddress, subject, msg, startDateTime, endDateTime, location, timeZone));
		} catch (Exception e) {
			throw new EMailException(e);
		}
		return msg1;
	}

	protected Message getMessageWithAttachment(String emailAddress, String subject, String msg, String startDateTime,
			String endDateTime, String location, String timeZone) throws EMailException {
		Message msg1 = null;
		try {
			msg1 = getMessageHeaders(emailAddress, subject);
			msg1.setContent(getMessageBodyWithAttachment(emailAddress, subject, msg, startDateTime, endDateTime,
					location, msg1, timeZone));
		} catch (Exception e) {
			throw new EMailException(e);
		}
		return msg1;
	}

	protected Message getMessageHeaders(String emailAddress, String subject)
			throws MessagingException, AddressException {
		// Get a Session object
		// register the text/calendar mime type
		MimetypesFileTypeMap mimetypes = (MimetypesFileTypeMap) MimetypesFileTypeMap.getDefaultFileTypeMap();
		mimetypes.addMimeTypes("text/calendar ics ICS");
		// mimetypes.addMimeTypes("Content-Type: text/calendar; method=REQUEST;
		// charset=UTF-8");

		MailcapCommandMap mailcap = (MailcapCommandMap) MailcapCommandMap.getDefaultCommandMap();
		mailcap.addMailcap("text/calendar;; x-java-content-handler=com.sun.mail.handlers.text_plain");

		CommandMap.setDefaultCommandMap(mailcap);
		Properties props = System.getProperties();
		props.put("mail.smtp.host", "intramail.cis.cat.com");
		Session session = Session.getDefaultInstance(props, null);

		MimeMessage msg = new MimeMessage(session);
		// msg.setFrom(new InternetAddress("rani.agrawal@yash.com"));
		msg.addRecipients(Message.RecipientType.TO, emailAddress);
		msg.setHeader("Errors-To", emailAddress);
		msg.setSubject(subject);
		msg.setSentDate(new Date());

		msg.addHeaderLine("method=REQUEST");
		msg.addHeaderLine("charset=UTF-8");
		msg.addHeaderLine("component=VEVENT");

		return msg;
	}

	protected Multipart getMessageBody(String emailAddress, String subject, String msg, String startDateTime,
			String endDateTime, String location, String timeZone) throws MessagingException {

		// Create the container for the message
		StringBuffer sb = new StringBuffer();
		BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);
		String fromMail = brandAdvocateEmailPropertyReader.getEmailid();

		StringBuffer buffer = sb
				.append("BEGIN:VCALENDAR\n" + "PRODID:-//Microsoft Corporation//Outlook 16.0 MIMEDIR//EN\n"
						+ "VERSION:2.0\n" + "METHOD:REQUEST\n" + "X-WR-TIMEZONE:" + timeZone + "\n"

						+ "BEGIN:VEVENT\n" + "ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:" + emailAddress + "\n"
						+ "ORGANIZER:MAILTO:" + fromMail + "\n" + "DTSTART:" + startDateTime + "Z\n" + "DTEND:"
						+ endDateTime + "Z\n" + "LOCATION:" + location + "\n" + "TRANSP:OPAQUE\n" + "SEQUENCE:0\n"
						+ "UID:040000008200E00074C5B7101A82E00800000000A0A742E5073AC5010000000000000000100\n"
						+ " 0000029606C073D82204AB6C77ACE6BC2FBE2\n" + "DESCRIPTION:" + "test meeting invite" + "\n\n"
						+ "SUMMARY:" + "" + "\n" + "PRIORITY:5\n" + "CLASS:PUBLIC\n" + "BEGIN:VALARM\n"
						+ "TRIGGER:PT1440M\n" + "ACTION:DISPLAY\n" + "DESCRIPTION:Reminder\n" + "END:VALARM\n"
						+ "END:VEVENT\n" + "END:VCALENDAR");

		Multipart mp = new MimeMultipart();
		// create and fill the body of the message
		MimeBodyPart msgbody = new MimeBodyPart();
		// Fill the message
		msgbody.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
		msgbody.setHeader("Content-ID", "calendar_message");

		try {

			msgbody.setDataHandler(new DataHandler(new ByteArrayDataSource(buffer.toString(), "text/calendar")));
			msgbody.setDisposition(MimeBodyPart.INLINE);

		} catch (IOException e) {
			e.printStackTrace();
		} // very important

		mp.addBodyPart(msgbody);
		return mp;
	}

	protected Multipart getMessageBodyWithAttachment(String emailAddress, String subject, String msg,
			String startDateTime, String endDateTime, String location, Message msg1, String timeZone)
			throws MessagingException {
		// Create the container for the message
		StringBuffer sb = new StringBuffer();
		BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);
		String fromMail = brandAdvocateEmailPropertyReader.getEmailid();
		// DateFormat iCalendarDateFormat = new
		// SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'");
		Date dTstamp = new Date();
		// This is for UTC time
		// SimpleDateFormat iCalendarDateFormat = new
		// SimpleDateFormat("yyyyMMdd'T'HHmm'00'");
		// iCalendarDateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
		//// String start = iCalendarDateFormat.format(startDateTime);
		// String end = iCalendarDateFormat.format(endDateTime);

		StringBuffer buffer = sb.append("BEGIN:VCALENDAR\n"
				+ "PRODID:-//Microsoft Corporation//Outlook 16.0 MIMEDIR//EN\n" + "VERSION:2.0\n" + "METHOD:REQUEST\n"
				+ "X-WR-TIMEZONE:" + timeZone + "\n" + "BEGIN:VEVENT\n"
				+ "ATTENDEE;ROLE=REQ-PARTICIPANT;RSVP=FALSE:MAILTO:" + emailAddress + "\n" + "ORGANIZER:MAILTO:"
				+ fromMail + "\n" + "DTSTART:" + startDateTime + "\n" + "DTEND:" + endDateTime + "\n" + "LOCATION:"
				+ location + "\n" + "TRANSP:OPAQUE\n" + "SEQUENCE:0\n"
				+ "UID:040000008200E00074C5B7101A82E00800000000002FF466CE3AC5010000000000000000100\n"
				+ " 000004377FE5C37984842BF9440448399EB02\n" + "DTSTAMP:" + dTstamp + "\n" + "CATEGORIES:Meeting\n"
				+ "DESCRIPTION:" + msg + ".\n\n" + "SUMMARY:" + subject + "\n" + "PRIORITY:5\n" + "CLASS:PUBLIC\n"
				+ "BEGIN:VALARM\n" + "TRIGGER:PT1440M\n" + "ACTION:DISPLAY\n" + "DESCRIPTION:Reminder\n"
				+ "END:VALARM\n" + "END:VEVENT\n" + "END:VCALENDAR");

		Multipart mp = new MimeMultipart();
		// create and fill the body of the message
		MimeBodyPart body = new MimeBodyPart();
		// Fill the message
		body.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
		body.setHeader("Content-ID", "calendar_message");
		body.setDisposition(MimeBodyPart.INLINE);

		try {

			body.setDataHandler(new DataHandler(new ByteArrayDataSource(buffer.toString(), "text/calendar")));
		} catch (IOException e) {
			e.printStackTrace();
		} // very important

		mp.addBodyPart(body);

		File[] listOfFiles = null;
		String attachmentPath = environment.getProperty("app.commonFilePath") + "/massmail/";
		File attachmentFolder = new File(attachmentPath);
		listOfFiles = attachmentFolder.listFiles();
		for (int k = 0; k < listOfFiles.length; k++) {
			if (listOfFiles[k].isFile()) {
				MimeBodyPart messageBodyPart2 = new MimeBodyPart();
				DataSource source = new FileDataSource(attachmentPath + "/" + listOfFiles[k].getName());
				messageBodyPart2.setDataHandler(new DataHandler(source));
				messageBodyPart2.setFileName(listOfFiles[k].getName());
				mp.addBodyPart(messageBodyPart2);
				msg1.setContent(mp);
			}
		}

		return mp;
	}

	/**
	 * This method is used to get Velocity Context Object
	 * 
	 * @param msg
	 * @return VelocityContext
	 */
	private VelocityContext getVelocityContext(String msg) {
		LOGGER.info(
				"\n<=========== Brand Advocate ===========>" + "BrandAdvocateEmailUtility's getVelocityContext method");
		VelocityContext velocityContext = new VelocityContext();
		velocityContext.put(UserMasterConstant.MESSAGE_BODY, msg);
		velocityContext.put(UserMasterConstant.MAIL_FROM, "");
		velocityContext.put(UserMasterConstant.TEAM_BRAND_ADVOCATE, "Team Brand Advocate");
		return velocityContext;
	}

}
