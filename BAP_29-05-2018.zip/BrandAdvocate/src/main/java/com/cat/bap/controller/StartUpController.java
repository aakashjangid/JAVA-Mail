package com.cat.bap.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
@RestController
public class StartUpController {
  @RequestMapping(value = "/")
  public ModelAndView processSubmit() {
    return new ModelAndView("redirect:/login");
  }

}
