package com.cat.bap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cat.bap.entity.BARegistrationVia;


public interface BARegistrationViaRepository extends JpaRepository<BARegistrationVia, Long>{

}
