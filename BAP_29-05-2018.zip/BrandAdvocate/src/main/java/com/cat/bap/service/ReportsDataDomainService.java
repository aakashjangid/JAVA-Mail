package com.cat.bap.service;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.entity.AffiliationDescription;
import com.cat.bap.repository.AffilationDescRepository;

@Service
public class ReportsDataDomainService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsDataDomainService.class);

	@Inject
	private AffilationDescRepository affilationDescRepository;

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public List<String> getAffiliationDescByName(String affliationDesc) {
		return affilationDescRepository.getAffiliationDescByName(affliationDesc);
	}
	
	@Transactional
	public String getAffiliationNameByDesc(String affliationName) {
		return affilationDescRepository.getAffiliationNameByDesc(affliationName);
	}
	
	@Transactional
	public List<String> getAllAffiliationNames() {
		
		////Query query = entityManager.createNamedQuery("getAllAffiliationNames");
		
		/** List of affiliation name on UI**/
		return affilationDescRepository.getAllAffiliationNames();
		///return  (List<String>)query.getResultList();
	}
}
