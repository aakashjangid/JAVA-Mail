package com.cat.bap.util;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;


/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose
 */
public class ExportToExcelUtilityForUserMaster {

  private XSSFCellStyle dataStyle;

  @Transactional(readOnly=true)
  public XSSFWorkbook generateExcel(List<BAUserDetailsDto> userMasterDTOs, String lang)
      throws IOException {

	  XSSFWorkbook workbook = null;

    Properties prop = new Properties();
    String propFileName = "properties/locale_" + lang + ".properties";

    InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);

    if (inputStream != null) {
      Reader reader = new InputStreamReader(inputStream, "UTF-8");
      prop.load(reader);
    } else {
      throw new FileNotFoundException(
          "property file '" + propFileName + "' not found in the classpath");
    }
    workbook = new XSSFWorkbook();
    XSSFSheet worksheet = workbook.createSheet(UserMasterConstant.ADMIN_EXCEL_SHEET_NAME);
    XSSFRow row = worksheet.createRow((short) 0);
    XSSFCellStyle style = ExcelUtil.getStyle(workbook);
    dataStyle = ExcelUtil.getDataStyle(workbook);
    XSSFCell cell;
    BAUserDetailsDto bAUserDetailsDto;
    XSSFCell tempCell;

    List<String> headerNames = new ArrayList<>();
      headerNames.add(prop.getProperty(UserMasterConstant.CUP_ID));
      headerNames.add(prop.getProperty(UserMasterConstant.CWS_USER_ID));
      headerNames.add(prop.getProperty(UserMasterConstant.LAST_NAME));
      headerNames.add(prop.getProperty(UserMasterConstant.FIRST_NAME));
      headerNames.add(prop.getProperty(UserMasterConstant.PREFERRED_FIRST_NAME));
      headerNames.add(prop.getProperty(UserMasterConstant.ORG_UNIT));
      headerNames.add(prop.getProperty(UserMasterConstant.EMAIL));
      headerNames.add(prop.getProperty(UserMasterConstant.SECONDARY_EMAIL));
      headerNames.add(prop.getProperty(UserMasterConstant.REGION));
      headerNames.add(prop.getProperty(UserMasterConstant.COUNTRY));
      headerNames.add(prop.getProperty(UserMasterConstant.FACILITY_NAME));
      headerNames.add(prop.getProperty(UserMasterConstant.COMMON_BUILDING));
      headerNames.add(prop.getProperty(UserMasterConstant.AFFILIATION_DESCRIPTION));
      headerNames.add(prop.getProperty(UserMasterConstant.JOB_KEYWORDS));
      headerNames.add(prop.getProperty(UserMasterConstant.SUB_PREFERENCES));
      headerNames.add(prop.getProperty(UserMasterConstant.QUESTIONS_COMMENTS));
      headerNames.add(prop.getProperty(UserMasterConstant.COMMON_NOTES));
      headerNames.add(prop.getProperty(UserMasterConstant.COMMON_REGISTERED_VIA));
      headerNames.add(prop.getProperty(UserMasterConstant.COMMON_REGISTRATION_DATE));
      headerNames.add(prop.getProperty(UserMasterConstant.COMMON_REGISTERED_BY));
      headerNames.add(prop.getProperty(UserMasterConstant.COMMON_MODIFIED_DATE));
      headerNames.add(prop.getProperty(UserMasterConstant.COMMON_MODIFIED_BY));

    for (int headerIndex = 0; headerIndex < headerNames.size(); headerIndex++) {
      cell = row.createCell(headerIndex);
      if (headerNames.get(headerIndex).length() > 15) {
        worksheet.setColumnWidth(headerIndex, 20 * 256);
      } else {
        worksheet.setColumnWidth(headerIndex, 15 * 256);
      }
      cell.setCellValue(headerNames.get(headerIndex));
      cell.setCellStyle(style);
    }

    for (int rowIndex = 0; rowIndex < userMasterDTOs.size(); rowIndex++) {
      row = worksheet.createRow((short) rowIndex + 1);
      bAUserDetailsDto = userMasterDTOs.get(rowIndex);
      int colIndex = 0;
      
         String cupId = bAUserDetailsDto.getCupId();
         tempCell = createCell(row, colIndex);
         if (!BrandAdvocateUtility.isEmptyString(cupId)) {
             tempCell.setCellValue(cupId);
         }
          
        colIndex++;

        String cwsUserId = bAUserDetailsDto.getCwsUserId();
        tempCell = createCell(row, colIndex);
        if (!BrandAdvocateUtility.isEmptyString(cwsUserId)) {
          tempCell.setCellValue(cwsUserId);
        }

        colIndex++;
    
        String lastName = bAUserDetailsDto.getLastName();
        tempCell = createCell(row, colIndex);

        if (!BrandAdvocateUtility.isEmptyString(lastName)) {
          tempCell.setCellValue(lastName);
      }
        
        colIndex++;
        
        String firstName = bAUserDetailsDto.getFirstName();
        tempCell = createCell(row, colIndex);

        if (!BrandAdvocateUtility.isEmptyString(firstName)) {
          tempCell.setCellValue(firstName);
      }
        
        colIndex++;
        
        String preferredFirstName = bAUserDetailsDto.getPreferredFirstName();
        tempCell = createCell(row, colIndex);

        if (!BrandAdvocateUtility.isEmptyString(preferredFirstName)) {
          tempCell.setCellValue(preferredFirstName);
      }
        
        colIndex++;
        
        String organizationName = bAUserDetailsDto.getOrganizationName();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(organizationName)) {
          tempCell.setCellValue(organizationName);
        }
        
        colIndex++;
        
        
        String email = bAUserDetailsDto.getPrimaryEmail();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(email)) {
          tempCell.setCellValue(email);
        }
        
        colIndex++;

        String secondaryEmail = bAUserDetailsDto.getSecondaryEmail();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(secondaryEmail)) {
          tempCell.setCellValue(secondaryEmail);
        }
        
        colIndex++;

        String region = bAUserDetailsDto.getRegionName();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(region)) {
          tempCell.setCellValue(region);
        }
        
        colIndex++;
        
        String country = bAUserDetailsDto.getCountryName();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(country)) {
          tempCell.setCellValue(country);
        }
        
        colIndex++;

        String facilityName = bAUserDetailsDto.getFacilityName();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(facilityName)) {
          tempCell.setCellValue(facilityName);
        }
        
        colIndex++;

        String buildingName = bAUserDetailsDto.getBuildingName();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(buildingName)) {
          tempCell.setCellValue(buildingName);
        }
        
        colIndex++;
        
        String affiliationDescription = bAUserDetailsDto.getAffiliationDescription();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(affiliationDescription)) {
          tempCell.setCellValue(affiliationDescription);
        }
        
        colIndex++;

        String jobKeywords = bAUserDetailsDto.getJobKeywords();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(jobKeywords)) {
          tempCell.setCellValue(jobKeywords);
        }
        
        colIndex++;
        
        String preferences = bAUserDetailsDto.getPreferencesStr();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(preferences)) {
          tempCell.setCellValue(preferences);
        }
        
        colIndex++;

        String comments = bAUserDetailsDto.getComments();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(comments)) {
          tempCell.setCellValue(comments);
        }
        
        colIndex++;

        String notes = bAUserDetailsDto.getNotes();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(notes)) {
          tempCell.setCellValue(notes);
        }
        
        colIndex++;

        String registeredVia = bAUserDetailsDto.getRegisteredVia();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(registeredVia)) {
          tempCell.setCellValue(registeredVia);
        }
        
        colIndex++;
        
        String registrationDate = bAUserDetailsDto.getCustomRegistrationDate();
        tempCell = createCell(row, colIndex);
        if (!BrandAdvocateUtility.isEmptyString(registrationDate)) {
          tempCell.setCellValue(registrationDate);
        }

        colIndex++;
        
        String registeredBy = bAUserDetailsDto.getRegisteredBy();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(registeredBy)) {
          tempCell.setCellValue(registeredBy);
        }
        
        colIndex++;
        
        String modifiedDate = bAUserDetailsDto.getCustomModifiedDate();
        tempCell = createCell(row, colIndex);
        if (!BrandAdvocateUtility.isEmptyString(modifiedDate)) {
          tempCell.setCellValue(modifiedDate);
        }

        colIndex++;
        
        String modifiedBy = bAUserDetailsDto.getModifiedBy();
        tempCell = createCell(row, colIndex);
        
        if (!BrandAdvocateUtility.isEmptyString(modifiedBy)) {
          tempCell.setCellValue(modifiedBy);
        }
        
    }

    return workbook;
  }

  /**
   * This method will create empty cell
   * 
   * @param row
   * @param colIndex
   * @return {@link XSSFCell}
   */
  public XSSFCell createCell(XSSFRow row, int colIndex) {
    XSSFCell cell = row.createCell(colIndex);
    cell.setCellStyle(dataStyle);
    return cell;
  }


  
}
