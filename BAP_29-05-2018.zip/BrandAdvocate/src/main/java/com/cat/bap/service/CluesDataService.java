package com.cat.bap.service;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.inject.Inject;
import javax.mail.MessagingException;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.exception.VelocityException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.common.BrandAdvocateConstant;
import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.dto.RegionDto;
import com.cat.bap.entity.AffiliationDescription;
import com.cat.bap.entity.Country;
import com.cat.bap.helper.MasterDataHelper;
import com.cat.bap.repository.AffilationDescRepository;
import com.cat.bap.repository.BAUserDetailsRepositoryCustom;
import com.cat.bap.repository.CluesUserDetailsRepositoryCustom;
import com.cat.bap.repository.CountryRepository;
import com.cat.bap.repository.SchedulerDetailRepository;
import com.cat.bap.util.BrandAdvocateEmailUtility;
import com.cat.bap.util.BrandAdvocateUtility;

import cat.cis.tuf.common.email.EMailException;

/**
 * @author rani.agrawal
 *
 */
@Service
public class CluesDataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BAUserDetailsService.class);

	@Inject
	private BAUserDetailsRepositoryCustom bAUserDetailsRepositoryCustom;

	@Inject
	private CluesUserDetailsRepositoryCustom cluesUserDetailsRepositoryCustom;

	@Inject
	private CountryRepository countryRepository;
	
	@Inject
	private AffilationDescRepository  affilationDescRepository;

	@Inject
	private SchedulerDetailRepository  schedulerDetailRepository;
	
	@Inject
	private BrandAdvocateEmailUtility brandAdvocateEmailUtility;


	/**
	 * @param cwsUserId
	 * @param emailid
	 * @return
	 *//*
		 * public Map<String, Object>
		 * getBAUserDetailsBasedOnCwsIdOrEmailId(String cwsUserId, String
		 * emailId) {
		 * 
		 * LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX +
		 * "CluesDataService getBAUserDetailsBasedOnCwsIdOrEmailId method. >> TimeStamp:"
		 * + System.currentTimeMillis() +
		 * " >> getBAUserDetailsBasedOnCwsIdOrEmailId:" + cwsUserId + emailId);
		 * return
		 * bAUserDetailsRepositoryCustom.getBAUserDetailsBasedOnCwsIdOrEmailId(
		 * cwsUserId, emailId); }
		 */

	/**
	 * @param cupId
	 * @return
	 * @throws SQLException
	 */
	public Map<String, Object> getCluesUserDetailsByCupId(String cupId) throws SQLException {
		
		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "CluesDataService getCluesUserDetailsByCupId method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getCluesUserDetailsByCupId:" + cupId);
		
		return cluesUserDetailsRepositoryCustom.getCluesUserDetailsByCupId(cupId);
	}

	public Map<String, Object> getCluesUserDetailsByCwsUserId(String cupId) throws SQLException {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "CluesDataService getCluesUserDetailsByCwsUserId method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getCluesUserDetailsByCwsUserId:" + cupId);

		return cluesUserDetailsRepositoryCustom.getCluesUserDetailsByCwsUserId(cupId);
	}

	public Map<String, Object> getCluesUserDetailsByEmailId(String emailId) throws SQLException {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "CluesDataService getCluesUserDetailsByCwsUserId method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getCluesUserDetailsByCwsUserId:" + emailId);

		return cluesUserDetailsRepositoryCustom.getCluesUserDetailsByEmailId(emailId);
	}

	public Map<String, Object> getCluesUserDetailsBasedOnCwsIdOrEmailId(String cwsUserId, String emailId)
			throws SQLException {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "CluesDataService getCluesUserDetailsBasedOnCwsIdOrEmailId method. >> TimeStamp:"
				+ System.currentTimeMillis() + " >> getCluesUserDetailsBasedOnCwsIdOrEmailId:" + cwsUserId + emailId);

		return cluesUserDetailsRepositoryCustom.getCluesUserDetailsBasedOnCwsIdOrEmailId(cwsUserId, emailId);
	}

	public Map<String, Object> getCluesUserDetailsBasedOnIds(String cwsUserId, String emailId, String cupId)
			throws SQLException {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "CluesDataService getCluesUserDetailsBasedOnIds method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getCluesUserDetailsBasedOnIds:" + cwsUserId + emailId + cupId);

		Map<String, Object> cluesUserDetailsBasedOnIds = cluesUserDetailsRepositoryCustom.getCluesUserDetailsBasedOnIds(cwsUserId, emailId, cupId);
		return cluesUserDetailsBasedOnIds;
	}

	/**
	 * @param cwsOrEmailIds
	 * @param isCWS
	 * @param baVia 
	 * @param userName 
	 * @return list of counts for different operations. It does upload filter/non-filter records.
	 * @throws SQLException
	 * @throws IOException 
	 * @throws MessagingException 
	 * @throws EMailException 
	 * @throws VelocityException 
	 */
	@Transactional
	public Map<String, String> bulkUploadForEmailsOrCWSIds(String cwsOrEmailIds, boolean isCWS, String userName, String baVia) throws SQLException, VelocityException, EMailException, MessagingException, IOException {

		Map<String, String> mapOfSummaryRecords = new HashMap<>();
		
		String strInValidCluesUsers = "";
		String strValidCluesUsers = "";
		
		List<String> stringValidCluesUsers =null;
		List<String> stringValidCluesUsersEmails=null;
		List<String> stringValidCluesUsersFirstNames=null;
		List<String> stringValidCluesUsersLastNames=null;
		List<String> inValidClueUsers = new ArrayList<>();
		
		List<CluesDataDetailDto> validCluesUsers = null;
		StringTokenizer tokenString = new StringTokenizer(cwsOrEmailIds);

		/** List of all CWS/Email passed **/
		List<String> listOfAllPassed = new ArrayList<>();

		while (tokenString.hasMoreTokens()) {
			listOfAllPassed.add(tokenString.nextToken());
		}

		/************************************
		 * Find Existing Active users
		 ****************************************/
		
		/** Get all existing user list from BAP DB **/
		List<BAUserDetailsDto> allExistingBAUsersList = cluesUserDetailsRepositoryCustom.getAllBAUsersList(cwsOrEmailIds, isCWS);

		/** Get list of Active & In-Active BA users. **/
		Map<String, List<BAUserDetailsDto>> mapOfNewAndExistingUsers = getAllBAsFiltered(allExistingBAUsersList);

		List<BAUserDetailsDto> existingActiveUsers = mapOfNewAndExistingUsers.get("existingActiveUsers");

		/** prepare comma separated strExistingActiveUsers **/
		String strExistingActiveUsers = BrandAdvocateUtility.getCommaSepratedStringValue(existingActiveUsers, isCWS);
			
		mapOfSummaryRecords.put("strExistingActiveUsers", strExistingActiveUsers);
		
		
		/******************** EXISTING NON ACTIVE USER - START *******************/
		
		/** Commenting below section as we are removing functionality to show InActive Users **/
		/***
		List<BAUserDetailsDto> existingNonActiveUsers = mapOfNewAndExistingUsers.get("existingNonActiveUsers");
		String strExistingNonActiveUsers = BrandAdvocateUtility.getCommaSepratedStringValue(existingNonActiveUsers, isCWS);
		mapOfSummaryRecords.put("strExistingNonActiveUsers",strExistingNonActiveUsers); 
		***/
		mapOfSummaryRecords.put("strExistingNonActiveUsers",""); 
		/******************** EXISTING NON ACTIVE USER - END *******************/

		
		List<BAUserDetailsDto> allExistingUsers = mapOfNewAndExistingUsers.get("allExistingBAPUsers");
		List<String> listOfNonExistUsers = new ArrayList<>(); 
		
		List<String> stringAllExistingUsers = new ArrayList<>();
		
		/* find difference between input values and list returned from BAP DB*/
		for (BAUserDetailsDto existUser : allExistingUsers) {
			if(isCWS){
				stringAllExistingUsers.add(existUser.getCwsUserId().toUpperCase());	
			}else{
				stringAllExistingUsers.add(existUser.getPrimaryEmail().toUpperCase());
			}
		}
		
		if(!listOfAllPassed.isEmpty()){
			for (String baUser : listOfAllPassed) {
				if (isCWS && !stringAllExistingUsers.contains(baUser.toUpperCase())) {
					listOfNonExistUsers.add(baUser.toUpperCase());
				}else if(!isCWS && !stringAllExistingUsers.contains(baUser.toUpperCase())) {
					listOfNonExistUsers.add(baUser.toUpperCase());
				}
			}
		}
		
		/*get comma separated string */
		String strListNonExistUsers = BrandAdvocateUtility.getCommaSeparatedString(listOfNonExistUsers);
		
		mapOfSummaryRecords.put("strListNonExistUsers", strListNonExistUsers);

		/******************************************************
		 * Fetch Non-existing valid/invalid records from CLUES
		 *******************************************************/

		/** Get Valid User list from clues to be registered **/
		if(!listOfNonExistUsers.isEmpty()){
			validCluesUsers = getValidCluesUsers(listOfNonExistUsers, isCWS);
			
			stringValidCluesUsers = new ArrayList<>();
			stringValidCluesUsersEmails = new ArrayList<>();
			stringValidCluesUsersFirstNames = new ArrayList<>();
			stringValidCluesUsersLastNames = new ArrayList<>();
			
			for (CluesDataDetailDto cluesDataDetailDto : validCluesUsers) {
				if(isCWS && !stringValidCluesUsers.contains(cluesDataDetailDto.getCwsUserId().toUpperCase())){
					stringValidCluesUsers.add(cluesDataDetailDto.getCwsUserId().toUpperCase());
					stringValidCluesUsersEmails.add(cluesDataDetailDto.getPrimaryEmail());
					stringValidCluesUsersFirstNames.add(cluesDataDetailDto.getFirstName());
					stringValidCluesUsersLastNames.add(cluesDataDetailDto.getLastName());
				}else if(!isCWS && !stringValidCluesUsers.contains(cluesDataDetailDto.getPrimaryEmail().toUpperCase())){
					stringValidCluesUsers.add(cluesDataDetailDto.getPrimaryEmail().toUpperCase());
					stringValidCluesUsersEmails.add(cluesDataDetailDto.getPrimaryEmail());
					stringValidCluesUsersFirstNames.add(cluesDataDetailDto.getFirstName());
					stringValidCluesUsersLastNames.add(cluesDataDetailDto.getLastName());
				}
			}
			
			/**
			 * Differentiate valid and non valid user CWSID. List of invalid clues
			 * users
			 **/

			if(!listOfNonExistUsers.isEmpty()){
				for (String nonExistUserCWSEmail : listOfNonExistUsers) {
					if(isCWS && !stringValidCluesUsers.contains(nonExistUserCWSEmail.toUpperCase())) {
						inValidClueUsers.add(nonExistUserCWSEmail);
					}
					if(!isCWS && !stringValidCluesUsers.contains(nonExistUserCWSEmail.toUpperCase())) {
						inValidClueUsers.add(nonExistUserCWSEmail);
					}
				}
			}
			}
			
			strInValidCluesUsers= BrandAdvocateUtility.getCommaSeparatedString(inValidClueUsers);
			strValidCluesUsers 	= BrandAdvocateUtility.getCommaSeparatedString(stringValidCluesUsers);

			mapOfSummaryRecords.put("strInValidCluesUsers", strInValidCluesUsers);
			mapOfSummaryRecords.put("strValidCluesUsers", strValidCluesUsers);

			/**************************************
			 * Register new user into BAP
			 *******************************************/
			if(null!=strValidCluesUsers && !strValidCluesUsers.isEmpty()){
				
				List<String>  cluesDataDetailDtoDuplicate = new ArrayList<>();
				List<CluesDataDetailDto> cluesDataDetailDtoList = new ArrayList<>();
				
				if(!isCWS){
					
					for (CluesDataDetailDto cluesData : validCluesUsers) {
						if(!cluesDataDetailDtoDuplicate.contains(null!=cluesData ? cluesData.getPrimaryEmail().toUpperCase() : "")){
							
							cluesDataDetailDtoDuplicate.add(cluesData.getPrimaryEmail().toUpperCase());
							cluesDataDetailDtoList.add(cluesData);
						}
					}
					validCluesUsers = cluesDataDetailDtoList;
				}
				
				if(null!=validCluesUsers && !validCluesUsers.isEmpty()){
					/** Execute batch registration for bulk users  **/
					executeBatchNewUserNativeSQLBatch(validCluesUsers, userName, baVia, isCWS);
				
					for (CluesDataDetailDto cluesDataDetailDto : validCluesUsers) {
	
						String firstName	= cluesDataDetailDto.getFirstName();
						String lastName 	= cluesDataDetailDto.getLastName();
						String emailToSend 	= cluesDataDetailDto.getPrimaryEmail();
					
						brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_BULK_UPLOAD, BrandAdvocateConstant.MSGBODY_BULK_UPLOAD.concat(emailToSend), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
					}
				}
			}
			
			/**************************************
			 * Update existing user to BAP
			 *******************************************/
			if(null!=allExistingUsers && !allExistingUsers.isEmpty()){
					
				/** Execute batch registration for bulk upload, user update  **/
				executeBatchExistingUserNativeSQLBatch(allExistingUsers, userName, isCWS);
				
				for (BAUserDetailsDto baDataDetailDto : allExistingUsers) {

					String firstName	= baDataDetailDto.getFirstName();
					String lastName 	= baDataDetailDto.getLastName();
					String emailToSend 	= baDataDetailDto.getPrimaryEmail();
					
					brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL,  BrandAdvocateConstant.SUBJECT_BULK_UPLOAD_UPDATE,  BrandAdvocateConstant.MSGBODY_BULK_UPLOAD_UPDATE.concat(emailToSend), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
				}
			}

		return mapOfSummaryRecords;
	}

	private void executeBatchExistingUserNativeSQLBatch(List<BAUserDetailsDto> allExistingUsers, String userName,
			boolean isCWS) throws SQLException {
		bAUserDetailsRepositoryCustom.executeBatchExistingUserNativeSQLBatch(allExistingUsers,userName, isCWS);
		
	}

	/**
	 * @param validCluesUsers
	 * @param baVia 
	 * @param userName 
	 * @throws SQLException 
	 * @throws ParseException
	 */
	private void executeBatchNewUserNativeSQLBatch(List<CluesDataDetailDto> validCluesUsers, String userName, String baVia, boolean isCWS) throws SQLException{

		/** Fetch country for country code coming from Clues **/
		for (CluesDataDetailDto cluesDataDetailDto : validCluesUsers) {
			
			Country countryDto = countryRepository.getCountryByCountryCode(cluesDataDetailDto.getCountryCode());
			
			if(null!=countryDto){
				cluesDataDetailDto.setCountryId(countryDto.getCountryId());
				cluesDataDetailDto.setCountryName(countryDto.getCountryName());
				cluesDataDetailDto.setRegionId(countryDto.getRegion().getRegionId());
				cluesDataDetailDto.setRegionName(countryDto.getRegion().getRegionName());
			}
		}
		
		List<AffiliationDescription> affTypeDataList = affilationDescRepository.findAll();


		bAUserDetailsRepositoryCustom.executeBatchNewUserNativeSQLBatch(validCluesUsers, userName, baVia,affTypeDataList);
		bAUserDetailsRepositoryCustom.executeBatchNewUserPreferencesNativeSQLBatch(validCluesUsers, isCWS);
		
	}

	/**
	 * @param allExistingUsers
	 */
	private void insertExistingActiveInActiveUsersInBAP(List<BAUserDetailsDto> allExistingUsers, String userName, String baVia) {
		
//		bAUserDetailsRepositoryCustom.executeBatchForExistingUsers(allExistingUsers,userName, baVia);
//		bAUserDetailsRepositoryCustom.executeBatchNewUserNativeSQLBatch(allExistingUsers,userName);
	}
	
	
	/**
	 * @param isCWS
	 * @param cwsOrEmailIds
	 * @return list of valid users in clues database
	 * @throws SQLException
	 */
	public List<CluesDataDetailDto> getValidCluesUsers(List<String> checkUsersInClue, boolean isCWS)
			throws SQLException {

		return cluesUserDetailsRepositoryCustom.getValidCluesUsers(checkUsersInClue, isCWS);
	}

	/**
	 * @param cwsOrEmailIds
	 * @return
	 * @throws SQLException
	 */
	/*
	 * public List<BAUserDetailsDto> getExistingUsersList(String[]
	 * cwsOrEmailIds) throws SQLException {
	 * 
	 * return
	 * cluesUserDetailsRepositoryCustom.getExistingUsersList(cwsOrEmailIds); }
	 */

	/**
	 * @param cwsOrEmailIds
	 * @return
	 * @throws SQLException
	 */
	/*
	 * public List<BAUserDetailsDto> getInvalidUsersList(String[] cwsOrEmailIds)
	 * throws SQLException {
	 * 
	 * return
	 * cluesUserDetailsRepositoryCustom.getInvalidUsersList(cwsOrEmailIds); }
	 */

	/**
	 * @param cwsOrEmailIds
	 * @return
	 */
	/*
	 * public Map<String, List<String>> getNewBAUserList(String[] cwsOrEmailIds)
	 * {
	 * 
	 * Map<String, List<String>> mapOfNewAndExisting = new HashMap<String,
	 * List<String>>();
	 * 
	 * List<String> idsConvertedToList = Arrays.asList(cwsOrEmailIds);
	 * List<String> idNewFound = new ArrayList<>(); List<String> idExistingFound
	 * = new ArrayList<>();
	 * 
	 * List<String> newBAUserList =
	 * cluesUserDetailsRepositoryCustom.getNewBAUserList(cwsOrEmailIds);
	 * 
	 * for (String cwsId : newBAUserList) {
	 * if(idsConvertedToList.contains(cwsId)){ idExistingFound.add(cwsId);
	 * }else{ idNewFound.add(cwsId); } }
	 * 
	 * mapOfNewAndExisting.put("newIds", idNewFound);
	 * mapOfNewAndExisting.put("existingIds", idExistingFound);
	 * 
	 * return mapOfNewAndExisting; }
	 */
	/*	*//**
			 * @param newBAUserList
			 * @return
			 *//*
			 * public Map<String, List<String>> getNewBAUserList(String[]
			 * cwsOrEmailIds) {
			 * 
			 * Map<String, List<String>> mapOfNewAndExisting = new
			 * HashMap<String, List<String>>();
			 * 
			 * List<String> idsConvertedToList = Arrays.asList(cwsOrEmailIds);
			 * List<String> idNewFound = new ArrayList<>(); List<String>
			 * idExistingFound = new ArrayList<>();
			 * 
			 * List<String> newBAUserList =
			 * cluesUserDetailsRepositoryCustom.getNewBAUserList(cwsOrEmailIds);
			 * 
			 * for (String cwsId : newBAUserList) {
			 * if(idsConvertedToList.contains(cwsId)){
			 * idExistingFound.add(cwsId); }else{ idNewFound.add(cwsId); } }
			 * 
			 * mapOfNewAndExisting.put("newIds", idNewFound);
			 * mapOfNewAndExisting.put("existingIds", idExistingFound);
			 * 
			 * return mapOfNewAndExisting; }
			 */

	private Map<String, List<BAUserDetailsDto>> getAllBAsFiltered(List<BAUserDetailsDto> newBAUserList) {

		Map<String, List<BAUserDetailsDto>> mapOfNewAndExistingUsers = new HashMap<>();

		List<BAUserDetailsDto> existingActiveUsers = new ArrayList<>();
		List<BAUserDetailsDto> existingNonActiveUsers = new ArrayList<>();
		List<BAUserDetailsDto> allExistingUsers = new ArrayList<>();

		
		for (BAUserDetailsDto baUserDetailsDto : newBAUserList) {
			if (baUserDetailsDto.getIsActive()) {
				existingActiveUsers.add(baUserDetailsDto);
			} else {
				existingNonActiveUsers.add(baUserDetailsDto);
			}
			allExistingUsers.add(baUserDetailsDto);
		}

		mapOfNewAndExistingUsers.put("existingActiveUsers", existingActiveUsers);
		mapOfNewAndExistingUsers.put("existingNonActiveUsers", existingNonActiveUsers);
		mapOfNewAndExistingUsers.put("allExistingBAPUsers", allExistingUsers);

		return mapOfNewAndExistingUsers;
	}
}
