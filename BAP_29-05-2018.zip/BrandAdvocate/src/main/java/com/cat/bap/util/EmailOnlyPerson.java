package com.cat.bap.util;

import cat.cis.tuf.common.directory.Attribute;
import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.directory.Schema;

public final class EmailOnlyPerson extends Person {
	/**
	 * 
	 */
	private static final long serialVersionUID = 734863848877594939L;
	private String emailId;
	public EmailOnlyPerson(String email) {
		emailId = email;
	}
	
	@Override
	public String getEmailId() {
		return emailId;
	}

	public String getLogonId() {
		
		return null;
	}

	protected Attribute getLogonIdAttribute() {
		
		return null;
	}

	public Schema getDefaultSchema() {
		
		return null;
	}
	@Override
	public void setLogonId(String arg0) {
		// Auto-generated method stub
		
	}
}
