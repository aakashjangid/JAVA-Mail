package com.cat.bap.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.entity.Preferences;
import com.cat.bap.entity.UserPreferences;

public interface UserPreferencesRepository extends JpaRepository<UserPreferences, Long>{

  @Query("SELECT p.preference.preferenceId,p.preference.preferenceName FROM UserPreferences p WHERE p.bAUserDetails.brandAdvocateId =:brandAdvocateId")
  List<Preferences> getPreferencesDetailsById(@Param("brandAdvocateId") Long brandAdvocateId);

  @Transactional
  @Modifying
  @Query("DELETE FROM UserPreferences upa WHERE upa.bAUserDetails.brandAdvocateId =:brandAdvocateId")
  void deleteRecordByBaId(@Param("brandAdvocateId") Long brandAdvocateId);
}
