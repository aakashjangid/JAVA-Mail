package com.cat.bap.dto;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 23-Feb-2018
 * @purpose
 */
public class CountryDto {

  private Long countryId;
  private String countryName;
  private String countryCode;
  
  public CountryDto() {
  }

  public CountryDto(Long countryId, String countryName, String countryCode) {
    super();
    this.countryId = countryId;
    this.countryName = countryName;
    this.countryCode = countryCode;
  }
  
  public Long getCountryId() {
    return countryId;
  }

  public void setCountryId(Long countryId) {
    this.countryId = countryId;
  }

  public String getCountryName() {
    return countryName;
  }

  public void setCountryName(String countryName) {
    this.countryName = countryName;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  @Override
  public String toString() {
    return "CountryDto [countryId=" + countryId + ", countryName=" + countryName + ", countryCode="
        + countryCode + "]";
  }
  
}
