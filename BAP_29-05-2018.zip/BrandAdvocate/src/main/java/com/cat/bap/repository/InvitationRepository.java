package com.cat.bap.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cat.bap.entity.Invitation;


/**
 * This is the Invitation Repository which is being used to store the data in the database.
 * @author rathor(aakash.jangid)
 *
 */
public interface InvitationRepository extends JpaRepository<Invitation, Long>{

}
