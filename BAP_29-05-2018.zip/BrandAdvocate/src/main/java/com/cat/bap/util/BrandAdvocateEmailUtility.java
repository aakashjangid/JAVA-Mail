package com.cat.bap.util;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.activation.MailcapCommandMap;
import javax.inject.Inject;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.exception.VelocityException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cat.bap.common.BrandAdvocateConstant;
import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.entity.BAUserDetails;

import cat.cis.tuf.common.email.EMailDocument;
import cat.cis.tuf.common.email.EMailException;
import cat.cis.tuf.common.email.EMailSender;
import cat.cis.tuf.common.email.SimpleDataSource;

/**
 * @author rathor
 */
@Component
@Service
public class BrandAdvocateEmailUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(BrandAdvocateEmailUtility.class);

	@Inject
	private BrandAdvocateEmailPropertyReader brandAdvocateEmailPropertyReader;

	@Inject
	private Environment environment;
	
	private static final String COMMON_FILE_PATH = "app.commonFilePath";
	
	private static final String MASSMAIL =  "/massmail/";

	public boolean sendBrandAdvocateEmail(List<BAUserDetails> baUserDetailsList, String msgBody, String subject,
			Boolean isAttachment) throws MessagingException {

		LOGGER.info("BrandAdvocateEmailUtility's sendBrandAdvocateEmail method");

		boolean isSent = false;

		for (BAUserDetails baUserDetails : baUserDetailsList) {

			String userPrimaryEmail = (null != baUserDetails.getPrimaryEmail()
					&& !baUserDetails.getPrimaryEmail().equals("")) ? baUserDetails.getPrimaryEmail() : "";
			String userSecondaryEmail = (null != baUserDetails.getSecondaryEmail()
					&& !baUserDetails.getSecondaryEmail().equals("")) ? baUserDetails.getSecondaryEmail() : "";

			String userEmail = !userPrimaryEmail.equals("") ? userPrimaryEmail : userSecondaryEmail;

			if (!userEmail.equals("")) {
				if (!isAttachment) {
					
					isSent = sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, subject, msgBody.concat(userEmail),
							baUserDetails.getFirstName(), baUserDetails.getLastName(),
							BrandAdvocateConstant.VM_MASS_EMAIL_TEMPLATE);
				} else {
					boolean deleteAttachmentsFromLocation = false;
					if (baUserDetailsList.indexOf(baUserDetails) == (baUserDetailsList.size() - 1)) {
						deleteAttachmentsFromLocation = true;
					}
					/**
					 * return sendMailAttachment(userEmail, subject,
					 * msgBody, baUserDetails.getFirstName(),
					 * baUserDetails.getLastName(),
					 * BrandAdvocateConstant.VM_MASS_EMAIL_TEMPLATE,
					 * isAttachment);
					 **/
					isSent = sendMailAttachment(BrandAdvocateConstant.USER_TESTER_EMAIL, subject,
							msgBody.concat(userEmail), baUserDetails.getFirstName(), baUserDetails.getLastName(),
							BrandAdvocateConstant.VM_MASS_EMAIL_TEMPLATE, isAttachment,
							deleteAttachmentsFromLocation);
				}
			}
		}
		
		/**Logic to delete files from folder after mail sending starts*/
		File[] listOfFiles = null;
		String attachmentPath = environment.getProperty(COMMON_FILE_PATH) + MASSMAIL;
		File attachmentFolder = new File(attachmentPath);
		listOfFiles = attachmentFolder.listFiles();
			if (isAttachment && null != listOfFiles) {
				for (int j = 0; j < listOfFiles.length; j++) {
					if (listOfFiles[j].isFile()) {
						listOfFiles[j].getAbsoluteFile().delete();
					}
				}
			}

			/**Logic to delete files from folder after mail sending ends*/
		
		return isSent;
	}

	/**
	 * @param emailToSend
	 * @param subject
	 * @param messageBody
	 * @param firstName
	 * @param lastName
	 * @param vmTemplate
	 * @return
	 * @throws IOException
	 * @throws EMailException
	 */
	public boolean sendMail(String emailToSend, String subject, String messageBody, String firstName, String lastName,
			String vmTemplate)  {

		LOGGER.info("BrandAdvocateEmailUtility's sendMail method");

		boolean isSentSuccessfully = false;

		MailcapCommandMap mailcap = (MailcapCommandMap) MailcapCommandMap.getDefaultCommandMap();
		mailcap.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_plain");

		Properties props = System.getProperties();
		props.put("mail.smtp.host", "intramail.cis.cat.com");
		Session session = Session.getDefaultInstance(props, null);
		BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);
		String fromMail = brandAdvocateEmailPropertyReader.getEmailid();

		MimeMessage message = new MimeMessage(session);

		try {
			message.setFrom(new InternetAddress(fromMail));
			message.addRecipients(Message.RecipientType.TO, emailToSend);
			message.setHeader("Errors-To", emailToSend);
			message.setSubject(subject);
		} catch (MessagingException e) {
			LOGGER.error("BrandAdvocateEmailUtility.sendMail() ", e); 
		}


		Multipart multipart = new MimeMultipart("mixed");

		Multipart mpMixedAlternative;
		try {
			mpMixedAlternative = newChild(multipart, "alternative");
			messageBody = getHtmlWithEncodedImages(multipart, messageBody);

			Properties properties = new Properties();
			properties.setProperty("resource.loader", "class");
			properties.setProperty("class.resource.loader.class",
					"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
			Velocity.init(properties);

			StringBuilder templatePath = new StringBuilder("templates/");

			Template template = Velocity.getTemplate(templatePath.append(vmTemplate).toString(), "UTF-8");

			VelocityContext velocityContext = getVelocityContext(messageBody, firstName, lastName);
			StringWriter stringWriter = new StringWriter();

			template.merge(velocityContext, stringWriter);

			// Add part one, HTML part

			BodyPart messageBodyPart;

			messageBodyPart = buildHtmlTextPart(stringWriter.toString());
			mpMixedAlternative.addBodyPart(messageBodyPart);

			// Put the multipart in message
			message.setContent(multipart);

			// send the message
			Transport transport = session.getTransport("smtp");
			transport.connect();
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
		} catch (MessagingException e) {
			LOGGER.error("BrandAdvocateEmailUtility.sendEmail() ", e);
		}

		isSentSuccessfully = true;
		LOGGER.info(UserMasterConstant.MESSAGE_SENT);

		return isSentSuccessfully;
	}

	private Multipart newChild(Multipart parent, String alternative) throws MessagingException {

		MimeMultipart child = new MimeMultipart(alternative);

		MimeBodyPart mbp = new MimeBodyPart();

		parent.addBodyPart(mbp);

		mbp.setContent(child);

		return child;

	}

	private String getHtmlWithEncodedImages(Multipart parent, String msg) {

		String temp = msg;
		String html = "<html><body>" + msg + "</body></html>";
		Document document = Jsoup.parse(html);
		Elements allElements = document.body().getElementsByTag("img");
		for (Element element : allElements) {
			String elementstring = element.toString();
			String tempfilename = elementstring.substring(elementstring.indexOf("file"));
			String filename = tempfilename.substring(0, tempfilename.indexOf('"'));
			temp = temp.replace(elementstring.substring(elementstring.indexOf('"'), elementstring.lastIndexOf('"')),
					"\"cid:" + filename);

			addImages(parent, filename);
		}
		return temp;
	}

	private void addImages(Multipart parent, String filename) {

		MimeBodyPart mbpAttachment = new MimeBodyPart();

		try {
			String path = System.getProperty("tuf.appFiles.rootDirectory");
			File file = new File(path + "/template-images/" + filename);
			FileDataSource ds = new FileDataSource(file);
			mbpAttachment.setDataHandler(new DataHandler(ds));
			mbpAttachment.setDisposition(BodyPart.INLINE);
			mbpAttachment.setHeader("Content-ID", "<"+filename+">");
			mbpAttachment.setFileName(filename);
			parent.addBodyPart(mbpAttachment);
		} catch (Exception e) {
			LOGGER.error("BrandAdvocateEmailutility.addImages() ", e);
		}
	}

	private BodyPart buildHtmlTextPart(String description) throws MessagingException {

		MimeBodyPart descriptionPart = new MimeBodyPart();
		descriptionPart.setContent(description, "text/html; charset=utf-8");

		return descriptionPart;

	}

	/**
	 * @param emailToSend
	 * @param subject
	 * @param messageBody
	 * @param firstName
	 * @param lastName
	 * @param vmTemplate
	 * @param deleteAttachmentsFromLocation
	 * @return
	 * @throws IOException
	 * @throws EMailException
	 * @throws MessagingException
	 */
	public boolean sendMailAttachment(String emailToSend, String subject, String messageBody, String firstName,
			String lastName, String vmTemplate, boolean isAttachment, boolean deleteAttachmentsFromLocation)
			throws MessagingException {

		LOGGER.info("BrandAdvocateEmailUtility's sendMessage method");

		boolean isSentSuccessfully = false;

		MailcapCommandMap mailcap = (MailcapCommandMap) MailcapCommandMap.getDefaultCommandMap();
		mailcap.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_plain");

		Properties props = System.getProperties();
		props.put("mail.smtp.host", "intramail.cis.cat.com");
		Session session = Session.getDefaultInstance(props, null);
		BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);
		String fromMail = brandAdvocateEmailPropertyReader.getEmailid();

		MimeMessage message = new MimeMessage(session);

		try {
			message.setFrom(new InternetAddress(fromMail));
			message.addRecipients(Message.RecipientType.TO, emailToSend);
			message.setHeader("Errors-To", emailToSend);
			message.setSubject(subject);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

		Multipart multipart = new MimeMultipart("mixed");

		Multipart mpMixedAlternative;
		try {
			mpMixedAlternative = newChild(multipart, "alternative");
			messageBody = getHtmlWithEncodedImages(multipart, messageBody);


			Properties properties = new Properties();
			properties.setProperty("resource.loader", "class");
			properties.setProperty("class.resource.loader.class",
					"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
			Velocity.init(properties);

			StringBuilder templatePath = new StringBuilder("templates/");

			Template template = Velocity.getTemplate(templatePath.append(vmTemplate).toString(), "UTF-8");

			VelocityContext velocityContext = getVelocityContext(messageBody, firstName, lastName);
			StringWriter stringWriter = new StringWriter();

			template.merge(velocityContext, stringWriter);

			// Add part one, HTML part

			BodyPart messageBodyPart;

			messageBodyPart = buildHtmlTextPart(stringWriter.toString());
			mpMixedAlternative.addBodyPart(messageBodyPart);

			File[] listOfFiles = null;
			String attachmentPath = environment.getProperty(COMMON_FILE_PATH) + MASSMAIL;
			File attachmentFolder = new File(attachmentPath);

			if (isAttachment) {
				listOfFiles = attachmentFolder.listFiles();
				for (int k = 0; k < listOfFiles.length; k++) {
					if (listOfFiles[k].isFile()) {
						MimeBodyPart messageBodyPart2 = new MimeBodyPart();
						DataSource source = new FileDataSource(attachmentPath + "/" + listOfFiles[k].getName());
						messageBodyPart2.setDataHandler(new DataHandler(source));
						messageBodyPart2.setFileName(listOfFiles[k].getName());
						messageBodyPart2.setDisposition(BodyPart.ATTACHMENT);
						multipart.addBodyPart(messageBodyPart2);
						message.setContent(multipart);
					}
				}
			}

			// Put the multipart in message
			message.setContent(multipart);

				// send the message
				
				try {
					Transport transport = session.getTransport("smtp");
					transport.connect();
					transport.sendMessage(message, message.getAllRecipients());
					transport.close();
				} catch (MessagingException e) {
					e.printStackTrace();
				}
				
			isSentSuccessfully = true;

			LOGGER.info(BrandAdvocateConstant.MESSAGE_SENT);

		} catch (MessagingException e) {
			e.printStackTrace();
		}

		LOGGER.info("Email with attachment sent. ");

		return isSentSuccessfully;
	}

	@SuppressWarnings("unchecked")
	public boolean sendMessage(String[] toEmail, String subject, String msg, String firstName, String lastName)
			throws MessagingException, IOException, EMailException {
		LOGGER.info("BrandAdvocateEmailUtility's sendMessage method");

		 List<String> mailList = Arrays.asList(toEmail);

		for (int i = 0; i < mailList.size(); i++) {
			List<String> firstNameList = new ArrayList<>();
			String[] firstNameArr = firstName.split(",");
			firstNameList.addAll((List<String>) (List<?>) Arrays.asList(firstNameArr));
			firstNameList.removeAll(Arrays.asList(null, ""));
			String firstNameForEmail = !firstNameList.isEmpty() ? firstNameList.get(i) : "";
			List<String> lastNameList = new ArrayList<>();
			String[] lastNameArr = lastName.split(",");
			lastNameList.addAll((List<String>) (List<?>) Arrays.asList(lastNameArr));
			lastNameList.removeAll(Arrays.asList(null, ""));
			String lastNameForEmail = !lastNameList.isEmpty() ? lastNameList.get(i) : "";

			BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);

			EMailDocument eMailDocument = new EMailDocument();
			eMailDocument.setFrom(brandAdvocateEmailPropertyReader.getEmailid());
			eMailDocument.addSendTO(new EmailOnlyPerson(BrandAdvocateConstant.USER_TESTER_EMAIL));
			eMailDocument.setSubject(subject);
			Properties properties = new Properties();
			properties.setProperty("resource.loader", "class");
			properties.setProperty("class.resource.loader.class",
					"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
			Velocity.init(properties);
			Template template = Velocity.getTemplate("templates/suggestPodcastNotificationMessage.vm", "UTF-8");
			VelocityContext velocityContext = getVelocityContext(msg, firstNameForEmail, lastNameForEmail);

			StringWriter stringWriter = new StringWriter();

			/** comment if wants to send calender invite */
			template.merge(velocityContext, stringWriter);
			/** ----------------------------------------- */
			DataHandler handler = new DataHandler(new SimpleDataSource(stringWriter.toString(), "text/html"));
			eMailDocument.setContent(handler);
			/** ----------------------------------------- */
			eMailDocument.send(EMailSender.ASYNC);

			LOGGER.info( UserMasterConstant.MESSAGE_SENT);

		}

		return true;
	}

	/**
	 * This method is used in mass mailing service to send bulk mail with
	 * attachment as well.
	 * 
	 * @param toEmail
	 * @param subject
	 * @param msg
	 * @param user
	 * @param isAttachment
	 * @return boolean
	 * @throws MessagingException
	 * @throws VelocityException
	 * @throws IOException
	 * @throws EMailException
	 */
	@SuppressWarnings("unchecked")
	public boolean sendMessageWithAttachment(String[] toEmail, String subject, String msg, String firstName,
			String lastName, Boolean isAttachment)
			throws MessagingException, IOException, EMailException {
		LOGGER.info("BrandAdvocateEmailUtility's sendMessageWithAttachment method");

		 List<String> mailList = Arrays.asList(toEmail);

		for (int i = 0; i < mailList.size(); i++) {

			String emailAddress = mailList.get(i);
			List<String> firstNameList = new ArrayList<>();
			String[] firstNameArr = firstName.split(",");
			firstNameList.addAll((List<String>) (List<?>) Arrays.asList(firstNameArr));
			firstNameList.removeAll(Arrays.asList(null, ""));

			String firstNameForEmail = firstNameList.get(i);

			List<String> lastNameList = new ArrayList<>();
			String[] lastNameArr = lastName.split(",");
			lastNameList.addAll((List<String>) (List<?>) Arrays.asList(lastNameArr));
			lastNameList.removeAll(Arrays.asList(null, ""));

			String lastNameForEmail = lastNameList.get(i);

			BrandAdocateEmailSession.setProperties(brandAdvocateEmailPropertyReader);
			MimeMessage message = new MimeMessage(BrandAdocateEmailSession.getSession());
			message.setFrom(new InternetAddress(brandAdvocateEmailPropertyReader.getEmailid()));
			message.setSubject(subject);
			message.setSentDate(new Date());
			// ** Adding Message Body *//*
			BodyPart messageBodyPart1 = new MimeBodyPart();
			Properties properties = new Properties();
			properties.setProperty("resource.loader", "class");
			properties.setProperty("class.resource.loader.class",
					"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");

			Velocity.init(properties);
			Template template = Velocity.getTemplate("templates/massMailMessage.vm", "UTF-8");
			VelocityContext velocityContext = getVelocityContext(msg, firstNameForEmail, lastNameForEmail);
			StringWriter stringWriter = new StringWriter();
			template.merge(velocityContext, stringWriter);

			messageBodyPart1.setContent(stringWriter.toString(), "text/html; charset=utf-8");
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart1);
			File[] listOfFiles = null;
			String attachmentPath = environment.getProperty(COMMON_FILE_PATH) + MASSMAIL;
			File attachmentFolder = new File(attachmentPath);
			if (isAttachment) {
				listOfFiles = attachmentFolder.listFiles();
				for (int k = 0; k < listOfFiles.length; k++) {
					if (listOfFiles[k].isFile()) {
						MimeBodyPart messageBodyPart2 = new MimeBodyPart();
						DataSource source = new FileDataSource(attachmentPath + "/" + listOfFiles[k].getName());
						messageBodyPart2.setDataHandler(new DataHandler(source));
						messageBodyPart2.setFileName(listOfFiles[k].getName());
						multipart.addBodyPart(messageBodyPart2);
						message.setContent(multipart);
					}
				}
			}

			InternetAddress recipient = new InternetAddress(emailAddress);
			message.setRecipient(Message.RecipientType.TO, recipient);
			try {
				Transport.send(message);
			} catch (Exception exception) {
				LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + exception + " : "
						+ BrandAdvocateConstant.SENDING_FAILED_TO_MAILID + recipient);
			}

			LOGGER.info(BrandAdvocateConstant.MESSAGE_SENT);
			if (isAttachment && null != listOfFiles) {
				for (int j = 0; j < listOfFiles.length; j++) {
					if (listOfFiles[j].isFile()) {
						listOfFiles[j].getAbsoluteFile().delete();
					}
				}
			}
			String massMail = environment.getProperty(COMMON_FILE_PATH) + "/massmail";
			File massMailFolder = new File(massMail);
			File[] listFolder = massMailFolder.listFiles();
			for (int j = 0; j < listFolder.length; j++) {
				if (listFolder[j].isDirectory() && listFolder[j].getName().equalsIgnoreCase(firstNameForEmail)) {
					listFolder[j].delete();
				}
			}

		}
		return true;
	}

	/**
	 * This method is used to get Velocity Context Object
	 * 
	 * @param msg
	 * @return VelocityContext
	 */
	private VelocityContext getVelocityContext(String msg, String firstName, String lastName) {
		LOGGER.info(
				"\n<=========== Brand Advocate ===========>" + "BrandAdvocateEmailUtility's getVelocityContext method");
		VelocityContext velocityContext = new VelocityContext();
		velocityContext.put(UserMasterConstant.FIRST_NAME_MAIL, firstName);
		velocityContext.put(UserMasterConstant.LAST_NAME_MAIL, lastName);
		velocityContext.put(UserMasterConstant.MESSAGE_BODY, msg);
		velocityContext.put(UserMasterConstant.MAIL_FROM, "");
		velocityContext.put(UserMasterConstant.DO_NOT_REPLY, brandAdvocateEmailPropertyReader.getDoNotReply());
		velocityContext.put(UserMasterConstant.TEAM_BRAND_ADVOCATE, "Team Brand Advocate");
		return velocityContext;
	}

}