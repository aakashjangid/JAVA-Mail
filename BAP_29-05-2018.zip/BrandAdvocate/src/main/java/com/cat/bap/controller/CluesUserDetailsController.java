package com.cat.bap.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.MessagingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.service.CluesDataService;
import com.cat.bap.util.SchedulerCLUES;

import cat.cis.tuf.common.email.EMailException;

/**
 * @author rani.agrawal
 *
 */
@RestController
@RequestMapping(value = "/manage/clue/v1/")
public class CluesUserDetailsController {

	@Inject
	private CluesDataService cluesDataService;

	@Inject
	SchedulerCLUES schedulerCLUES;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BAUserDetailsController.class);
	
	/**
	 * @param cupId
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "/getcluesdetailsbycupid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getCluesUserDetailsByCupId(@RequestParam("cupId") String cupId)
			throws SQLException {

		LOGGER.info("CLuesUserDetailsController.getCluesUserDetailsByCupId()");

		return new ResponseWrapper<>(null, HttpStatus.OK, "", cluesDataService.getCluesUserDetailsByCupId(cupId));
	}
	
	
	/**
	 * @param cwsUserId
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "/getcluesdetailsbycwsid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getCluesUserDetailsByCwsId(@RequestParam("cwsuserid") String cwsUserId)
			throws SQLException {

		LOGGER.info("CLuesUserDetailsController.getCluesUserDetailsByCwsId()");
		
		return new ResponseWrapper<>(null, HttpStatus.OK, "", cluesDataService.getCluesUserDetailsByCwsUserId(cwsUserId));
	}
	

	/**
	 * @param emailId
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "/getcluesdetailsbyemailid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getCluesUserDetailsByEmailId(@RequestParam("emailid") String emailId)
			throws SQLException {

		LOGGER.info("CLuesUserDetailsController.getCluesUserDetailsByEmailId()");

		return new ResponseWrapper<>(null, HttpStatus.OK, "", cluesDataService.getCluesUserDetailsByEmailId(emailId));
	}

	/**
	 * This method is used for CLUES Update.
	 * 
	 * @param request
	 * @param requestHeader
	 * @throws ParseException 
	 * @throws IOException
	 */
	@RequestMapping(value = "/scheduler")
	public ResponseWrapper<Boolean> startCluesUpdateScheduler() throws ParseException {
		
		LOGGER.info("CLuesUserDetailsController.startCluesUpdateScheduler()");
		
		schedulerCLUES.schedulerCluesFrequency();
		return new ResponseWrapper<>(null, HttpStatus.OK, "", true);
	}
	
	
	@RequestMapping(value = "/getcluesuserdetailsbycwsidoremailid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getCluesUserDetailsByCwsIdOrEmailId(
			@RequestParam("cwsuserid") String cwsUserId, @RequestParam("emailid") String emailId) throws SQLException {
		
		LOGGER.info("CLuesUserDetailsController.getCluesUserDetailsByCwsIdorEmailId()");

		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				cluesDataService.getCluesUserDetailsBasedOnCwsIdOrEmailId(cwsUserId, emailId));
	}
	
	/**
	 * @param cwsUserId
	 * @param emailid
	 * @return
	 * @throws SQLException 
	 */
	@RequestMapping(value = "/getcluesuserdetailsbyids", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getCluesUserDetailsByIds(
			@RequestParam("cwsuserid") String cwsUserId, @RequestParam("emailid") String emailId , @RequestParam("cupid") String cupId) throws SQLException {

		LOGGER.info("CLuesUserDetailsController.getCluesUserDetailsByIds()");
		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				cluesDataService.getCluesUserDetailsBasedOnIds(cwsUserId, emailId,cupId));
	}
	
	@RequestMapping(value = "/bulkuploadcwsoremailids", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, String>> bulkUploadForEmailsOrCWSIds(
			@RequestParam("cwsoremailids") String cwsOrEmailIds,@RequestParam("iscws") boolean isCWS,@RequestParam("username") String userName,@RequestParam("registeredvia") String registeredVia) throws SQLException, EMailException, MessagingException, IOException {
		
		LOGGER.info("CLuesUserDetailsController.bulkUploadForEmailsOrCWSIds()");

		/** Check and upload all data and return numbers to show on UI.  **/		
		Map<String, String> existingNonExisitingBAUserMap = cluesDataService.bulkUploadForEmailsOrCWSIds(cwsOrEmailIds, isCWS, userName, registeredVia);
		
		return new ResponseWrapper<>(null, HttpStatus.OK, "", existingNonExisitingBAUserMap);
		
	}
}