package com.cat.bap.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.slf4j.MDC;

import com.cat.bap.util.PersonUtil;

/**
 * Servlet filter store the logged-in User info in Threadlocal for Log4j.
 * 
 */
public class Log4JContextFilter implements Filter {
	private static final String REMOTE_I_P_ADDR = "remoteIPAddr";
	private static final String CURRENT_USER_LOG_ON_ID = "currentUserLogOnId";

	public void init(FilterConfig config) throws ServletException {
		// Lines Added to remove SonarLint Errors.
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain next) throws IOException, ServletException {

		setUserInfoForLog4j(request);

		try {
			next.doFilter(request, response);
		} finally {
			MDC.clear();
		}

	}

	/**
	 * @param currentUserLogOnId
	 * @param remoteIPAddr
	 */
	private void setUserInfoForLog4j(ServletRequest request) {
		final String currentUserLogOnId = PersonUtil
				.getCurrentUserLogOnId((HttpServletRequest) request);

		final String remoteAddr = request.getRemoteAddr();

		if (StringUtils.isNotBlank(currentUserLogOnId)) {
			MDC.put(CURRENT_USER_LOG_ON_ID, currentUserLogOnId);
		}

		if (StringUtils.isNotBlank(remoteAddr)) {
			MDC.put(REMOTE_I_P_ADDR, remoteAddr);
		}
	}

	public void destroy() {
		// Lines Added to remove SonarLint Errors.
	}
}
