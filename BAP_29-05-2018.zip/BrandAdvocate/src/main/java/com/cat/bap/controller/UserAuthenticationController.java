package com.cat.bap.controller;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.MasterDataDto;
import com.cat.bap.service.MasterDataDomainService;
import com.cat.bap.util.PersonUtil;

import cat.cis.tuf.common.directory.CGDS;
import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.persistence.PersistenceException;

/**
 * @author rathor
 * @purpose This controller class is used to authenticate user.
 */
@RestController
@RequestMapping(value = "/user/authentication/v1/")
public class UserAuthenticationController {
	
	@Inject
	private MasterDataDomainService masterDataDomainService;

	@RequestMapping(value = "/getUserInformation", method = RequestMethod.GET)
	@ResponseBody
	public ResponseWrapper<Map<String, BAUserDetailsDto>> login(HttpServletRequest request) throws PersistenceException {

		/** Get CUPID **/
		String currentUserCupid = PersonUtil.getCurrentUserCupid(request);

		/** Get Person Object **/
		Person personObj = PersonUtil.getPerson(currentUserCupid);

		/** Check if user Admin or not **/
		Boolean isAdminPerson = PersonUtil.isAdminPerson(request);

		/** **/
		BAUserDetailsDto userDTO = new BAUserDetailsDto();

		userDTO.setCupId(personObj.getProperty(CGDS.CUPID));										//CUPID
		userDTO.setCwsUserId(personObj.getLogonId());												//CWSID
		userDTO.setIsAdmin(isAdminPerson);
		userDTO.setFirstName(personObj.getProperty(CGDS.FIRST_NAME));								//First Name
		userDTO.setLastName(personObj.getProperty(CGDS.LAST_NAME)); 								//Last Name
		userDTO.setPreferredFirstName(personObj.getProperty(CGDS.PREFERRED_FIRST_NAME)); 			//Preferred First Name
		userDTO.setOrganizationName(personObj.getProperty(CGDS.ADMINISTRATIVE_CODE_DESCRIPTION)); 	//Organization / Division
		userDTO.setFacilityName(personObj.getProperty(CGDS.WORK_LOC_DESC)); 						//Facility
		userDTO.setBuildingName(personObj.getProperty(CGDS.WORK_BUILDING)); 						//Building (ex: AB, LC)
		userDTO.setJobKeywords(personObj.getProperty(CGDS.JOB_CODE)); 								//Job Keywords
		userDTO.setCountryCode(personObj.getProperty(CGDS.COUNTRY)); 								//Country
		userDTO.setPrimaryEmail(personObj.getProperty(CGDS.BUSINESS_EMAIL_ADDRESS)); 				//Email 
		userDTO.setAffiliationDescription(personObj.getProperty(CGDS.AFFILIATION_DESCRIPTION)); 				//Email 

		MasterDataDto masterDataDto = new MasterDataDto();
		
		masterDataDto.setListCountry(masterDataDomainService.getAllCountries());
		masterDataDto.setListPreferences(masterDataDomainService.getAllPreferences());
		masterDataDto.setListBARegistraionStatus(masterDataDomainService.getListRegistrationReason());
		masterDataDto.setListRegion(masterDataDomainService.getAllRegions());
		
		userDTO.setMasterDataDto(masterDataDto);
		
		Map<String, BAUserDetailsDto> mapObj = new HashMap<>();
		mapObj.put("userMasterDto", userDTO);
		
		return new ResponseWrapper<>(null, HttpStatus.OK, "", mapObj);
	}
}
