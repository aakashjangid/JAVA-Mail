package com.cat.bap.util;

import java.util.Calendar;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.service.SchedulerCluesUpdateService;

import cat.cis.tuf.common.scheduler.BatchScheduler;
import cat.cis.tuf.common.scheduler.DailyFrequencyPolicy;
import cat.cis.tuf.common.scheduler.DurationPolicy;
import cat.cis.tuf.common.scheduler.ForeverDurationPolicy;
import cat.cis.tuf.common.scheduler.FrequencyPolicy;
import cat.cis.tuf.common.scheduler.MillisecondFrequencyPolicy;
import cat.cis.tuf.common.scheduler.MonthlyFrequencyPolicy;
import cat.cis.tuf.common.scheduler.Schedule;
import cat.cis.tuf.common.scheduler.Task;
import cat.cis.tuf.common.scheduler.TransientTask;
import cat.cis.tuf.common.scheduler.WeeklyFrequencyPolicy;

/**
 * @author Rani Agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 23-Feb-2018
 * @purpose
 */

@Component
public class SchedulerCLUES {

	@Autowired
    private ApplicationContext applicationContext;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SchedulerCLUES.class); 
	
	@PostConstruct
	public void schedulerCluesFrequency() {
		
		LOGGER.info("SchedulerCluesFrequency() started ");
		
		String frequency = "Every 30 Mins";
		
    	/** find out Monday and scheduled it for every week starting from today/next Monday **/
		Calendar nextMonday = Calendar.getInstance();
		int weekday = nextMonday.get(Calendar.DAY_OF_WEEK);
		if (weekday != Calendar.SUNDAY)
		{
		    int days = (Calendar.SATURDAY - weekday + 2) % 7;
		    nextMonday.add(Calendar.DAY_OF_YEAR, days);
		    nextMonday.set(Calendar.HOUR_OF_DAY, 00);
		    nextMonday.set(Calendar.MINUTE, 05);
		    nextMonday.set(Calendar.SECOND, 0);
		    nextMonday.set(Calendar.MILLISECOND, 0);
		}
		
		Schedule schedule =null;
		
		DurationPolicy durationPolicy = new ForeverDurationPolicy();
		
		switch (frequency) {
		
		case "Every 30 Mins":
		   	MillisecondFrequencyPolicy millSecondfrequency = new MillisecondFrequencyPolicy(UserMasterConstant.THIRTY_MINS);
	    	schedule = new Schedule(durationPolicy, millSecondfrequency);
			break;
			
		case "Daily":
			FrequencyPolicy dailyFrequencyPolicy = new DailyFrequencyPolicy();
			schedule = new Schedule(durationPolicy, dailyFrequencyPolicy);
			break;
			
		case "Weekly":
	    	WeeklyFrequencyPolicy weeklyPolicy = new WeeklyFrequencyPolicy(1);
	    	weeklyPolicy.setTime(UserMasterConstant.BATCH_EXECUTION_HOUR, UserMasterConstant.BATCH_EXECUTION_MIN);
	    	DurationPolicy duPolicy1 = new ForeverDurationPolicy();
	    	schedule = new Schedule( duPolicy1, weeklyPolicy,(Calendar)nextMonday );
	    	
	    	break;
		case "Monthly":
			MonthlyFrequencyPolicy monthlyFrequencyDefinition= new MonthlyFrequencyPolicy();
			monthlyFrequencyDefinition.setDayOfMonth(1);
			monthlyFrequencyDefinition.setTime(UserMasterConstant.BATCH_EXECUTION_HOUR, UserMasterConstant.BATCH_EXECUTION_MIN);	
	    	break;
		case "Fortnightly":
			break;

		default:
			break;
		}
    	
    	SchedulerCluesUpdateService myThread = applicationContext.getBean(SchedulerCluesUpdateService.class);
    	Task task=new TransientTask(schedule, myThread);
    	    	    	
    	BatchScheduler.getInstance().addTask(task);
    	
    	LOGGER.info("SchedulerCluesFrequency() ended. Scheduler CLUES job started Sucessfully");
    }
}
