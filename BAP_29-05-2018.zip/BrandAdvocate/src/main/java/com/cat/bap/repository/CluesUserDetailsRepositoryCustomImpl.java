package com.cat.bap.repository;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.persistence.util.TufConnectionProvider;
import com.cat.bap.service.BAUserDetailsService;
import com.cat.bap.util.BrandAdvocateUtility;

/**
 * @author rathor
 *
 */
@Repository
public class CluesUserDetailsRepositoryCustomImpl implements CluesUserDetailsRepositoryCustom {

	private static final Logger logger = LoggerFactory.getLogger(BAUserDetailsService.class);

	@PersistenceContext
	private EntityManager entityManager;

	@Inject
	private TufConnectionProvider tufConnectionProvider;

	@Inject
	private AffilationDescRepository affilationDescRepository;

	public TufConnectionProvider getTufConnectionProvider() {
		return tufConnectionProvider;
	}

	@Override
	public Map<String, Object> getCluesUserDetailsByEmailId(String emailId) throws SQLException {

		Map<String, Object> response = new HashMap<>();
		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();

		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		Connection con = tufConnectionProvider.getConnection();

		try (PreparedStatement ps = con.prepareStatement(
				"select USER_CUPID,AFLTN_DESC,PS_EMP_LAST_NM,PS_EMP_FST_NM,PERS_PREF_FST_NM,PS_ADMN_CD_DESC,WRK_LOC_DESC,BUS_EMAIL_ADR,JOB_KEYWORD,CTRY_CD FROM Z1FZ001$.CAT_GLBL_DIR_OWNED WHERE BUS_EMAIL_ADR  ='"
						+ emailId + "' ");) {
			ResultSet result = ps.executeQuery();
			while (result.next()) {
				cluesDataDetailDto.setAffiliationDescription(result.getString("USER_CUPID"));
				cluesDataDetailDto.setAffiliationDescription(result.getString("AFLTN_DESC"));
				cluesDataDetailDto.setLastName(result.getString("PS_EMP_LAST_NM"));
				cluesDataDetailDto.setFirstName(result.getString("PS_EMP_FST_NM"));
				cluesDataDetailDto.setPreferredFirstName(result.getString("PERS_PREF_FST_NM"));
				cluesDataDetailDto.setOrganizationName(result.getString("PS_ADMN_CD_DESC"));
				cluesDataDetailDto.setFacilityName(result.getString("WRK_LOC_DESC"));
				cluesDataDetailDto.setPrimaryEmail(result.getString("BUS_EMAIL_ADR"));
				cluesDataDetailDto.setJobKeywords(result.getString("JOB_KEYWORD"));
				cluesDataDetailDto.setCountryCode(result.getString("CTRY_CD"));
				userMasterDTOs.add(cluesDataDetailDto);
			}
			if (!userMasterDTOs.isEmpty()) {
				response.put(UserMasterConstant.LIST, userMasterDTOs.get(0));
			} else {
				response.put(UserMasterConstant.LIST, userMasterDTOs);
			}
		}
		return response;
	}

	@Override
	public Map<String, Object> getCluesUserDetailsByCwsUserId(String cwsUserId) throws SQLException {

		Map<String, Object> response = new HashMap<>();
		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();

		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		Connection con = tufConnectionProvider.getConnection();
		PreparedStatement ps = con.prepareStatement(
				"select USER_CUPID,AFLTN_DESC,PS_EMP_LAST_NM,PS_EMP_FST_NM,PERS_PREF_FST_NM,PS_ADMN_CD_DESC,WRK_LOC_DESC,BUS_EMAIL_ADR,JOB_KEYWORD,CTRY_CD FROM Z1FZ001$.CAT_GLBL_DIR_OWNED WHERE USER_CWS_ID = '"
						+ cwsUserId + "' ");
		ResultSet result = ps.executeQuery();
		while (result.next()) {
			cluesDataDetailDto.setAffiliationDescription(result.getString("USER_CUPID"));
			cluesDataDetailDto.setAffiliationDescription(result.getString("AFLTN_DESC"));
			cluesDataDetailDto.setLastName(result.getString("PS_EMP_LAST_NM"));
			cluesDataDetailDto.setFirstName(result.getString("PS_EMP_FST_NM"));
			cluesDataDetailDto.setPreferredFirstName(result.getString("PERS_PREF_FST_NM"));
			cluesDataDetailDto.setOrganizationName(result.getString("PS_ADMN_CD_DESC"));
			cluesDataDetailDto.setFacilityName(result.getString("WRK_LOC_DESC"));
			cluesDataDetailDto.setPrimaryEmail(result.getString("BUS_EMAIL_ADR"));
			cluesDataDetailDto.setJobKeywords(result.getString("JOB_KEYWORD"));
			cluesDataDetailDto.setCountryCode(result.getString("CTRY_CD"));
			userMasterDTOs.add(cluesDataDetailDto);
		}
		if (!userMasterDTOs.isEmpty()) {
			response.put(UserMasterConstant.LIST, userMasterDTOs.get(0));
		} else {
			response.put(UserMasterConstant.LIST, userMasterDTOs);
		}
		return response;
	}

	@Override
	public Map<String, Object> getCluesUserDetailsByCupId(String cupId) throws SQLException {

		Map<String, Object> response = new HashMap<>();
		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();

		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		Connection con = tufConnectionProvider.getConnection();
		PreparedStatement ps = con.prepareStatement(
				"select USER_CUPID,AFLTN_DESC,PS_EMP_LAST_NM,PS_EMP_FST_NM,PERS_PREF_FST_NM,PS_ADMN_CD_DESC,WRK_LOC_DESC,BUS_EMAIL_ADR,JOB_KEYWORD,CTRY_CD FROM Z1FZ001$.CAT_GLBL_DIR_OWNED where USER_CUPI= '"
						+ cupId + "'");
		ResultSet result = ps.executeQuery();
		while (result.next()) {
			cluesDataDetailDto.setCupId(result.getString("USER_CUPID"));
			cluesDataDetailDto.setAffiliationDescription(result.getString("AFLTN_DESC"));
			cluesDataDetailDto.setLastName(result.getString("PS_EMP_LAST_NM"));
			cluesDataDetailDto.setFirstName(result.getString("PS_EMP_FST_NM"));
			cluesDataDetailDto.setPreferredFirstName(result.getString("PERS_PREF_FST_NM"));
			cluesDataDetailDto.setOrganizationName(result.getString("PS_ADMN_CD_DESC"));
			cluesDataDetailDto.setFacilityName(result.getString("WRK_LOC_DESC"));
			cluesDataDetailDto.setPrimaryEmail(result.getString("BUS_EMAIL_ADR"));
			cluesDataDetailDto.setJobKeywords(result.getString("JOB_KEYWORD"));
			cluesDataDetailDto.setCountryCode(result.getString("CTRY_CD"));
			userMasterDTOs.add(cluesDataDetailDto);
		}

		response.put(UserMasterConstant.LIST, userMasterDTOs);
		return response;
	}

	@Override
	public Map<String, Object> getCluesUserDetailsBasedOnCwsIdOrEmailId(String cwsUserId, String emailId)
			throws SQLException {

		Map<String, Object> response = new HashMap<>();
		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();

		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		Connection con = tufConnectionProvider.getConnection();
		StringBuilder createQuery = new StringBuilder();
		createQuery.append(
				"select USER_CUPID,AFLTN_DESC,PS_EMP_LAST_NM,PS_EMP_FST_NM,PERS_PREF_FST_NM,PS_ADMN_CD_DESC,WRK_LOC_DESC,BUS_EMAIL_ADR,JOB_KEYWORD,CTRY_CD FROM Z1FZ001$.CAT_GLBL_DIR_OWNED where ");

		if (!BrandAdvocateUtility.isEmptyString(cwsUserId))
			createQuery.append("UPPER(USER_CWS_ID) = UPPER('" + cwsUserId + "')");

		if (!BrandAdvocateUtility.isEmptyString(emailId))
			createQuery.append("UPPER(BUS_EMAIL_ADR) = UPPER('" + emailId + "')");

		PreparedStatement ps = con.prepareStatement(createQuery.toString());

		ResultSet result = ps.executeQuery();
		while (result.next()) {
			cluesDataDetailDto.setCupId(result.getString("USER_CUPID"));
			cluesDataDetailDto.setAffiliationDescription(result.getString("AFLTN_DESC"));
			cluesDataDetailDto.setLastName(result.getString("PS_EMP_LAST_NM"));
			cluesDataDetailDto.setFirstName(result.getString("PS_EMP_FST_NM"));
			cluesDataDetailDto.setPreferredFirstName(result.getString("PERS_PREF_FST_NM"));
			cluesDataDetailDto.setOrganizationName(result.getString("PS_ADMN_CD_DESC"));
			cluesDataDetailDto.setFacilityName(result.getString("WRK_LOC_DESC"));
			cluesDataDetailDto.setPrimaryEmail(result.getString("BUS_EMAIL_ADR"));
			cluesDataDetailDto.setJobKeywords(result.getString("JOB_KEYWORD"));
			cluesDataDetailDto.setCountryCode(result.getString("CTRY_CD"));
			userMasterDTOs.add(cluesDataDetailDto);
		}
		tufConnectionProvider.closeConnection(con);
		if (!userMasterDTOs.isEmpty()) {
			response.put(UserMasterConstant.LIST, userMasterDTOs.get(0));
		} else {
			response.put(UserMasterConstant.LIST, userMasterDTOs);
		}

		return response;
	}

	@Override
	public Map<String, Object> getCluesUserDetailsBasedOnIds(String cwsUserId, String emailId, String cupId)
			throws SQLException {

		Map<String, Object> response = new HashMap<>();
		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();

		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		Connection con = tufConnectionProvider.getConnection();
		StringBuilder createQuery = new StringBuilder();
		createQuery.append(
				"select USER_CUPID,AFLTN_DESC,PS_EMP_LAST_NM,PS_EMP_FST_NM,PERS_PREF_FST_NM,PS_ADMN_CD_DESC,WRK_LOC_DESC,BUS_EMAIL_ADR,JOB_KEYWORD,CTRY_CD,USER_CWS_ID FROM Z1FZ001$.CAT_GLBL_DIR_OWNED where ");

		if (!BrandAdvocateUtility.isEmptyString(cwsUserId))
			createQuery.append("UPPER(USER_CWS_ID) = UPPER('" + cwsUserId + "')");

		if (!BrandAdvocateUtility.isEmptyString(emailId))
			createQuery.append("UPPER(BUS_EMAIL_ADR) = UPPER('" + emailId + "') ");

		if (!BrandAdvocateUtility.isEmptyString(cupId))
			createQuery.append("USER_CUPID = '" + cupId + "' ");

		PreparedStatement ps = con.prepareStatement(createQuery.toString());

		ResultSet result = ps.executeQuery();
		while (result.next()) {
			cluesDataDetailDto.setCupId(BrandAdvocateUtility.getStringValue(result.getString("USER_CUPID")));
			cluesDataDetailDto
					.setAffiliationDescription(BrandAdvocateUtility.getStringValue(result.getString("AFLTN_DESC")));
			cluesDataDetailDto.setLastName(BrandAdvocateUtility.getStringValue(result.getString("PS_EMP_LAST_NM")));
			cluesDataDetailDto.setFirstName(BrandAdvocateUtility.getStringValue(result.getString("PS_EMP_FST_NM")));
			cluesDataDetailDto
					.setPreferredFirstName(BrandAdvocateUtility.getStringValue(result.getString("PERS_PREF_FST_NM")));
			cluesDataDetailDto
					.setOrganizationName(BrandAdvocateUtility.getStringValue(result.getString("PS_ADMN_CD_DESC")));
			cluesDataDetailDto.setFacilityName(BrandAdvocateUtility.getStringValue(result.getString("WRK_LOC_DESC")));
			cluesDataDetailDto.setPrimaryEmail(BrandAdvocateUtility.getStringValue(result.getString("BUS_EMAIL_ADR")));
			cluesDataDetailDto.setJobKeywords(BrandAdvocateUtility.getStringValue(result.getString("JOB_KEYWORD")));
			cluesDataDetailDto.setCountryCode(BrandAdvocateUtility.getStringValue(result.getString("CTRY_CD")));
			cluesDataDetailDto.setCwsUserId(BrandAdvocateUtility.getStringValue(result.getString("USER_CWS_ID")));
			userMasterDTOs.add(cluesDataDetailDto);
		}
		tufConnectionProvider.closeConnection(con);

		for (CluesDataDetailDto cluesDataDetailDto2 : userMasterDTOs) {
			cluesDataDetailDto2.setMappedAffiliationName(
					affilationDescRepository.getAffiliationNameByDesc(cluesDataDetailDto2.getAffiliationDescription()));
		}

		if (!userMasterDTOs.isEmpty()) {
			response.put(UserMasterConstant.LIST, userMasterDTOs.get(0));
		} else {
			response.put(UserMasterConstant.LIST, userMasterDTOs);
		}

		return response;
	}

	@Override
	public Map<String, List<BAUserDetailsDto>> uploadBulkUploadForEmailsOrCWSIds(String cwsUserIds)
			throws SQLException {

		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();

		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		Connection conn = tufConnectionProvider.getConnection();
		StringBuilder createQuery = new StringBuilder();
		createQuery.append("SELECT " + "USER_CWS_ID," + "USER_CUPID," + "AFLTN_DESC," + "PS_EMP_LAST_NM,"
				+ "PS_EMP_FST_NM," + "PERS_PREF_FST_NM," + "PS_ADMN_CD_DESC," + "WRK_LOC_DESC," + "BUS_EMAIL_ADR,"
				+ "JOB_KEYWORD," + "CTRY_CD " + "FROM " + "Z1FZ001$.CAT_GLBL_DIR_OWNED where ");

		if (BrandAdvocateUtility.isEmailId(cwsUserIds)) {
			createQuery.append("BUS_EMAIL_ADR  IN ('");
		} else {
			createQuery.append("USER_CWS_ID  IN ('");
		}

		createQuery.append("')");

		PreparedStatement ps = conn.prepareStatement(createQuery.toString());

		ResultSet result = ps.executeQuery();
		while (result.next()) {
			cluesDataDetailDto.setCupId(BrandAdvocateUtility.getStringValue(result.getString("USER_CUPID")));
			cluesDataDetailDto
					.setAffiliationDescription(BrandAdvocateUtility.getStringValue(result.getString("AFLTN_DESC")));
			cluesDataDetailDto.setLastName(BrandAdvocateUtility.getStringValue(result.getString("PS_EMP_LAST_NM")));
			cluesDataDetailDto.setFirstName(BrandAdvocateUtility.getStringValue(result.getString("PS_EMP_FST_NM")));
			cluesDataDetailDto
					.setPreferredFirstName(BrandAdvocateUtility.getStringValue(result.getString("PERS_PREF_FST_NM")));
			cluesDataDetailDto
					.setOrganizationName(BrandAdvocateUtility.getStringValue(result.getString("PS_ADMN_CD_DESC")));
			cluesDataDetailDto.setFacilityName(BrandAdvocateUtility.getStringValue(result.getString("WRK_LOC_DESC")));
			cluesDataDetailDto.setPrimaryEmail(BrandAdvocateUtility.getStringValue(result.getString("BUS_EMAIL_ADR")));
			cluesDataDetailDto.setJobKeywords(BrandAdvocateUtility.getStringValue(result.getString("JOB_KEYWORD")));
			cluesDataDetailDto.setCountryCode(BrandAdvocateUtility.getStringValue(result.getString("CTRY_CD")));
			userMasterDTOs.add(cluesDataDetailDto);
		}
		tufConnectionProvider.closeConnection(conn);
		
		return null;
	}

	@Override
	public List<CluesDataDetailDto> getValidCluesUsers(List<String> newBAObject, boolean isCWS) throws SQLException {

		List<CluesDataDetailDto> cluesDetailDtoList = new ArrayList<>();

		Connection conn = tufConnectionProvider.getConnection();
		StringBuilder createQuery = new StringBuilder();

		createQuery.append(
				"SELECT " + "USER_CWS_ID," + "USER_CUPID," + "AFLTN_DESC," + "PS_EMP_LAST_NM," + "PS_EMP_FST_NM,"
						+ "PERS_PREF_FST_NM," + "PS_ADMN_CD_DESC," + "WRK_LOC_DESC," + "BUS_EMAIL_ADR," + "JOB_KEYWORD,"
						+ "CTRY_CD " + "FROM " + UserMasterConstant.CLUES_DB_SCHEMA + ".CAT_GLBL_DIR_OWNED where ");

		if (isCWS) {
			createQuery.append("UPPER(USER_CWS_ID)  IN ( ");
		} else {
			createQuery.append("UPPER(BUS_EMAIL_ADR)  IN ( ");
		}

		StringBuilder preparedValues = new StringBuilder();

		for (String baCwsIdEmailString : newBAObject) {
			preparedValues.append("UPPER('");
			preparedValues.append(baCwsIdEmailString);
			preparedValues.append("'),");
		}
		String preparedValue = (preparedValues.length() > 0) ? preparedValues.substring(0, preparedValues.length() - 1)
				: "";

		createQuery.append(preparedValue);
		createQuery.append(")");

		PreparedStatement ps = conn.prepareStatement(createQuery.toString());

		ResultSet result = ps.executeQuery();
		while (result.next()) {
			CluesDataDetailDto cluesDataDetailDto = null;
			cluesDataDetailDto = new CluesDataDetailDto();
			cluesDataDetailDto.setCwsUserId(BrandAdvocateUtility.getStringValue(result.getString("USER_CWS_ID")));
			cluesDataDetailDto.setCupId(BrandAdvocateUtility.getStringValue(result.getString("USER_CUPID")));
			cluesDataDetailDto
					.setAffiliationDescription(BrandAdvocateUtility.getStringValue(result.getString("AFLTN_DESC")));
			cluesDataDetailDto.setLastName(BrandAdvocateUtility.getStringValue(result.getString("PS_EMP_LAST_NM")));
			cluesDataDetailDto.setFirstName(BrandAdvocateUtility.getStringValue(result.getString("PS_EMP_FST_NM")));
			cluesDataDetailDto
					.setPreferredFirstName(BrandAdvocateUtility.getStringValue(result.getString("PERS_PREF_FST_NM")));
			cluesDataDetailDto
					.setOrganizationName(BrandAdvocateUtility.getStringValue(result.getString("PS_ADMN_CD_DESC")));
			cluesDataDetailDto.setFacilityName(BrandAdvocateUtility.getStringValue(result.getString("WRK_LOC_DESC")));
			cluesDataDetailDto.setPrimaryEmail(BrandAdvocateUtility.getStringValue(result.getString("BUS_EMAIL_ADR")));
			cluesDataDetailDto.setJobKeywords(BrandAdvocateUtility.getStringValue(result.getString("JOB_KEYWORD")));
			cluesDataDetailDto.setCountryCode(BrandAdvocateUtility.getStringValue(result.getString("CTRY_CD")));
			cluesDetailDtoList.add(cluesDataDetailDto);
		}
		 tufConnectionProvider.closeConnection(conn);

		return cluesDetailDtoList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BAUserDetailsDto> getAllBAUsersList(String cwsOrEmailIds, boolean isCWS) {

		List<BAUserDetailsDto> cluesDetailDtoList = new ArrayList<>();

		StringBuilder createQuery = new StringBuilder();

		createQuery.append("SELECT " + "ba.brand_advocate_id," + "ba.cws_user_id," + "ba.last_name," + "ba.first_name,"
				+ "ba.preferred_first_name," + "ba.organization_name," + "ba.primary_email," + "ba.secondary_email,"
				+ "ba.facility_name," + "ba.building_name," + "ba.job_keywords," + "ba.affiliation_description,"
				+ "ba.brand_advocate_status," + "ba.cup_id, " + " ba.is_active "

				+ "FROM " + "brand_advocate_details ba where ");

		if (isCWS) {
			createQuery.append("upper(ba.cws_user_id)  IN (");
		} else {
			createQuery.append("upper(ba.primary_email)  IN (");
		}

		StringBuilder prepareQuery = new StringBuilder();
		StringTokenizer tokenString = new StringTokenizer(cwsOrEmailIds);

		while (tokenString.hasMoreTokens()) {
			prepareQuery.append("UPPER('").append(tokenString.nextToken()).append("'),");
		}

		createQuery.append(prepareQuery);

		String commSepratedValue = createQuery.substring(0, createQuery.length() - 1).concat(")");

		List<Object[]> dataList = null;
		try {
			Query query = entityManager.createNativeQuery(commSepratedValue);
			dataList = query.getResultList();
		} catch (Exception ex) {
			logger.error("Error in create query", ex);
		}

		if (null != dataList) {
			dataList.stream().forEach(record -> {

				BAUserDetailsDto bAUserDetailsDto = null;
				bAUserDetailsDto = new BAUserDetailsDto();

				bAUserDetailsDto.setBrandAdvocateId(record[0] != null ? ((BigInteger) record[0]).longValue() : null);
				bAUserDetailsDto.setCwsUserId(record[1] != null ? "" + (String) record[1] : "");
				bAUserDetailsDto.setLastName(record[2] != null ? "" + (String) record[2] : "");
				bAUserDetailsDto.setFirstName(record[3] != null ? "" + (String) record[3] : "");
				bAUserDetailsDto.setPreferredFirstName(record[4] != null ? "" + (String) record[4] : "");
				bAUserDetailsDto.setOrganizationName(record[5] != null ? "" + (String) record[5] : "");
				bAUserDetailsDto.setPrimaryEmail(record[6] != null ? "" + (String) record[6] : "");
				bAUserDetailsDto.setSecondaryEmail(record[7] != null ? "" + (String) record[7] : "");
				bAUserDetailsDto.setFacilityName(record[8] != null ? "" + (String) record[8] : "");
				bAUserDetailsDto.setWorkLocation(record[9] != null ? "" + (String) record[9] : "");
				bAUserDetailsDto.setJobKeywords(record[10] != null ? "" + (String) record[10] : "");
				bAUserDetailsDto.setAffiliationDescription(record[11] != null ? "" + (String) record[11] : "");
				bAUserDetailsDto.setBrandAdvocateStatus(record[12] != null ? "" + (String) record[12] : "");
				bAUserDetailsDto.setCupId(record[13] != null ? "" + (String) record[13] : "");
				Character charValue = (Character) record[14];
				if (charValue == 'Y') {
					bAUserDetailsDto.setIsActive(true);
				} else {
					bAUserDetailsDto.setIsActive(false);
				}

				cluesDetailDtoList.add(bAUserDetailsDto);
			});
		}

		return cluesDetailDtoList;
	}

	@Override
	public List<CluesDataDetailDto> getAllCluesUserForCupIds(List<String> baObjList) throws SQLException {

		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();
		StringBuilder userValues = new StringBuilder();

		Connection con = tufConnectionProvider.getConnection();
		PreparedStatement prepareQuery;

		StringBuilder createQuery = new StringBuilder();

		createQuery.append("SELECT " + "USER_CWS_ID," + "USER_CUPID," + "AFLTN_DESC," + "PS_EMP_LAST_NM,"
				+ "PS_EMP_FST_NM," + "PERS_PREF_FST_NM," + "PS_ADMN_CD_DESC," + "WRK_LOC_DESC," + "BUS_EMAIL_ADR,"
				+ "JOB_KEYWORD," + "CTRY_CD, " + "GLBL_DIR_STAT " + "FROM " + UserMasterConstant.CLUES_DB_SCHEMA
				+ ".CAT_GLBL_DIR_OWNED where UPPER(USER_CUPID) IN (");

		for (String cupID : baObjList) {
			userValues.append("UPPER('").append(cupID).append("'),");
		}

		String commSepratedValue = userValues.substring(0, userValues.length() - 1);

		createQuery.append(commSepratedValue);
		createQuery.append(")");

		prepareQuery = con.prepareStatement(createQuery.toString());

		ResultSet result = prepareQuery.executeQuery();

		while (result.next()) {
			CluesDataDetailDto cluesDataDetailDto = null;
			cluesDataDetailDto = new CluesDataDetailDto();

			cluesDataDetailDto.setCwsUserId(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("USER_CWS_ID")));
			cluesDataDetailDto.setCupId(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("USER_CUPID")));
			cluesDataDetailDto
					.setAffiliationDescription(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("AFLTN_DESC")));
			cluesDataDetailDto.setLastName(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("PS_EMP_LAST_NM")));
			cluesDataDetailDto.setFirstName(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("PS_EMP_FST_NM")));
			cluesDataDetailDto.setPreferredFirstName(
					BrandAdvocateUtility.getEmptyOrNotNull(result.getString("PERS_PREF_FST_NM")));
			cluesDataDetailDto
					.setOrganizationName(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("PS_ADMN_CD_DESC")));
			cluesDataDetailDto
					.setFacilityName(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("WRK_LOC_DESC")));
			cluesDataDetailDto
					.setPrimaryEmail(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("BUS_EMAIL_ADR")));
			cluesDataDetailDto.setJobKeywords(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("JOB_KEYWORD")));
			cluesDataDetailDto.setCountryCode(BrandAdvocateUtility.getEmptyOrNotNull(result.getString("CTRY_CD")));
			cluesDataDetailDto.setGlobalDirectoryStatus(
					BrandAdvocateUtility.getEmptyOrNotNull(result.getString("GLBL_DIR_STAT")));

			userMasterDTOs.add(cluesDataDetailDto);
		}

		return userMasterDTOs;
	}

}
