package com.cat.bap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_preferences_tbl")
public class UserPreferences {

	@Id
	@Column(name = "upa_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long upaId;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "brand_advocate_id", foreignKey = @ForeignKey(name = "fk_user_preferences_access_user_master"))
	private BAUserDetails bAUserDetails;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "preference_id", foreignKey = @ForeignKey(name = "fk_user_preferences_access_preferences"))
	private Preferences preference;

	public Long getUpaId() {
		return upaId;
	}

	public void setUpaId(Long upaId) {
		this.upaId = upaId;
	}

	public BAUserDetails getUserMaster() {
		return bAUserDetails;
	}

	public void setUserMaster(BAUserDetails userMaster) {
		this.bAUserDetails = userMaster;
	}

	public Preferences getPreference() {
		return preference;
	}

	public void setPreference(Preferences preference) {
		this.preference = preference;
	}

}
