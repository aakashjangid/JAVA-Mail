package com.cat.bap.entity;
	
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
	
/**
 * @author rathor
 */

@Entity
@Table(name = "miscellaneous_tbl")
public class Miscellaneous {

	@Id
	@Column(name = "miscellaneous_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long miscId;

	@Column(name = "miscellaneous_name")
	private String miscName;

	
	@Column(name = "miscellaneous_desc")
	private String miscDesc;


	/**
	 * @return the miscId
	 */
	public Long getMiscId() {
		return miscId;
	}


	/**
	 * @param miscId the miscId to set
	 */
	public void setMiscId(Long miscId) {
		this.miscId = miscId;
	}


	/**
	 * @return the miscName
	 */
	public String getMiscName() {
		return miscName;
	}


	/**
	 * @param miscName the miscName to set
	 */
	public void setMiscName(String miscName) {
		this.miscName = miscName;
	}


	/**
	 * @return the miscDesc
	 */
	public String getMiscDesc() {
		return miscDesc;
	}


	/**
	 * @param miscDesc the miscDesc to set
	 */
	public void setMiscDesc(String miscDesc) {
		this.miscDesc = miscDesc;
	}
	
}
