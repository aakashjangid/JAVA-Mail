package com.cat.bap.dto;

import java.io.Serializable;
import java.util.List;

import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.Documents;

/**
 * @author Rani.Agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 20-March-2018
 * @purpose
 */

public class CalendarRequest implements Serializable {

	private static final long serialVersionUID = -5923436225957169206L;

	private Long invitationId;
	
	private String uId;
	
	private String subject;

	private String messageBody;

	private String location;

	private String firstName;

	private String lastName;

	private String startDateTime;

	private String endDateTime;
	
	private String timezone;
	
	private transient List<BAUserDetails> baUserDetailsList;
	
	private transient List<Documents> documentsList;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(String startDateTime) {
		this.startDateTime = startDateTime;
	}

	public String getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(String endDateTime) {
		this.endDateTime = endDateTime;
	}
	
	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public List<BAUserDetails> getBaUserDetailsList() {
		return baUserDetailsList;
	}

	public void setBaUserDetailsList(List<BAUserDetails> baUserDetailsList) {
		this.baUserDetailsList = baUserDetailsList;
	}

	public List<Documents> getDocumentsList() {
		return documentsList;
	}

	public void setDocumentsList(List<Documents> documentsList) {
		this.documentsList = documentsList;
	}

	public Long getInvitationId() {
		return invitationId;
	}

	public void setInvitationId(Long invitationId) {
		this.invitationId = invitationId;
	}

	public String getuId() {
		return uId;
	}

	public void setuId(String uId) {
		this.uId = uId;
	}
	
}