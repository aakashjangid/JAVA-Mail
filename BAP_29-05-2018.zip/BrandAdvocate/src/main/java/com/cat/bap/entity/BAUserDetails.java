package com.cat.bap.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;



@Entity
@Table(name = "brand_advocate_details")
public class BAUserDetails {

  @Id
  @Column(name = "brand_advocate_id")
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long brandAdvocateId;

  @Column(name = "cws_user_id")
  private String cwsUserId;

  @Column(name = "last_name")
  private String lastName;

  @Column(name = "first_name")
  private String firstName;

  @Column(name = "preferred_first_name")
  private String preferredFirstName;

  @Column(name = "organization_name")
  private String organizationName;

  @Column(name = "primary_email")
  private String primaryEmail;

  @Column(name = "secondary_email")
  private String secondaryEmail;

  // @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "country_id", foreignKey = @ForeignKey(name = "fk_user_country"))
  private Country country;

  @Column(name = "facility_name")
  private String facilityName;

  @Column(name = "building_name")
  private String buildingName;

  @Column(name = "job_keywords")
  private String jobKeywords;

  @Column(name = "affiliation_description")
  private String affiliationDescription;

  @Column(name = "brand_advocate_status")
  private String brandAdvocateStatus;

  @Lob
  @Column(name = "comments", length = 512)
  private String comments;

  @Lob
  @Column(name = "notes", length = 512)
  private String notes;

  @Column(name = "registered_via")
  private String registeredVia;

  @Column(name = "is_active", columnDefinition = "char default 'Y'")
  @Type(type = "yes_no")
  private Boolean isActive = true;

  @Column(name = "registration_date")
  @Temporal(TemporalType.TIMESTAMP)
  private Date registrationDate;

  @Column(name = "registered_by")
  private String registeredBy;

  @Column(name = "modified_date")
  @Temporal(TemporalType.TIMESTAMP)
  private Date modifiedDate;

  @Column(name = "modified_by")
  private String modifiedBy;

  @Column(name = "managed_by")
  private String managedBy;
  
  @Column(name ="cup_id")
  private String cupId;
  
  @Column(name="inactive_date")
  private Date inActiveDate;
  
  @Column(name="affiliation_description_ui")
  private String mappedAffType;


/**
 * @return the mappedAffType
 */
public String getMappedAffType() {
	return mappedAffType;
}

/**
 * @param mappedAffType the mappedAffType to set
 */
public void setMappedAffType(String mappedAffType) {
	this.mappedAffType = mappedAffType;
}

/**
 * @return the brandAdvocateId
 */
public Long getBrandAdvocateId() {
	return brandAdvocateId;
}

/**
 * @param brandAdvocateId the brandAdvocateId to set
 */
public void setBrandAdvocateId(Long brandAdvocateId) {
	this.brandAdvocateId = brandAdvocateId;
}

/**
 * @return the cwsUserId
 */
public String getCwsUserId() {
	return cwsUserId;
}

/**
 * @param cwsUserId the cwsUserId to set
 */
public void setCwsUserId(String cwsUserId) {
	this.cwsUserId = cwsUserId;
}

/**
 * @return the lastName
 */
public String getLastName() {
	return lastName;
}

/**
 * @param lastName the lastName to set
 */
public void setLastName(String lastName) {
	this.lastName = lastName;
}

/**
 * @return the firstName
 */
public String getFirstName() {
	return firstName;
}

/**
 * @param firstName the firstName to set
 */
public void setFirstName(String firstName) {
	this.firstName = firstName;
}

/**
 * @return the preferredFirstName
 */
public String getPreferredFirstName() {
	return preferredFirstName;
}

/**
 * @param preferredFirstName the preferredFirstName to set
 */
public void setPreferredFirstName(String preferredFirstName) {
	this.preferredFirstName = preferredFirstName;
}

/**
 * @return the organizationName
 */
public String getOrganizationName() {
	return organizationName;
}

/**
 * @param organizationName the organizationName to set
 */
public void setOrganizationName(String organizationName) {
	this.organizationName = organizationName;
}

/**
 * @return the primaryEmail
 */
public String getPrimaryEmail() {
	return primaryEmail;
}

/**
 * @param primaryEmail the primaryEmail to set
 */
public void setPrimaryEmail(String primaryEmail) {
	this.primaryEmail = primaryEmail;
}

/**
 * @return the secondaryEmail
 */
public String getSecondaryEmail() {
	return secondaryEmail;
}

/**
 * @param secondaryEmail the secondaryEmail to set
 */
public void setSecondaryEmail(String secondaryEmail) {
	this.secondaryEmail = secondaryEmail;
}

/**
 * @return the country
 */
public Country getCountry() {
	return country;
}

/**
 * @param country the country to set
 */
public void setCountry(Country country) {
	this.country = country;
}

/**
 * @return the facilityName
 */
public String getFacilityName() {
	return facilityName;
}

/**
 * @param facilityName the facilityName to set
 */
public void setFacilityName(String facilityName) {
	this.facilityName = facilityName;
}

/**
 * @return the buildingName
 */
public String getBuildingName() {
	return buildingName;
}

/**
 * @param buildingName the buildingName to set
 */
public void setBuildingName(String buildingName) {
	this.buildingName = buildingName;
}

/**
 * @return the jobKeywords
 */
public String getJobKeywords() {
	return jobKeywords;
}

/**
 * @param jobKeywords the jobKeywords to set
 */
public void setJobKeywords(String jobKeywords) {
	this.jobKeywords = jobKeywords;
}

/**
 * @return the affiliationDescription
 */
public String getAffiliationDescription() {
	return affiliationDescription;
}

/**
 * @param affiliationDescription the affiliationDescription to set
 */
public void setAffiliationDescription(String affiliationDescription) {
	this.affiliationDescription = affiliationDescription;
}

/**
 * @return the brandAdvocateStatus
 */
public String getBrandAdvocateStatus() {
	return brandAdvocateStatus;
}

/**
 * @param brandAdvocateStatus the brandAdvocateStatus to set
 */
public void setBrandAdvocateStatus(String brandAdvocateStatus) {
	this.brandAdvocateStatus = brandAdvocateStatus;
}

/**
 * @return the comments
 */
public String getComments() {
	return comments;
}

/**
 * @param comments the comments to set
 */
public void setComments(String comments) {
	this.comments = comments;
}

/**
 * @return the notes
 */
public String getNotes() {
	return notes;
}

/**
 * @param notes the notes to set
 */
public void setNotes(String notes) {
	this.notes = notes;
}

/**
 * @return the registeredVia
 */
public String getRegisteredVia() {
	return registeredVia;
}

/**
 * @param registeredVia the registeredVia to set
 */
public void setRegisteredVia(String registeredVia) {
	this.registeredVia = registeredVia;
}

/**
 * @return the isActive
 */
public Boolean getIsActive() {
	return isActive;
}

/**
 * @param isActive the isActive to set
 */
public void setIsActive(Boolean isActive) {
	this.isActive = isActive;
}

/**
 * @return the registrationDate
 */
public Date getRegistrationDate() {
	return registrationDate;
}

/**
 * @param registrationDate the registrationDate to set
 */
public void setRegistrationDate(Date registrationDate) {
	this.registrationDate = registrationDate;
}

/**
 * @return the registeredBy
 */
public String getRegisteredBy() {
	return registeredBy;
}

/**
 * @param registeredBy the registeredBy to set
 */
public void setRegisteredBy(String registeredBy) {
	this.registeredBy = registeredBy;
}

/**
 * @return the modifiedDate
 */
public Date getModifiedDate() {
	return modifiedDate;
}

/**
 * @param modifiedDate the modifiedDate to set
 */
public void setModifiedDate(Date modifiedDate) {
	this.modifiedDate = modifiedDate;
}

/**
 * @return the modifiedBy
 */
public String getModifiedBy() {
	return modifiedBy;
}

/**
 * @param modifiedBy the modifiedBy to set
 */
public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
}

/**
 * @return the managedBy
 */
public String getManagedBy() {
	return managedBy;
}

/**
 * @param managedBy the managedBy to set
 */
public void setManagedBy(String managedBy) {
	this.managedBy = managedBy;
}

/**
 * @return the cupId
 */
public String getCupId() {
	return cupId;
}

/**
 * @param cupId the cupId to set
 */
public void setCupId(String cupId) {
	this.cupId = cupId;
}

public Date getInActiveDate() {
	return inActiveDate;
}

public void setInActiveDate(Date inActiveDate) {
	this.inActiveDate = inActiveDate;
}


}
