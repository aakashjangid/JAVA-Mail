package com.cat.bap.helper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CalendarRequest;
import com.cat.bap.dto.SchedulerDetailsDto;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.Country;
import com.cat.bap.entity.Invitation;
import com.cat.bap.entity.Region;
import com.cat.bap.entity.SchedulerDetail;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose
 */
public class UserMasterHelper {
	
	private UserMasterHelper(){
		
	}

	public static BAUserDetailsDto convertEntityToDto(BAUserDetails userMasterEntity) {

		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		if (null != userMasterEntity) {
			if (null != userMasterEntity.getBrandAdvocateId()) {
				bAUserDetailsDto.setBrandAdvocateId(userMasterEntity.getBrandAdvocateId());
			}
			if (null != userMasterEntity.getCwsUserId()) {
				bAUserDetailsDto.setCwsUserId(userMasterEntity.getCwsUserId());
			}
			if (null != userMasterEntity.getCupId()) {
				bAUserDetailsDto.setCupId(userMasterEntity.getCupId());
			}
			if (null != userMasterEntity.getLastName()) {
				bAUserDetailsDto.setLastName(userMasterEntity.getLastName());
			}
			if (null != userMasterEntity.getFirstName()) {
				bAUserDetailsDto.setFirstName(userMasterEntity.getFirstName());
			}
			if (null != userMasterEntity.getPreferredFirstName()) {
				bAUserDetailsDto.setPreferredFirstName(userMasterEntity.getPreferredFirstName());
			}
			if (null != userMasterEntity.getOrganizationName()) {
				bAUserDetailsDto.setOrganizationName(userMasterEntity.getOrganizationName());
			}
			if (null != userMasterEntity.getPrimaryEmail()) {
				bAUserDetailsDto.setPrimaryEmail(userMasterEntity.getPrimaryEmail());
			}
			if (null != userMasterEntity.getSecondaryEmail()) {
				bAUserDetailsDto.setSecondaryEmail(userMasterEntity.getSecondaryEmail());
			}
			if (null != userMasterEntity.getCountry()) {

				if (null != userMasterEntity.getCountry().getCountryId()) {
					bAUserDetailsDto.setCountryId(userMasterEntity.getCountry().getCountryId());
				}
				if (null != userMasterEntity.getCountry().getCountryName()) {
					bAUserDetailsDto.setCountryName(userMasterEntity.getCountry().getCountryName());
				}
				if (null != userMasterEntity.getCountry().getCountryCode()) {
					bAUserDetailsDto.setCountryCode(userMasterEntity.getCountry().getCountryCode());
				}
				if (null != userMasterEntity.getCountry().getRegion().getRegionId()) {
					bAUserDetailsDto.setRegionId(userMasterEntity.getCountry().getRegion().getRegionId());
				}
				if (null != userMasterEntity.getCountry().getRegion().getRegionName()) {
					bAUserDetailsDto.setRegionName(userMasterEntity.getCountry().getRegion().getRegionName());
				}
			}
			if (null != userMasterEntity.getFacilityName()) {
				bAUserDetailsDto.setFacilityName(userMasterEntity.getFacilityName());
			}
			if (null != userMasterEntity.getBuildingName()) {
				bAUserDetailsDto.setBuildingName(userMasterEntity.getBuildingName());
			}
			if (null != userMasterEntity.getJobKeywords()) {
				bAUserDetailsDto.setJobKeywords(userMasterEntity.getJobKeywords());
			}
			if (null != userMasterEntity.getMappedAffType()) {
				bAUserDetailsDto.setMappedAffiliationName(userMasterEntity.getMappedAffType());
			}
			if (null != userMasterEntity.getAffiliationDescription()) {
				bAUserDetailsDto.setAffiliationDescription(userMasterEntity.getAffiliationDescription());
			}
			if (null != userMasterEntity.getBrandAdvocateStatus()) {
				bAUserDetailsDto.setBrandAdvocateStatus(userMasterEntity.getBrandAdvocateStatus());
			}
			if (null != userMasterEntity.getComments()) {
				bAUserDetailsDto.setComments(userMasterEntity.getComments());
			}
			if (null != userMasterEntity.getNotes()) {
				bAUserDetailsDto.setNotes(userMasterEntity.getNotes());
			}
			if (null != userMasterEntity.getRegisteredVia()) {
				bAUserDetailsDto.setRegisteredVia(userMasterEntity.getRegisteredVia());
			}
			bAUserDetailsDto.setIsActive(userMasterEntity.getIsActive());

			if (null != userMasterEntity.getRegistrationDate()) {
				bAUserDetailsDto.setRegistrationDate(userMasterEntity.getRegistrationDate());
			}
			if (null != userMasterEntity.getRegisteredBy()) {
				bAUserDetailsDto.setRegisteredBy(userMasterEntity.getRegisteredBy());
			}
			if (null != userMasterEntity.getModifiedDate()) {
				bAUserDetailsDto.setModifiedDate(userMasterEntity.getModifiedDate());
			}
			if (null != userMasterEntity.getModifiedBy()) {
				bAUserDetailsDto.setModifiedBy(userMasterEntity.getModifiedBy());
			}
			if (null != userMasterEntity.getManagedBy()) {
				bAUserDetailsDto.setManagedBy(userMasterEntity.getManagedBy());
			}
		}
		return bAUserDetailsDto;
	}

	public static BAUserDetails convertDtoToEntity(BAUserDetailsDto bAUserDetailsDto) throws ParseException {

		BAUserDetails userMasterEntity = new BAUserDetails();
		if (null != bAUserDetailsDto) {
			if (null != bAUserDetailsDto.getBrandAdvocateId()) {
				userMasterEntity.setBrandAdvocateId(bAUserDetailsDto.getBrandAdvocateId());
			}
			if (null != bAUserDetailsDto.getCwsUserId()) {
				userMasterEntity.setCwsUserId(bAUserDetailsDto.getCwsUserId());
			}
			if (null != bAUserDetailsDto.getCupId()) {
				userMasterEntity.setCupId(bAUserDetailsDto.getCupId());
			}
			if (null != bAUserDetailsDto.getLastName()) {
				userMasterEntity.setLastName(bAUserDetailsDto.getLastName());
			}
			if (null != bAUserDetailsDto.getFirstName()) {
				userMasterEntity.setFirstName(bAUserDetailsDto.getFirstName());
			}
			if (null != bAUserDetailsDto.getPreferredFirstName()) {
				userMasterEntity.setPreferredFirstName(bAUserDetailsDto.getPreferredFirstName());
			}
			if (null != bAUserDetailsDto.getOrganizationName()) {
				userMasterEntity.setOrganizationName(bAUserDetailsDto.getOrganizationName());
			}
			if (null != bAUserDetailsDto.getPrimaryEmail()) {
				userMasterEntity.setPrimaryEmail(bAUserDetailsDto.getPrimaryEmail());
			}
			if (null != bAUserDetailsDto.getSecondaryEmail()) {
				userMasterEntity.setSecondaryEmail(bAUserDetailsDto.getSecondaryEmail());
			}
			if (null != bAUserDetailsDto.getCountryId()) {
				Country country = new Country();
				country.setCountryId(bAUserDetailsDto.getCountryId());
				country.setCountryName(bAUserDetailsDto.getCountryName());
				country.setCountryCode(bAUserDetailsDto.getCountryCode());
				Region region = new Region();
				region.setRegionId(bAUserDetailsDto.getRegionId());
				region.setRegionName(bAUserDetailsDto.getRegionName());
				List<Country> countries = new ArrayList<>();
				Country prefCountry = new Country();
				prefCountry.setCountryId(bAUserDetailsDto.getCountryId());
				prefCountry.setCountryName(bAUserDetailsDto.getCountryName());
				prefCountry.setCountryCode(bAUserDetailsDto.getCountryCode());
				prefCountry.setRegion(region);
				countries.add(prefCountry);
				region.setCountries(countries);
				country.setRegion(region);
				userMasterEntity.setCountry(country);
			}
			if (null != bAUserDetailsDto.getFacilityName()) {
				userMasterEntity.setFacilityName(bAUserDetailsDto.getFacilityName());
			}
			if (null != bAUserDetailsDto.getBuildingName()) {
				userMasterEntity.setBuildingName(bAUserDetailsDto.getBuildingName());
			}
			if (null != bAUserDetailsDto.getJobKeywords()) {
				userMasterEntity.setJobKeywords(bAUserDetailsDto.getJobKeywords());
			}
			if (null != bAUserDetailsDto.getAffiliationDescription()) {
				userMasterEntity.setAffiliationDescription(bAUserDetailsDto.getAffiliationDescription());
			}
			if (null != bAUserDetailsDto.getMappedAffiliationName()) {
				userMasterEntity.setMappedAffType(bAUserDetailsDto.getMappedAffiliationName());
			}
			if (null != bAUserDetailsDto.getBrandAdvocateStatus()) {
				userMasterEntity.setBrandAdvocateStatus(bAUserDetailsDto.getBrandAdvocateStatus());
			}
			if (null != bAUserDetailsDto.getComments()) {
				userMasterEntity.setComments(bAUserDetailsDto.getComments());
			}
			if (null != bAUserDetailsDto.getNotes()) {
				userMasterEntity.setNotes(bAUserDetailsDto.getNotes());
			}
			if (null != bAUserDetailsDto.getRegisteredVia()) {
				userMasterEntity.setRegisteredVia(bAUserDetailsDto.getRegisteredVia());
			}

			userMasterEntity.setIsActive(bAUserDetailsDto.getIsActive());

			if (null != bAUserDetailsDto.getRegistrationDate()) {
				userMasterEntity.setRegistrationDate(bAUserDetailsDto.getRegistrationDate());
			}
			if (null != bAUserDetailsDto.getRegisteredBy()) {
				userMasterEntity.setRegisteredBy(bAUserDetailsDto.getRegisteredBy());
			}
			if (null != bAUserDetailsDto.getModifiedDate()) {
				userMasterEntity.setModifiedDate(bAUserDetailsDto.getModifiedDate());
			}
			if (null != bAUserDetailsDto.getModifiedBy()) {
				userMasterEntity.setModifiedBy(bAUserDetailsDto.getModifiedBy());
			}
			if (null != bAUserDetailsDto.getManagedBy()) {
				userMasterEntity.setManagedBy(bAUserDetailsDto.getManagedBy());
			}
		}
		return userMasterEntity;
	}

	public static BAUserDetails convertDtoToEntityForSync(BAUserDetailsDto bAUserDetailsDto, Country countryDetails) {

		BAUserDetails userMasterEntity = null;
		userMasterEntity = new BAUserDetails();

		if (null != bAUserDetailsDto) {
			if (null != bAUserDetailsDto.getBrandAdvocateId()) {
				userMasterEntity.setBrandAdvocateId(bAUserDetailsDto.getBrandAdvocateId());
			}
			if (null != bAUserDetailsDto.getCwsUserId()) {
				userMasterEntity.setCwsUserId(bAUserDetailsDto.getCwsUserId());
			}
			if (null != bAUserDetailsDto.getCupId()) {
				userMasterEntity.setCupId(bAUserDetailsDto.getCupId());
			}
			if (null != bAUserDetailsDto.getLastName()) {
				userMasterEntity.setLastName(bAUserDetailsDto.getLastName());
			}
			if (null != bAUserDetailsDto.getFirstName()) {
				userMasterEntity.setFirstName(bAUserDetailsDto.getFirstName());
			}
			if (null != bAUserDetailsDto.getPreferredFirstName()) {
				userMasterEntity.setPreferredFirstName(bAUserDetailsDto.getPreferredFirstName());
			}
			if (null != bAUserDetailsDto.getOrganizationName()) {
				userMasterEntity.setOrganizationName(bAUserDetailsDto.getOrganizationName());
			}
			if (null != bAUserDetailsDto.getPrimaryEmail()) {
				userMasterEntity.setPrimaryEmail(bAUserDetailsDto.getPrimaryEmail());
			}
			if (null != bAUserDetailsDto.getCountryCode()) {
				userMasterEntity.setCountry(countryDetails);
			}
			if (null != bAUserDetailsDto.getFacilityName()) {
				userMasterEntity.setFacilityName(bAUserDetailsDto.getFacilityName());
			}

			if (null != bAUserDetailsDto.getAffiliationDescription()) {
				userMasterEntity.setAffiliationDescription(bAUserDetailsDto.getAffiliationDescription());
			}
			if (null != bAUserDetailsDto.getSecondaryEmail()) {
				userMasterEntity.setSecondaryEmail(bAUserDetailsDto.getSecondaryEmail());
			}
			if (null != bAUserDetailsDto.getBuildingName()) {
				userMasterEntity.setBuildingName(bAUserDetailsDto.getBuildingName());
			}
			if (null != bAUserDetailsDto.getJobKeywords()) {
				userMasterEntity.setJobKeywords(bAUserDetailsDto.getJobKeywords());
			}
			if (null != bAUserDetailsDto.getBrandAdvocateStatus()) {
				userMasterEntity.setBrandAdvocateStatus(bAUserDetailsDto.getBrandAdvocateStatus());
			}
			if (null != bAUserDetailsDto.getComments()) {
				userMasterEntity.setComments(bAUserDetailsDto.getComments());
			}
			if (null != bAUserDetailsDto.getNotes()) {
				userMasterEntity.setNotes(bAUserDetailsDto.getNotes());
			}
			if (null != bAUserDetailsDto.getRegisteredVia()) {
				userMasterEntity.setRegisteredVia(bAUserDetailsDto.getRegisteredVia());
			}
			if (null != bAUserDetailsDto.getRegistrationDate()) {
				userMasterEntity.setRegistrationDate(bAUserDetailsDto.getRegistrationDate());
			}
			if (null != bAUserDetailsDto.getRegisteredBy()) {
				userMasterEntity.setRegisteredBy(bAUserDetailsDto.getRegisteredBy());
			}
			if (null != bAUserDetailsDto.getManagedBy()) {
				userMasterEntity.setManagedBy(bAUserDetailsDto.getManagedBy());
			}
		}
		return userMasterEntity;
	}

	public static SchedulerDetail convertDtoToEntity(SchedulerDetailsDto schedulerDetailsDto) {

		SchedulerDetail schedulerDetail = null;
		schedulerDetail = new SchedulerDetail();

		if (null != schedulerDetailsDto) {
			if (null != schedulerDetailsDto.getJobExecutedBy()) {
				schedulerDetail.setJobExecutedBy(schedulerDetailsDto.getJobExecutedBy());
			}
			if (null != schedulerDetailsDto.getJobGenerateCode()) {
				schedulerDetail.setJobGenerateCode(schedulerDetailsDto.getJobGenerateCode());
			}
			if (null != schedulerDetailsDto.getJobStatus()) {
				schedulerDetail.setJobStatus(schedulerDetailsDto.getJobExecutedBy());
			}
			if (null != schedulerDetailsDto.getJobStatusLog()) {
				schedulerDetail.setJobStatus(schedulerDetailsDto.getJobStatusLog());
			}

		}
		return schedulerDetail;
	}

	public static Invitation convertDtoToEntity(String emailAddresses, String subject, String msg, Date startDate,
			Date endDate, String location, String timeZone) {
		Invitation invitation = new Invitation();
		invitation.setSendTo(emailAddresses);
		invitation.setSubject(subject);
		invitation.setStartDateTime(startDate);
		invitation.setEndDateTime(endDate);
		invitation.setLocation(location);
		invitation.setDescription(msg);
		invitation.setTimezone(timeZone);
		return invitation;
	}

	public static CalendarRequest convertEntityToDto(Invitation invitation) {
		CalendarRequest calendarRequest = new CalendarRequest();
		calendarRequest.setuId(invitation.getuId());
		calendarRequest.setMessageBody(invitation.getDescription());
		calendarRequest.setLocation(invitation.getLocation());
		calendarRequest.setTimezone(invitation.getTimezone());
		return calendarRequest;
	}
}
