/*
 * Created on May 19, 2010
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.cat.bap.web.filter;


import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public final class RequestWrapper extends HttpServletRequestWrapper {   
       
    public RequestWrapper(HttpServletRequest servletRequest) {   
        super(servletRequest);   
    }   
       
    @Override
	public String getHeader(String name) {   
        String value = super.getHeader(name);   
        if (value == null)   
            return null;   
        return hTMLEncode(value);   
           
    }   
    
	public String[] getParameterValues(String parameter) {   
    	  
    	String[] values = super.getParameterValues(parameter);   
    	if (values==null)  {   
    		return values;   
    	}   
    	int count = values.length;   
    	String[] encodedValues = new String[count];   
    	for (int i = 0; i < count; i++) {   
    	    encodedValues[i] = hTMLEncode(values[i]);   
    	}     
    	return encodedValues;    
    }   
    	       
	public String getParameter(String parameter) {   
    	 String value = super.getParameter(parameter);   
    	 if (value == null) {   
    	     return null;    
    	 }   
    	 return hTMLEncode(value);   
    }   
    
	@Override
	public Cookie[] getCookies() {
        Cookie[] cookies = super.getCookies();
        for (int i=0;i<cookies.length;i++){
            String value = cookies[i].getValue();
            String newValue = hTMLEncode(value);
            if (!newValue.equals(value))
            {
                cookies[i].setValue(newValue);
            }
        }
        return cookies;
    } 
  
    public String hTMLEncode(String input){
    	String s = input;
    	s = s.replaceAll("\\\"","&quot;");
    	s = s.replaceAll("'", "&#039;"); 
    	s = s.replaceAll("\\\\", "&#092;");
    	return s;
	}
}  
