package com.cat.bap.common;

import java.util.List;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose
 */
public class BrandAdvocateException extends RuntimeException {

//  private final String errorCode;

  private final String msg;

//  private final transient List<RejectValues> rejectValues;

  private static final long serialVersionUID = -7965026482000560956L;

  public BrandAdvocateException(String errorCode, String msg, List<RejectValues> rejectValues) {
    super();
//    this.errorCode = errorCode;
    this.msg = msg;
//    this.rejectValues = rejectValues;
  }
  
  public BrandAdvocateException(String msg) {
	  super();
//	  this.errorCode = errorCode;
	  this.msg = msg;
//	  this.rejectValues = rejectValues;
  }

  public BrandAdvocateException(String msg, Throwable cause) {
	  super(cause);
	  this.msg = msg;
}

/*public List<RejectValues> getRejectValues() {
    return rejectValues;
  }

  public String getErrorCode() {
    return errorCode;
  }*/

  public String getMsg() {
    return msg;
  }

}
