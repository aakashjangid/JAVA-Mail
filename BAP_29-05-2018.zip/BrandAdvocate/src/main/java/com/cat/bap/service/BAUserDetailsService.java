package com.cat.bap.service;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.velocity.exception.VelocityException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.cat.bap.common.BrandAdvocateConstant;
import com.cat.bap.common.BrandAdvocateException;
import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CalendarRequest;
import com.cat.bap.dto.MailRequest;
import com.cat.bap.dto.UserMasterRequest;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.Country;
import com.cat.bap.entity.Documents;
import com.cat.bap.entity.Invitation;
import com.cat.bap.entity.Preferences;
import com.cat.bap.entity.Templates;
import com.cat.bap.helper.UserMasterHelper;
import com.cat.bap.repository.BAUserDetailsRepositoryCustom;
import com.cat.bap.repository.CountryRepository;
import com.cat.bap.repository.InvitationRepository;
import com.cat.bap.repository.TemplatesRepository;
import com.cat.bap.util.BrandAdvocateCalendarUtility;
import com.cat.bap.util.BrandAdvocateEmailUtility;
import com.cat.bap.util.BrandAdvocateUtility;
import com.cat.bap.util.ExportToExcelUtilityForFindOtherBA;
import com.cat.bap.util.ExportToExcelUtilityForUserMaster;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import cat.cis.tuf.common.email.EMailException;

/**
 * @author ratnak1
 * @date 13-Feb-2018
 * @purpose This class is used as application service for manage admin.
 */
@Service
public class BAUserDetailsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(BAUserDetailsService.class);

	@Inject
	private Environment environment;

	@Inject
	private BAUserDetailsDomainService manageAdminDomainService;

	@Inject
	private UserPreferencesDomainService userPreferencesAccessDomainService;

	@Inject
	private BrandAdvocateEmailUtility brandAdvocateEmailUtility;

	@Inject
	private BrandAdvocateCalendarUtility brandAdvocateCalendarUtility;

	@Inject
	private BAUserDetailsRepositoryCustom bAUserDetailsRepositoryCustom;

	@Inject
	private TemplatesRepository templatesRepository;
	
	@Inject
	private InvitationRepository invitationRepository;

	@Inject
	private CountryRepository countryRepository;
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmm'00'");
	SimpleDateFormat dateParser = new SimpleDateFormat("dd-MM-yyyy HH:mm");
	SimpleDateFormat dateFormater = new SimpleDateFormat("dd-MM-yyyy");

	public Map<String, Object> getAllBAUsersDetailsFromJson(String manageAdminRequest) {

		Gson gson = new Gson();
		return this.getAllBAUserDetails(gson.fromJson(manageAdminRequest, UserMasterRequest.class));
	}

	public Map<String, Object> getAllBAUserDetails(UserMasterRequest manageAdminRequest) {
		return manageAdminDomainService.getAllAdminDetails(manageAdminRequest);
	}

	public Map<String, Object> getBAUserDetailsById(Long brandAdvocateId) {
		Map<String, Object> map = new HashMap<>();
		BAUserDetailsDto userMasterDto = UserMasterHelper
				.convertEntityToDto(manageAdminDomainService.findRecordBasedOnId(brandAdvocateId));
		List<Preferences> preferences = userPreferencesAccessDomainService.getPreferencesDetailsById(brandAdvocateId);
		userMasterDto.setPreferences(preferences);
		map.put(UserMasterConstant.MANAGE_ADMIN_DETAILS_DTO, userMasterDto);
		return map;
	}

	public BAUserDetailsDto getBAUserDetailsObjectById(Long brandAdvocateId) {

		BAUserDetailsDto userMasterDto = UserMasterHelper
				.convertEntityToDto(manageAdminDomainService.findRecordBasedOnId(brandAdvocateId));
		List<Preferences> preferences = userPreferencesAccessDomainService.getPreferencesDetailsById(brandAdvocateId);
		userMasterDto.setPreferences(preferences);

		return userMasterDto;
	}

	public Map<String, Object> addOrUpdateUserInformation(BAUserDetailsDto userMasterDto) throws ParseException {
		userMasterDto.setIsActive(Boolean.TRUE);
		Map<String, Object> responseMap = new HashMap<>();
		BAUserDetailsDto userMasterDto2 = UserMasterHelper
				.convertEntityToDto(manageAdminDomainService.addOrUpdateAdminDetails(userMasterDto));
		responseMap.put(UserMasterConstant.MANAGE_ADMIN_DETAILS_DTO, userMasterDto2);
		return responseMap;
	}

	public void addNotes(BAUserDetailsDto userMasterDto) {
		manageAdminDomainService.addNotes(userMasterDto);
	}

	public void addCommentsQuestions(BAUserDetailsDto userMasterDto) {
		manageAdminDomainService.addCommentsQuestions(userMasterDto);
	}

	public void changeActiveStatus(Long brandAdvocateId,Boolean activeStatus,BAUserDetailsDto bauserDetailDto) throws SQLException, EMailException, IOException {
		
		boolean isUpdated = manageAdminDomainService.changeActiveStatus(brandAdvocateId, activeStatus);

		String userPrimaryEmail = (null != bauserDetailDto.getPrimaryEmail()
				&& !bauserDetailDto.getPrimaryEmail().equals("")) ? bauserDetailDto.getPrimaryEmail() : "";
		String userSecondaryEmail = (null != bauserDetailDto.getSecondaryEmail()
				&& !bauserDetailDto.getSecondaryEmail().equals("")) ? bauserDetailDto.getSecondaryEmail() : "";

		String userEmail = !userPrimaryEmail.equals("") ? userPrimaryEmail : userSecondaryEmail;

		if (isUpdated) {
			new Thread(() -> 
			{
					brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL,
							BrandAdvocateConstant.SUBJECT_INACTIVE_NOTIFICATION,
							BrandAdvocateConstant.MSGBODY_INACTIVE_NOTIFICATION.concat(userEmail),
							bauserDetailDto.getFirstName(), bauserDetailDto.getLastName(),
							BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
			}).start();
		}
	}
	@Transactional(readOnly = true)
	public void generateXLSFromJson(HttpServletResponse response, String manageAdminRequest, HttpHeaders requestHeader)
			throws IOException, ParseException, NoSuchFieldException {
		Gson gson = new Gson();
		UserMasterRequest adminRequest = gson.fromJson(manageAdminRequest, UserMasterRequest.class);
		this.generateXLS(response, adminRequest, requestHeader);
	}

	@Transactional(readOnly = true)
	public void generateXLSFromJsonForFindOtherBa(HttpServletResponse response, String manageAdminRequest,
			HttpHeaders requestHeader) throws IOException, ParseException, SecurityException, NoSuchFieldException {
		Gson gson = new Gson();
		UserMasterRequest adminRequest = gson.fromJson(manageAdminRequest, UserMasterRequest.class);
		this.generateXLSForFindOtherBa(response, adminRequest, requestHeader);
	}

	@Transactional(readOnly = true)
	public void generateXLS(HttpServletResponse response, UserMasterRequest manageAdminRequest,
			HttpHeaders requestHeader) throws IOException, ParseException, SecurityException, NoSuchFieldException {
		XSSFWorkbook aXSSFWorkbook = exportToExcel(manageAdminRequest, manageAdminRequest.getLang(),
				BrandAdvocateUtility.getCookieFromHeader(requestHeader,
						environment.getProperty("app.sessionIdentifier")));
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=BrandAdvocateDetails_"
				+ BrandAdvocateUtility.getDateStringByDateFormat(UserMasterConstant.FORMATE_2) + ".xlsx");
		aXSSFWorkbook.write(response.getOutputStream());
		response.getOutputStream().close();
	}

	@Transactional(readOnly = true)
	public void generateXLSForFindOtherBa(HttpServletResponse response, UserMasterRequest manageAdminRequest,
			HttpHeaders requestHeader) throws IOException, ParseException, SecurityException, NoSuchFieldException {
		XSSFWorkbook aXSSFWorkbook = exportToExcelForFindOtherBa(manageAdminRequest, manageAdminRequest.getLang(),
				BrandAdvocateUtility.getCookieFromHeader(requestHeader,
						environment.getProperty("app.sessionIdentifier")));
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		response.setHeader("Content-Disposition", "attachment; filename=BrandAdvocateDetails_"
				+ BrandAdvocateUtility.getDateStringByDateFormat(UserMasterConstant.FORMATE_2) + ".xlsx");
		aXSSFWorkbook.write(response.getOutputStream());
		response.getOutputStream().close();
	}

	@Transactional(readOnly = true)
	public XSSFWorkbook exportToExcel(UserMasterRequest manageAdminRequest, String lang, String cookieValue)
			throws IOException {

		List<BAUserDetailsDto> userMasterDTOs = manageAdminRequest.getSelectedRecordsListForExportToExcel();
		ExportToExcelUtilityForUserMaster excelUtilityForUserMaster = new ExportToExcelUtilityForUserMaster();
		return excelUtilityForUserMaster.generateExcel(userMasterDTOs, lang);
	}

	@Transactional(readOnly = true)
	public XSSFWorkbook exportToExcelForFindOtherBa(UserMasterRequest manageAdminRequest, String lang,
			String cookieValue) throws IOException{

		List<BAUserDetailsDto> userMasterDTOs = manageAdminRequest.getSelectedRecordsListForExportToExcel();
		ExportToExcelUtilityForFindOtherBA excelUtilityForFindOtherBA = new ExportToExcelUtilityForFindOtherBA();
		return excelUtilityForFindOtherBA.generateExcel(userMasterDTOs, lang);
	}

	public void sendMailFromJsonData(MultipartHttpServletRequest request, HttpHeaders requestHeader, String mailRequest)
			throws IOException, MessagingException,
			EMailException {

		LOGGER.debug("sendMailFromJsonData. START ");

		ObjectMapper configure = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		sendMail(request, requestHeader, configure.readValue(mailRequest, MailRequest.class));

		LOGGER.debug("sendMailFromJsonData. END ");
	}

	public void sendCalendarInviteFromJsonData(MultipartHttpServletRequest request, HttpHeaders requestHeader,
			String calendarrequest) throws JsonParseException, JsonMappingException, IOException, ParseException {

		ObjectMapper configure = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		sendCalendarInvite(request, requestHeader, configure.readValue(calendarrequest, CalendarRequest.class));
	}

	public void sendMail(MultipartHttpServletRequest request, HttpHeaders requestHeader, MailRequest mailRequest)
			throws IOException, MessagingException, EMailException {

		Boolean isAttachment = Boolean.FALSE;

		if (null != request) {
			Iterator<String> fileNames = request.getFileNames();
			String commonDirPath = environment.getProperty("app.commonFilePath");
			File dir = new File(commonDirPath + "/massmail/");
			if (dir.exists()) {
				LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + "UserMasterApplicationService's sendMail method "
						+ BrandAdvocateConstant.DIRECTORY_EXIST);
			} else {
				Boolean dirCreated = dir.mkdirs();
				if (dirCreated) {
					LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + "UserMasterApplicationService's sendMail method "
							+ BrandAdvocateConstant.DIRECTORY_CREATED);
				} else {
					LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + "UserMasterApplicationService's sendMail method "
							+ BrandAdvocateConstant.DIRECTORY_NOT_CREATED);
				}
			}

			List<Documents> documents = mailRequest.getDocumentsList();
			if (null != documents && !documents.isEmpty()) {
				isAttachment = Boolean.TRUE;
				for (Documents document : documents) {
					copyFileUsingStream(new File(document.getDocumentPath()),
							new File(commonDirPath + "/massmail/" + document.getDocumentName()));
				}
			}

			while (fileNames.hasNext()) {
				String key = fileNames.next();
				MultipartFile mpf = request.getFile(key);
				if (mpf.getSize() > 5000000) {
					throw new BrandAdvocateException(HttpStatus.BAD_REQUEST.toString(),
							BrandAdvocateConstant.FILE_SIZE_EXCEEDS, null);
				} else {
					String fileName = commonDirPath + "/massmail//" + mpf.getOriginalFilename();
					byte[] bytes = mpf.getBytes();
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
					stream.write(bytes);
					stream.flush();
					stream.close();
				}

				String fileName = commonDirPath + "/massmail//" + mpf.getOriginalFilename();
				byte[] bytes = mpf.getBytes();
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
				isAttachment = Boolean.TRUE;
				stream.write(bytes);
				stream.flush();
				stream.close();
			}
		}

		List<BAUserDetails> baUserDetailsList = mailRequest.getBaUserDetailsList();
		String messageBody = mailRequest.getMessageBody();
		String subject = mailRequest.getSubject();

		brandAdvocateEmailUtility.sendBrandAdvocateEmail(baUserDetailsList, messageBody, subject, isAttachment);
	}

	private static void copyFileUsingStream(File source, File dest) throws IOException {
		InputStream is = null;
		OutputStream os = null;
		try {
			is = new FileInputStream(source);
			os = new FileOutputStream(dest);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
		} finally {
			is.close();
			os.close();
		}
	}

	public void sendCalendarInvite(MultipartHttpServletRequest request, HttpHeaders requestHeader,
			CalendarRequest calendarRequest) throws IOException, ParseException {

		String subjectTitle = calendarRequest.getSubject();
		String emailMessage = calendarRequest.getMessageBody();

		SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm a MM/dd/yyyy");
		Date startDate = dateFormat.parse(calendarRequest.getStartDateTime());
		String startDateTime = timeZoneToUTC(calendarRequest, startDate);

		Date endDate = dateFormat.parse(calendarRequest.getEndDateTime());
		String endDateTime = timeZoneToUTC(calendarRequest, endDate);

		String location = calendarRequest.getLocation();
		String timeZone = calendarRequest.getTimezone();

		List<BAUserDetails> baUserDetailsList = calendarRequest.getBaUserDetailsList();

		Long invitationId = calendarRequest.getInvitationId();

		/** Code to check attachment exist in Request starts */

		Boolean isAttachment = Boolean.FALSE;

		if (null != request) {
			Iterator<String> fileNames = request.getFileNames();
			String commonDirPath = environment.getProperty("app.commonFilePath");
			File dir = new File(commonDirPath + "/massmail/");
			if (dir.exists()) {
				LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + "UserMasterApplicationService's sendMail method "
						+ BrandAdvocateConstant.DIRECTORY_EXIST);
			} else {
				Boolean dirCreated = dir.mkdirs();
				if (dirCreated) {
					LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + "UserMasterApplicationService's sendMail method "
							+ BrandAdvocateConstant.DIRECTORY_CREATED);
				} else {
					LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX + "UserMasterApplicationService's sendMail method "
							+ BrandAdvocateConstant.DIRECTORY_NOT_CREATED);
				}
			}

			while (fileNames.hasNext()) {
				String key = fileNames.next();
				MultipartFile mpf = request.getFile(key);
				if (mpf.getSize() > 5000000) {
					throw new BrandAdvocateException(HttpStatus.BAD_REQUEST.toString(),
							BrandAdvocateConstant.FILE_SIZE_EXCEEDS, null);
				} else {
					String fileName = commonDirPath + "/massmail//" + mpf.getOriginalFilename();
					byte[] bytes = mpf.getBytes();
					BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
					isAttachment = Boolean.TRUE;
					stream.write(bytes);
					stream.flush();
					stream.close();
				}
			}
		}
		/** Code to check attachment exist in Request ends */
		
		Long id = null;
		if (invitationId != null) {
			id = invitationId;
		}
		
		/** code to save tinyMce template Data Start */
		String commonDirPath = environment.getProperty("app.commonFilePath");
		String fileName;
		File dir = new File(commonDirPath + "/invitation-content");
		if (!dir.exists()) {
			dir.mkdirs();
		}
		fileName = commonDirPath + "/invitation-content/" + Math.random();
		byte[] bytes = emailMessage.getBytes();
		BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		stream.write(bytes);
		stream.close();
		/** code to save tinyMce template Data end */

		brandAdvocateCalendarUtility.prepareCalendarInviteToSend(baUserDetailsList, subjectTitle, fileName,
				startDateTime, endDateTime, location, isAttachment, timeZone, startDate, endDate, id);
	}

	public BAUserDetailsDto checkBAExistInPortal(BAUserDetailsDto baUserDetailDto) {
		BAUserDetailsDto baUserDetail = null != manageAdminDomainService.findBADetails(baUserDetailDto)
				? UserMasterHelper.convertEntityToDto(manageAdminDomainService.findBADetails(baUserDetailDto)) : null;

		/*
		 * List<Preferences> preferences =
		 * userPreferencesAccessDomainService.getPreferencesDetailsById(
		 * baUserDetail.getBrandAdvocateId());
		 * baUserDetail.setPreferences(preferences);
		 */

		return baUserDetail;
	}

	/*
	 * public Map<String, Object> getBAUserDetailsBasedOnCwsIdOrEmailId(String
	 * cwsUserId, String emailId) {
	 * 
	 * LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX +
	 * "BAUserDetailsService getBAUserDetailsBasedOnCwsIdOrEmailId method. >> TimeStamp:"
	 * + System.currentTimeMillis() +
	 * " >> getBAUserDetailsBasedOnCwsIdOrEmailId:" + cwsUserId + emailId);
	 * return
	 * bAUserDetailsRepositoryCustom.getBAUserDetailsBasedOnCwsIdOrEmailId(
	 * cwsUserId, emailId); }
	 */

	public Map<String, Object> getBAUserDetailsBasedOnIds(String cwsUserId, String emailId, String cupId) {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "BAUserDetailsService getBAUserDetailsBasedOnIds method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getBAUserDetailsBasedOnIds:" + cwsUserId + emailId + cupId);
		return bAUserDetailsRepositoryCustom.getBAUserDetailsBasedOnIds(cwsUserId, emailId, cupId);
	}

	/**
	 * @param cupId
	 * @return
	 * @throws SQLException
	 */
	public Map<String, Object> getBAUserDetailsByCupId(String cupId) throws SQLException {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "BAUserDetailsService getBAUserDetailsByCupId method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getBAUserDetailsByCupId:" + cupId);

		return bAUserDetailsRepositoryCustom.getBAUserDetailsByCupId(cupId);
	}

	public Map<String, Object> getBAUserDetailsByCwsUserId(String cwsUserId) throws SQLException {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "BAUserDetailsService getBAUserDetailsByCwsUserId method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getBAUserDetailsByCwsUserId:" + cwsUserId);

		return bAUserDetailsRepositoryCustom.getBAUserDetailsByCwsUserId(cwsUserId);
	}

	public Map<String, Object> getBAUserDetailsByEmailId(String emailId) throws SQLException {

		LOGGER.info(BrandAdvocateConstant.LOGGER_PREFIX
				+ "BAUserDetailsService getBAUserDetailsByEmailId method. >> TimeStamp:" + System.currentTimeMillis()
				+ " >> getBAUserDetailsByEmailId:" + emailId);

		return bAUserDetailsRepositoryCustom.getBAUserDetailsByEmailId(emailId);
	}

	public void updateSecondaryMail(BAUserDetailsDto userMasterDto) throws ParseException {
		manageAdminDomainService.updateSecondaryMail(userMasterDto);
	}

	public void deleteUserInfo(Long brandAdvocateId) {
		manageAdminDomainService.deleteUserInfo(brandAdvocateId);
	}

	@Transactional
	public void saveMailTemplateData(MultipartHttpServletRequest multipartHttpServletRequest, HttpHeaders requestHeader,
			String templateRequest, String subject, String templateName) throws IOException {

		/** code to save files Start */
		BrandAdvocateUtility advocateUtility = new BrandAdvocateUtility();
		String commonDirPath;
		List<Documents> docList;
		commonDirPath = environment.getProperty("app.commonFilePath");
		// List<Documents> documents = new ArrayList<>();
		List<Documents> previousDocumentsList = new ArrayList<>();
		docList = advocateUtility.uploadDocument(multipartHttpServletRequest,
				commonDirPath + "/template-attachment-images/", templateName, previousDocumentsList);
		/*
		 * if (null != docList && !docList.isEmpty()) { documents =
		 * manageAdminDomainService.saveDocument(docList); }
		 */
		/** code to save files end */

		/** code to save tinyMce template Data Start */
		Templates templates = new Templates();
		String fileName;
		File dir = new File(commonDirPath + "/templates");
		if (!dir.exists()) {
			dir.mkdirs();
		}
		fileName = commonDirPath + "/templates/" + templateName;
		byte[] bytes = templateRequest.getBytes();
		BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		stream.write(bytes);
		stream.close();
		String fname = fileName.replace(commonDirPath + "/templates/", "");
		templates.setTemplateName(fname);
		templates.setTemplatePath(fileName);
		templates.setTemplateSubject(subject);
		if (null != docList && !docList.isEmpty()) {
			templates.setDocuments(docList);
		}
		/*
		 * for(Documents document : documents){ Templates templates2 = new
		 * Templates(); documents.add(document);
		 * templates2.setDocuments(documents); }
		 */

		manageAdminDomainService.saveTinyMceTemplate(templates);
		/** code to save tinyMce template Data end */

	}

	public Map<String, Object> getAllTemplates() {
		Map<String, Object> map = new HashMap<>();
		List<Templates> responseList = new ArrayList<>();
		List<Templates> templatesList = manageAdminDomainService.getAllTemplates();
		for (Templates template : templatesList) {
			Templates templates = new Templates();
			templates.setTemplateId(template.getTemplateId());
			templates.setTemplateName(template.getTemplateName());
			responseList.add(templates);
		}
		map.put(UserMasterConstant.LIST, responseList);
		return map;
	}

	public Map<String, Object> getTemplateDetailsByTemplateId(Long templateId, HttpServletResponse response)
			throws IOException {
		Map<String, Object> responseMap = new HashMap<>();

		Templates templateDetails = manageAdminDomainService.getTemplateDetailsByTemplateId(templateId);

		String content = "";
		try {
			BufferedReader in = new BufferedReader(new FileReader(templateDetails.getTemplatePath()));
			String str;
			while ((str = in.readLine()) != null) {
				content += str;
			}
			in.close();
		} catch (IOException e) {
		}

		// for(Documents document : templateDetails.getDocuments()){
		/*
		 * response.setContentType("application/octet-stream");
		 * response.setHeader("Content-Disposition",
		 * "attachment;filename="+document.getDocumentName());
		 */

		/*
		 * File file = new File(document.getDocumentPath()); FileInputStream
		 * fileIn = new FileInputStream(file);
		 */
		/*
		 * ServletOutputStream out = response.getOutputStream();
		 * 
		 * byte[] outputByte = new byte[(int)file.length()]; //copy binary
		 * contect to output stream while(fileIn.read(outputByte, 0,
		 * (int)file.length()) != -1) { out.write(outputByte, 0,
		 * (int)file.length()); }
		 */
		// responseMap.put(UserMasterConstant.DOCUMENTS, file);
		// }

		responseMap.put(UserMasterConstant.CONTENT, content);
		responseMap.put(UserMasterConstant.DOCUMENTS, templateDetails.getDocuments());
		responseMap.put(UserMasterConstant.SUBJECT, templateDetails.getTemplateSubject());
		return responseMap;
	}

	public List<BAUserDetailsDto> getMailIdListByBaIdFromJson(String manageAdminRequest) {
		Gson gson = new Gson();
		UserMasterRequest userMasterRequest = gson.fromJson(manageAdminRequest, UserMasterRequest.class);
		return bAUserDetailsRepositoryCustom.getMailIdListByBaId(userMasterRequest);
	}

	public Map<String, List<?>> getInitialDataForFindBA() {
		Map<String, List<?>> map = new HashMap<>();
		map.put(UserMasterConstant.USER_NAME_LIST, manageAdminDomainService.getDbUserNameByPreferenceForFindBA());
		map.put(UserMasterConstant.ORGANIZATION_LIST,
				manageAdminDomainService.getDbOrganizationByPreferenceForFindBA());
		map.put(UserMasterConstant.REGION_LIST, manageAdminDomainService.getDbRegionByPreferenceForFindBA());
		map.put(UserMasterConstant.COUNTRY_LIST, manageAdminDomainService.getDbCountryByPreferenceForFindBA());
		return map;
	}

	public void updateMailTemplateFromJsonData(MultipartHttpServletRequest request, HttpHeaders requestHeader,
			String mailRequest) throws IOException {

		ObjectMapper configure = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		updateMailTemplateData(request, requestHeader, configure.readValue(mailRequest, MailRequest.class));

	}

	public void updateMailTemplateData(MultipartHttpServletRequest multipartHttpServletRequest,
			HttpHeaders requestHeader, MailRequest mailRequest) throws IOException {

		List<Documents> previousDocumentsList = mailRequest.getDocumentsList();
		Templates templatesData = templatesRepository.getOne(mailRequest.getTemplateId());
		String templateName = templatesData.getTemplateName();

		/** Delete old data starts */
		// templatesRepository.delete(mailRequest.getTemplateId());
		/** Delete old data ends */

		/** code to save files Start */
		BrandAdvocateUtility advocateUtility = new BrandAdvocateUtility();
		String commonDirPath;
		List<Documents> docList;
		commonDirPath = environment.getProperty("app.commonFilePath");

		/** Logic to delete old files from folders starts */
		File index = new File(commonDirPath + "/template-attachment-images/" + templateName);
		String[] entries = index.list();
		if (null != entries) {
			for (String s : entries) {
				File currentFile = new File(index.getPath(), s);
				List<Documents> documents = mailRequest.getDocumentsList();
				if (null != documents && !documents.isEmpty()) {
					for (Documents doc : documents) {
						if (!currentFile.getName().equalsIgnoreCase(doc.getDocumentName())) {
							currentFile.delete();
						}
					}
				} else {
					currentFile.delete();
				}
			}
		}
		/** Logic to delete old files from folders ends */

		docList = advocateUtility.uploadDocument(multipartHttpServletRequest,
				commonDirPath + "/template-attachment-images/", templateName, previousDocumentsList);
		/** code to save files end */

		/** code to save tinyMce template Data Start */
		Templates templates = new Templates();
		String fileName;
		File dir = new File(commonDirPath + "/templates");
		if (!dir.exists()) {
			dir.mkdirs();
		}
		fileName = commonDirPath + "/templates/" + templateName;
		byte[] bytes = mailRequest.getMessageBody().getBytes();
		BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
		stream.write(bytes);
		stream.close();
		String fname = fileName.replace(commonDirPath + "/templates/", "");
		templates.setTemplateId(mailRequest.getTemplateId());
		templates.setTemplateName(fname);
		templates.setTemplatePath(fileName);
		templates.setTemplateSubject(mailRequest.getSubject());
		if (null != docList && !docList.isEmpty()) {
			templates.setDocuments(docList);
		}

		manageAdminDomainService.saveTinyMceTemplate(templates);
		/** code to save tinyMce template Data end */

	}

	public Map<String, String> getMapOfDifference(BAUserDetailsDto bauserDetailDto, BAUserDetailsDto baUserInDB) {

		Map<String, String> mapOfFields = new HashMap<String, String>();

		// if((null!=bauserDetailDto.getSecondaryEmail() &&
		// null!=baUserInDB.getSecondaryEmail()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getSecondaryEmail())
				.equals(baUserInDB.getSecondaryEmail())) {
			mapOfFields.put(BrandAdvocateConstant.SECONDARYEMAIL, bauserDetailDto.getSecondaryEmail());
		}

		// if((null!=bauserDetailDto.getBuildingName() &&
		// null!=baUserInDB.getBuildingName()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getBuildingName())
				.equals(baUserInDB.getBuildingName())) {
			mapOfFields.put(BrandAdvocateConstant.BUILDING, bauserDetailDto.getBuildingName());
		}

		// if((null!=bauserDetailDto.getJobKeywords() &&
		// null!=baUserInDB.getJobKeywords()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getJobKeywords())
				.equals(baUserInDB.getJobKeywords())) {
			mapOfFields.put(BrandAdvocateConstant.JOBKEYWORD, bauserDetailDto.getJobKeywords());
		}

		/*
		 * if((null!=bauserDetailDto.getComments() &&
		 * null!=baUserInDB.getComments()) &&
		 * !bauserDetailDto.getComments().equals(baUserInDB.getComments())){
		 * 
		 * String differenceComment =
		 * StringUtils.difference(baUserInDB.getComments(),
		 * bauserDetailDto.getComments());
		 * mapOfFields.put(BrandAdvocateConstant.COMMENTS,
		 * differenceComment.length()>1 ? differenceComment.substring(1) : "");
		 * }
		 */

		// if((null!=bauserDetailDto.getComments() &&
		// null!=baUserInDB.getComments()) &&
		// !bauserDetailDto.getComments().equals(baUserInDB.getComments())){
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getComments()).equals(baUserInDB.getComments())) {

			if (null != bauserDetailDto.getIsAdmin() && bauserDetailDto.getIsAdmin()) {
				mapOfFields.put(BrandAdvocateConstant.COMMENTS, bauserDetailDto.getComments());
			} else {
				if(!"".equals(BrandAdvocateUtility.getEmptyOrNotNull(baUserInDB.getComments()))){
					String differenceComment = StringUtils.difference(baUserInDB.getComments(),
							bauserDetailDto.getComments());
					mapOfFields.put(BrandAdvocateConstant.COMMENTS,
							differenceComment.length() > 1 ? differenceComment.substring(1) : "");
				} else {
					mapOfFields.put(BrandAdvocateConstant.COMMENTS, bauserDetailDto.getComments());
				}
			}
		}

		// if((null!=bauserDetailDto.getNotes() && null!=baUserInDB.getNotes())
		// &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getNotes()).equals(baUserInDB.getNotes())) {
			mapOfFields.put(BrandAdvocateConstant.NOTES, bauserDetailDto.getNotes());
		}

		// if((null!=bauserDetailDto.getBrandAdvocateStatus() &&
		// null!=baUserInDB.getBrandAdvocateStatus()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getBrandAdvocateStatus())
				.equals(baUserInDB.getBrandAdvocateStatus())) {
			mapOfFields.put(BrandAdvocateConstant.BASTATUS, bauserDetailDto.getBrandAdvocateStatus());
		}

		if ((null != bauserDetailDto.getPreferences() && null != baUserInDB.getPreferences())
				&& bauserDetailDto.getPreferences().size() != baUserInDB.getPreferences().size()) {
			mapOfFields.put(BrandAdvocateConstant.SUBS_PREF, "true");
		}

		/** Compare First Name **/
		// if((null!=bauserDetailDto.getFirstName() &&
		// null!=baUserInDB.getFirstName()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getFirstName()).equals(baUserInDB.getFirstName())) {
			mapOfFields.put(BrandAdvocateConstant.FIRST_NAME, bauserDetailDto.getFirstName());
		}
		/** Compare Last Name **/
		// if((null!=bauserDetailDto.getLastName() &&
		// null!=baUserInDB.getLastName()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getLastName()).equals(baUserInDB.getLastName())) {
			mapOfFields.put(BrandAdvocateConstant.LAST_NAME, bauserDetailDto.getLastName());
		}

		/** Compare Preferred Name **/
		// if((null!=bauserDetailDto.getPreferredFirstName() &&
		// null!=baUserInDB.getPreferredFirstName()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getPreferredFirstName())
				.equals(baUserInDB.getPreferredFirstName())) {
			mapOfFields.put(BrandAdvocateConstant.PREF_NAME, bauserDetailDto.getPreferredFirstName());
		}

		/** Compare Organization/Division **/
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getOrganizationName())
				.equals(baUserInDB.getOrganizationName())) {
			mapOfFields.put(BrandAdvocateConstant.ORG_NAME, bauserDetailDto.getOrganizationName());
		}

		/** Compare Primary email **/
		// if((null!=bauserDetailDto.getPrimaryEmail() &&
		// null!=baUserInDB.getPrimaryEmail()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getPrimaryEmail())
				.equals(baUserInDB.getPrimaryEmail())) {
			mapOfFields.put(BrandAdvocateConstant.PRIMARY_EMAIL, bauserDetailDto.getPrimaryEmail());
		}

		/** Compare Region **/
		// if((null!=bauserDetailDto.getRegionName() &&
		// null!=baUserInDB.getRegionName()) &&
		Country countryDetails = countryRepository.getCountryByCountryId(bauserDetailDto.getCountryId());
		Country countryDetailsOld = countryRepository.getCountryByCountryId(baUserInDB.getCountryId());
		
//		if(!countryDetails.getCountryId().equals(baUserInDB.getCountryId())){
		if(!countryDetails.getRegion().getRegionName().equals(countryDetailsOld.getRegion().getRegionName())){
			
			//countryDetails = countryRepository.getCountryByCountryId(bauserDetailDto.getCountryId());

			mapOfFields.put(BrandAdvocateConstant.REGION_NAME, countryDetails.getRegion().getRegionName());
			mapOfFields.put(BrandAdvocateConstant.COUNTRY_NAME, countryDetails.getCountryName());
		} else
		/** Compare Country **/
		if ((null != bauserDetailDto.getCountryId() && null != baUserInDB.getCountryId())
				&& !bauserDetailDto.getCountryId().equals(baUserInDB.getCountryId())) {

			//Country countryDetails = countryRepository.getCountryByCountryId(bauserDetailDto.getCountryId());
			mapOfFields.put(BrandAdvocateConstant.COUNTRY_NAME, countryDetails.getCountryName());

			if ((null != bauserDetailDto.getRegionName() && null != baUserInDB.getRegionName())
					&& !bauserDetailDto.getRegionName().equals(baUserInDB.getRegionName())) {
				mapOfFields.put(BrandAdvocateConstant.REGION_NAME, countryDetails.getRegion().getRegionName());
			}
		}

		/** Compare Facility **/
		// if((null!=bauserDetailDto.getFacilityName() &&
		// null!=baUserInDB.getFacilityName()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getFacilityName())
				.equals(baUserInDB.getFacilityName())) {
			mapOfFields.put(BrandAdvocateConstant.FACILITY_NAME, bauserDetailDto.getFacilityName());
		}

		/** Compare Affiliation **/
		// if((null!=bauserDetailDto.getMappedAffiliationName() &&
		// null!=baUserInDB.getMappedAffiliationName()) &&
		if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getMappedAffiliationName())
				.equals(baUserInDB.getMappedAffiliationName())) {
			mapOfFields.put(BrandAdvocateConstant.AFFILIATION_NAME, bauserDetailDto.getMappedAffiliationName());
		}

		return mapOfFields;
	}

	/*
	 * public Map<String, Boolean> sendEmailFromGrid(List<BAUserDetailsDto>
	 * baUserDetailsDtos) throws EMailException, IOException { Map<String,
	 * Boolean> map = new HashMap<>(); Boolean response; for (BAUserDetailsDto
	 * baUserDetailsDto : baUserDetailsDtos) { // response =
	 * brandAdvocateEmailUtility.sendMail(emailToSend, subject, messageBody,
	 * firstName, lastName, vmTemplate);
	 * 
	 * if((null!=baUserDetailsDto.getPrimaryEmail() &&
	 * !baUserDetailsDto.getPrimaryEmail().equals(""))){ response =
	 * brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.
	 * USER_TESTER_EMAIL, "Runtime subject", "Runtime body",
	 * baUserDetailsDto.getFirstName(), baUserDetailsDto.getLastName(),
	 * BrandAdvocateConstant.MASS_EMAIL_TEMPLATE); }else
	 * if((null!=baUserDetailsDto.getSecondaryEmail()) &&
	 * !baUserDetailsDto.getSecondaryEmail().equals("")){ response =
	 * brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.
	 * USER_TESTER_EMAIL, "Runtime subject", "Runtime body",
	 * baUserDetailsDto.getFirstName(), baUserDetailsDto.getLastName(),
	 * BrandAdvocateConstant.MASS_EMAIL_TEMPLATE); }
	 * 
	 * } map.put("", response); return map; }
	 */
	private String timeZoneToUTC(CalendarRequest calendarRequest, Date date) {
		ZoneId zone = ZoneId.of(calendarRequest.getTimezone());

		System.out.println(date);

		String date1 = dateParser.format(date);

		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm").withZone(zone);

		ZonedDateTime utc = ZonedDateTime.parse(date1, fmt).withZoneSameInstant(ZoneId.of("UTC"));

		System.out.println("+++++++++++++++++++++" + utc);

		Timestamp sqlTs = Timestamp.valueOf(utc.toLocalDateTime());

		return dateFormat.format(sqlTs);
	}

	public List<Invitation> getAllCalendarInvitations() {
		return invitationRepository.findAll();
	}
	
	public Invitation getCalendarInvitationById(Long id) {
		Invitation invitation =  invitationRepository.findOne(id);
		String content = "";
		try {
			BufferedReader in = new BufferedReader(new FileReader(invitation.getDescription()));
			String str;
			while ((str = in.readLine()) != null) {
				content += str;
			}
			in.close();
		} catch (IOException e) {
		}
		invitation.setDescription(content);
		return invitation;
	}

public Map<String, String> getMapOfCommentDifference(BAUserDetailsDto bauserDetailDto, BAUserDetailsDto baUserInDB) {
		
	Map<String, String> mapOfFields = new HashMap<String, String>();
	
	if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getComments()).equals(baUserInDB.getComments())) {
		
		if (null != bauserDetailDto.getIsAdmin() && bauserDetailDto.getIsAdmin()) {
			mapOfFields.put(BrandAdvocateConstant.COMMENTS, bauserDetailDto.getComments());
		} else {
			if(!"".equals(BrandAdvocateUtility.getEmptyOrNotNull(baUserInDB.getComments()))){
				String differenceComment = StringUtils.difference(baUserInDB.getComments(),
						bauserDetailDto.getComments());
				mapOfFields.put(BrandAdvocateConstant.COMMENTS,
						differenceComment.length() > 1 ? differenceComment.substring(1) : "");
			} else {
				mapOfFields.put(BrandAdvocateConstant.COMMENTS, bauserDetailDto.getComments());
			}
		}
	}
	
	return mapOfFields;
}
}
