package com.cat.bap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rohan.rathore
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rohan.rathore@yash.com
 * @date 20-Mar-2018
 * @purpose This class is used as dto for manage admin details.
 */
@Entity
@Table(name = "preferences_tbl")
public class Preferences {

	@Id
	@Column(name = "preference_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long preferenceId;

	@Column(name = "preference_name")
	private String preferenceName;

	/**
	 * @return the preferenceId
	 */
	public Long getPreferenceId() {
		return preferenceId;
	}

	/**
	 * @param preferenceId
	 *            the preferenceId to set
	 */
	public void setPreferenceId(Long preferenceId) {
		this.preferenceId = preferenceId;
	}

	/**
	 * @return the preferenceName
	 */
	public String getPreferenceName() {
		return preferenceName;
	}

	/**
	 * @param preferenceName
	 *            the preferenceName to set
	 */
	public void setPreferenceName(String preferenceName) {
		this.preferenceName = preferenceName;
	}

}
