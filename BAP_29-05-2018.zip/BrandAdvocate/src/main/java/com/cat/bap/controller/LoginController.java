package com.cat.bap.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose This class is used as login controller.
 */
@RestController
public class LoginController {

  @RequestMapping(value = "/login", method = RequestMethod.GET)
  @ResponseBody
  public ModelAndView login() {
	    
    return new ModelAndView("index");
  }

}
