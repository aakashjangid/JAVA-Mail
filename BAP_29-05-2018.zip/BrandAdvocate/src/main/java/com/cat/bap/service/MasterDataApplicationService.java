package com.cat.bap.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BARegistrationViaDto;
import com.cat.bap.dto.CountryDto;
import com.cat.bap.dto.PreferenceDto;
import com.cat.bap.dto.RegionDto;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 23-Feb-2018
 * @purpose
 */
@Service
public class MasterDataApplicationService {

	@Inject
	private MasterDataDomainService masterDataDomainService;

	@Transactional
	public Map<String, Object> getAllCountries() {
		Map<String, Object> countryMap = new HashMap<>();
		List<CountryDto> countriesDtoList = masterDataDomainService.getAllCountries();
		countryMap.put(UserMasterConstant.LIST, countriesDtoList);
		return countryMap;
	}

	@Transactional
	public Map<String, Object> getAllRegions() {
		Map<String, Object> regionMap = new HashMap<>();
		List<RegionDto> regionDtoList = masterDataDomainService.getAllRegions();
		regionMap.put(UserMasterConstant.LIST, regionDtoList);
		return regionMap;
	}

	@Transactional
	public Map<String, Object> getAllPreferences() {
		Map<String, Object> preferenceMap = new HashMap<>();
		List<PreferenceDto> preferenceDtoList = masterDataDomainService.getAllPreferences();
		preferenceMap.put(UserMasterConstant.LIST, preferenceDtoList);
		return preferenceMap;
	}

	@Transactional
	public Map<String, Object> getRegionsByCountryId(Long countryId) {
		Map<String, Object> regionMap = new HashMap<>();
		List<RegionDto> regionDtos = masterDataDomainService.getRegionsByCountryId(countryId);
		regionMap.put(UserMasterConstant.LIST, regionDtos);
		return regionMap;
	}

	@Transactional
	public Map<String, Object> getCountriesByRegionId(Long regionId) {
		Map<String, Object> countryMap = new HashMap<>();
		List<CountryDto> countryDtos = masterDataDomainService.getCountriesByRegionId(regionId);
		countryMap.put(UserMasterConstant.LIST, countryDtos);
		return countryMap;
	}
	
	@Transactional
	public Map<String, Object> getListRegistrationReason() {
		Map<String, Object> countryMap = new HashMap<>();
		List<BARegistrationViaDto> regReasonDto = masterDataDomainService.getListRegistrationReason();
		countryMap.put(UserMasterConstant.LIST, regReasonDto);
		return countryMap;
	}

	public Map<String, List<String>> getAllAffiliationNameUI() {
		Map<String, List<String>> affNameUIMap = new HashMap<>();
		List<String> affDescriptionList = masterDataDomainService.getAllAffiliationNameUI();
		affNameUIMap.put(UserMasterConstant.LIST, affDescriptionList);
		return affNameUIMap;
	}
	
	

}
