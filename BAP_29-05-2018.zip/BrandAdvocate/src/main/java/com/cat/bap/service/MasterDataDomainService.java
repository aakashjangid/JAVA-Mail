package com.cat.bap.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cat.bap.dto.BARegistrationViaDto;
import com.cat.bap.dto.CountryDto;
import com.cat.bap.dto.PreferenceDto;
import com.cat.bap.dto.RegionDto;
import com.cat.bap.entity.Country;
import com.cat.bap.helper.MasterDataHelper;
import com.cat.bap.repository.AffilationDescRepository;
import com.cat.bap.repository.BARegistrationViaRepository;
import com.cat.bap.repository.CountryRepository;
import com.cat.bap.repository.PreferenceRepository;
import com.cat.bap.repository.RegionRepository;

/**
 * @author rohan.rathore
 * @email rohan.rathore@yash.com
 * @date 21-Mar-2018
 * @purpose
 */
@Service
public class MasterDataDomainService {

	@Inject
	private CountryRepository countryRepository;
	@Inject
	private RegionRepository regionRepository;
	@Inject
	private PreferenceRepository preferenceRepository;
	@Inject
	private BARegistrationViaRepository regReasonRepository;
	@Inject
	private AffilationDescRepository affilationDescRepository;

	/**
	 * @return List of Countries
	 */
	@Transactional
	public List<CountryDto> getAllCountries() {
		return MasterDataHelper.convertEntityListToDtoListForCountry(countryRepository.findAll());
	}

	/**
	 * @return List of Region
	 */
	@Transactional
	public List<RegionDto> getAllRegions() {
		return MasterDataHelper.convertEntityListToDtoListForRegion(regionRepository.findAll());
	}

	/**
	 * @return List of Preferences
	 */
	@Transactional
	public List<PreferenceDto> getAllPreferences() {
		return MasterDataHelper.convertEntityListToDtoListForPreference(preferenceRepository.findAll());
	}

	/**
	 * @param countryId
	 * @return list Region based on countryId
	 */
	@Transactional
	public List<RegionDto> getRegionsByCountryId(Long countryId) {
		return MasterDataHelper.convertEntityListToDtoListForRegion(countryRepository.getRegionsByCountryId(countryId));
	}
	
	@Transactional
	public CountryDto getCountryByCountryCode(String countryCode) {

		Country countryEntity = countryRepository.getCountryByCountryCode(countryCode);
		
		CountryDto countryDto = new CountryDto();
	    countryDto.setCountryId(countryEntity.getCountryId());
	    countryDto.setCountryName(countryEntity.getCountryName());
	    countryDto.setCountryCode(countryEntity.getCountryCode());
		
		return countryDto;
	}

	/**
	 * @param regionId
	 * @return List of Country based on regionId
	 */
	@Transactional
	public List<CountryDto> getCountriesByRegionId(Long regionId) {
		return MasterDataHelper.convertEntityListToDtoListForCountry(regionRepository.getCountriesByRegionId(regionId));
	}

	public List<BARegistrationViaDto> getListRegistrationReason() {
		return MasterDataHelper.convertEntityListToDtoListForRegistrationReason(regReasonRepository.findAll());
	}

	public List<String> getAllAffiliationNameUI() {
		List<String> affiliationNamesUIList= affilationDescRepository.getAllAffiliationNamesUI();
		return affiliationNamesUIList;
	}
}
