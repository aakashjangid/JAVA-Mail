package com.cat.bap.dto;

import java.util.Date;
import java.util.List;

import com.cat.bap.entity.Preferences;



/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose This class is used as dto for manage admin details.
 */
public class BAUserDetailsDto {

	private Long brandAdvocateId;
	private String cwsUserId;
	private String lastName;
	private String firstName;
	private String preferredFirstName;
	private String organizationName;
	private String workLocation;
	private String primaryEmail;
	private String secondaryEmail;
	private Long countryId;
	private String countryName;
	private String countryCode;
	private String facilityName;
	private String buildingName;
	private String jobKeywords;
	private String affiliationDescription;
	private String brandAdvocateStatus;
	private String comments;
	private String notes;
	private List<Preferences> preferences;
	private String registeredVia;
	private Date registrationDate;
	private String registeredBy;
	private Date modifiedDate;
	private String modifiedBy;
	private String managedBy;
	private Long regionId;
	private String regionName;
	private Boolean isActive;
	private Boolean isAdmin;
	private String cupId;
	private MasterDataDto masterDataDto;
	private String preferencesStr;
	private String loggedInUserName;
	private String customRegistrationDate;
	private String customModifiedDate;
	private String customInactiveDate;
	private String mappedAffiliationName;
	private String loggedInUserEmailId;
	

	public BAUserDetailsDto() {
		super();
	}


	public Long getBrandAdvocateId() {
		return brandAdvocateId;
	}

	public void setBrandAdvocateId(Long brandAdvocateId) {
		this.brandAdvocateId = brandAdvocateId;
	}

	public String getCwsUserId() {
		return cwsUserId;
	}

	public void setCwsUserId(String cwsUserId) {
		this.cwsUserId = cwsUserId;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getPreferredFirstName() {
		return preferredFirstName;
	}

	public void setPreferredFirstName(String preferredFirstName) {
		this.preferredFirstName = preferredFirstName;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getWorkLocation() {
		return workLocation;
	}

	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}

	public String getPrimaryEmail() {
		return primaryEmail;
	}

	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	public String getSecondaryEmail() {
		return secondaryEmail;
	}

	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getJobKeywords() {
		return jobKeywords;
	}

	public void setJobKeywords(String jobKeywords) {
		this.jobKeywords = jobKeywords;
	}

	public String getAffiliationDescription() {
		return affiliationDescription;
	}

	public void setAffiliationDescription(String affiliationDescription) {
		this.affiliationDescription = affiliationDescription;
	}

	public String getBrandAdvocateStatus() {
		return brandAdvocateStatus;
	}

	public void setBrandAdvocateStatus(String brandAdvocateStatus) {
		this.brandAdvocateStatus = brandAdvocateStatus;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public List<Preferences> getPreferences() {
		return preferences;
	}

	public void setPreferences(List<Preferences> preferences) {
		this.preferences = preferences;
	}

	public String getRegisteredVia() {
		return registeredVia;
	}

	public void setRegisteredVia(String registeredVia) {
		this.registeredVia = registeredVia;
	}

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getRegisteredBy() {
		return registeredBy;
	}

	public void setRegisteredBy(String registeredBy) {
		this.registeredBy = registeredBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getManagedBy() {
		return managedBy;
	}

	public void setManagedBy(String managedBy) {
		this.managedBy = managedBy;
	}

	public Long getRegionId() {
		return regionId;
	}

	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getCupId() {
		return cupId;
	}

	public void setCupId(String cupId) {
		this.cupId = cupId;
	}

	public MasterDataDto getMasterDataDto() {
		return masterDataDto;
	}

	public void setMasterDataDto(MasterDataDto masterDataDto) {
		this.masterDataDto = masterDataDto;
	}

	public String getPreferencesStr() {
		return preferencesStr;
	}

	public void setPreferencesStr(String preferencesStr) {
		this.preferencesStr = preferencesStr;
	}

	public String getLoggedInUserName() {
		return loggedInUserName;
	}

	public void setLoggedInUserName(String loggedInUserName) {
		this.loggedInUserName = loggedInUserName;
	}
	
	public String getCustomRegistrationDate() {
		return customRegistrationDate;
	}

	public void setCustomRegistrationDate(String customRegistrationDate) {
		this.customRegistrationDate = customRegistrationDate;
	}

	public String getCustomModifiedDate() {
		return customModifiedDate;
	}

	public void setCustomModifiedDate(String customModifiedDate) {
		this.customModifiedDate = customModifiedDate;
	}
	
	public String getCustomInactiveDate() {
		return customInactiveDate;
	}


	public void setCustomInactiveDate(String customInactiveDate) {
		this.customInactiveDate = customInactiveDate;
	}

	/**
	 * @return the mappedAffiliationName
	 */
	public String getMappedAffiliationName() {
		return mappedAffiliationName;
	}


	/**
	 * @param mappedAffiliationName the mappedAffiliationName to set
	 */
	public void setMappedAffiliationName(String mappedAffiliationName) {
		this.mappedAffiliationName = mappedAffiliationName;
	}


	public String getLoggedInUserEmailId() {
		return loggedInUserEmailId;
	}


	public void setLoggedInUserEmailId(String loggedInUserEmailId) {
		this.loggedInUserEmailId = loggedInUserEmailId;
	}


	@Override
	public String toString() {
		return "BAUserDetailsDto [brandAdvocateId=" + brandAdvocateId + ", cwsUserId=" + cwsUserId + ", lastName="
				+ lastName + ", firstName=" + firstName + ", preferredFirstName=" + preferredFirstName
				+ ", organizationName=" + organizationName + ", workLocation=" + workLocation + ", primaryEmail="
				+ primaryEmail + ", secondaryEmail=" + secondaryEmail + ", countryId=" + countryId + ", countryName="
				+ countryName + ", countryCode=" + countryCode + ", facilityName=" + facilityName + ", buildingName="
				+ buildingName + ", jobKeywords=" + jobKeywords + ", affiliationDescription=" + affiliationDescription
				+ ", brandAdvocateStatus=" + brandAdvocateStatus + ", comments=" + comments + ", notes=" + notes
				+ ", preferences=" + preferences + ", registeredVia=" + registeredVia + ", registrationDate="
				+ registrationDate + ", registeredBy=" + registeredBy + ", modifiedDate=" + modifiedDate
				+ ", modifiedBy=" + modifiedBy + ", managedBy=" + managedBy + ", regionId=" + regionId + ", regionName="
				+ regionName + ", isActive=" + isActive + ", isAdmin=" + isAdmin + ", cupId=" + cupId
				+ ", masterDataDto=" + masterDataDto + ", preferencesStr=" + preferencesStr + ", loggedInUserName="
				+ loggedInUserName + ", customRegistrationDate=" + customRegistrationDate + ", customModifiedDate="
				+ customModifiedDate + ", customInactiveDate=" + customInactiveDate + ", mappedAffiliationName="
				+ mappedAffiliationName + ", loggedInUserEmailId=" + loggedInUserEmailId + "]";
	}
	
}
