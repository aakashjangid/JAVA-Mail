package com.cat.bap.dto;

import java.util.List;

/**
 * @author rohan.rathore
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rohan.rathore@yash.com
 * @date 20-Mar-2018
 * @purpose This class is used as dto for manage list of master data details.
 */
public class MasterDataDto {

	List<CountryDto> listCountry;
	List<PreferenceDto> listPreferences;
	List<BARegistrationViaDto> listBARegistraionStatus;
	List<RegionDto> listRegion;

	/**
	 * @return the listRegion
	 */
	public List<RegionDto> getListRegion() {
		return listRegion;
	}

	/**
	 * @param listRegion the listRegion to set
	 */
	public void setListRegion(List<RegionDto> listRegion) {
		this.listRegion = listRegion;
	}


	/**
	 * @return the listCountry
	 */
	public List<CountryDto> getListCountry() {
		return listCountry;
	}

	/**
	 * @param listCountry
	 *            the listCountry to set
	 */
	public void setListCountry(List<CountryDto> listCountry) {
		this.listCountry = listCountry;
	}

	/**
	 * @return the listPreferences
	 */
	public List<PreferenceDto> getListPreferences() {
		return listPreferences;
	}

	/**
	 * @param listPreferences
	 *            the listPreferences to set
	 */
	public void setListPreferences(List<PreferenceDto> listPreferences) {
		this.listPreferences = listPreferences;
	}

	/**
	 * @return the listBARegistraionStatus
	 */
	public List<BARegistrationViaDto> getListBARegistraionStatus() {
		return listBARegistraionStatus;
	}

	/**
	 * @param listBARegistraionStatus
	 *            the listBARegistraionStatus to set
	 */
	public void setListBARegistraionStatus(List<BARegistrationViaDto> listBARegistraionStatus) {
		this.listBARegistraionStatus = listBARegistraionStatus;
	}
}
