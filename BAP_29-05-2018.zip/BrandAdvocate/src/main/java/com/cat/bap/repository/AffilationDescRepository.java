package com.cat.bap.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cat.bap.entity.AffiliationDescription;

/**
 * @author rathor
 *
 */
public interface AffilationDescRepository extends JpaRepository<AffiliationDescription , Long>{
	
  @Query("SELECT ad.affiliationDesc FROM AffiliationDescription ad WHERE ad.affiliationName =:adName")
  public List<String> getAffiliationDescByName(@Param("adName") String adName);
  
  //@Query("SELECT distinct(ad.affiliationName) FROM AffiliationDescription ad")
  @Query("SELECT distinct(ad.affiliationName) FROM AffiliationDescription ad ORDER BY FIELD(ad.affiliationName,'Employees','Dealers','Others')")
  public List<String> getAllAffiliationNames();
  
  @Query("SELECT ad.affiliationNameUI FROM AffiliationDescription ad WHERE ad.affiliationDesc =:adName")
  public String getAffiliationNameByDesc(@Param("adName") String adName);
  
  @Query("SELECT distinct(ad.affiliationNameUI) FROM AffiliationDescription ad")
  public List<String> getAllAffiliationNamesUI();
  
}
