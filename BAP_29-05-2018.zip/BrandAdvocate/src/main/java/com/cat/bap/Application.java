package com.cat.bap;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.boot.context.embedded.ServletContextInitializer;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.web.filter.CharsetFilter;
import com.cat.bap.web.filter.Log4JContextFilter;
import com.cat.bap.web.filter.UserContextFilter;

import cat.cis.tuf.mbean.MBeanInitializerListener;
import cat.cis.tuf.server.container.listener.ContextInitializerListener;
import cat.cis.tuf.server.filter.TUFMasterFilter;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 19-Feb-2018
 * @purpose  ToCheck
 */
@SpringBootApplication
@EnableScheduling
@EnableJpaRepositories(repositoryImplementationPostfix = "CustomImpl")
@PropertySource(value={"classpath:cws.properties"})
public class Application extends SpringBootServletInitializer {

public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(Application.class);
  }

  @Bean
  public ViewResolver getViewResolver() {
    InternalResourceViewResolver resolver = new InternalResourceViewResolver();
    resolver.setPrefix("/html/");
    resolver.setSuffix(".html");
    return resolver;
  }
  
  @Bean
  public FilterRegistrationBean userContext() {

      FilterRegistrationBean registration = new FilterRegistrationBean();
      
      registration.setFilter(new UserContextFilter());
      registration.addUrlPatterns(UserMasterConstant.URL_PATTERN_COMMON);
      registration.setName(UserContextFilter.class.getName());
      return registration;
  } 

  
  @Bean
  public FilterRegistrationBean log4JContextFilter() {

      FilterRegistrationBean registration = new FilterRegistrationBean();
      
      registration.setFilter(new Log4JContextFilter());
      registration.addUrlPatterns(UserMasterConstant.URL_PATTERN_COMMON);
      registration.setName(Log4JContextFilter.class.getName());
      return registration;
  } 
  
  
  @Bean
  public FilterRegistrationBean charsetFilter() {

      FilterRegistrationBean registration = new FilterRegistrationBean();
      
      registration.setFilter(new CharsetFilter());
      registration.addUrlPatterns(UserMasterConstant.URL_PATTERN_COMMON);
      registration.setName(CharsetFilter.class.getName());
      return registration;
  } 
  
  @Bean
  public FilterRegistrationBean tUFMasterFilter() {

      FilterRegistrationBean registration = new FilterRegistrationBean();
      
      registration.setFilter(new TUFMasterFilter());
      registration.addUrlPatterns(UserMasterConstant.URL_PATTERN_COMMON);
      registration.setName(TUFMasterFilter.class.getName());
      return registration;
  }   
  
  @Bean
  public ContextInitializerListener registerContextInitializerListener() {
      return new ContextInitializerListener();
  }
  
  @Bean
  public MBeanInitializerListener myServletListener () {
      
      return new MBeanInitializerListener() {
  		
  		@Override
  		public void contextInitialized(ServletContextEvent arg0) {
  		}
  		
  		@Override
  		public void contextDestroyed(ServletContextEvent arg0) {
  		}
  	};
  }
  
  @Bean
  public ServletContextInitializer initializer() {
      return new ServletContextInitializer() {

          @Override
          public void onStartup(ServletContext servletContext) throws ServletException {
              servletContext.setInitParameter("heartbeat.timeout", "120000");
              servletContext.setInitParameter("securityEnabled", "true");
              servletContext.setInitParameter("securityWrapperImplementation", "cat.cis.tuf.server.security.cws.CWSSecurityWrapper");
              servletContext.setInitParameter("tuf.mbean.extensions", "tufws-mbeans");
          }
      };
  }
}
