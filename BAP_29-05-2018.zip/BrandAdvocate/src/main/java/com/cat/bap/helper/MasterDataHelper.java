package com.cat.bap.helper;

import java.util.ArrayList;
import java.util.List;

import com.cat.bap.dto.BARegistrationViaDto;
import com.cat.bap.dto.CountryDto;
import com.cat.bap.dto.PreferenceDto;
import com.cat.bap.dto.RegionDto;
import com.cat.bap.entity.BARegistrationVia;
import com.cat.bap.entity.Country;
import com.cat.bap.entity.Preferences;
import com.cat.bap.entity.Region;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 23-Feb-2018
 * @purpose
 */
public class MasterDataHelper {
	
	private MasterDataHelper(){
		
	}

  public static List<CountryDto> convertEntityListToDtoListForCountry(List<Country> countryEntityList){
    List<CountryDto> countryDtoList = new ArrayList<>();
    for(Country country : countryEntityList){
      CountryDto countryDto = new CountryDto();
      countryDto.setCountryId(country.getCountryId());
      countryDto.setCountryName(country.getCountryName().trim());
      countryDto.setCountryCode(country.getCountryCode());
      countryDtoList.add(countryDto);
    }
    return countryDtoList;
  }
  
  public static List<RegionDto> convertEntityListToDtoListForRegion(List<Region> regionEntityList){
    List<RegionDto> regionDtoList = new ArrayList<>();
    for(Region region : regionEntityList){
      RegionDto regionDto = new RegionDto();
      regionDto.setRegionId(region.getRegionId());
      regionDto.setRegionName(region.getRegionName().trim());
      regionDtoList.add(regionDto);
    }
    return regionDtoList;
  }

  public static List<PreferenceDto> convertEntityListToDtoListForPreference(List<Preferences> preferenceEntityList){
    
    List<PreferenceDto> preferenceDtoList = new ArrayList<>();
    for(Preferences preference : preferenceEntityList){
      PreferenceDto preferenceDto = new PreferenceDto();
      preferenceDto.setPreferenceId(preference.getPreferenceId());
      preferenceDto.setPreferenceName(preference.getPreferenceName().trim());
      preferenceDtoList.add(preferenceDto);
    }
    return preferenceDtoList;
  }

public static List<BARegistrationViaDto> convertEntityListToDtoListForRegistrationReason(
		List<BARegistrationVia> regReasonEntityList) {
	
    List<BARegistrationViaDto> regReasonDtoList = new ArrayList<>();
    for(BARegistrationVia regReasonObj : regReasonEntityList){
      BARegistrationViaDto reasonDto = new BARegistrationViaDto();
      reasonDto.setRegId(regReasonObj.getRegistrationId());
      reasonDto.setRegistrationStatusName(regReasonObj.getRegistrationStatusName());
      regReasonDtoList.add(reasonDto);
    }
    return regReasonDtoList;
}

}
