package com.cat.bap.dto;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email agrawal_rani@cat.com
 * @date 23-March-2018
 * @purpose This class is used as dto for manage Clues details.
 */

public class CluesDataDetailDto {
	
	private Long brandAdvocateId;
	private String cwsUserId;
	private String lastName;
	private String firstName;
	private String preferredFirstName;
	private String organizationName;
	private String workLocation;
	private String primaryEmail;
	private String secondaryEmail;
	private Long countryId;
	private String countryName;
	private String countryCode;
	private String facilityName;
	private String jobKeywords;
	private String affiliationDescription;
	private String brandAdvocateStatus;
	private Long regionId;
	private String regionName;
	private boolean isActive;
	private String cupId;
	private MasterDataDto masterDataDto;
	private String globalDirectoryStatus;
	private String mappedAffiliationName;
	
		
	public CluesDataDetailDto() {
		super();
	}

	/**
	 * @return the brandAdvocateId
	 */
	public Long getBrandAdvocateId() {
		return brandAdvocateId;
	}



	/**
	 * @param brandAdvocateId the brandAdvocateId to set
	 */
	public void setBrandAdvocateId(Long brandAdvocateId) {
		this.brandAdvocateId = brandAdvocateId;
	}



	/**
	 * @return the cwsUserId
	 */
	public String getCwsUserId() {
		return cwsUserId;
	}



	/**
	 * @param cwsUserId the cwsUserId to set
	 */
	public void setCwsUserId(String cwsUserId) {
		this.cwsUserId = cwsUserId;
	}



	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}



	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}



	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	/**
	 * @return the preferredFirstName
	 */
	public String getPreferredFirstName() {
		return preferredFirstName;
	}



	/**
	 * @param preferredFirstName the preferredFirstName to set
	 */
	public void setPreferredFirstName(String preferredFirstName) {
		this.preferredFirstName = preferredFirstName;
	}



	/**
	 * @return the organizationName
	 */
	public String getOrganizationName() {
		return organizationName;
	}



	/**
	 * @param organizationName the organizationName to set
	 */
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}



	/**
	 * @return the workLocation
	 */
	public String getWorkLocation() {
		return workLocation;
	}



	/**
	 * @param workLocation the workLocation to set
	 */
	public void setWorkLocation(String workLocation) {
		this.workLocation = workLocation;
	}



	/**
	 * @return the primaryEmail
	 */
	public String getPrimaryEmail() {
		return primaryEmail;
	}



	/**
	 * @param primaryEmail the primaryEmail to set
	 */
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}



	/**
	 * @return the secondaryEmail
	 */
	public String getSecondaryEmail() {
		return secondaryEmail;
	}



	/**
	 * @param secondaryEmail the secondaryEmail to set
	 */
	public void setSecondaryEmail(String secondaryEmail) {
		this.secondaryEmail = secondaryEmail;
	}



	/**
	 * @return the countryId
	 */
	public Long getCountryId() {
		return countryId;
	}



	/**
	 * @param countryId the countryId to set
	 */
	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}



	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return countryName;
	}



	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}



	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}



	/**
	 * @param countryCode the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}



	/**
	 * @return the facilityName
	 */
	public String getFacilityName() {
		return facilityName;
	}



	/**
	 * @param facilityName the facilityName to set
	 */
	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}



	/**
	 * @return the jobKeywords
	 */
	public String getJobKeywords() {
		return jobKeywords;
	}



	/**
	 * @param jobKeywords the jobKeywords to set
	 */
	public void setJobKeywords(String jobKeywords) {
		this.jobKeywords = jobKeywords;
	}



	/**
	 * @return the affiliationDescription
	 */
	public String getAffiliationDescription() {
		return affiliationDescription;
	}



	/**
	 * @param affiliationDescription the affiliationDescription to set
	 */
	public void setAffiliationDescription(String affiliationDescription) {
		this.affiliationDescription = affiliationDescription;
	}



	/**
	 * @return the brandAdvocateStatus
	 */
	public String getBrandAdvocateStatus() {
		return brandAdvocateStatus;
	}



	/**
	 * @param brandAdvocateStatus the brandAdvocateStatus to set
	 */
	public void setBrandAdvocateStatus(String brandAdvocateStatus) {
		this.brandAdvocateStatus = brandAdvocateStatus;
	}



	/**
	 * @return the regionId
	 */
	public Long getRegionId() {
		return regionId;
	}



	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}



	/**
	 * @return the regionName
	 */
	public String getRegionName() {
		return regionName;
	}



	/**
	 * @param regionName the regionName to set
	 */
	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}



	/**
	 * @return the isActive
	 */
	public boolean isActive() {
		return isActive;
	}



	/**
	 * @param isActive the isActive to set
	 */
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}



	/**
	 * @return the cupId
	 */
	public String getCupId() {
		return cupId;
	}



	/**
	 * @param cupId the cupId to set
	 */
	public void setCupId(String cupId) {
		this.cupId = cupId;
	}



	/**
	 * @return the masterDataDto
	 */
	public MasterDataDto getMasterDataDto() {
		return masterDataDto;
	}



	/**
	 * @param masterDataDto the masterDataDto to set
	 */
	public void setMasterDataDto(MasterDataDto masterDataDto) {
		this.masterDataDto = masterDataDto;
	}
	
	/**
	 * @return the globalDirectoryStatus
	 */
	public String getGlobalDirectoryStatus() {
		return globalDirectoryStatus;
	}

	/**
	 * @param globalDirectoryStatus the globalDirectoryStatus to set
	 */
	public void setGlobalDirectoryStatus(String globalDirectoryStatus) {
		this.globalDirectoryStatus = globalDirectoryStatus;
	}
	

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CluesDataDetailDto [brandAdvocateId=" + brandAdvocateId + ", cwsUserId=" + cwsUserId + ", lastName="
				+ lastName + ", firstName=" + firstName + ", preferredFirstName=" + preferredFirstName
				+ ", organizationName=" + organizationName + ", workLocation=" + workLocation + ", primaryEmail="
				+ primaryEmail + ", secondaryEmail=" + secondaryEmail + ", countryId=" + countryId + ", countryName="
				+ countryName + ", countryCode=" + countryCode + ", facilityName=" + facilityName + ", jobKeywords="
				+ jobKeywords + ", affiliationDescription=" + affiliationDescription + ", brandAdvocateStatus="
				+ brandAdvocateStatus + ", regionId=" + regionId + ", regionName=" + regionName + ", isActive="
				+ isActive + ", cupId=" + cupId + ", masterDataDto=" + masterDataDto + "]";
	}

	/**
	 * @return the mappedAffiliationName
	 */
	public String getMappedAffiliationName() {
		return mappedAffiliationName;
	}

	/**
	 * @param mappedAffiliationName the mappedAffiliationName to set
	 */
	public void setMappedAffiliationName(String mappedAffiliationName) {
		this.mappedAffiliationName = mappedAffiliationName;
	}
	
	

}
