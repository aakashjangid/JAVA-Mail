package com.cat.bap.common;

/**
 * @author rathor
 * @purpose To maintain application level constants
 */
public interface BrandAdvocateConstant {

	public static final String LOGGER_PREFIX = "\n<=========== Brand Advocate ===========>";
	public static final String DIRECTORY_EXIST = "Directory already exist";
	public static final String DIRECTORY_CREATED = "Directory created.";
	public static final String DIRECTORY_NOT_CREATED = "Directory not created.";
	public static final String FILE_SIZE_EXCEEDS = "File size limit 5MB exceeds.";
	public static final String SENDING_FAILED_TO_MAILID = "Sending Failed to Mail Id: ";
	public static final String MESSAGE_SENT = "Message is sent";
	public static final String INVALID_EMAIL_IDS = "Invalid Email Ids";
	public static final String SENDING_FAILED_MSG = "Sending failed for Following email Ids : ";
	public static final String ERROR_MESSAGE_SENT = "Error Message is sent";

	/*********** EMAIL CONSTANTS ************/

	public static final String VM_GENERIC_EMAIL_TEMPLATE = "genericemailmessage.vm";
	public static final String VM_REG_EMAIL_TEMPLATE = "registrationmailmessage.vm";
	public static final String VM_MASS_EMAIL_TEMPLATE = "massemailmessage.vm";

	public static final String MSG_WELCOME_REG = "Welcome to Brand Advocate Portal! Thank You so much for joining us.";
	public static final String MSG_UPDATE_REG = "<br>Your information has been updated in Brand advocate portal.";

	public static final String SUBJECT_WELCOME_REG = "Brand Advocate Portal: Welcome User!!";
	public static final String SUBJECT_INACTIVE_NOTIFICATION = "Brand Advocate Portal: Account Deactivated";
	public static final String SUBJECT_WELCOME_REG_COMMENT = "Brand Advocate Portal: Added Comments/Questions";
	public static final String SUBJECT_WELCOME_REG_USERCOMMENT = "Brand Advocate Portal: User added Comments/Questions";
	public static final String SUBJECT_UPDATE_REG = "Brand Advocate Portal: Update information notification";
	public static final String SUBJECT_UPDATE_COMMENTS = "Brand Advocate Portal: Update Comments/Questions";
	public static final String SUBJECT_BULK_UPLOAD = "Brand Advocate Portal: Welcome User!!";
	public static final String SUBJECT_BULK_UPLOAD_UPDATE = "Brand Advocate Portal: Update information notification";
	public static final String SUBJECT_SYNC_EMAIL = "Sync Service: Information update Notification";
	public static final String SUBJECT_SYNC_EMAIL_ADMIN = "Sync Service successfully completed";
	public static final String SYNC_INPROGRESS 	= "Sync Service started";
	public static final String SYNC_COMPLETED 	= "Sync Service completed";

	public static final String MSGBODY_BULK_UPLOAD = "<p>You have been registered with Brand Advocate Portal.</p>"
			+ "<br>Admin<br/>Brand Advocate Portal<br/>";

	public static final String MSGBODY_INACTIVE_NOTIFICATION = "<p>Your account has been deactivated in Brand Advocate Portal.</p>"
			+ "<br>Admin<br/>Brand Advocate Portal<br/>";

	public static final String MSGBODY_BULK_UPLOAD_UPDATE = "<p>Your information has been updated in Brand Advocate portal.</p>"
			+ "<br>Admin<br/>Brand Advocate Portal<br/>";

	public static final String MSGBODY_SYNC_SERVICE = "<p>Your information has been updated in Brand Advocate portal thru Sync service.</p>"
			+ "<br>Admin<br/>Brand Advocate Portal<br/>";

	public static final String MSGBODY_SYNC_SERVICE_ADMIN = "<p>The Sync service job has been completed successfully.</p>"
			+ "<br>Admin<br/>Brand Advocate Portal<br/>";

	public static final String MSGBODY_INFO_UPDATES_USER= "<p>Your information has been updated in Brand Advocate portal. Following are the updated information -";
	public static final String MSGBODY_SIGNATURE 		= "<br>Admin<br/>Brand Advocate Portal<br/>";

	public static final String MSGBODY_QUESTION_TO_ADMIN = "<p>Comments/questions has been added by user while registration process in Brand Advocate portal. Below are the information - </p>";
	public static final String MSGBODY_QUESTION_TO_ADMIN_HIMSELF = "<p>Comments/questions has been added by you while registration process in Brand Advocate portal. Below are the information - </p>";
	public static final String MSGBODY_QUESTION_TO_ADMIN_BY_ADMIN = "<p>You have added Comments/questions for user while registration process in Brand Advocate portal. Below are the information - </p>";
	public static final String MSGBODY_QUESTION_UPDATE_TO_ADMIN_BY_ADMIN = "<p>You have added Comments/questions for user while updating information in Brand Advocate portal. Below are the information - </p>";
	public static final String MSGBODY_QUESTION_UPDATE_TO_ADMIN = "<p>Comments/questions has been added by user while updating informations in Brand Advocate portal. Below are the information - ";
	public static final String MSGBODY_UPDATE_INFO_TO_ADMIN = "<p>User has added comments/questions for you while registration process in Brand Advocate portal. Below are the information - </p>";
	public static final String MSGBODY_QUESTION_BY_USER = "<p>You have added below comments/questions while registration process in Brand Advocate portal.</p>";
	public static final String MSGBODY_QUESTION_TO_USER_BY_ADMIN = "<p>Comments/questions has been added for you while registration process in Brand Advocate portal. Below are the information.</p>";
	public static final String MSGBODY_QUESTION_UPDATE_BY_USER = "<p>You have added below comments/questions while updating information in Brand Advocate portal.";

	public static final String USER_TESTER_EMAIL = "Rathore_Rohan@cat.com";
	public static final String USER_TESTER_ADMIN = " ADMIN : rohan.rathore@cat.com";

	/** Fields used for label **/
	public static final String MAIL_LABEL_SECONDARY_EMAIL 	= "Secondary Email : ";
	public static final String MAIL_LABEL_BUILDING 			= "Building : ";
	public static final String MAIL_LABEL_JOB_KEYWORD 		= "Job Keyword : ";
	public static final String MAIL_LABEL_PREFERENCE 		= "Subscription preference : ";
	public static final String MAIL_LABEL_COMMENTS_QUES 	= "Comments/Questions : ";
	public static final String MAIL_LABEL_NOTES 			= "Notes : ";
	public static final String MAIL_LABEL_BA_STATUS 		= "Brand Advocate Status : ";
	public static final String MAIL_LABEL_USER_NAME 		= "User Name : ";
	public static final String MAIL_LABEL_USER_EMAIL 		= "User Email : ";
	
	public static final String MAIL_LABEL_AFFILIATION_NAME 	= "AffiliationName : ";
	public static final String MAIL_LABEL_FACILITY_NAME 	= "FacilityName : ";
	public static final String MAIL_LABEL_REGION_NAME 		= "RegionName : ";
	public static final String MAIL_LABEL_COUNTRY_NAME 		= "CountryName : ";
	public static final String MAIL_LABEL_PRIMARY_EMAIL 	= "PrimaryEmail : ";
	public static final String MAIL_LABEL_ORG_NAME 			= "OrganizationName : ";
	public static final String MAIL_LABEL_PREF_NAME 		= "PreferredName : ";
	public static final String MAIL_LABEL_LAST_NAME 		= "LastName : ";
	public static final String MAIL_LABEL_FIRST_NAME 		= "FirstName : ";

	/** Compare constants **/
	public static final String BUILDING 		= "Building";
	public static final String JOBKEYWORD 		= "JobKeyword";
	public static final String SECONDARYEMAIL 	= "SecondaryEmail";
	public static final String BASTATUS 		= "BrandAdvocateStatus";
	public static final String SUBS_PREF	 	= "SubscriptionPreference";
	public static final String COMMENTS 		= "Comments";
	public static final String NOTES 			= "Notes";
	public static final String AFFILIATION_NAME = "AffiliationName";
	public static final String FACILITY_NAME 	= "FacilityName";
	public static final String REGION_NAME 		= "RegionName";
	public static final String COUNTRY_NAME 	= "CountryName";
	public static final String PRIMARY_EMAIL 	= "PrimaryEmail";
	public static final String ORG_NAME 		= "OrganizationName";
	public static final String PREF_NAME 		= "PreferredName";
	public static final String LAST_NAME 		= "LastName";
	public static final String FIRST_NAME 		= "FirstName";
	
	
	/**Reporting module constants*/
	public static final String Q1_TY = "Q1 of This Year";
	public static final String Q2_TY = "Q2 of This Year";
	public static final String Q3_TY = "Q3 of This Year";
	public static final String Q4_TY = "Q4 of This Year";
	
	public static final String Q1_LY = "Q1 of Last Year";
	public static final String Q2_LY = "Q2 of Last Year";
	public static final String Q3_LY = "Q3 of Last Year";
	public static final String Q4_LY = "Q4 of Last Year";

	public static final String Q1 = "Q1";
	public static final String Q2 = "Q2";
	public static final String Q3 = "Q3";
	public static final String Q4 = "Q4";

	public static final String CURRENT_YEAR = "currentYear";
	public static final String PREVIOUS_YEAR = "previousYear";

}
