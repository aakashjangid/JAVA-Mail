package com.cat.bap.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.cat.bap.common.BrandAdvocateConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.entity.Preferences;
import com.cat.bap.util.BrandAdvocateEmailUtility;

import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.email.EMailException;

@Service
public class EmailUtilityService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailUtilityService.class);
	
	@Inject
	BrandAdvocateEmailUtility brandAdvocateEmailUtility;

	/**
	 * @param bauserDetailDto
	 * @param adminGroupUsers 
	 */
	public void sendEmailToNewUsers(BAUserDetailsDto bauserDetailDto, List<Person> adminGroupUsers){
		
		LOGGER.debug("sendEmailToNewUsers() : START");
		
		if(null==bauserDetailDto.getBrandAdvocateId()){
			
			String toMail=bauserDetailDto.getPrimaryEmail();
			String firstName = bauserDetailDto.getFirstName();
			String lastName =  bauserDetailDto.getLastName();
			
			new Thread(() -> 
			{
				try {
					/** Welcome email to users. **/
					 sendWelcomeEmailToUser(toMail, firstName, lastName); //CORRECT
					 
						 if(null!=bauserDetailDto.getComments() && !"".equals(bauserDetailDto.getComments())){
							 
							 /** Email notification to User about comments notes.**/
							 sendEmailtoUserWithCommentsQuestion(toMail, firstName, lastName, bauserDetailDto);// CORRECT
							// sendEmailtoAdminWithCommentsQuestion(toMail, firstName, lastName, bauserDetailDto);// CORRECT
							
							 /** Admin will receive notes/comments information along with user information **/
							 if(null==bauserDetailDto.getIsAdmin()){
								 
								 StringBuilder allEmails = new StringBuilder();
								 
								 /** Retrieve all admin list to inform**/
								 for (Person person : adminGroupUsers) {
									 allEmails.append(person.getEmailId()).append(", ");
								 }
								 
								 sendEmailtoAdminAllDetails(allEmails.toString(), "Admin", bauserDetailDto);
								 
							 }else if(bauserDetailDto.getIsAdmin()){
								 	 sendEmailtoAdminAllDetails(bauserDetailDto.getLoggedInUserEmailId(), bauserDetailDto.getLoggedInUserName(), bauserDetailDto);
							 }
						 }
					 
					} catch (EMailException | IOException e) {
						LOGGER.error("New user registration : Error occured while sending email to user",e.getMessage());
					}
			}).start();
		}
		LOGGER.debug("sendEmailToNewUsers() : END");
	}

	private void sendEmailtoAdminAllDetails(String toMail, String firstName, BAUserDetailsDto bauserDetailDto) throws EMailException, IOException {
		
		 LOGGER.debug("sendEmailtoAdminAllDetails() : START");

		 if(null!=bauserDetailDto.getComments() && !"".equals(bauserDetailDto.getComments())){
			 
			 StringBuilder msgBodyUpdate = new StringBuilder();
			 
			 if(null!= bauserDetailDto.getIsAdmin() && bauserDetailDto.getIsAdmin()){
				 msgBodyUpdate.append(BrandAdvocateConstant.MSGBODY_QUESTION_TO_ADMIN_HIMSELF);
			 }else  if(null== bauserDetailDto.getIsAdmin()){
				 msgBodyUpdate.append(BrandAdvocateConstant.MSGBODY_QUESTION_TO_ADMIN);
			 }
			 
			 msgBodyUpdate.append("<p>");
			 
			 msgBodyUpdate.append(BrandAdvocateConstant.MAIL_LABEL_USER_NAME)
			 			  .append(bauserDetailDto.getLastName()).append(" ")
			 			  .append(bauserDetailDto.getFirstName())
			 			  .append("<br/>");
			 msgBodyUpdate.append(BrandAdvocateConstant.MAIL_LABEL_USER_EMAIL)
			 			  .append(bauserDetailDto.getPrimaryEmail()).append("<p>");
			 
			 msgBodyUpdate.append(BrandAdvocateConstant.MAIL_LABEL_COMMENTS_QUES)
			 			  .append("".equals(bauserDetailDto.getComments()) 	? "" : bauserDetailDto.getComments()).append("<p>");
			 msgBodyUpdate.append("<p>");
			 msgBodyUpdate.append(BrandAdvocateConstant.MSGBODY_SIGNATURE).append(" ADMIN: ");
			 msgBodyUpdate.append(toMail);
		
			 brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_WELCOME_REG_USERCOMMENT,  msgBodyUpdate.toString(), firstName, "", BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
/**		 	 brandAdvocateEmailUtility.sendMail(toMail, BrandAdvocateConstant.SUBJECT_WELCOME_REG,  BrandAdvocateConstant.MSGBODY_BULK_UPLOAD.concat(toMail), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE); **/
		 }

		LOGGER.debug("sendEmailtoAdminAllDetails() : END");
	}

	private void sendEmailtoUserWithCommentsQuestion(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDto) throws EMailException, IOException {
		
		LOGGER.debug("sendEmailtoUserWithCommentsQuestion() : START");
		
		if(null==bauserDetailDto.getIsAdmin()){
				
			StringBuilder msgUser = new StringBuilder();
			
			msgUser.append(BrandAdvocateConstant.MSGBODY_QUESTION_BY_USER);
			msgUser.append("<p><p>");
			msgUser.append(BrandAdvocateConstant.MAIL_LABEL_COMMENTS_QUES);
			msgUser.append("".equals(bauserDetailDto.getComments()) ? "" : bauserDetailDto.getComments()).append("<p>");
			msgUser.append("<p><p>");
			msgUser.append(BrandAdvocateConstant.MSGBODY_SIGNATURE);
			msgUser.append(toMail);
			 
			brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_WELCOME_REG_COMMENT,  msgUser.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
	/**		brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_WELCOME_REG,  msgUser.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);**/
		
		}
		

		LOGGER.debug("sendEmailtoUserWithCommentsQuestion() : END");
	}

	private void sendWelcomeEmailToUser(String toMail, String firstName, String lastName) throws EMailException, IOException {
		
		LOGGER.debug("sendWelcomeEmailToUser() : START");
		
		brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_WELCOME_REG,  BrandAdvocateConstant.MSGBODY_BULK_UPLOAD.concat(toMail), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
/**		brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_WELCOME_REG,  BrandAdvocateConstant.MSGBODY_BULK_UPLOAD.concat(toMail), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);**/
		
		LOGGER.debug("sendWelcomeEmailToUser() : END");
	}

	public void sendEMailToExistingUser(BAUserDetailsDto bauserDetailDto, Map<String, String> diffOfFieldMap, List<Person> adminGroupUsers){
		
		LOGGER.debug("sendEMailToExistingUser() : START");
		
		//String toMail=bauserDetailDto.getPrimaryEmail();
		String firstName = bauserDetailDto.getFirstName();
		String lastName =  bauserDetailDto.getLastName();
		
		 String userPrimaryEmail = (null != bauserDetailDto.getPrimaryEmail()
			     && !bauserDetailDto.getPrimaryEmail().equals("")) ? bauserDetailDto.getPrimaryEmail() : "";
		 String userSecondaryEmail = (null != bauserDetailDto.getSecondaryEmail()
			     && !bauserDetailDto.getSecondaryEmail().equals("")) ? bauserDetailDto.getSecondaryEmail() : "";

		String userEmail = !userPrimaryEmail.equals("") ? userPrimaryEmail : userSecondaryEmail;   
			         
		if(null!=bauserDetailDto.getBrandAdvocateId()){		
		new Thread(() ->
		{
			try {
				if(null!=bauserDetailDto.getIsAdmin() && bauserDetailDto.getIsAdmin()){
					/** If user related information is updated, sene an email **/
					sendEmailToUserForAdminUpdateInfo(userEmail, firstName, lastName, bauserDetailDto, diffOfFieldMap);
					
					/** if comments/notes is updated by admin, admin will receive an email**/
					sendEmailToAdminForAdminUpdateCommentsUpdate(bauserDetailDto.getLoggedInUserEmailId(), bauserDetailDto.getLoggedInUserName(), "", bauserDetailDto, diffOfFieldMap);
				}else{
					/**Send all updated information to User **/
					sendEmailToUserWithAllUpdatedInformation(userEmail, firstName, lastName, bauserDetailDto, diffOfFieldMap); //correct
				
					/**Send email to user and admin if comments/questions are updated **/
					StringBuilder allEmails = new StringBuilder();
					 for (Person person : adminGroupUsers) {
						 allEmails.append(person.getEmailId()).append(", ");
					}
					 	/**Sending mail to user for comments/questions **/
						sendEmailToUserForCommentsQuestions(userEmail, firstName, lastName, bauserDetailDto, diffOfFieldMap);
						
						/**Sending mail to admin for comments/questions **/
						sendEmailToAdminForCommentsQuestions(allEmails.toString(), "Admin", "", bauserDetailDto, diffOfFieldMap);
				}
			} catch (EMailException | IOException e) {
				LOGGER.error("Update user registration: Error occured while sending email to user",e.getMessage());
			}
		}).start();
		}

		LOGGER.debug("sendEMailToExistingUser() : END");		
	}

	private void sendEmailToAdminForAdminUpdateCommentsUpdate(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDtoNew, Map diffOfFieldMap) throws EMailException, IOException {
		
		 LOGGER.debug("sendEmailToUserForAdminUpdateCommentsUpdate() : START");

		 boolean isAnyFieldUpdate = false;
		
		 StringBuilder msgBodyUpdateField = new StringBuilder();
		 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_QUESTION_UPDATE_TO_ADMIN_BY_ADMIN);
		 msgBodyUpdateField.append("<p>");
		 
		 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_USER_NAME)
						   .append(bauserDetailDtoNew.getLastName()).append(" ")
						   .append(bauserDetailDtoNew.getFirstName())
						   .append("<br/>");
		 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_USER_EMAIL)
			  			   .append(bauserDetailDtoNew.getPrimaryEmail()).append("<p>");
		 
		 /** Check getComments value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.COMMENTS)){
			 
			 	msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_COMMENTS_QUES)
			 				      .append(diffOfFieldMap.get(BrandAdvocateConstant.COMMENTS)).append("<br/>");
			 	isAnyFieldUpdate = true;
		 }
		 
		 /** Check getNotes value**/
/*		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.NOTES)){
			 
			 	msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_NOTES)
			 				   	  .append(diffOfFieldMap.get(BrandAdvocateConstant.NOTES));
			 	isAnyFieldUpdate = true;
		 }*/
			 
		 msgBodyUpdateField.append("<br/>");
		 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_SIGNATURE).append(" Admin : ");
		 msgBodyUpdateField.append(toMail);	
	 
		 /**send mail to admin**/
		 if(isAnyFieldUpdate){
			 	brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_UPDATE_COMMENTS,  msgBodyUpdateField.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);	 
		 }
		 

		LOGGER.debug("sendEmailToUserForAdminUpdateCommentsUpdate() : END");		
	}

	private void sendEmailToUserForAdminUpdateInfo(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDtoNew, Map<String,String> diffOfFieldMap) throws EMailException, IOException {
		
		LOGGER.debug("sendEmailToUserForAdminUpdateInfo() : START");////////////
		
		 boolean isAnyFieldUpdate = false;
		
		 StringBuilder msgBodyUpdateField = new StringBuilder();
		 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_INFO_UPDATES_USER);
		 msgBodyUpdateField.append("<p>");

		 
		 ////////////////////////////////////////////
		 /** Check Last Name value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.LAST_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_LAST_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.LAST_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check First Name value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.FIRST_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_FIRST_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.FIRST_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }		 
		 
		 /** Check Preferred name value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.PREF_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_PREF_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.PREF_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check Organization value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.ORG_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_ORG_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.ORG_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check primary email value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.PRIMARY_EMAIL)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_PRIMARY_EMAIL)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.PRIMARY_EMAIL)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 
		 /** Check Secondary email value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.SECONDARYEMAIL)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_SECONDARY_EMAIL)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.SECONDARYEMAIL)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check region value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.REGION_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_REGION_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.REGION_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
         
		 
		 /** Check country value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.COUNTRY_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_COUNTRY_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.COUNTRY_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check Facility email value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.FACILITY_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_FACILITY_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.FACILITY_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check Building value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.BUILDING)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_BUILDING)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.BUILDING)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check Brand advocate status**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.BASTATUS)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_BA_STATUS)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.BASTATUS)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 
		 /** Check Job keyword value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.JOBKEYWORD)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_JOB_KEYWORD)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.JOBKEYWORD)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }		 

		 /** Check Affiliation value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.AFFILIATION_NAME)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_AFFILIATION_NAME)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.AFFILIATION_NAME)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check user preferences value **/
         if(null!=diffOfFieldMap.get(BrandAdvocateConstant.SUBS_PREF)){
                       
	            msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_PREFERENCE);
	           
	            List<Preferences> preferences = bauserDetailDtoNew.getPreferences();
	            StringBuilder preferenceName = new StringBuilder();
	           
	            for (Preferences preference : preferences) {
	            	preferenceName.append(preference.getPreferenceName()).append(", ");
	            }
	            
	            String preString = preferenceName.toString();
	            msgBodyUpdateField.append(preString.substring(0, preString.length() - 2));
	            msgBodyUpdateField.append("<br/>");
	         isAnyFieldUpdate = true;  
          }			 

		 
/*		 String userPrimaryEmail = (null != bauserDetailDtoNew.getPrimaryEmail()
			     && !bauserDetailDtoNew.getPrimaryEmail().equals("")) ? bauserDetailDtoNew.getPrimaryEmail() : "";
		 String userSecondaryEmail = (null != bauserDetailDtoNew.getSecondaryEmail()
			     && !bauserDetailDtoNew.getSecondaryEmail().equals("")) ? bauserDetailDtoNew.getSecondaryEmail() : "";

		String userEmail = !userPrimaryEmail.equals("") ? userPrimaryEmail : userSecondaryEmail;  */ 
			         
		 msgBodyUpdateField.append("<br>");
		 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_SIGNATURE).append(" Admin : ");
		 msgBodyUpdateField.append(toMail);
		 
		 if(isAnyFieldUpdate){
			 brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_UPDATE_REG,  msgBodyUpdateField.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);	 
		 }
		 
/**		 brandAdvocateEmailUtility.sendMail(toMail, BrandAdvocateConstant.SUBJECT_UPDATE_REG,  msgUser.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);**/
		 
		LOGGER.debug("sendEmailToUserForAdminUpdateInfo() : END");		
	}

	private void sendEmailToUserForCommentsQuestions(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDto, Map diffOfFieldMap) throws EMailException, IOException {

		LOGGER.debug("sendEmailToUserAndAdminForCommentsQuestions() : START");
		
		 if(null!=diffOfFieldMap.get("Comments")){
			 
			 StringBuilder msgBodyUpdateUser = new StringBuilder();
				 
			 msgBodyUpdateUser.append(BrandAdvocateConstant.MSGBODY_QUESTION_UPDATE_BY_USER);
			 msgBodyUpdateUser.append("<br/><br/>");
			 msgBodyUpdateUser.append(BrandAdvocateConstant.MAIL_LABEL_COMMENTS_QUES)
			 		.append(diffOfFieldMap.get("Comments"));

			 msgBodyUpdateUser.append("<br/>");
			 msgBodyUpdateUser.append(BrandAdvocateConstant.MSGBODY_SIGNATURE);
			 msgBodyUpdateUser.append(toMail);
			 
			 /** Email notification to User about comments notes.**/
			 brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_WELCOME_REG_COMMENT,  msgBodyUpdateUser.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
			
		 }
		LOGGER.debug("sendEmailToUserAndAdminForCommentsQuestions() : END");
	}

	private void sendEmailToAdminForCommentsQuestions(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDto, Map diffOfFieldMap) throws EMailException, IOException {
		
		LOGGER.debug("sendEmailToUserAndAdminForCommentsQuestions() : START");
		
		if(null!=diffOfFieldMap.get(BrandAdvocateConstant.COMMENTS)){
			
			StringBuilder msgBodyUpdate = new StringBuilder();
			
			msgBodyUpdate.append(BrandAdvocateConstant.MSGBODY_QUESTION_UPDATE_TO_ADMIN);
			msgBodyUpdate.append("<p>");
			msgBodyUpdate.append(BrandAdvocateConstant.MAIL_LABEL_USER_NAME)
			.append(bauserDetailDto.getLastName()).append(" ")
			.append(bauserDetailDto.getFirstName())
			.append("<br/>");
			msgBodyUpdate.append(BrandAdvocateConstant.MAIL_LABEL_USER_EMAIL)
			.append(bauserDetailDto.getPrimaryEmail()).append("<p>");
			
			msgBodyUpdate.append(BrandAdvocateConstant.MAIL_LABEL_COMMENTS_QUES).append(diffOfFieldMap.get("Comments"));
			msgBodyUpdate.append("<br/>");
			msgBodyUpdate.append(BrandAdvocateConstant.MSGBODY_SIGNATURE).append(" Admin");
			msgBodyUpdate.append(toMail);		
			
			/** Admin will receive notes/comments information along with user information **/
			brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_WELCOME_REG_USERCOMMENT,  msgBodyUpdate.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
			
		}
		LOGGER.debug("sendEmailToUserAndAdminForCommentsQuestions() : END");
	}
	
	private void sendEmailToUserWithAllUpdatedInformation(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDtoNew,Map diffOfFieldMap) throws EMailException, IOException {

		LOGGER.debug("sendEmailToUserWithAllUpdatedInformation() : START");
		
		 boolean isAnyFieldUpdate = false;
		 
		 StringBuilder msgBodyUpdateField = new StringBuilder();
		 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_INFO_UPDATES_USER);
		 msgBodyUpdateField.append("<br/><br/>");

		 /** Check Building value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.BUILDING)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_BUILDING)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.BUILDING)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check Job keyword value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.JOBKEYWORD)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_JOB_KEYWORD)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.JOBKEYWORD)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 /** Check Secondary email value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.SECONDARYEMAIL)){
			 
			 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_SECONDARY_EMAIL)
			 				   .append(diffOfFieldMap.get(BrandAdvocateConstant.SECONDARYEMAIL)).append("<br/>");
			 isAnyFieldUpdate = true;
		 }
		 
		 
		 /** Check user preferences value **/
         if(null!=diffOfFieldMap.get(BrandAdvocateConstant.SUBS_PREF)){
                       
	            msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_PREFERENCE);
	           
	            List<Preferences> preferences = bauserDetailDtoNew.getPreferences();
	            StringBuilder preferenceName = new StringBuilder();
	           
	            for (Preferences preference : preferences) {
	            	preferenceName.append(preference.getPreferenceName()).append(", ");
	            }
	            
	            String preString = preferenceName.toString();
	            msgBodyUpdateField.append(preString.substring(0, preString.length() - 2));
	            isAnyFieldUpdate = true;
          }		 

			 msgBodyUpdateField.append("<br/>");
			 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_SIGNATURE);
			 msgBodyUpdateField.append(toMail);
			 
			 if(isAnyFieldUpdate){
			 brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_UPDATE_REG,  msgBodyUpdateField.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
/**			 brandAdvocateEmailUtility.sendMail(toMail, BrandAdvocateConstant.SUBJECT_UPDATE_REG,  msgUser.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);**/
			 }

	
		LOGGER.debug("sendEmailToUserWithAllUpdatedInformation() : END");		
	}
	

	/**
	 * @param bauserDetailDto
	 * @throws EMailException
	 * @throws IOException
	 */
	public void sendEmailtoUserOnSecondaryEmailUpdate(BAUserDetailsDto bauserDetailDto) throws EMailException, IOException {
		
		 LOGGER.debug("sendEmailtoUserOnSecondaryEmailUpdate() : START");

			 StringBuilder msgBodyUpdate = new StringBuilder();
			 
			 msgBodyUpdate.append(BrandAdvocateConstant.MSG_UPDATE_REG);
			 msgBodyUpdate.append("<p>");
			 
			 msgBodyUpdate.append(BrandAdvocateConstant.MAIL_LABEL_SECONDARY_EMAIL)
			 			  .append("".equals(bauserDetailDto.getSecondaryEmail()) 	? "" : bauserDetailDto.getSecondaryEmail()).append("<p>");
			 msgBodyUpdate.append(BrandAdvocateConstant.MSGBODY_SIGNATURE);
			 msgBodyUpdate.append(bauserDetailDto.getPrimaryEmail());
		
			 brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_UPDATE_REG,  msgBodyUpdate.toString(), bauserDetailDto.getFirstName(), "", BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);
		 
		LOGGER.debug("sendEmailtoUserOnSecondaryEmailUpdate() : END");
	}
	

	public void sendEmailToAdminForCommentsUpdateFromGrid(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDtoNew, Map<String, String> diffOfFieldMap) throws EMailException, IOException {
		
		 LOGGER.debug("sendEmailToAdminForCommentsUpdateFromGrid() : START");
		 
		/**send mail to recipients**/
		 new Thread(() -> 
			{
				sendMailWithCommentsAddedFromGrid( toMail,  firstName,  lastName, bauserDetailDtoNew,  diffOfFieldMap);				
			});

		LOGGER.debug("sendEmailToAdminForCommentsUpdateFromGrid() : END");		
	}

	private void sendMailWithCommentsAddedFromGrid(String toMail, String firstName, String lastName,
			BAUserDetailsDto bauserDetailDtoNew, Map diffOfFieldMap) {

		 boolean isAnyFieldUpdate = false;
			
		 StringBuilder msgBodyUpdateField = new StringBuilder();
		 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_QUESTION_UPDATE_TO_ADMIN_BY_ADMIN);
		 msgBodyUpdateField.append("<p>");
		 
		 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_USER_NAME)
						   .append(bauserDetailDtoNew.getLastName()).append(" ")
						   .append(bauserDetailDtoNew.getFirstName())
						   .append("<br/>");
		 msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_USER_EMAIL)
			  			   .append(bauserDetailDtoNew.getPrimaryEmail()).append("<p>");
		 
		 /** Check getComments value**/
		 if(null!=diffOfFieldMap.get(BrandAdvocateConstant.COMMENTS)){
			 
			 	msgBodyUpdateField.append(BrandAdvocateConstant.MAIL_LABEL_COMMENTS_QUES)
			 				      .append(diffOfFieldMap.get(BrandAdvocateConstant.COMMENTS)).append("<br/>");
			 	isAnyFieldUpdate = true;
		 }
			 
		 msgBodyUpdateField.append("<br/>");
		 msgBodyUpdateField.append(BrandAdvocateConstant.MSGBODY_SIGNATURE).append(" Admin : ");
		 msgBodyUpdateField.append(toMail);	
	 
		 /**send mail to admin**/
		 if(isAnyFieldUpdate){
			 	brandAdvocateEmailUtility.sendMail(BrandAdvocateConstant.USER_TESTER_EMAIL, BrandAdvocateConstant.SUBJECT_UPDATE_COMMENTS,  msgBodyUpdateField.toString(), firstName, lastName, BrandAdvocateConstant.VM_GENERIC_EMAIL_TEMPLATE);	 
		 }
	}

	
}
