package com.cat.bap.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.entity.Documents;

/**
 * @author kuldeep.ratnawat
 * @copyright Yash Technologies Pvt. Ltd.
 * @email kuldeep.ratnawat@yash.com
 * @date 13-Feb-2018
 * @purpose
 */
public class BrandAdvocateUtility {

	static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	static SecureRandom rnd = new SecureRandom();

	public static boolean isEmptyString(String strValue) {

		return (null != strValue && !"".equals(strValue)) ? false : true;
	}

	public static String getEmptyOrNotNull(Object obj) {

		if (null != obj && ((String) obj).length() > 0) {
			return ((String) obj).trim();
		} else
			return "";
	}

	public static boolean isEmailId(String emailIds) {

		if (null != emailIds && emailIds.toString().contains("@")) {
			return true;
		}
		return false;
	}

	public static String getStringValue(String strValue) {

		if (null != strValue) {
			return strValue.trim();
		} else
			return "";
	}

	/**
	 * This method is used to search given string on the given list of Objects.
	 * 
	 * @param results
	 * @param searchString
	 * @return List<Object[]>
	 */
	public static List<Object[]> searchStringInList(List<Object[]> results, String searchString) {
		List<Object[]> output = new ArrayList<>();
		for (int i = 0; i < results.size(); i++) {
			String searchStringResponse = searchString.toLowerCase();
			Object[] objects = results.get(i);
			for (int j = 0; j < objects.length; j++) {
				if (null != objects[j] && objects[j].toString().toLowerCase().contains(searchStringResponse)) {
					output.add(objects);
					break;
				}
			}
		}
		return output;
	}

	public static String convertObjectToCustomDate(Object obj) {
		Date date = (Date) obj;
		Format formatter = new SimpleDateFormat("dd MMM YYYY");
		String customDate = formatter.format(date);
		return customDate;
	}

	public static Date convertStringToDate(String strDate) throws ParseException {
		DateFormat format = new SimpleDateFormat("YYYY MMMM dd", Locale.ENGLISH);
		Date date = format.parse(strDate);
		return date;
	}

	/**
	 * This method is used to get Cookie from Request Header
	 * 
	 * @param requestHeader
	 * @param sessionIdentifier
	 * @return {@link String}
	 */
	public static String getCookieFromHeader(HttpHeaders requestHeader, String sessionIdentifier) {
		Set<String> keys = requestHeader.keySet();

		String cookieValue = "";

		for (String header : keys) {
			if (UserMasterConstant.COOKIE.equals(header)) {
				cookieValue = requestHeader.get(header).get(0);
				break;
			}
		}

		String[] cookieParamValues = cookieValue.split(";");

		for (int i = 0; i < cookieParamValues.length - 1; i++) {
			String[] cookieValues = cookieParamValues[i].split("=");
			if (UserMasterConstant.ADMIN_TOKEN.equalsIgnoreCase(cookieValues[0].trim())) {
				cookieValue = cookieValues[1].trim();
				break;
			}
		}

		if (!isEmptyString(cookieValue))
			cookieValue = cookieValue.replaceAll("%22", "");

		cookieValue = sessionIdentifier + "=" + cookieValue + "; Path=/brandadvocate/" + "; HttpOnly";

		return cookieValue;
	}

	/**
	 * This method is used to get Date String By User TimeZone
	 * 
	 * @param dateFormat
	 * @return {@link String}
	 */
	public static String getDateStringByDateFormat(String dateFormat) {
		DateFormat formatter = new SimpleDateFormat(dateFormat);
		return formatter.format(new Date());
	}

	/**
	 * @param existingNonActiveUsers
	 * @param isCWS
	 * @return
	 */
	public static String getCommaSepratedStringValue(List<BAUserDetailsDto> existingNonActiveUsers, boolean isCWS) {
		StringBuilder sbExistingNonActiveUsers = new StringBuilder();

		if (null != existingNonActiveUsers && !existingNonActiveUsers.isEmpty()) {
			for (BAUserDetailsDto nonActive : existingNonActiveUsers) {
				if (isCWS) {
					sbExistingNonActiveUsers.append(nonActive.getCwsUserId()).append(", ");
				} else {
					sbExistingNonActiveUsers.append(nonActive.getPrimaryEmail()).append(", ");
				}
			}
			return sbExistingNonActiveUsers.substring(0, sbExistingNonActiveUsers.length() - 2);
		}
		return "";
	}

	public static String getCommaSeparatedString(List<String> listOfNonExistUsers) {

		if (null != listOfNonExistUsers && !listOfNonExistUsers.isEmpty()) {
			StringBuilder sbNonExistUser = new StringBuilder();
			for (String nonExistUser : listOfNonExistUsers) {
				sbNonExistUser.append(nonExistUser.toLowerCase()).append(", ");
			}

			return sbNonExistUser.substring(0, sbNonExistUser.length() - 2);
		}
		return "";
	}

	public List<Documents> uploadDocument(MultipartHttpServletRequest request, String commonPath,String templateName,List<Documents> previousDocumentsList) throws IOException {

		File dir = new File(commonPath);
		if (!dir.exists()) {
			dir.mkdirs();
		}

		List<Documents> docList = new ArrayList<>();
		Iterator<String> itr = request.getFileNames();
		while (itr.hasNext()) {
			
			File directory = new File(commonPath+templateName);
			if (!directory.exists()) {
				directory.mkdirs();
			}
			
			Documents doc = new Documents();
			String fileName;
			String key = itr.next();
			MultipartFile mpf = request.getFile(key);

			fileName = commonPath + templateName + "/" + mpf.getOriginalFilename();

			byte[] bytes = mpf.getBytes();
			BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(fileName)));
			stream.write(bytes);
			stream.close();

			String fname = fileName.replace(commonPath+templateName+"/", "");
			doc.setDocumentName(fname);
			doc.setDocumentPath(fileName);
			docList.add(doc);
		}
		
		if(!previousDocumentsList.isEmpty()){
			for(Documents document:previousDocumentsList){
				Documents doc = new Documents();
				doc.setDocumentId(document.getDocumentId());
				doc.setDocumentName(document.getDocumentName());
				doc.setDocumentPath(document.getDocumentPath());
				docList.add(doc);
			}
		}

		return docList;
	}

	public static String convertDateInYYYMMDD(Date date) throws ParseException {
		SimpleDateFormat newDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date d = newDateFormat.parse(newDateFormat.format(date));
		return newDateFormat.format(d);
	}
	
	public static String randomString(int len) {
		StringBuilder sb = new StringBuilder(len);
		for (int i = 0; i < len; i++)
			sb.append(AB.charAt(rnd.nextInt(AB.length())));
		return sb.toString();
	}
}
