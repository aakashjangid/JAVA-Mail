package com.cat.bap.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.util.IOUtils;
import org.apache.velocity.exception.VelocityException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.cat.bap.common.BrandAdvocateConstant;
import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.common.UserMasterConstant;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.entity.Invitation;
import com.cat.bap.entity.SchedulerDetail;
import com.cat.bap.persistence.util.TufConnectionProvider;
import com.cat.bap.service.BAUserDetailsDomainService;
import com.cat.bap.service.BAUserDetailsService;
import com.cat.bap.service.EmailUtilityService;
import com.cat.bap.service.SchedulerCluesUpdateService;
import com.cat.bap.service.SyncDataService;
import com.cat.bap.util.BrandAdvocateEmailUtility;
import com.cat.bap.util.BrandAdvocateUtility;
import com.cat.bap.util.PersonUtil;
import com.cat.bap.util.SchedulerCLUES;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.email.EMailException;
import cat.cis.tuf.common.persistence.PersistenceException;

/**
 * @author rathor
 *
 */
@RestController
@RequestMapping(value = "/manage/details/v1/")
public class BAUserDetailsController {

	private static final Logger LOGGER = LoggerFactory.getLogger(BAUserDetailsController.class);

	private static final String PATHDELIMINATOR = "/";

	@Inject
	private BAUserDetailsService baUserDetailsService;

	@Inject
	private SyncDataService sncDataService;

	@Inject
	SchedulerCLUES schedulerCLUES;

	@Inject
	TufConnectionProvider tufConnectionProvider;

	@Inject
	BrandAdvocateEmailUtility brandAdvocateEmailUtility;

	@Inject
	private SchedulerCluesUpdateService schedulerCluesUpdateService;

	@Inject
	private EmailUtilityService emailUtilityService;

	@Inject
	private BAUserDetailsDomainService baUserDetailsDomainService;

	@Inject
	private Environment environment;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/saveuserinformation", method = RequestMethod.POST)
	public ResponseWrapper<Map<String, Object>> addOrUpdateUserInformation(
			@RequestBody BAUserDetailsDto bauserDetailDto) throws ParseException, PersistenceException {

		LOGGER.trace("addOrUpdateUserInformation : START");

		Map<String, String> diffOfFieldMap = null;

		/** get old data for comparison **/
		Long brandAdvocateId = bauserDetailDto.getBrandAdvocateId();

		if (null != brandAdvocateId) {
			BAUserDetailsDto baUserInDB = baUserDetailsService.getBAUserDetailsObjectById(brandAdvocateId);
			diffOfFieldMap = baUserDetailsService.getMapOfDifference(bauserDetailDto, baUserInDB);
		}

		Map<String, Object> response = baUserDetailsService.addOrUpdateUserInformation(bauserDetailDto);

		List<Person> adminGroupUsers = PersonUtil.getAdminGroupUsers();

		/** send email for new registration **/
		emailUtilityService.sendEmailToNewUsers(bauserDetailDto, adminGroupUsers);

		/** send email for registration updates **/
		emailUtilityService.sendEMailToExistingUser(bauserDetailDto, diffOfFieldMap, adminGroupUsers);

		LOGGER.trace("addOrUpdateUserInformation : END");

		return new ResponseWrapper<>(null, HttpStatus.OK, "", response);
	}

	@RequestMapping(value = "/getallbauserdetails", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getAllBAUsersDetails(
			@RequestParam("manageadminrequest") String manageAdminRequest) {

		LOGGER.info("* getAllBAUsersDetails method is called from BAUserDetaisController *");

		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				baUserDetailsService.getAllBAUsersDetailsFromJson(manageAdminRequest));
	}

	@RequestMapping(value = "/getbauserdetailsbyid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getBAUserDetailsById(
			@RequestParam("brandadvocateid") Long brandAdvocateId) {

		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				baUserDetailsService.getBAUserDetailsById(brandAdvocateId));
	}

	@RequestMapping(value = "/addNotes", method = RequestMethod.POST)
	public void addNotes(@RequestBody BAUserDetailsDto userMasterDto) throws ParseException {
		baUserDetailsService.addNotes(userMasterDto);
	}

	@RequestMapping(value = "/addCommentsQuestions", method = RequestMethod.POST)
	public void addCommentsQuestions(@RequestBody BAUserDetailsDto bauserDetailDto) throws ParseException {

		baUserDetailsService.addCommentsQuestions(bauserDetailDto);

		BAUserDetailsDto baUserInDB = baUserDetailsService
				.getBAUserDetailsObjectById(bauserDetailDto.getBrandAdvocateId());
		Map<String, String> diffOfFieldMap = baUserDetailsService.getMapOfCommentDifference(bauserDetailDto,
				baUserInDB);

		try {
			if (!BrandAdvocateUtility.getEmptyOrNotNull(bauserDetailDto.getComments())
					.equals(baUserInDB.getComments())) {

				emailUtilityService.sendEmailToAdminForCommentsUpdateFromGrid(bauserDetailDto.getLoggedInUserEmailId(),
						bauserDetailDto.getLoggedInUserName(), "", bauserDetailDto, diffOfFieldMap);
			}

		} catch (EMailException | IOException ex) {
			LOGGER.error("Error occured while adding comments from Grid.", ex);
		}

	}

	@RequestMapping(value = "/checkbaexistinportal", method = RequestMethod.POST)
	public ResponseWrapper<BAUserDetailsDto> checkBAExistInPortal(@RequestBody BAUserDetailsDto userMasterDto) {

		BAUserDetailsDto baExist = baUserDetailsService.checkBAExistInPortal(userMasterDto);
		return new ResponseWrapper<>(null, HttpStatus.OK, "", baExist);
	}

	@RequestMapping(value = "/dobastatusinactive", method = RequestMethod.GET)
	public void changeActiveStatus(@RequestParam("brandadvocateid") Long brandAdvocateId,
			@RequestParam("activestatus") Boolean activeStatus,
			@RequestParam("loggedinusername") String baUseDetailObject1) {

		BAUserDetailsDto baUseDetailObject = new BAUserDetailsDto();
		baUseDetailObject.setFirstName("Saajan Tester");
		baUseDetailObject.setLastName("Sony");
		baUseDetailObject.setPrimaryEmail("saajan.soni@yash.com");

		/** change active to inactive state **/
		try {
			baUserDetailsService.changeActiveStatus(brandAdvocateId, activeStatus, baUseDetailObject);
		} catch (EMailException | SQLException | IOException e) {
			LOGGER.error("Error occurred while updating user status to inactive.", e);
		}
	}

	/**
	 * This method is used for export to excel.
	 * 
	 * @param response
	 * @param manageAdminRequest
	 * @param requestHeader
	 * @throws NoSuchFieldException
	 * @throws IOException
	 * @throws ParseException
	 */
	@RequestMapping(value = "/exporttoexcel", method = RequestMethod.POST)
	public void generateXLS(HttpServletResponse response, @RequestBody String manageAdminRequest,
			@RequestHeader HttpHeaders requestHeader) throws NoSuchFieldException, IOException, ParseException {
		baUserDetailsService.generateXLSFromJson(response, manageAdminRequest, requestHeader);
	}

	@RequestMapping(value = "/exporttoexcelforfindotherba", method = RequestMethod.POST)
	public void generateXLSForFindOtherBa(HttpServletResponse response, @RequestBody String manageAdminRequest,
			@RequestHeader HttpHeaders requestHeader) throws NoSuchFieldException, IOException, ParseException {
		baUserDetailsService.generateXLSFromJsonForFindOtherBa(response, manageAdminRequest, requestHeader);
	}

	/**
	 * This method is used to send Mail.
	 * 
	 * @param request
	 * @param requestHeader
	 * @param mailRequest
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 * @throws MessagingException
	 * @throws VelocityException
	 * @throws EMailException
	 * @throws Exception
	 */
	@RequestMapping(value = "/sendmail", method = RequestMethod.POST)
	public ResponseWrapper<Boolean> sendMail(MultipartHttpServletRequest request,
			@RequestHeader HttpHeaders requestHeader, @RequestParam(value = "mailrequest") String mailRequest)
			throws IOException, MessagingException, EMailException {
		baUserDetailsService.sendMailFromJsonData(request, requestHeader, mailRequest);
		return new ResponseWrapper<>(null, HttpStatus.OK, "", true);
	}

	/**
	 * This method is used to send Calendar Invite.
	 * 
	 * @param request
	 * @param requestHeader
	 * @param CalendarRequest
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 * @throws ParseException
	 * @throws Exception
	 */
	@RequestMapping(value = "/sendcalinvite", method = RequestMethod.POST)
	public ResponseWrapper<Boolean> sendCalendarInvite(MultipartHttpServletRequest request,
			@RequestHeader HttpHeaders requestHeader, @RequestParam(value = "calendarrequest") String calendarrequest)
			throws IOException, ParseException {
		baUserDetailsService.sendCalendarInviteFromJsonData(request, requestHeader, calendarrequest);
		return new ResponseWrapper<>(null, HttpStatus.OK, "", true);
	}

	@RequestMapping(value = "/getbauserdetailsbyids", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getBAUserDetailsByIds(@RequestParam("cwsuserid") String cwsUserId,
			@RequestParam("emailid") String emailId, @RequestParam("cupid") String cupId) {

		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				baUserDetailsService.getBAUserDetailsBasedOnIds(cwsUserId, emailId, cupId));
	}

	/**
	 * @param cupId
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "/getbauserdetailsbycupid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getBAUserDetailsByCupId(@RequestParam("cupid") String cupId)
			throws SQLException {

		return new ResponseWrapper<>(null, HttpStatus.OK, "", baUserDetailsService.getBAUserDetailsByCupId(cupId));
	}

	/**
	 * @param cwsUserId
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "/getbauserdetailsbycwsid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getBAUserDetailsByCwsId(@RequestParam("cwsuserid") String cwsUserId)
			throws SQLException {

		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				baUserDetailsService.getBAUserDetailsByCwsUserId(cwsUserId));
	}

	/**
	 * @param emailId
	 * @return
	 * @throws SQLException
	 */
	@RequestMapping(value = "/getbauserdetailsbyemailid", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getBAUserDetailsByEmailId(@RequestParam("emailid") String emailId)
			throws SQLException {

		return new ResponseWrapper<>(null, HttpStatus.OK, "", baUserDetailsService.getBAUserDetailsByEmailId(emailId));
	}

	@RequestMapping(value = "/getalltemplates", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getAllTemplates() {

		Map<String, Object> response = baUserDetailsService.getAllTemplates();
		return new ResponseWrapper<>(null, HttpStatus.OK, "", response);
	}

	@RequestMapping(value = "/updateSecondaryMail", method = RequestMethod.POST)
	public void updateSecondaryMail(@RequestBody BAUserDetailsDto userMasterDto)
			throws ParseException, EMailException, IOException {

		LOGGER.info("updateSecondaryMail() : START");

		baUserDetailsService.updateSecondaryMail(userMasterDto);
		emailUtilityService.sendEmailtoUserOnSecondaryEmailUpdate(userMasterDto);

		LOGGER.info("updateSecondaryMail() : END");

	}

	@RequestMapping(value = "/gettemplatedetails", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, Object>> getTemplateDetailsByTemplateId(
			@RequestParam("templateid") Long templateId, HttpServletResponse httpServletResponse) throws IOException {

		Map<String, Object> response = baUserDetailsService.getTemplateDetailsByTemplateId(templateId,
				httpServletResponse);
		return new ResponseWrapper<>(null, HttpStatus.OK, "", response);
	}

	@RequestMapping(value = "/deleteuserinfo", method = RequestMethod.DELETE)
	public void deleteUserInfo(@RequestParam("brandadvocateid") Long brandAdvocateId) {
		baUserDetailsService.deleteUserInfo(brandAdvocateId);
	}

	@RequestMapping(value = "/synccluesdata", method = RequestMethod.GET)
	public void syncCluesdata(@RequestParam("adminfirstname") String adminFirstName,
			@RequestParam("adminlastname") String adminLastName, @RequestParam("adminemailid") String adminEmailId)
			throws SQLException, EMailException, IOException, ParseException {

		LOGGER.info("Manual Sync Execution : START");

		LOGGER.info(" executeSyncService() : START");

		Timestamp executionStartTime = new Timestamp(new Date().getTime());
		String jobGenerateCode = BrandAdvocateUtility.randomString(UserMasterConstant.NO_OF_DIGIT_CODE);

		String jobStatusInProgress = UserMasterConstant.INPROGRESS;
		String jobStatusFailed = UserMasterConstant.FAILED;
		String jobStatusCompleted = UserMasterConstant.COMPLETED;
		String jobStatusInProgressLog = BrandAdvocateConstant.SYNC_INPROGRESS;
		String jobStatusCompletedLog = BrandAdvocateConstant.SYNC_COMPLETED;

		SchedulerDetail maintainSyncSchedulerInfo = baUserDetailsDomainService.maintainSyncSchedulerInfo(null,
				jobGenerateCode, jobStatusInProgress, UserMasterConstant.SYNC_MANUAL, executionStartTime, null,
				jobStatusInProgressLog);
		/** Manual sync process **/
		try {

			schedulerCluesUpdateService.syncCluesData(adminFirstName, adminLastName, adminEmailId,
					UserMasterConstant.SYNC_MANUAL);

		} catch (EMailException | SQLException | IOException | ParseException e) {

			LOGGER.error("Error occurred while manul sync service execution. ", e);

			Timestamp executionFailedTime = new Timestamp(new Date().getTime());
			baUserDetailsDomainService.maintainSyncSchedulerInfo(maintainSyncSchedulerInfo.getJobId(), jobGenerateCode,
					jobStatusFailed, UserMasterConstant.SYNC_MANUAL, executionStartTime, executionFailedTime,
					e.getMessage());
		}

		/** Update sync process value in databases - STARTED **/
		Timestamp executionEndTime = new Timestamp(new Date().getTime());

		if (null != maintainSyncSchedulerInfo.getJobId()) {
			baUserDetailsDomainService.maintainSyncSchedulerInfo(maintainSyncSchedulerInfo.getJobId(), jobGenerateCode,
					jobStatusCompleted, UserMasterConstant.SYNC_MANUAL, executionStartTime, executionEndTime,
					jobStatusCompletedLog);
		}

		LOGGER.info("Manual Sync Execution : END");
	}

	@RequestMapping(value = "/savemailtemplatedata", method = RequestMethod.POST)
	public ResponseWrapper<Boolean> saveMailTemplateData(MultipartHttpServletRequest request,
			@RequestHeader HttpHeaders requestHeader, @RequestParam(value = "templaterequest") String templateRequest,
			@RequestParam(value = "subject") String subject, @RequestParam("templatename") String templateName)
			throws IOException {
		baUserDetailsService.saveMailTemplateData(request, requestHeader, templateRequest, subject, templateName);
		return new ResponseWrapper<>(null, HttpStatus.OK, "", true);
	}

	@RequestMapping(value = "/updatemailtemplatedata", method = RequestMethod.POST)
	public ResponseWrapper<Boolean> updateMailTemplateData(MultipartHttpServletRequest request,
			@RequestHeader HttpHeaders requestHeader, @RequestParam(value = "mailrequest") String mailRequest)
			throws IOException {
		baUserDetailsService.updateMailTemplateFromJsonData(request, requestHeader, mailRequest);
		return new ResponseWrapper<>(null, HttpStatus.OK, "", true);
	}

	@RequestMapping(value = "/getmaillidlistbybaid", method = RequestMethod.POST)
	public ResponseWrapper<List<BAUserDetailsDto>> getMailIdListByBaId(@RequestBody String manageAdminRequest) {
		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				baUserDetailsService.getMailIdListByBaIdFromJson(manageAdminRequest));
	}

	@RequestMapping(value = "/getinitialdataforfindba", method = RequestMethod.GET)
	public ResponseWrapper<Map<String, List<?>>> getInitialDataForFindBA() {
		return new ResponseWrapper<>(null, HttpStatus.OK, "", baUserDetailsService.getInitialDataForFindBA());
	}

	@RequestMapping(value = "/getlastsyncoperationdate", method = RequestMethod.GET)
	public ResponseWrapper<String> getLastSyncOperationDate() {

		LOGGER.info("getLastSyncOperationDate() : START ");
		String lastExecutionTime = "";

		try {
			lastExecutionTime = sncDataService.getLastSchedulerExecutionTime();
		} catch (SQLException exception) {
			LOGGER.info("Error in getLastSyncOperationDate() : FAILED ", exception);
		}

		String message = "Last sync operation was happened on " + lastExecutionTime + ". Do you want to sync again?";

		LOGGER.info("getLastSyncOperationDate() : START ");
		return new ResponseWrapper<>(null, HttpStatus.OK, "", message);
	}

	@RequestMapping(value = "/uploadinlineimage", method = RequestMethod.POST)
	public String uploadAnImage(@RequestParam MultipartFile file, HttpServletRequest request) {

		if (!file.isEmpty()) {
			byte[] bytes = null;
			String path = System.getProperty("tuf.appFiles.rootDirectory");
			File dir = new File(path + "/template-images");
			if (!dir.isDirectory()) {
				dir.mkdir();
			}

			File serverfile = null;
			try {
				bytes = file.getBytes();
				serverfile = new File(
						dir.getAbsolutePath() + PATHDELIMINATOR + file.getName() + Math.random() + ".png");
			} catch (IOException e1) {
				LOGGER.error("Error in closing the Resource..", e1);
			}

			if (serverfile != null) {
				try (BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverfile));) {
					stream.write(bytes);
					String hostname = environment.getProperty("app.hostName");
					return "{\"location\" : \"" + hostname + "/manage/details/v1/image/path/" + serverfile.getName()
							+ "\"}";

				} catch (IOException e) {
					LOGGER.error("Error in uploadImage Method in BAUserDetailsController ", e);
				}
			}
		}

		return "{\"location\" : \"http://localhost.cat.com:8181/brandadvocate/image/path/{name}.png\"}";

	}

	@RequestMapping(value = "image/path/{name}", method = RequestMethod.GET)
	public void getImage(@PathVariable String name, HttpServletResponse response) {

		File file = new File(System.getProperty("tuf.appFiles.rootDirectory") + "/template-images/" + name + ".png");
		try (FileInputStream is = new FileInputStream(file);) {
			response.setContentType(MediaType.IMAGE_PNG_VALUE);
			IOUtils.copy(is, response.getOutputStream());
		} catch (IOException e) {
			LOGGER.error("Error in getImage Method of BAUserDeatailsController ", e);
		}

	}

	@RequestMapping(value = "/getallinvitations", method = RequestMethod.GET)
	public ResponseWrapper<List<Invitation>> getAllInvitations() {
		return new ResponseWrapper<>(null, HttpStatus.OK, "", baUserDetailsService.getAllCalendarInvitations());
	}

	@RequestMapping(value = "/getinvitationbyid", method = RequestMethod.GET)
	public ResponseWrapper<Invitation> getInvitationById(@RequestParam("invitationid") Long invitationId) {
		return new ResponseWrapper<>(null, HttpStatus.OK, "",
				baUserDetailsService.getCalendarInvitationById(invitationId));
	}

}