package com.cat.bap.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cat.bap.entity.SchedulerDetail;

/**
 * @author rathor
 *
 */
public interface SchedulerDetailRepository extends JpaRepository<SchedulerDetail , Long>{
  
  @Query(" FROM SchedulerDetail sd")
  public List<String> getAllSchedulerInfo();
	
}
