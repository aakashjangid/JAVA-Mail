'use strict';

baControllers.controller('advHomeNotesCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'advHomeNotesFactory','filterFilter', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, advHomeNotesFactory,filterFilter){
	
	$scope.input = new advHomeNotesFactory();
	$scope.input.notes = $scope.notes;
	
	$scope.addNotes = function(newNotes){
		$scope.input.brandAdvocateId = $scope.brandAdvocateId;
		$scope.input.notes = newNotes;
		$scope.input.loggedInUserName=$scope.loggedInUserName;
		advHomeNotesFactory.addNotes($scope.input,function(response){
			console.log(response.data);
			ngDialog.close();
			$route.reload();
		})/*.error(function(result) { 
			location.href = "#/brandInfo";
		}); */
	};
	


	
}]);
