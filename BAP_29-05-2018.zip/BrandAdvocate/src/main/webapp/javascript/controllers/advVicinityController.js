'use strict';

baControllers.controller('advVicinityCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'advVicinityFactory','filterFilter', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, advVicinityFactory,filterFilter){
	
	

	/**Global Variables*/
	$scope.input = new advVicinityFactory();
	$scope.finalInput = new advVicinityFactory();
	$scope.baList = [];
	$scope.inputRequest = new advVicinityFactory();
	$scope.offset = 0;
	$scope.count = 10;
	$scope.srtng = "desc";
	$scope.IsVisible_nodata = true;
	$scope.allDataCount = 0;
	$scope.countForToggle = 0;
	$scope.allSearchDataCount = '';
	$scope.rejectionComment = "";
	$rootScope.urlChange = false;
	$scope.isEnable = false;
	
	
	
	/**Table headers i18N*/
	$scope.lRecordId = jQuery.i18n.prop('record_id');
	$scope.lCwsUserId = jQuery.i18n.prop('cws_user_id');
	$scope.lBaSince = jQuery.i18n.prop('ba_since');
	$scope.lLastName = jQuery.i18n.prop('last_name');
	$scope.lFirstName = jQuery.i18n.prop('first_name');
	$scope.lDivision = jQuery.i18n.prop('division');
	$scope.lWorkLocation = jQuery.i18n.prop('work_location');
	$scope.lCountry = jQuery.i18n.prop('country');
	$scope.lEmail = jQuery.i18n.prop('email');
	
	$scope.lAction = jQuery.i18n.prop('common_action');
	$scope.lNext = jQuery.i18n.prop('common_next');
	$scope.lPrevious = jQuery.i18n.prop('common_previous');
	$scope.lAll = jQuery.i18n.prop('common_all');
	$scope.lPage = jQuery.i18n.prop('common_page');
	$scope.lFirstPage = jQuery.i18n.prop('common_first_page');
	$scope.lLastPage = jQuery.i18n.prop('common_last_page');
	$scope.lPreviousPage = jQuery.i18n.prop('common_previous_page');
	$scope.lNextPage = jQuery.i18n.prop('common_next_page');
	
	
	/**Display all approval Process*//*
	$scope.loadData = function(){
		
		$scope.baAllData = [{"recordId" : 1,"cwsUserId": 1, "baSince" :"09/02/2018" ,"lastName" :"advocate","firstName" :"brand","division" :"abc","workLocation":"Indore","country" : "India","email":"brandadvocate@gmail.com"},
		                    {"recordId" : 2,"cwsUserId": 2, "baSince" :"09/02/2018" ,"lastName" :"advocate","firstName" :"brand","division" :"abc","workLocation":"Indore","country" : "India","email":"brandadvocate@gmail.com"}];
		$scope.IsVisible_nodata = false;
		
	};
	
	*//**Display all approvalProcess initially*//*
	$scope.loadData();*/
	
	$scope.displayRecords = function(){
		var dataCount = $scope.count;
		if($scope.count<0 || $scope.count==''){
			$scope.total = 1;
			dataCount = $scope.baList.length;
		}
		var data = $scope.baList;
		$scope.tableParams = new NgTableParams({
			page: 1,
			count: dataCount 
		}, { 
			filterDelay: 0,
			//data: $scope.approvalProcessList
			getData: function($defer, params) {
				var orderedData;
	        			orderedData = params.sorting() ? $filter('orderBy')(data, params.orderBy()) : data;
	        			if(params.sorting().salesPlanId==undefined && params.sorting().description==undefined && params.sorting().salesArea==undefined && params.sorting().salesYear==undefined && params.sorting().currency==undefined && params.sorting().approvalStatus==undefined && params.sorting().isActive==undefined){
	        				orderedData = data;
	        			
	        	}

		        $defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
			}
		});//End//
	}
	
	/**Display all approval Process*/
	$scope.loadData = function(){
		$scope.baList =  [{"recordId" : 1,"cwsUserId": 1, "baSince" :"09/02/2018" ,"lastName" :"advocate","firstName" :"brand","division" :"abc","workLocation":"Indore","country" : "India","email":"brandadvocate@gmail.com"},
		                    {"recordId" : 2,"cwsUserId": 2, "baSince" :"09/02/2018" ,"lastName" :"advocate","firstName" :"brand","division" :"abc","workLocation":"Indore","country" : "India","email":"brandadvocate@gmail.com"},
		                    {"recordId" : 2,"cwsUserId": 2, "baSince" :"09/02/2018" ,"lastName" :"advocate","firstName" :"brand","division" :"abc","workLocation":"Indore","country" : "India","email":"brandadvocate@gmail.com"}];
		$scope.allSearchDataCount = $scope.baList.length;
		var dataCount = $scope.count;
		if($scope.count<0 || $scope.count==''){
			$scope.total = 1;
			dataCount = $scope.baList.length;
		}else{
			$scope.total = Math.ceil($scope.allSearchDataCount/$scope.count);
		}
		$scope.currentPage = $scope.offset+1;
		if ($scope.baList != null && $scope.baList.length > 0) {
	         $scope.IsVisible_nodata = false;
			} else {
	         $scope.IsVisible_nodata = true;
	         $scope.total = 0;
	        }

			$scope.totalDataCount = $scope.allSearchDataCount ;
			if($scope.allSearchDataCount <1) {
				$scope.noData = true;
				$scope.noDataSearch = false;
				 $scope.total = 0;
				 $scope.selectedAll = false;
			}
			angular.forEach($scope.baList, function(value, key){
				$scope.baList[key].Selected = false;
			});
			$scope.displayRecords();
	};
	
	/**Display all approvalProcess initially*/
	$scope.loadData();
	
	/**No. of records(5,10,20,All) changed*/
	$scope.updateRecords = function(){
		$scope.offset = 0;
		$scope.currentPage = 1;
		$scope.loadData();
	};

	/**Pagination action*/
	$scope.PagingAct = function(page) {
		$scope.offset = page-1;
		$scope.loadData();		
	}
	
	/**Select-Unselect all checkboxes*/
	$scope.selectAllCheckbox = function () {
		
		if ($scope.selectedAll) {
			$scope.countForToggle = 0;
			$scope.selectedAll = false;		
		}else {
			$scope.countForToggle = $scope.totalDataCount;
			$scope.selectedAll = true;		
		}	
			angular.forEach($scope.baList, function (item) {
				item.Selected = $scope.selectedAll;
			});
	};
	
	
	$scope.changeToggleStatus = function(itemSelected, index){
		if(itemSelected){
			$scope.countForToggle-- ;
		}else{
			$scope.countForToggle++ ;
		}
		$scope.finalList = angular.copy($scope.baList);
		$scope.finalList = filterFilter($scope.finalList,$scope.search);
		if($scope.finalList.length != 0 && $scope.countForToggle>=$scope.finalList.length && !itemSelected){
			$scope.selectedAll = true;
		}else{
			$scope.selectedAll = false;
		}
	}
	
	$scope.approvalProcessSearchChange = function(){
		$scope.offset = 0;
		$scope.loadData();
		$scope.finalList = angular.copy($scope.baList);
		$scope.finalList = filterFilter($scope.finalList,$scope.search);
		if($scope.finalList.length == 0) {
			$scope.isEnable = true;
		}
		else {
			$scope.isEnable = false;
		}
		if($scope.finalList.length != 0 && $scope.countForToggle>=$scope.finalList.length){
			var count = 0;
			angular.forEach($scope.finalList,function(value){
				if(!value.Selected){
					count++;
				}
			});
			if(count==0){
				$scope.selectedAll = true;
			}else{
				$scope.selectedAll = false;
			}
		}else{
			$scope.selectedAll = false;
		}
	};
	
	
	//this is used to prevent URL from being changed
	/*$scope.$on('$locationChangeStart', function(event) {
		if($rootScope.urlChange ==true){
 			$rootScope.urlChange = false;
 		}else{
 			event.preventDefault();
 		}
	});*/
	
	$scope.changeToggleStatus = function(itemSelected, index){
		if(itemSelected){
			$scope.countForToggle-- ;
		}else{
			$scope.countForToggle++ ;
		}
		$scope.finalList = angular.copy($scope.baList);
		$scope.finalList = filterFilter($scope.finalList,$scope.search);
		if($scope.finalList.length != 0 && $scope.countForToggle>=$scope.finalList.length && !itemSelected){
			$scope.selectedAll = true;
		}else{
			$scope.selectedAll = false;
		}
	}

	
	/*$scope.editAdvInfo = function(viewMode, cwsUserId){
		$location.path('/viewBrandInfo').search({
			cwsUserId : cwsUserId,
			mode : viewMode
		});
	}*/
	
	
}]);
