'use strict';

baControllers.controller('advWebinarHomeMailCtrl',['$scope',
                                    		'$filter',
                                    		'$route',
                                    		'$http',
                                    		'$location',
                                    		'$rootScope',
                                    		'$window',
                                    		'ngDialog','advWebinarHomeMailFactory','fileUploadService','localStorageService','$timeout', function($scope, $filter, $route, $http, $location, $rootScope, $window, ngDialog,advWebinarHomeMailFactory,fileUploadService,localStorageService,$timeout){

	$scope.input = new advWebinarHomeMailFactory();
	$scope.readonly = true;
	
	$scope.fileList=[];
	$scope.files = [];
	
	$scope.emailList = [];
	
	$scope.isTemplateSelected = false;
	$scope.isStartTimeSelected = false;
	
	$scope.lRemove = jQuery.i18n.prop('common_remove');
	$scope.validateEndTime = jQuery.i18n.prop('validate_end_time_webinar_invite');
	
	$scope.validateStartTime = jQuery.i18n.prop('validate_start_time');
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	 $scope.timings= [];
	 $scope.endTimings = [];
	 var searchObject = $location.search();
	 $scope.sharedDataInvitations = {};
	 $scope.baUserDetailsList = [];
	 //$scope.test();
	 
	 if (searchObject.invitationId != null && searchObject.invitationId != '') {
		 if(searchObject.mode = 'invitation'){
			var invitationId = searchObject.invitationId;
			$scope.input.invitationId = invitationId; // send at the time of rescheduling mail.
			advWebinarHomeMailFactory.getInvitationById({invitationid:invitationId},function(response){
				console.log(response.data);
				$scope.emailList = response.data.sendTo;
				$scope.input.location = response.data.location;
				$scope.input.subject = response.data.subject;
				//$('#texteditor').html(response.data.description);
				$timeout( function(){
				//tinyMCE.get('texteditor').setContent(response.data.description);
					$('#texteditor').html(response.data.description);
				});
				var startDateTimestamp = response.data.startDateTime;
				var startDateTime = new Date(startDateTimestamp);
				$scope.input.startDate = startDateTime.getMonth()+1+'/'+startDateTime.getDate()+'/'+startDateTime.getFullYear();

				var endDateTimestamp = response.data.endDateTime;
				var endDateTime = new Date(endDateTimestamp);
				$scope.input.endDate = endDateTime.getMonth()+1+'/'+endDateTime.getDate()+'/'+endDateTime.getFullYear();
				
				console.log(moment(startDateTimestamp).format('hh:mm A'));
				console.log(moment(endDateTimestamp).format('hh:mm A'));
				$scope.input.startTime = moment(startDateTimestamp).format('hh:mm A'); // set start time
				
				$scope.startTimeChange($scope.input.startTime);
				//$scope.input.endTime = moment(endDateTimestamp).format('hh:mm A'); // set end time
				
				/**make logic to make list from comma seperated string*/
				var array = $scope.emailList.split(',');
				array.forEach(function(element) {
					  console.log(element);
					  $scope.baUserDetailsList.push({primaryEmail:element});
					});
				
				$scope.input.baUserDetailsList = $scope.baUserDetailsList;
				console.log("list.............."+$scope.input.baUserDetailsList);
				/***/
			});
		 }
	  }
	 
	$scope.momentLogicForDate = function(selectedTimezone){
		 $scope.today=moment.tz(new Date(), selectedTimezone);
		 $scope.setValidFromDate = ($scope.today.month()+1)+'/'+$scope.today.date()+'/'+$scope.today.year();
		 $scope.input.startDate = $scope.setValidFromDate;
		 $scope.input.endDate = $scope.setValidFromDate;
		 
		 console.log(moment.tz.names());  // Get list of all available time zone names
		 $scope.timezonesList = moment.tz.names();
		 
		 $scope.timings = [{value:'12:00 AM',viewValue:'12:00 AM'},{value:'12:30 AM',viewValue:'12:30 AM'},
		 {value:'01:00 AM',viewValue:'01:00 AM'},{value:'01:30 AM',viewValue:'01:30 AM'},
		 {value:'02:00 AM',viewValue:'02:00 AM'},{value:'02:30 AM',viewValue:'02:30 AM'},
		 {value:'03:00 AM',viewValue:'03:00 AM'},{value:'03:30 AM',viewValue:'03:30 AM'},
		 {value:'04:00 AM',viewValue:'04:00 AM'},{value:'04:30 AM',viewValue:'04:30 AM'},
		 {value:'05:00 AM',viewValue:'05:00 AM'},{value:'05:30 AM',viewValue:'05:30 AM'},
		 {value:'06:00 AM',viewValue:'06:00 AM'},{value:'06:30 AM',viewValue:'06:30 AM'},
		 {value:'07:00 AM',viewValue:'07:00 AM'},{value:'07:30 AM',viewValue:'07:30 AM'},
		 {value:'08:00 AM',viewValue:'08:00 AM'},{value:'08:30 AM',viewValue:'08:30 AM'},
		 {value:'09:00 AM',viewValue:'09:00 AM'},{value:'09:30 AM',viewValue:'09:30 AM'},
		 {value:'10:00 AM',viewValue:'10:00 AM'},{value:'10:30 AM',viewValue:'10:30 AM'},
		 {value:'11:00 AM',viewValue:'11:00 AM'},{value:'11:30 AM',viewValue:'11:30 AM'},
		 {value:'12:00 PM',viewValue:'12:00 PM'},{value:'12:30 PM',viewValue:'12:30 PM'},
		 {value:'01:00 PM',viewValue:'01:00 PM'},{value:'01:30 PM',viewValue:'01:30 PM'},
		 {value:'02:00 PM',viewValue:'02:00 PM'},{value:'02:30 PM',viewValue:'02:30 PM'},
		 {value:'03:00 PM',viewValue:'03:00 PM'},{value:'03:30 PM',viewValue:'03:30 PM'},
		 {value:'04:00 PM',viewValue:'04:00 PM'},{value:'04:30 PM',viewValue:'04:30 PM'},
		 {value:'05:00 PM',viewValue:'05:00 PM'},{value:'05:30 PM',viewValue:'05:30 PM'},
		 {value:'06:00 PM',viewValue:'06:00 PM'},{value:'06:30 PM',viewValue:'06:30 PM'},
		 {value:'07:00 PM',viewValue:'07:00 PM'},{value:'07:30 PM',viewValue:'07:30 PM'},
		 {value:'08:00 PM',viewValue:'08:00 PM'},{value:'08:30 PM',viewValue:'08:30 PM'},
		 {value:'09:00 PM',viewValue:'09:00 PM'},{value:'09:30 PM',viewValue:'09:30 PM'},
		 {value:'10:00 PM',viewValue:'10:00 PM'},{value:'10:30 PM',viewValue:'10:30 PM'},
		 {value:'11:00 PM',viewValue:'11:00 PM'},{value:'11:30 PM',viewValue:'11:30 PM'}
		 ];
		 
		 
		 
		 const dateTimeUtc = moment("2017-06-05T19:41:03Z").utc();
		 //document.querySelector(".js-TimeUtc").innerHTML = dateTimeUtc.format("ddd, DD MMM YYYY HH:mm:ss");

		 /**new code for timezone dropdown starts*/
		 $scope.filtered =[];
		 angular.forEach(moment.tz.names(),function(value,key){
			 if (!(/^Etc/.test(value))) {
		            $scope.filtered.push(value);
		        }
		 });
		 const selectorOptions = $scope.filtered
		   .reduce((memo, tz) => {
		     memo.push({
		       name: tz,
		       offset: moment.tz(tz).utcOffset()
		     });
		     
		     return memo;
		   }, [])
		   .sort((a, b) => {
		     return a.offset - b.offset
		   })
		   .reduce((memo, tz) => {
		     const timezone = tz.offset ? moment.tz(tz.name).format('Z') : '';

		     return memo.concat(`<option value="${tz.name}">(UTC${timezone}) ${tz.name}</option>`);
		   }, "");

		 document.querySelector(".js-Selector").innerHTML = selectorOptions;

		 document.querySelector(".js-Selector").addEventListener("change", e => {
		   const timestamp = dateTimeUtc.unix();
		   const offset = moment.tz(e.target.value).utcOffset() * 60;
		   const dateTimeLocal = moment.unix(timestamp + offset).utc();
		   $scope.input.timezone = e.target.value;

		   //document.querySelector(".js-TimeLocal").innerHTML = dateTimeLocal.format("ddd, DD MMM YYYY HH:mm:ss");
		 });

		 document.querySelector(".js-Selector").value = moment.tz.guess(); // guess current timezone

		 const event = new Event("change");
		 document.querySelector(".js-Selector").dispatchEvent(event);
		 /**new code for timezone dropdown ends*/
		 
	} 
	 
	 
	$scope.onLoad = function(){
		 $scope.input.timezone = moment.tz.guess(); // guess current timezone
		 $scope.momentLogicForDate(moment.tz.guess());
		
	}
	
	$scope.onLoad();
	
	$scope.timeZoneChange = function(timezone){
		 $scope.momentLogicForDate(timezone);
	}
	 
	 $scope.input.baUserDetailsList = angular.copy(localStorageService.get('baUserDetailsList'));
	 angular.forEach($scope.input.baUserDetailsList,function(value,key){
		 if(value.primaryEmail!=''){
			 $scope.emailList.push(value.primaryEmail);
		 }else if(value.secondaryEmail!=''){
			 $scope.emailList.push(value.secondaryEmail);
		 }
	 });
	 

	 
	 $scope.startTimeChange = function(startTime,$event){
		 $scope.endTimings = [{value:'12:00 AM',viewValue:'12:00 AM'},{value:'12:30 AM',viewValue:'12:30 AM'},
			 {value:'01:00 AM',viewValue:'01:00 AM'},{value:'01:30 AM',viewValue:'01:30 AM'},
			 {value:'02:00 AM',viewValue:'02:00 AM'},{value:'02:30 AM',viewValue:'02:30 AM'},
			 {value:'03:00 AM',viewValue:'03:00 AM'},{value:'03:30 AM',viewValue:'03:30 AM'},
			 {value:'04:00 AM',viewValue:'04:00 AM'},{value:'04:30 AM',viewValue:'04:30 AM'},
			 {value:'05:00 AM',viewValue:'05:00 AM'},{value:'05:30 AM',viewValue:'05:30 AM'},
			 {value:'06:00 AM',viewValue:'06:00 AM'},{value:'06:30 AM',viewValue:'06:30 AM'},
			 {value:'07:00 AM',viewValue:'07:00 AM'},{value:'07:30 AM',viewValue:'07:30 AM'},
			 {value:'08:00 AM',viewValue:'08:00 AM'},{value:'08:30 AM',viewValue:'08:30 AM'},
			 {value:'09:00 AM',viewValue:'09:00 AM'},{value:'09:30 AM',viewValue:'09:30 AM'},
			 {value:'10:00 AM',viewValue:'10:00 AM'},{value:'10:30 AM',viewValue:'10:30 AM'},
			 {value:'11:00 AM',viewValue:'11:00 AM'},{value:'11:30 AM',viewValue:'11:30 AM'},
			 {value:'12:00 PM',viewValue:'12:00 PM'},{value:'12:30 PM',viewValue:'12:30 PM'},
			 {value:'01:00 PM',viewValue:'01:00 PM'},{value:'01:30 PM',viewValue:'01:30 PM'},
			 {value:'02:00 PM',viewValue:'02:00 PM'},{value:'02:30 PM',viewValue:'02:30 PM'},
			 {value:'03:00 PM',viewValue:'03:00 PM'},{value:'03:30 PM',viewValue:'03:30 PM'},
			 {value:'04:00 PM',viewValue:'04:00 PM'},{value:'04:30 PM',viewValue:'04:30 PM'},
			 {value:'05:00 PM',viewValue:'05:00 PM'},{value:'05:30 PM',viewValue:'05:30 PM'},
			 {value:'06:00 PM',viewValue:'06:00 PM'},{value:'06:30 PM',viewValue:'06:30 PM'},
			 {value:'07:00 PM',viewValue:'07:00 PM'},{value:'07:30 PM',viewValue:'07:30 PM'},
			 {value:'08:00 PM',viewValue:'08:00 PM'},{value:'08:30 PM',viewValue:'08:30 PM'},
			 {value:'09:00 PM',viewValue:'09:00 PM'},{value:'09:30 PM',viewValue:'09:30 PM'},
			 {value:'10:00 PM',viewValue:'10:00 PM'},{value:'10:30 PM',viewValue:'10:30 PM'},
			 {value:'11:00 PM',viewValue:'11:00 PM'},{value:'11:30 PM',viewValue:'11:30 PM'}];
		 
		 
		 var index=parseInt(event.target.value);
		 
		 for(var i=0;i<index;i++){
			 $scope.endTimings.push($scope.endTimings[i]);
			
		 }
		 $scope.endTimings= $scope.endTimings.splice(index);
		 
		 console.log($scope.endTimings);
		 
		 $scope.temptimesend=JSON.parse(JSON.stringify($scope.endTimings));
		 for(var i=0;i<$scope.temptimesend.length;i++){
			 if(i===0){
				 $scope.temptimesend[i].viewValue=$scope.temptimesend[i].viewValue+' (0 minute)'
			 }
			 if(i===1){
				 $scope.temptimesend[i].viewValue=$scope.temptimesend[i].viewValue+' (30 minutes)'
			 }
			 if(i===2){
				 $scope.temptimesend[i].viewValue=$scope.temptimesend[i].viewValue+' (1 hour)'
			 }
			 if(i>2){
			 $scope.temptimesend[i].viewValue=$scope.temptimesend[i].viewValue+' ('+i*0.5+' hours)';
			 }
		 }
		 
		 
		 
		 console.log($scope.input.endTime);
		 if(startTime.value!='' && startTime.value!=undefined){
			 $scope.isStartTimeSelected = true;
		 }else{
			 $scope.isStartTimeSelected = false;
		 }
		 
//		 var filteredTime = $scope.timings.filter(function(time) {
//			 $scope.startMomentTime = moment(startTime.value, "hh:mm a");
//			 $scope.momenttime = moment(time, "hh:mm a");
//		   return $scope.momenttime > $scope.startMomentTime;
//		 });
//		 
//		 $scope.endTimings = filteredTime;
		 
		 $scope.initEndTime=JSON.parse(JSON.stringify($scope.temptimesend[1]));
		 
		 $scope.time=$scope.initEndTime;
		 
		 $scope.endTimeSelected($scope.time.value);
		 
//		 console.log($scope.time)
		 
		 
	 }
	 
	 
	 $scope.endTimeSelected=function(endTime){
		 
		 
		 
		 $scope.input.endDate=$scope.input.startDate;
		 
		 console.log(endTime);
		 if(endTime.includes('AM') && $scope.input.startTime.viewValue.includes('PM')){
			 var end=new Date($scope.input.endDate);
			 end.setDate(end.getDate()+1);
			 end.setMonth(end.getMonth()+1);
			 
			 console.log(end.getMonth());
			 
			 $scope.input.endDate=end.getMonth()+'/'+end.getDate()+'/'+end.getFullYear();
		 }
	 }
	 
/**------file upload section start*/
	
	$scope.addFileRow = function(){
		$scope.totalSize = 0;
		$scope.delKey;
		angular.forEach($scope.files, function (item, key) {
			$scope.totalSize = $scope.totalSize + item.size;
			$scope.delKey = item;
		});
		
		if($scope.totalSize >= 5000000){
			jAlert(jQuery.i18n.prop('validate_total_file_size'));
			$scope.fileList.splice($scope.fileList.indexOf($scope.delKey), 1);
			$scope.files.splice($scope.files.indexOf($scope.delKey), 1);
			return;
		}
		else if($scope.fileList.length > 9){
            jAlert(jQuery.i18n.prop('validate_upload'));
            return;
		}else{
            $scope.fileList.push({documentId:""});
		}
	};
	
	$scope.removeFileRow = function(data, index){
		$scope.fileList.splice($scope.fileList.indexOf(data), 1);
	};
	
	$scope.$on("fileSelected", function (event, args) {
        $scope.$apply(function () {            
              $scope.files[args.index]=args.file;
       });
        $scope.totalSize = 0;
		$scope.delKey;
		$scope.tempKey;
		angular.forEach($scope.files, function (item, key) {
			$scope.totalSize = $scope.totalSize + item.size;
			$scope.delKey = item;
			$scope.tempKey = key;
		});
		if($scope.totalSize >= 5000000){
			jAlert(jQuery.i18n.prop('validate_total_file_size'));
			$scope.files.splice($scope.files.indexOf($scope.delKey), 1);
			$scope.$apply(function () {            
				$scope.fileList.splice($scope.tempKey, 1);
	       });
			return;
		}
	});
	
	/**------file upload section end*/
	
	advWebinarHomeMailFactory.getAllTemplates(function(response){
		$scope.templateList = response.data.LIST;
	});
	
	$scope.sendMail = function() {
		/** for tinyMce*/
		var entirePageHTML = tinymce.get("texteditor").getContent();
		var bodyHtml = /<body.*?>([\s\S]*)<\/body>/.exec(entirePageHTML)[1];
		$scope.input.messageBody = bodyHtml;
		/**-----------*/
		
	if($scope.webinarMail.$valid){
		if($scope.validateEmailForm()){
			var i = 0;
			var formData = new FormData();
			//Add all files into formData//
			angular.forEach($scope.files, function (item) {
				 formData.append('files' + i, item);
				 i = i + 1;
			});
			
			
			
		$scope.input.startDateTime = $scope.input.startTime.value+" "+$scope.input.startDate;
		$scope.input.endDateTime = $scope.time.value+" "+$scope.input.endDate;
		
		$scope.input.emailList = $scope.emailList;
			
		formData.append("calendarrequest",angular.toJson($scope.input));
		fileUploadService.uploadFiles('/brandadvocate/manage/details/v1/sendcalinvite', formData).success(function(response){
			if(response.statusCode=="OK"){
				jAlert(jQuery.i18n.prop('email_campaign_email_sent'),jQuery.i18n.prop('common_success'),function(r){
				//ngDialog.close();
				if(r){
				$location.path('/brandInfo').search('');
				$scope.$apply(); // used because location was not changing.
				}
				//window.location.reload(true);  // to get tinymce (no need to do ctrl+f5)
				//$scope.reset();
				});
			}
		}).error(function(result){
		    jAlert(response.msg);
		});
	}
	}else{
		angular.element("[name='" + $scope.webinarMail.$name + "']").find('.ng-invalid:visible:first').focus();
	        return false;
		}
		
	}
	
	$scope.saveMailTemplateData = function(){
		/** for tinyMce*/
		var entirePageHTML = tinymce.get("texteditor").getContent();
		var bodyHtml = /<body.*?>([\s\S]*)<\/body>/.exec(entirePageHTML)[1];
		$scope.input.messageBody = bodyHtml;
		/**-----------*/
		
		var i = 0;
		var formData = new FormData();
		//Add all files into formData//
		angular.forEach($scope.files, function (item) {
			 formData.append('files' + i, item);
			 i = i + 1;
		});
		
	formData.append("templaterequest",angular.toJson($scope.input));
	formData.append("subject",$scope.input.subject);
	
	$scope.formData = formData;
	
	$rootScope.dialog = ngDialog.open({
	    template: 'html/home/advocate_home_mail_template.html',
	    controller: 'advHomeMailTemplateCtrl',
	    closeByDocument: false,
	    showClose: false,
	    scope : $scope
	});
	
	}
	
	$scope.validateEmailForm = function(){
		/*if($scope.emailList === undefined || $scope.emailList.length < 0 || $scope.emailList == "" || $scope.emailList[0] == ""){
			jAlert(jQuery.i18n.prop('email_campaign_validate_email'));
			return false;
		}
		else if($scope.input.subject === undefined || $scope.input.subject == ""){
			jAlert(jQuery.i18n.prop('email_campaign_validate_subject'));
			return false;
		}
		else if($scope.input.messageBody === undefined || $scope.input.messageBody == ""){
			jAlert(jQuery.i18n.prop('email_campaign_validate_body'));
			return false;
		}*/
		if($scope.input.startTime === undefined || $scope.input.startTime == ""){
			jAlert(jQuery.i18n.prop('validate_start_time'));
			return false;
		}else{
			return true;
		}
	};
	
	$scope.resetMail = function(urlPath){
		$scope.input.subject = '';
		tinyMCE.get('texteditor').setContent("");
		$scope.templateId='';
		$scope.fileList = [];
		$scope.input.location = '';
		$scope.input.startTime = '';
		$scope.input.endTime = '';
		$scope.isStartTimeSelected = false;
		$scope.setValidFromDate = ($scope.today.month()+1)+'/'+$scope.today.date()+'/'+$scope.today.year();
		$scope.input.startDate = $scope.setValidFromDate;
		$scope.input.endDate = $scope.setValidFromDate;
	}
	
	$scope.getTemplateData = function(templateId){
		if(templateId != "" && templateId !=undefined && templateId != null ){
		advWebinarHomeMailFactory.getTemplateDetails({templateid:templateId},function(response){
			tinyMCE.get('texteditor').setContent(response.data.contents);
			$scope.input.subject = response.data.subject;
			//$scope.fileList = response.data.documents;
			$scope.isTemplateSelected = true;
		});
	}else{
		tinyMCE.get('texteditor').setContent("");
		$scope.input.subject = '';
		$scope.isTemplateSelected = false;
	}
}
	
	$scope.cancel = function(urlPath){
		//ngDialog.close();
		//$route.reload();
		$location.path(urlPath);
		//window.location.reload(true);  // to get tinymce (no need to do ctrl+f5)
		//$location.path(urlPath);	
	
	}
	
	$scope.filterChangeStartDate = function(){
		$scope.setValidFromDate = $scope.input.startDate;
		$scope.input.endDate = $scope.input.startDate;
	}
	
	
}]);

