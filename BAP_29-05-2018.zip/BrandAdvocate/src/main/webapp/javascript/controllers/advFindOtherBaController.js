'use strict';

baControllers.controller('advFindOtherBaCtrl',['$scope','$http','$location','$rootScope', '$route', 'ngTableParams','ngDialog', '$filter', 'advFindOtherBaFactory','filterFilter','localStorageService', function($scope, $http, $location, $rootScope, $route, ngTableParams, ngDialog, $filter, advFindOtherBaFactory,filterFilter,localStorageService){

	
	/**Global Variables*/
	$scope.input = new advFindOtherBaFactory();
	$scope.searchDropdownsInput = new advFindOtherBaFactory();
	$scope.baList = [];
	$scope.inputRequest = new advFindOtherBaFactory();
	$scope.offset = 0;
	$scope.count = 10;
	$scope.srtng = "desc";
	$scope.IsVisible_nodata = true;
	$scope.allDataCount = 0;
	$scope.countForToggle = 0;
	$scope.allSearchDataCount = '';
	$scope.search = "";
	$rootScope.urlChange = false;
	$scope.isEnable = false;
	
	$scope.checkBoxStatus = false;
	$scope.countryDropDisabled = true;
	$scope.showSelectAllCheckBox = false;
	
	/**Table headers i18N*/
	$scope.lLastName = jQuery.i18n.prop('last_name');
	$scope.lFirstName = jQuery.i18n.prop('first_name');
	$scope.lPreferredFirstName = jQuery.i18n.prop('preferred_first_name');
	$scope.lDivision = jQuery.i18n.prop('org_unit');
	$scope.lEmail = jQuery.i18n.prop('common_email');
	$scope.lSecondaryEmail = jQuery.i18n.prop('secondary_email');
	$scope.lRegion = jQuery.i18n.prop('region');
	$scope.lCountry = jQuery.i18n.prop('country');
	$scope.lFacilityName = jQuery.i18n.prop('facility_name');
	$scope.lBuildingName = jQuery.i18n.prop('common_building');
	$scope.lBrandAdvocateStatus = jQuery.i18n.prop('brand_advocate_status');
	$scope.lJobKeywords = jQuery.i18n.prop('job_keywords');
	$scope.lBaStatus = jQuery.i18n.prop('common_ba_status');
	
	$scope.emailList = [];
	$scope.emailListForMassMail = [];
	$scope.firstNameListForMassMail = [];
	$scope.lastNameListForMassMail = [];
	$scope.selectedRecordsListForExportToExcel = [];
	$scope.fullNameList = [];
	$scope.organizationNameListDB = [];
	$scope.organizationNameList = [];

	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName;
	
	$scope.tooltipForExportToExcel = "Export Selected";
	
	$scope.loadData = function(){
	/*	*//**Logic to get data for search dropdown's start*//*
		$scope.searchDropdownsInput.sortOrder = 'desc';
		$scope.searchDropdownsInput.globalSearch = $scope.search;
		$scope.searchDropdownsInput.isActive = 'Y';
		$scope.searchDropdownsInput.criteriaFlag = false;
		advFindOtherBaFactory.getAllAdminDetails({manageadminrequest:$scope.searchDropdownsInput}, function(result){
			$scope.listForDropdowns = result.data.LIST;
			
			*//**Logic to prepare full name list and organization name list from DB data start*//*
			angular.forEach($scope.listForDropdowns,function(value,key){
				$scope.fullNameList.push(value.lastName+" "+value.firstName);
				
				if(value.organizationName !=''){
					$scope.organizationNameListDB.push({"orgId":key,"orgName":value.organizationName});
				}
			});
			
			var lookup = {};
			for (var item, i = 0; item = $scope.organizationNameListDB[i++];) {
			  var orgName = item.orgName;
			  var orgId = item.orgId;
				  if (!(orgName in lookup)) {
				    lookup[orgName] = 1;
				    $scope.organizationNameList.push({"orgId":orgId,"orgName":orgName});
				  }
				}
			*//**Logic to prepare full name list and organization name list from DB data end*//*
			
		});
		*//**Logic to get data for search dropdown's end*//*
		
		
		*//**Get master data code starts*//*
		advFindOtherBaFactory.getRegions(function(response){
			$scope.regionList = response.data.LIST;	
		});
		
		advFindOtherBaFactory.getCountries(function(response){
			$scope.countryList = response.data.LIST;	
		});
		*//**Get master data code ends*/
		
		advFindOtherBaFactory.getInitialDataForFindBA(function(response){
			$scope.fullNameList = response.data.userNameList;
			$scope.organizationNameList = response.data.organizationList;
			$scope.regionList = response.data.regionList;
			$scope.countryList = response.data.countryList;
		});
		
	}
	
	$scope.loadData();
	
	$scope.searchedData = function(fromSearch){
		$scope.selectedAll = false;
		$scope.inputRequest = {};
		//$scope.inputRequest.pageNumber = $scope.offset;
		//$scope.inputRequest.records = $scope.count;
		$scope.inputRequest.sortOrder = 'asc';
		$scope.inputRequest.globalSearch = $scope.search;
		$scope.inputRequest.isActive = 'Y';
		$scope.inputRequest.criteriaFlag = true;
		
		$scope.inputRequest.regionId = fromSearch.regionIdFromSearch;
		$scope.inputRequest.countryId = fromSearch.countryIdFromSearch;
		$scope.inputRequest.fullName= fromSearch.fullNameFromSearch;
		$scope.inputRequest.organizationName= fromSearch.orgNameFromSearch;
		$scope.inputRequest.preferenceName = fromSearch.preferenceNameFromSearch;
		
		advFindOtherBaFactory.getAllAdminDetails({manageadminrequest:$scope.inputRequest}, function(result){
			$scope.baListTemp = result.data.LIST;
			var data = $scope.baListTemp;
			
			$scope.baList = $scope.baListTemp;   //set list to iterate on UI.
			
			angular.forEach($scope.baList, function(value, key){
				if(value.baSince){
					value.baSince = $filter('date')(value.baSince, "MM/dd/yyyy");
				}
			});
		
			if ($scope.baList != null && $scope.baList.length > 0) {
	             $scope.IsVisible_nodata = false;
	             $scope.showSelectAllCheckBox = true;
	    }else{
	             $scope.IsVisible_nodata = true;
	             $scope.showSelectAllCheckBox = false;
	    }
		
		var length = result.data.COUNT;
		$scope.totalDataCount = result.data.COUNT;
		$scope.total = Math.ceil(length/$scope.count);
		if ($scope.count < 0) 
		{
			$scope.total = 1;
           $scope.allDataCount=result.data.COUNT;
       } else
       {
       	$scope.allDataCount=$scope.count;
       }
		$scope.currentPage = $scope.offset+1;
		//** Sorting and Filtering *//*
		$scope.tableParams = new ngTableParams(
			{
				page : 1,
				count : $scope.allDataCount,
				/*sorting: {
					cwsUserId: 'desc'     // initial sorting
		        }*/
			},
			{
				 filterSwitch: true,
		         total: 0, //data.length, // length of data
				// filterDelay : 0,
			      getData: function($defer, params) {
			    	// use build-in angular filter
			    	  function validateKey(e,k,a){
			    		  return  params.filter()[k]!="";
			    	  }
			    	  //var data = angular.copy($scope.baList);
			    	  	var filteredData = Object.keys(params.filter()).some(validateKey) ?  $filter('filter')(data, params.filter()) : $scope.baList;
	                    var orderedData = !angular.equals(params.sorting(), {}) ? $filter('orderBy')(filteredData, params.orderBy()) : filteredData;
	                    params.total(orderedData.length);
	                    // set total for recalc pagination
	                    $defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
			      },
		});
	});
		
	};
	
	$scope.getSearchedData = function(){
		$scope.fromSearch = [];
		
		/*if($scope.regionList.regionId!=undefined){
			$scope.fromSearch.regionIdFromSearch = $scope.regionList.regionId.selected;
		}
		if($scope.countryList.countryId!=undefined){
			$scope.fromSearch.countryIdFromSearch = $scope.countryList.countryId.selected;
		}
		$scope.fromSearch.fullNameFromSearch = $scope.input.fullName;
		if($scope.organizationNameList.orgName!=undefined){
			$scope.fromSearch.orgNameFromSearch = $scope.organizationNameList.orgName.selected;
		}*/
		if($scope.input.fullName!='' && $scope.input.fullName!=undefined){
			$scope.fromSearch.fullNameFromSearch = $scope.input.fullName.replace(/,/g,"");
		}
		if($scope.input.regionName!=null && $scope.input.regionName!=undefined && $scope.input.regionName!=''){
			angular.forEach($scope.regionList,function(value,key){
			if(value.regionName == $scope.input.regionName){
				$scope.fromSearch.regionIdFromSearch = value.regionId;
			}
			});
		}
		
		if($scope.input.countryName!=null && $scope.input.countryName!=undefined && $scope.input.countryName!=''){
			angular.forEach($scope.countryList,function(value,key){
			if(value.countryName == $scope.input.countryName){
			$scope.fromSearch.countryIdFromSearch = value.countryId;
			}
			});
		}
		
		if($scope.input.orgName!=null && $scope.input.orgName!=undefined && $scope.input.orgName!=''){
			$scope.fromSearch.orgNameFromSearch = $scope.input.orgName;
		}
		
		
		$scope.fromSearch.preferenceNameFromSearch = "Brand event communications";   // get data on the basis of given preference name in all case.
		
		$scope.searchedData($scope.fromSearch);
	}
	
	
	/**No. of records(5,10,20,All) changed*/
	$scope.updateRecords = function(){
		$scope.offset = 0;
		$scope.currentPage = 1;
		$scope.selectedAll = false;
		$scope.countForToggle = 0;
		$scope.loadData();
	};

	/**Pagination action*/
	$scope.PagingAct = function(page) {
		$scope.selectedAll = false;
		$scope.countForToggle = 0;
		$scope.offset = page-1;
		$scope.loadData();		
	}
	
	/** Common Search */
    $scope.baSearchChange = function(){
		$scope.offset = 0;
		$scope.selectedAll = false;
		$scope.countForToggle = 0;
		$scope.loadData();
	};
	
	/**Select-Unselect all checkboxes*/
	$scope.selectAllCheckbox = function () {
		
		if ($scope.selectedAll) {
			$scope.countForToggle = 0;
			$scope.selectedAll = false;		
			$scope.selectedRecordsListForExportToExcel = [];
			/**--------------Mass mail code starts----------*/
			$scope.emailListForMassMail = [];
			$scope.firstNameListForMassMail = [];
			$scope.lastNameListForMassMail = [];
			$scope.checkBoxStatus = false;
			/**--------------Mass mail code ends----------*/
		}else {
			$scope.countForToggle = $scope.totalDataCount;
			$scope.selectedAll = true;	
			$scope.selectedRecordsListForExportToExcel = angular.copy($scope.baList);
			
			/**--------------Mass mail code starts----------*/
			angular.forEach($scope.baList, function(value, key){
				if(value.primaryEmail!='' && value.primaryEmail!=undefined){
					$scope.emailListForMassMail.push(value.primaryEmail);
				}else{
					$scope.emailListForMassMail.push(value.secondaryEmail);
				}
				$scope.firstNameListForMassMail.push(value.firstName);
				$scope.lastNameListForMassMail.push(value.lastName);
			});
			$scope.checkBoxStatus = true;
			/**--------------Mass mail code ends----------*/
			
		}	
		
			angular.forEach($scope.baList, function (item) {
				item.Selected = $scope.selectedAll;
			});
	};
	
	
	$scope.changeToggleStatus = function(itemSelected, index, baData){
		 var primaryEmailFromToggle = baData.primaryEmail;
		 var secondaryEmailFromToggle = baData.secondaryEmail;
		 var firstNameFromToggle = baData.firstName;
		 var lastNameFromToggle = baData.lastName;
		
		if(itemSelected){
			$scope.countForToggle-- ;
			
			var index = $scope.selectedRecordsListForExportToExcel.indexOf(baData);
			$scope.selectedRecordsListForExportToExcel.splice(index, 1);
			console.log("after... "+$scope.selectedRecordsListForExportToExcel);
			
			/**--------------Mass mail code starts----------*/
			if(primaryEmailFromToggle!='' && primaryEmailFromToggle!=undefined){
				var index = $scope.emailListForMassMail.indexOf(primaryEmailFromToggle);
				$scope.emailListForMassMail.splice(index, 1);
			}else{
				var index = $scope.emailListForMassMail.indexOf(secondaryEmailFromToggle);
				$scope.emailListForMassMail.splice(index, 1);
			}
			
			console.log("after... "+$scope.emailListForMassMail);

			var index = $scope.firstNameListForMassMail.indexOf(firstNameFromToggle);
			$scope.firstNameListForMassMail.splice(index, 1);
			console.log("after... "+$scope.firstNameListForMassMail);

			var index = $scope.lastNameListForMassMail.indexOf(lastNameFromToggle);
			$scope.lastNameListForMassMail.splice(index, 1);
			console.log("after... "+$scope.lastNameListForMassMail);

			if($scope.selectedAll){
				$scope.checkBoxStatus = true;
			}else{
				$scope.checkBoxStatus = false;
			}
			/**--------------Mass mail code ends----------*/
			
		}else{
			$scope.countForToggle++ ;
			
			$scope.selectedRecordsListForExportToExcel.push(baData);
			
			/**--------------Mass mail code starts----------*/
			if(primaryEmailFromToggle!='' && primaryEmailFromToggle!=undefined){
				$scope.emailListForMassMail.push(primaryEmailFromToggle);
			}else{
				$scope.emailListForMassMail.push(secondaryEmailFromToggle);
			}
			console.log("before email :.... "+$scope.emailListForMassMail);

			$scope.firstNameListForMassMail.push(firstNameFromToggle);
			console.log("before firstname :.... "+$scope.firstNameListForMassMail);

			$scope.lastNameListForMassMail.push(lastNameFromToggle);
			console.log("before lastname :.... "+$scope.lastNameListForMassMail);

			$scope.checkBoxStatus = true;
			/**--------------Mass mail code ends----------*/
		}
		console.log("selected records list for export to excel.......::::::"+ $scope.selectedRecordsListForExportToExcel);
		console.log("email list.......::::::"+ $scope.emailListForMassMail);
		console.log("first name list.......::::::"+ $scope.firstNameListForMassMail);
		console.log("last name list.......::::::"+ $scope.lastNameListForMassMail);
		
		
		$scope.finalList = angular.copy($scope.baList);
		$scope.finalList = filterFilter($scope.finalList,$scope.search);
		if($scope.finalList.length != 0 && $scope.countForToggle>=$scope.finalList.length && !itemSelected){
			$scope.selectedAll = true;
		}else{
			$scope.selectedAll = false;
		}
	}
	
	

	$scope.exportToExcel = function(){
		if($scope.selectedRecordsListForExportToExcel.length>0){
			$scope.inputRequest = {};
			/** set parameters if wants to get limited data*/
			//$scope.inputRequest.pageNumber = $scope.offset;
			//$scope.inputRequest.records = $scope.count;
			//$scope.inputRequest.sortOrder = 'desc';
			/**---------------------------------------------*/
			$scope.inputRequest.lang = 'en';
			
			angular.forEach($scope.selectedRecordsListForExportToExcel,function(value,key){
				delete value.registrationDate;
				delete value.modifiedDate;
				delete value.preferences;
			});
			
			
			$scope.inputRequest.selectedRecordsListForExportToExcel = $scope.selectedRecordsListForExportToExcel;
			//window.location.href = $rootScope.urlContext+'/brandadvocate/manage/details/v1/exporttoexcel?manageadminrequest='+angular.toJson($scope.inputRequest);
			$http({
			    url: '/brandadvocate/manage/details/v1/exporttoexcelforfindotherba',
			    method: "POST",
			    data: angular.toJson($scope.inputRequest), //this is your json data string
			    headers: {
			       'Content-type': 'application/json'
			    },
			    responseType: 'arraybuffer'
			}).success(function (data, status, headers, config) {
			    var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"});
			    var todaysDate = new Date();
			    saveAs(blob, "BrandAdvocateDetails_"+todaysDate+".xlsx");
			    //var objectUrl = URL.createObjectURL(blob);
			    //window.open(objectUrl);
			}).error(function (data, status, headers, config) {
			    //upload failed
			});

		}else{
			jAlert(jQuery.i18n.prop('validate_export'));
		}
		
	};
	
	$scope.getRegionsByCountryId = function(countryId){
    	if(countryId!=null && countryId!=undefined){
    	advFindOtherBaFactory.getRegionsByCountryId({countryid:countryId},function(response){
    		$scope.regionListResponse = response.data.LIST;
    		angular.forEach($scope.regionListResponse,function(value,key){
    			$scope.input.regionId=value.regionId;
    		});
    	});
    	}else{
    		$scope.input.regionId = "";
    		$scope.input.countryId = "";
    	}
    	
    }

    $scope.getCountriesByRegionId = function(regionId){
    	if(regionId!=null && regionId!=undefined){
    		advFindOtherBaFactory.getCountriesByRegionId({regionid:regionId},function(response){
    		$scope.countryList = response.data.LIST;	
    		$scope.countryDropDisabled = false;
    	});
    	}else{
    		$scope.input.countryId = "";
    		$scope.input.regionId = "";
    		$scope.countryDropDisabled = true;
    	}
    }
	
	
	$scope.clearData = function(){
		$scope.input.fullName = '';
		/*$scope.organizationNameList.orgName.selected = undefined;
		$scope.regionList.regionId.selected = undefined;
		$scope.countryList.countryId.selected = undefined;*/
		$scope.inputRequest = {};
		$scope.input.fullName = '';
		$scope.input.orgName = '';
		$scope.input.regionName = '';
		$scope.input.countryName = '';
		//$scope.countryDropDisabled = true;
		$scope.baList = [];
		var data = $scope.baList;
		
		//** Sorting and Filtering *//*
		$scope.tableParams = new ngTableParams(
			{
				page : 1,
				count : $scope.allDataCount,
			},
			{
				 filterSwitch: true,
		         total: 0, //data.length, // length of data
				// filterDelay : 0,
			      getData: function($defer, params) {
			    	// use build-in angular filter
			    	  //var data = angular.copy($scope.baList);
	                    var filteredData = params.filter() ?  $filter('filter')(data, params.filter()) : $scope.baList;
	                    var orderedData = isEmpty(params.sorting()) ? $filter('orderBy')(filteredData, params.orderBy()) : filteredData;
	                    params.total(orderedData.length);
	                    // set total for recalc pagination
	                    $defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
			      },
		});
		
		$scope.showSelectAllCheckBox = false;
		$scope.IsVisible_nodata = true;
		
	}

}]);
