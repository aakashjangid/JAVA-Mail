'use strict';

baControllers.controller('advBulkUploadCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'advBulkUploadFactory','filterFilter','localStorageService','Idle','$cookieStore', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, advBulkUploadFactory,filterFilter,localStorageService,Idle,$cookieStore){

	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName; 
	
	$scope.input = new advBulkUploadFactory();
	
	$scope.validateRegisteredVia = jQuery.i18n.prop('validate_registered_via');
	
	$scope.isRegisteredViaSelected = false;
	
	$scope.uploadByList = [{uploadById:1 ,uploadByName:"CWS ID"},{uploadById:2 ,uploadByName:"Email"}];
	$scope.uploadByName = "CWS ID";  //default checked
	
	$scope.userRegisterQueList = [{registerId:1 ,registerVia:"Manual entry"},{registerId:2 ,registerVia:"Took a brand class"},
		{registerId:3 ,registerVia:"Participated in other training"},{registerId:4 ,registerVia:"Completed Big Yellow Quiz"},{registerId:5 ,registerVia:"Registered through the portal"}];
	
	
	$scope.serviceCall = function(){
		advBulkUploadFactory.bulkUploadForEmailsOrCWSIds({cwsoremailids:$scope.data , iscws:$scope.iscws , username:$scope.loggedInUserName ,registeredvia:$scope.input.registeredVia },function(response){
			console.log("Response from Bulk upload : " +response);
			$scope.response = response.data;
			$rootScope.dialog = ngDialog.open({
			    template: 'html/home/advocate_bulk_upload_response.html',
			    controller: 'advBulkUploadResponseCtrl',
			    closeByDocument: false,
			    showClose: false,
			    scope : $scope
			});
		});
	}
	
	
	$scope.uploadData = function(textAreaValues,uploadBy){
		if($scope.bulkUploadForm.$valid){
			if(textAreaValues!='' && textAreaValues!=undefined && uploadBy == "Email"){
				if(!textAreaValues.replace(/\s/g, '').length){
					// string only contained whitespace (ie. spaces, tabs or line breaks)
				}else{
				var textAreaValuesList = textAreaValues.replace(/\s\s+/g, ' ').trim().split(" ");
				console.log(textAreaValuesList.length);
				if(textAreaValuesList.length>50){
					jAlert(jQuery.i18n.prop('max_length_email_upload'));
				}else{
					$scope.emailIds = textAreaValues;
					$scope.data = $scope.emailIds;
					$scope.iscws = false;
					$scope.serviceCall();
				}
				}
				
				
				/*var splittedTextAreaValue;
				if(textAreaValues.indexOf(' ') >= 0){
					 splittedTextAreaValue = textAreaValues.substr(0,textAreaValues.indexOf(' '));
				}else{
					 splittedTextAreaValue = textAreaValues;
				}
				if($scope.validateEmail(splittedTextAreaValue)){
					$scope.emailIds = textAreaValues;
					$scope.data = $scope.emailIds;
					$scope.iscws = false;
					$scope.serviceCall();
				}*/
			}else if(textAreaValues!='' && textAreaValues!=undefined && uploadBy == "CWS ID"){
				if(!textAreaValues.replace(/\s/g, '').length){
					// string only contained whitespace (ie. spaces, tabs or line breaks)
				}else{
					var textAreaValuesList = textAreaValues.replace(/\s\s+/g, ' ').trim().split(" ");
					console.log(textAreaValuesList.length);
					if(textAreaValuesList.length>100){
						jAlert(jQuery.i18n.prop('max_length_cws_id_upload'));
					}else{
						$scope.cwsIds = textAreaValues;
						$scope.data = $scope.cwsIds;
						$scope.iscws = true;
						$scope.serviceCall();
					}
				}
				
			}else if(textAreaValues==undefined && uploadBy == "CWS ID"){
				jAlert(jQuery.i18n.prop('validate_cws_id_upload'));
			}else if(textAreaValues==undefined && uploadBy == "Email"){
				jAlert(jQuery.i18n.prop('validate_email_upload'));
			}
			
		}else{
			angular.element("[name='" + $scope.bulkUploadForm.$name + "']").find('.ng-invalid:visible:first').focus();
  	        return false;
  		}
	}
	
	 $scope.validateEmail = function(textAreaValue){
	    	var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			if(textAreaValue === undefined || textAreaValue == '' || textAreaValue == null){
				return true;
			}else if (reg.test(textAreaValue) == false) 
			{
				jAlert(jQuery.i18n.prop('enter_valid_email_id'),jQuery.i18n.prop('common_message'),function(){
					
				});
				return false;
			}else{
				return true;
			}
		};
	
	 $scope.resetDetails = function(){
		 //$scope.input.textAreaValues = '';
		 //$scope.uploadByName = "CWS ID";
		 //$scope.input.registeredVia = '';
		 $route.reload();
	 }
	 
	 $scope.registeredViaChange = function(registeredVia){
		 if(registeredVia!='' && registeredVia!=undefined){
			 $scope.isRegisteredViaSelected = true;
		 }else{
			 $scope.isRegisteredViaSelected = false;
		 }
	 }
	 
}]);
