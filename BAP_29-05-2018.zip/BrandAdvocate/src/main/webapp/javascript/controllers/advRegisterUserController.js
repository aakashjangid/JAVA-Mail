'use strict';

baControllers.controller('advRegisterUserCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'advRegisterUserFactory','filterFilter','localStorageService','Idle','$cookieStore','loggedInUserService','$window', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, advRegisterUserFactory,filterFilter,localStorageService,Idle,$cookieStore,loggedInUserService,$window){

	$scope.preferencesArray = [];
	$scope.preferencesList = [];
	$scope.preferences = [];
	$scope.preferencesData = [];
	$scope.preferencesTemp = [];
	$scope.preferencesToSave = [];
	
	$scope.subscriptionPreferencesList = [];
	
	$scope.input = new advRegisterUserFactory();
	
	$scope.input.preferences = [];

	$scope.validateRegisterQue = jQuery.i18n.prop('validate_register_que');
	$scope.validateBuilding = jQuery.i18n.prop('validate_building');
	$scope.enterEmail = jQuery.i18n.prop('enter_email');
	
	$scope.validateClueField = jQuery.i18n.prop('clue_populated_value_modify');
	
	$scope.isClueField = true;
	$scope.checkboxUncheckFlag = false;
	$scope.globalCwsId = '';
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	$rootScope.baExistInPortal  = localStorageService.get("baexistinportal");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName;
	
    $scope.onLoad = function(){
    	
    		var lineHeight = $('.col-md-6').height();
    		console.log('lineHeight',lineHeight);
    		$('.vertical-divider').height(lineHeight+60);
    		
    		$scope.radiobrandadvocate = true; //default radio button check.
        	/** Code for preferences dropdown start*/
        	
        	 $scope.preferencesSettings = {
        		      scrollableHeight: '170px',
        		      scrollable: true,
        		      enableSearch: false
        		    };
        	 
        	 advRegisterUserFactory.getPreferences(function(response){
     			$scope.preferencesList = response.data.LIST;
     			$scope.subscriptionPreferencesList = $scope.preferencesList;
     			angular.forEach($scope.preferencesList,function(value,key){
     				$scope.preferencesData.push({"label":value.preferenceName,"id":value.preferenceId});
     				console.log($scope.preferencesData);
     			});
     			angular.forEach($scope.preferencesData,function(value,key){
     				$scope.preferencesTemp.push({"label":value.label,"id":value.id});
     				console.log($scope.preferencesTemp);
     			});
     			$scope.preferences = $scope.preferencesTemp;
     		});
        	 
        		    $scope.getData = function() {
        		    	$scope.$watch('preferences', function(val) {
        		    		$scope.val = val;
        		    		
        		    });
        		    };
        		    
        		    angular.element(document).on('click', function () {
        		    	if(!isEmpty($scope.val)){
        		    	$scope.getData();
        		    	}
        		    });
        		    
        		    /*angular.forEach($scope.preferencesData,function(value,key){
           		 $scope.preferences = $scope.preferences.push($scope.preferencesData[key]); //dummy Data need to replace with actual value
           		 console.log("dummy Data need to replace with actual value"+$scope.preferences)
       			});*/
        		    
        	  /** Code for preferences dropdown end*/
        		    
        	
        		advRegisterUserFactory.getCountries(function(response){
        				$scope.countryList = response.data.LIST;	
        				$scope.onLoadCountryList = angular.copy($scope.countryList);
        		});
        		
        		advRegisterUserFactory.getRegions(function(response){
        			$scope.regionList = response.data.LIST;	
        			$scope.onLoadRegionList = angular.copy($scope.regionList);
        		});
        		
        		$scope.userRegisterQueList = [{registerId:1 ,registerVia:"Manual entry"},{registerId:2 ,registerVia:"Took a brand class"},
        			{registerId:3 ,registerVia:"Participated in other training"},{registerId:4 ,registerVia:"Completed Big Yellow Quiz"},{registerId:5 ,registerVia:"Registered through the portal"}];
        		
        		$scope.brandAdvocateStatusList = [{brandAdvocateStatusId:1 ,brandAdvocateStatus:"Brand Advocate"},{brandAdvocateStatusId:2 ,brandAdvocateStatus:"CBA"},{brandAdvocateStatusId:3 ,brandAdvocateStatus:"CBA Instructor"}];
        		$scope.input.brandAdvocateStatus = "Brand Advocate";
    	
    	/**get clue data when user logged in*/
    	loggedInUserService.loggedInUserCall('/brandadvocate/user/authentication/v1/getUserInformation').success(function(response){
    		console.log(response.data.userMasterDto);
    		$scope.clueResponse = response.data.userMasterDto;
    		$scope.input.cwsUserId = $scope.clueResponse.cwsUserId;
    		$scope.input.cupId = $scope.clueResponse.cupId;
    		$scope.globalCwsId = $scope.input.cwsUserId;
    		$scope.input.lastName = $scope.clueResponse.lastName; 
    		$scope.input.firstName = $scope.clueResponse.firstName; 
    		$scope.input.preferredFirstName = $scope.clueResponse.preferredFirstName; 
    		$scope.input.organizationName = $scope.clueResponse.organizationName; 
    		//$scope.input.buildingName = $scope.clueResponse.buildingName; 
    		$scope.input.jobKeywords = $scope.clueResponse.jobKeywords; 
    		$scope.input.facilityName = $scope.clueResponse.facilityName; 
    		$scope.clueCountryCode = $scope.clueResponse.countryCode; 
    		$scope.input.affiliationDescription = $scope.clueResponse.affiliationDescription;
    		angular.forEach($scope.countryList,function(value,key){
				if($scope.clueCountryCode == value.countryCode){
					$scope.input.countryId = value.countryId;    //populate country on the basis of country code.
					//$scope.input.regionId = value.regionId;
					if($scope.input.countryId!=null && $scope.input.countryId!=undefined){
				    	advRegisterUserFactory.getRegionsByCountryId({countryid:$scope.input.countryId},function(response){
				    		$scope.input.regionId = response.data.LIST[0].regionId;	
				    	});
				    	}
				}
 			});
    		$scope.input.primaryEmail = $scope.clueResponse.primaryEmail; 
    		
    	});
    		
    }
    
    $scope.onLoad();
    
    
    $scope.getRegionsByCountryId = function(countryId){
    	if(countryId!=null && countryId!=undefined){
    	advRegisterUserFactory.getRegionsByCountryId({countryid:countryId},function(response){
    		$scope.regionList = response.data.LIST;	
    	});
    	}else{
    		$scope.regionList = $scope.onLoadRegionList;
    		$scope.input.regionId='';
    	}
    	
    }

    $scope.getCountriesByRegionId = function(regionId){
    	if(regionId!=null && regionId!=undefined){
    	advRegisterUserFactory.getCountriesByRegionId({regionid:regionId},function(response){
    		$scope.countryList = response.data.LIST;	
    	});
    	}else{
    		$scope.countryList = $scope.onLoadCountryList;
    		$scope.input.countryId='';
    	}
    }
    
	/*$scope.validatePrimaryEmail = function(primaryEmail){
		var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
		if(primaryEmail === undefined || primaryEmail == '' || primaryEmail == null){
			return true;
		}else if (reg.test(primaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_email_id'));
			$scope.input.primaryEmail = '';
			return false;
		}else{
			return true;
		}
	};*/
    
    /**new code changes for subscription preferences starts*/
	
	 $scope.checkboxModel = {
			 webinarCheckbox : true,
		     brandEventCheckbox : true,
		     newsletterCheckbox : true
	 };

	$scope.preferencesCheckboxChange = function(selectedCheckBoxValue,prefCheckBoxValue){
		if(!prefCheckBoxValue){
		if(selectedCheckBoxValue=='webinarCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":1,"preferenceName":"Webinar invitations"});
		}else if(selectedCheckBoxValue=='brandEventCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":2,"preferenceName":"Brand event communications"});
		}else if(selectedCheckBoxValue=='newsletterCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":3,"preferenceName":"Newsletters"});
		}
		}else{
			var index;
			if(selectedCheckBoxValue=='webinarCheckbox'){
				index = $scope.getIndex("Webinar invitations");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='brandEventCheckbox'){
				index = $scope.getIndex("Brand event communications");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='newsletterCheckbox'){
				index = $scope.getIndex("Newsletters");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}
		}
	}
	
	$scope.getIndex = function(val){
		var index = -1;
		var filteredObj = $scope.subscriptionPreferencesList.find(function(item, i){
     	  if(item.preferenceName === val){
     		index = i;
     	  }
     	});
		return index;
	}
	
	/**new code changes for subscription preferences ends*/
	
	$scope.saveDetails = function(){
		if(null!=$scope.globalCwsId){
			$scope.input.cwsUserId = $scope.globalCwsId;
		}
		//get toggle value
		/*console.log("Toggle Value :"+$scope.toggleValue);
		angular.forEach($scope.val,function(value,key){
    		$scope.input.preferences.push({"preferenceId" : value.id});
		})*/
		$scope.preferencesToSave = [];
		angular.forEach($scope.preferences,function(value,key){
			angular.forEach($scope.preferencesList,function(valuePref,keyPref){
				if(value.id == valuePref.preferenceId){
					$scope.preferencesToSave.push({"preferenceId":valuePref.preferenceId,"preferenceName":valuePref.preferenceName});
				}
 			});
		});
		//$scope.input.preferences = $scope.preferencesToSave;
		$scope.input.preferences = $scope.subscriptionPreferencesList;
		if($scope.registerForm.$valid){
			if($scope.validateRegistrationDetails()){
				var saveMsg ;
					saveMsg = 'user_register_as_ba_success';
			
		$scope.input.managedBy = "System";
		$scope.input.loggedInUserName = $scope.loggedInUserName;
		
		advRegisterUserFactory.saveAdminInformation($scope.input,function(response){
			jAlert(jQuery.i18n.prop(saveMsg),jQuery.i18n.prop('common_success'),function(){
				if(response.statusCode == false){
					jAlert(response.msg);
				}if(response.statusCode == "OK"){
					$window.location.href = 'https://brand.cat.com/en/education.html';
				}
			});
		});
	}
	}else{
			angular.element("[name='" + $scope.registerForm.$name + "']").find('.ng-invalid:visible:first').focus();
  	        return false;
  		}

	}
	
	
	/** validation for User fields */
	$scope.validateRegistrationDetails = function(){
			if($scope.input.buildingName == '' || $scope.input.buildingName == undefined){
				jAlert(jQuery.i18n.prop('validate_building'));
				return false;
			}else{
				return true;
			}
	}
	
	$scope.validateSecondaryEmail = function(secondaryEmail){
		//var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
		var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(secondaryEmail === undefined || secondaryEmail == '' || secondaryEmail == null){
			return true;
		}else if (reg.test(secondaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_secondary_email_id'));
			$scope.input.secondaryEmail = '';
			return false;
		}else{
			return true;
		}
	};
	
	/**default check checkbox*/
	//$scope.checkBoxValue=true;
	
	/*$scope.checkBoxChange = function(checkBoxValue){
		if(checkBoxValue){
			$scope.isClueField = true;
			$scope.checkboxUncheckFlag = false;
		}else{
			$scope.isClueField = false;
			$scope.checkboxUncheckFlag = true;
			$scope.input.cwsUserId = '';
		}
	}*/
	
	
	$scope.resetDetails = function(){
		$scope.input.buildingName = '';
		$scope.input.jobKeywords = '';
		$scope.input.comments = '';
		$scope.input.secondaryEmail = '';
		$scope.preferences=[];
		$scope.preferencesList = [];
		$scope.preferencesTemp = [];
		$scope.preferencesData = [];
		advRegisterUserFactory.getPreferences(function(response){
 			$scope.preferencesList = response.data.LIST;
 			angular.forEach($scope.preferencesList,function(value,key){
 				$scope.preferencesData.push({"label":value.preferenceName,"id":value.preferenceId});
 				console.log($scope.preferencesData);
 			});
 			angular.forEach($scope.preferencesData,function(value,key){
 				$scope.preferencesTemp.push({"label":value.label,"id":value.id});
 				console.log($scope.preferencesTemp);
 			});
 			$scope.preferences = $scope.preferencesTemp;
 		});
	}
	
	var myVideo = document.getElementById("video1");
	$scope.playPause = function() { 
	    if (myVideo.paused) 
	        myVideo.play(); 
	    else 
	        myVideo.pause(); 
	} 

	$scope.makeBig = function() { 
	    myVideo.width = 450; 
	    myVideo.height = 250;
	} 

	$scope.makeSmall = function() { 
	    myVideo.width = 350;
	    myVideo.height = 250;
	} 

	$scope.makeNormal = function() { 
	    myVideo.width = 420;
	    myVideo.height = 250;
	} 
	
	$('.play').on('click', function () {
		  $(this).toggleClass('pause');
		});
	
    
}]);

