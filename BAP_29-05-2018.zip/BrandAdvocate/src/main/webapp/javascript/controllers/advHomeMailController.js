'use strict';

baControllers.controller('advHomeMailCtrl',['$scope',
                                    		'$filter',
                                    		'$route',
                                    		'$http',
                                    		'$location',
                                    		'$rootScope',
                                    		'$window',
                                    		'ngDialog','advHomeMailFactory','fileUploadService','localStorageService', function($scope, $filter, $route, $http, $location, $rootScope, $window, ngDialog,advHomeMailFactory,fileUploadService,localStorageService){

	$scope.input = new advHomeMailFactory();
	$scope.readonly = true;
	var searchObject = $location.search();
	
	$scope.fileList=[];
	$scope.files = [];
	
	$scope.emailList = [];
	
	$scope.isTemplateSelected = false;
	
	$scope.lRemove = jQuery.i18n.prop('common_remove');
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	 
	 $scope.input.baUserDetailsList = angular.copy(localStorageService.get('baUserDetailsList'));
	 angular.forEach($scope.input.baUserDetailsList,function(value,key){
		 if(value.primaryEmail!=''){
			 $scope.emailList.push(value.primaryEmail);
		 }else if(value.secondaryEmail!=''){
			 $scope.emailList.push(value.secondaryEmail);
		 }
	 });
	 
/**------file upload section start*/
	
	$scope.addFileRow = function(){
		$scope.totalSize = 0;
		$scope.delKey;
		angular.forEach($scope.files, function (item, key) {
			$scope.totalSize = $scope.totalSize + item.size;
			$scope.delKey = item;
		});
		
		if($scope.totalSize >= 5000000){
			jAlert(jQuery.i18n.prop('validate_total_file_size'));
			$scope.fileList.splice($scope.fileList.indexOf($scope.delKey), 1);
			$scope.files.splice($scope.files.indexOf($scope.delKey), 1);
			return;
		}
		else if($scope.fileList.length > 9){
            jAlert(jQuery.i18n.prop('validate_upload'));
            return;
		}else{
            $scope.fileList.push({documentId:""});
		}
	};
	
	$scope.removeFileRow = function(data, index){
		$scope.fileList.splice($scope.fileList.indexOf(data), 1);
	};
	
	$scope.removeFileRowDb = function(data, index){
		$scope.fileListFromDb.splice($scope.fileListFromDb.indexOf(data), 1);
	};
	
	$scope.$on("fileSelected", function (event, args) {
        $scope.$apply(function () {            
              $scope.files[args.index]=args.file;
       });
        $scope.totalSize = 0;
		$scope.delKey;
		$scope.tempKey;
		angular.forEach($scope.files, function (item, key) {
			$scope.totalSize = $scope.totalSize + item.size;
			$scope.delKey = item;
			$scope.tempKey = key;
		});
		if($scope.totalSize >= 5000000){
			jAlert(jQuery.i18n.prop('validate_total_file_size'));
			$scope.files.splice($scope.files.indexOf($scope.delKey), 1);
			$scope.$apply(function () {            
				$scope.fileList.splice($scope.tempKey, 1);
	       });
			return;
		}
	});
	
	/**------file upload section end*/
	
	advHomeMailFactory.getAllTemplates(function(response){
		$scope.templateList = response.data.LIST;
	});
	
	$scope.sendMail = function() {
		/** for tinyMce*/
		var entirePageHTML = tinymce.get("texteditor").getContent();
		var bodyHtml = /<body.*?>([\s\S]*)<\/body>/.exec(entirePageHTML)[1];
		console.log("dasdasdasdasd"+bodyHtml);
		$scope.input.messageBody = bodyHtml;
		/**-----------*/
		
		if($scope.validateEmailForm()){
			var i = 0;
			var formData = new FormData();
			//Add all files into formData//
			angular.forEach($scope.files, function (item) {
				 formData.append('files' + i, item);
				 i = i + 1;
			});
			
			$scope.input.documentsList = $scope.fileListFromDb;
			
		formData.append("mailrequest",angular.toJson($scope.input));
		
		fileUploadService.uploadFiles('/brandadvocate/manage/details/v1/sendmail', formData).success(function(response){
			if(response.statusCode=="OK"){
				jAlert(jQuery.i18n.prop('email_campaign_email_sent'),jQuery.i18n.prop('common_success'),function(r){
				//ngDialog.close();
				if(r){
				$location.path('/brandInfo').search('');
				$scope.$apply(); // used because location was not changing.
				}
				//window.location.reload(true);  // to get tinymce (no need to do ctrl+f5)
				//$scope.reset();
				});
			}
		}).error(function(result){
		    jAlert(response.msg);
		});
	}
		
	}
	
	$scope.saveMailTemplateData = function(){
		/** for tinyMce*/
		var entirePageHTML = tinymce.get("texteditor").getContent();
		var bodyHtml = /<body.*?>([\s\S]*)<\/body>/.exec(entirePageHTML)[1];
		//$scope.input.messageBody = bodyHtml;
		/**-----------*/
		
		var i = 0;
		var formData = new FormData();
		//Add all files into formData//
		angular.forEach($scope.files, function (item) {
			 formData.append('files' + i, item);
			 i = i + 1;
		});
		
	formData.append("templaterequest",bodyHtml);
	formData.append("subject",$scope.input.subject);
	
	$scope.formData = formData;
	
	if($scope.input.subject == undefined || $scope.input.subject == ''){
		jAlert(jQuery.i18n.prop('validate_mail_subject'));
	}else{
		$rootScope.dialog = ngDialog.open({
		    template: 'html/home/advocate_home_mail_template.html',
		    controller: 'advHomeMailTemplateCtrl',
		    closeByDocument: false,
		    showClose: false,
		    scope : $scope
		});
	}
	
	}
	
	$scope.updateMailTemplateData = function(){
		/** for tinyMce*/
		var entirePageHTML = tinymce.get("texteditor").getContent();
		var bodyHtml = /<body.*?>([\s\S]*)<\/body>/.exec(entirePageHTML)[1];
		$scope.input.messageBody = bodyHtml;
		/**-----------*/
		
		var i = 0;
		var formData = new FormData();
		//Add all files into formData//
		angular.forEach($scope.files, function (item) {
			 formData.append('files' + i, item);
			 i = i + 1;
		});
		
		$scope.input.documentsList = $scope.fileListFromDb;
		$scope.input.templateId = $scope.templateId;
		formData.append("mailrequest",angular.toJson($scope.input));
	
		if($scope.input.subject == undefined || $scope.input.subject == ''){
			jAlert(jQuery.i18n.prop('validate_mail_subject'));
		}else{
			fileUploadService.uploadFiles('/brandadvocate/manage/details/v1/updatemailtemplatedata', formData).success(function(response){
		if(response.statusCode=="OK"){
			jAlert(jQuery.i18n.prop('template_saved_successfully'),jQuery.i18n.prop('common_success'),function(r){
			if(r){
			ngDialog.close();
			window.location.reload(true)
			}
			});
		}
	}).error(function(result){
	    jAlert(response.msg);
	});		
		}
	}
	
	$scope.validateEmailForm = function(){
		if($scope.emailList === undefined || $scope.emailList.length < 0 || $scope.emailList == "" || $scope.emailList[0] == ""){
			jAlert(jQuery.i18n.prop('email_campaign_validate_email'));
			return false;
		}
		else if($scope.input.subject === undefined || $scope.input.subject == ""){
			jAlert(jQuery.i18n.prop('email_campaign_validate_subject'));
			return false;
		}
		else if($scope.input.messageBody === undefined || $scope.input.messageBody == ""){
			jAlert(jQuery.i18n.prop('email_campaign_validate_body'));
			return false;
		}
		else{
			return true;
		}
	};
	
	$scope.resetMail = function(urlPath){
		$scope.input.subject = '';
		tinyMCE.get('texteditor').setContent("");
		$scope.templateId='';
		$scope.fileList = [];
		$scope.fileListFromDb = [];
		$scope.isTemplateSelected = false;
	}
	
	$scope.getTemplateData = function(templateId){
		if(templateId != "" && templateId !=undefined && templateId != null ){
		advHomeMailFactory.getTemplateDetails({templateid:templateId},function(response){
			tinyMCE.get('texteditor').setContent(response.data.contents);
			$scope.input.subject = response.data.subject;
			//$scope.fileList = response.data.documents;
			$scope.isTemplateSelected = true;
			$scope.fileListFromDb = response.data.documents;
		});
	}else{
		tinyMCE.get('texteditor').setContent("");
		$scope.input.subject = '';
		$scope.isTemplateSelected = false;
		$scope.fileListFromDb = [];
		$scope.fileList = [];
	}
}
	
	$scope.cancel = function(urlPath){
		//ngDialog.close();
		//$route.reload();
		$location.path(urlPath);
		//window.location.reload(true);  // to get tinymce (no need to do ctrl+f5)
		//$location.path(urlPath);	
	
	}
	
	
}]);

