'use strict';

baControllers.controller('advInvitationsCtrl',['$scope','$http','$location','$rootScope', '$route', 'ngTableParams','ngDialog', '$filter', 'advInvitationsFactory','filterFilter','localStorageService','loggedInUserService','dataShare', function($scope, $http, $location, $rootScope, $route, ngTableParams, ngDialog, $filter, advInvitationsFactory,filterFilter,localStorageService,loggedInUserService,dataShare){

	
	/**Global Variables*/
	$scope.input = new advInvitationsFactory();
	$scope.finalInput = new advInvitationsFactory();
	$scope.invitationsList = [];
	$scope.inputRequest = new advInvitationsFactory();
	$scope.IsVisible_nodata = true;
	
	$scope.offset = 0;
	$scope.count = 10;
	$scope.IsVisible_nodata = true;
	$scope.allDataCount = 0;
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName;
	

	$scope.lSubject = jQuery.i18n.prop('common_invitations_subject');
	$scope.lStartDateTime = jQuery.i18n.prop('common_invitations_start_date_time');
	$scope.lEndDateTime = jQuery.i18n.prop('common_invitations_end_date_time');
	$scope.lLocation = jQuery.i18n.prop('common_invitations_location');
	$scope.lCreatedDate = jQuery.i18n.prop('common_invitations_created_date');
	$scope.lModifiedDate = jQuery.i18n.prop('common_invitations_modified_date');
	
	/**Table headers i18N*/
	$scope.lAction = jQuery.i18n.prop('common_action');
	$scope.lNext = jQuery.i18n.prop('common_next');
	$scope.lPrevious = jQuery.i18n.prop('common_previous');
	$scope.lAll = jQuery.i18n.prop('common_all');
	$scope.lPage = jQuery.i18n.prop('common_page');
	$scope.lFirstPage = jQuery.i18n.prop('common_first_page');
	$scope.lLastPage = jQuery.i18n.prop('common_last_page');
	$scope.lPreviousPage = jQuery.i18n.prop('common_previous_page');
	$scope.lNextPage = jQuery.i18n.prop('common_next_page');
	
	
	$scope.loadData = function(){
		
		advInvitationsFactory.getInvitationsDetails(function(result){
			$scope.invitationsList = result.data;
			console.log($scope.invitationsList);
			var data = $scope.invitationsList;
			
			if ($scope.invitationsList != null && $scope.invitationsList.length > 0) {
	             $scope.IsVisible_nodata = false;
	    }else{
	             $scope.IsVisible_nodata = true;
	    }
		
		var length = $scope.invitationsList.length;
		$scope.totalDataCount = $scope.invitationsList.length;
		$scope.total = Math.ceil(length/$scope.count);
		if ($scope.count < 0) 
		{
			$scope.total = 1;
           $scope.allDataCount=$scope.invitationsList.length;
       } else
       {
       	$scope.allDataCount=$scope.count;
       }
		$scope.currentPage = $scope.offset+1;
		//** Sorting and Filtering *//*
		$scope.tableParams = new ngTableParams(
			{
				page : 1,
				count : $scope.allDataCount,
			},
			{
				 filterSwitch: true,
		         total: 0,
			      getData: function($defer, params) {
	                    var filteredData = Object.keys(params.filter()).some(k => params.filter()[k]!="") ?  $filter('filter')(data, params.filter()) : $scope.invitationsList;
	                    var orderedData = !angular.equals(params.sorting(), {}) ? $filter('orderBy')(filteredData, params.orderBy()) : filteredData;
	                    params.total(orderedData.length);
	                    $defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
			      },
		});
	});
		
	};
	
	$scope.loadData();
	
	
	/** Common Search */
    $scope.baSearchChange = function(){
		$scope.offset = 0;
		$scope.selectedAll = false;
		$scope.countForToggle = 0;
		$scope.loadData();
	};
	
	$scope.rescheduleInvitation = function(invitationId){
		//$scope.invitations = invitations;
		$location.path('/webinarHomeMail').search({
			invitationId : invitationId,
			mode : 'invitation'
		});
		//dataShare.sendData($scope);
	}
	
	$scope.test = function(){
		console.log("test method called from webinar controller");
		$scope.input.location = $scope.invitations;
	}
	
}]);
