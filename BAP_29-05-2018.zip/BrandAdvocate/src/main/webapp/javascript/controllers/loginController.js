'use strict';

baControllers.controller('loginCtrl',['$scope','$location','$rootScope','$cookieStore','i18n','localStorageService','Idle','loggedInUserService','loginFactory',function($scope,$location,$rootScope,$cookieStore,i18n,localStorageService,Idle,loggedInUserService,loginFactory){
	
	$scope.input = new loginFactory();
	
	$rootScope.title = jQuery.i18n.prop('common_project_title');
	
	/** Code to get user object after login*/
	$rootScope.invalidSession = false;
    $rootScope.showModal = false;
	/**====================================*/
	
	/**Code to get logged in user details*/
	
    /**Use when want to use clue*/
	loggedInUserService.loggedInUserCall('/brandadvocate/user/authentication/v1/getUserInformation').success(function(response){
		console.log(response.data.userMasterDto);
		$scope.response = response.data.userMasterDto;
		$scope.loggedInUserName = $scope.response.firstName+" "+$scope.response.lastName; //set logged in user name on header.
		$rootScope.userName = $scope.loggedInUserName;
		$rootScope.isAdminPerson  = $scope.response.isAdmin;
		$rootScope.response = $scope.response;
    /**-------------------------------*/
    
    /**Use when do not want to use clue dummy data*/
/*    $scope.loggedInUserName = "Kuldeep";
	$rootScope.userName = $scope.loggedInUserName;
	$rootScope.isAdminPerson  = false;
	$scope.response = {"firstName":"kuldeep"};*/
	/**-------------------------------*/
	
		if($rootScope.isAdminPerson){
			$scope.role = "Admin";
			$rootScope.brandAdvocateRole = " ["+$scope.role+"]";
		}else{
			$scope.role = "User";
			$rootScope.brandAdvocateRole = " ["+$scope.role+"]"; 
		}
		localStorageService.set("userlogin",$rootScope.userName);
		localStorageService.set("userrole",$rootScope.isAdminPerson);
		localStorageService.set("brandadvocaterole",$rootScope.brandAdvocateRole);
		localStorageService.set("userresponse",$rootScope.response);
		$rootScope.globals = {
	            currentUser: {
	                userName: $rootScope.userName,
	            },
	            userRole: {
	            	isAdminPerson: $rootScope.isAdminPerson,
	            }
	        };
		
		$cookieStore.put('globals', $rootScope.globals);
		localStorageService.set("userloginglobals",$rootScope.globals);
		
		localStorageService.set("userrole",$rootScope.isAdminPerson);
		$rootScope.globals = {
	            userRole: {
	            	isAdminPerson: $rootScope.isAdminPerson,
	            }
	        };
		
		$cookieStore.put('globals', $rootScope.globals);
		localStorageService.set("userloginglobals",$rootScope.globals);
		
		if($rootScope.isAdminPerson){
	    	$location.path('/brandInfo').search('');
	    }else{
	    	/**Used to check BA exist in portal*/
	    	$scope.input.primaryEmail = $scope.response.primaryEmail; 
	    	$scope.input.cwsUserId = $scope.response.cwsUserId;
	    	$scope.input.cupId = $scope.response.cupId;
	    	loginFactory.checkBAExistInPortal($scope.input,function(result){
        		if(!isEmpty(result.data) && null!=result.data){
        			$scope.brandAdvocateId = result.data.brandAdvocateId;
        			localStorageService.set("brandAdvocateIdFromLoginForEditPage",$scope.brandAdvocateId);
        			$rootScope.baExistInPortal = true;
        			$location.path('/editBARegisterUser').search({brandAdvocateId:$scope.brandAdvocateId});
        		}else{
        			$rootScope.baExistInPortal = false;
        			$location.path('/baRegisterUser').search('');
        		}
        		
        		localStorageService.set("baexistinportal",$rootScope.baExistInPortal);
        		
        	});
	    }
	});
}]);