'use strict';

baControllers.controller('editAdvHomeCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'editAdvHomeFactory','filterFilter','localStorageService', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, editAdvHomeFactory,filterFilter,localStorageService){

	
	$scope.preferencesArray = [];
	$scope.preferencesList = [];
	$scope.preferences = [];
	$scope.preferencesData = [];
	$scope.preferencesTemp = [];
	$scope.preferencesToSave = [];
	
	$scope.subscriptionPreferencesList = [];
	
	$scope.input = new editAdvHomeFactory();
	
	$scope.input.preferences = [];

	$scope.validateRegisterQue = jQuery.i18n.prop('validate_register_que');
	$scope.enterEmail = jQuery.i18n.prop('enter_email');
	$scope.validateBuilding = jQuery.i18n.prop('validate_building');
	$scope.validatePrimaryEmail = jQuery.i18n.prop('validate_primary_email');
	
	$scope.validateClueField = jQuery.i18n.prop('clue_populated_value_modify');
	
	/*$scope.isClueField = true;*/
	$scope.isManagedByAdmin = false;
	$scope.isManagedBySystem = false;
	
	$scope.checkboxUncheckFlag = false;
	
	var searchObject = $location.search();
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	$rootScope.baExistInPortal  = localStorageService.get("baexistinportal");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName;
	$scope.loggedInUserEmailId = $rootScope.response.primaryEmail;
	$scope.isAdmin = $rootScope.isAdminPerson;
	
    $scope.onLoad = function(){
    	
    	var lineHeight = $('.col-md-6').height();
		console.log('lineHeight',lineHeight);
		$('.vl').height(lineHeight+60);
    	
    	$scope.radiobrandadvocate = true; //default radio button check.
    	/** Code for preferences dropdown start*/
    	 $scope.preferencesSettings = {
    		      scrollableHeight: '170px',
    		      scrollable: true,
    		      enableSearch: false
    		    };
    	 
    		    $scope.getData = function() {
    		    	$scope.$watch('preferences', function(val) {
    		    		$scope.val = val;
    		    		
    		    });
    		    };
    		    
    		    angular.element(document).on('click', function () {
    		    	if(!isEmpty($scope.val)){
    		    	$scope.getData();
    		    	}
    		    });
    		    
    	  /** Code for preferences dropdown end*/
    		    
    		editAdvHomeFactory.getCountries(function(response){
    				$scope.countryList = response.data.LIST;	
    				$scope.onLoadCountryList = angular.copy($scope.countryList);
    		});

    		editAdvHomeFactory.getRegions(function(response){
    			$scope.regionList = response.data.LIST;	
    			$scope.onLoadRegionList = angular.copy($scope.regionList);
    		});
    		
    		$scope.userRegisterQueList = [{registerId:1 ,registerVia:"Manual entry"},{registerId:2 ,registerVia:"Took a brand class"},
    			{registerId:3 ,registerVia:"Participated in other training"},{registerId:4 ,registerVia:"Completed Big Yellow Quiz"},{registerId:5 ,registerVia:"Registered through the portal"}];
    		
    		//$scope.brandAdvocateStatusList = [{brandAdvocateStatusId:1 ,brandAdvocateStatus:"Brand Advocate"},{brandAdvocateStatusId:2 ,brandAdvocateStatus:"CBA"},{brandAdvocateStatusId:3 ,brandAdvocateStatus:"CBA Instructor"}];
    		$scope.input.brandAdvocateStatus = "Brand Advocate"; //default value
    		
    }
    
    $scope.onLoad();
    
    $scope.managedByList = [{managedBy:"System"},{managedBy:"Admin"}];
    
    $scope.getBAUserDetailsById = function(brandAdvocateId){
    	editAdvHomeFactory.getBAUserDetailsById({brandadvocateid:brandAdvocateId},function(result){
			$scope.resultData = result.data.userMasterDto;
			$scope.input.brandAdvocateId = $scope.resultData.brandAdvocateId; 
			$scope.input.cwsUserId = $scope.resultData.cwsUserId; 
			$scope.input.cupId = $scope.resultData.cupId; 
			//$scope.baSince =  $filter('date')($scope.resultData.baSince, "MM/dd/yyyy");
			//$scope.input.workLocation = $scope.resultData.workLocation;
			$scope.input.registeredVia = $scope.resultData.registeredVia;
			$scope.input.affiliationDescription = $scope.resultData.affiliationDescription;
			$scope.input.mappedAffiliationName = $scope.resultData.mappedAffiliationName;
			$scope.input.lastName = $scope.resultData.lastName;
			$scope.input.firstName = $scope.resultData.firstName;
			$scope.input.preferredFirstName = $scope.resultData.preferredFirstName;
			$scope.input.organizationName = $scope.resultData.organizationName;
			$scope.input.facilityName = $scope.resultData.facilityName;
			$scope.input.buildingName = $scope.resultData.buildingName;
			$scope.input.jobKeywords = $scope.resultData.jobKeywords;
			$scope.input.countryId = $scope.resultData.countryId;
			$scope.input.regionId = $scope.resultData.regionId;
			$scope.input.primaryEmail = $scope.resultData.primaryEmail;
			$scope.input.secondaryEmail = $scope.resultData.secondaryEmail;
			$scope.input.brandAdvocateStatus = $scope.resultData.brandAdvocateStatus;
			$scope.input.notes = $scope.resultData.notes;
			//extra values send values at the time of save not used on UI.
			$scope.input.countryName = $scope.resultData.countryName;
			$scope.input.countryCode = $scope.resultData.countryCode;
			$scope.input.regionName = $scope.resultData.regionName;
			$scope.input.comments = $scope.resultData.comments;
			$scope.input.registrationDate = $scope.resultData.registrationDate;
			$scope.input.secondaryEmail = $scope.resultData.secondaryEmail;
			$scope.input.managedBy = $scope.resultData.managedBy;
			if($scope.input.managedBy == "Admin"){
				$scope.isManagedByAdmin = true;
				$scope.isManagedBySystem = false;
			}else if($scope.input.managedBy == "System"){
				$scope.isManagedByAdmin = false;
				$scope.isManagedBySystem = true;
			}
			
			$scope.input.registrationDate = $scope.resultData.registrationDate;
			$scope.input.registeredBy = $scope.resultData.registeredBy;
			
			$scope.brandAdvocateStatusDb = $scope.resultData.brandAdvocateStatus;
			if($scope.brandAdvocateStatusDb == "Brand Advocate"){
				$scope.radiobrandadvocate = true;
				$scope.radiocba = false;
				$scope.radiocbainstructor = false;
			}else if($scope.brandAdvocateStatusDb == "Certified Brand Advocate (CBA)"){
				$scope.radiocba = true;
				$scope.radiobrandadvocate = false;
				$scope.radiocbainstructor = false;
			}else if($scope.brandAdvocateStatusDb == "CBA Instructor"){
				$scope.radiocbainstructor = true;
				$scope.radiobrandadvocate = false;
				$scope.radiocba = false;
			}
			
			/**new code changes for subscription preferences starts*/
			
			$scope.subscriptionPreferencesList = [];
			$scope.checkboxModel=[];
			angular.forEach($scope.resultData.preferences,function(value,key){
				$scope.subscriptionPreferencesList.push({"preferenceId":value[0],"preferenceName":value[1].trim()});
 			});

			angular.forEach($scope.subscriptionPreferencesList,function(value,key){
				if(value.preferenceName == "Webinar invitations"){
					$scope.checkboxModel.webinarCheckbox = true;
				}else if(value.preferenceName == "Brand event communications"){
					$scope.checkboxModel.brandEventCheckbox = true;
				}else if(value.preferenceName == "Newsletters"){
					$scope.checkboxModel.newsletterCheckbox = true;
				}
			});
			
			/**new code changes for subscription preferences ends*/
			
			//$scope.preferences = [$scope.preferencesData[0]]; //dummy Data need to replace with actual value
			$scope.preferencesTemp = [];
			 editAdvHomeFactory.getPreferences(function(response){
		 			$scope.preferencesList = response.data.LIST;
		 			angular.forEach($scope.preferencesList,function(value,key){
		 				$scope.preferencesData.push({"label":value.preferenceName,"id":value.preferenceId});
		 				console.log($scope.preferencesData);
		 			});
		 			angular.forEach($scope.resultData.preferences,function(value,key){
		 				$scope.preferencesTemp.push({"label":value[1],"id":value[0]});
		 				console.log($scope.preferencesTemp);
		 			});
		 			$scope.preferences = $scope.preferencesTemp;
		 		});
			
 			
			/*if($scope.input.cwsUserId!=''){
				$scope.isClueField = true;
			}*/

		});

	}
	
    
    if (searchObject != null && searchObject != '') {
		var brandAdvocateId = searchObject.brandAdvocateId;
				$scope.getBAUserDetailsById(brandAdvocateId);
		}
    
    
    $scope.getRegionsByCountryId = function(countryId){
    	if(countryId!=null && countryId!=undefined){
    	editAdvHomeFactory.getRegionsByCountryId({countryid:countryId},function(response){
    		$scope.regionList = response.data.LIST;	
    	});
    	}else{
    		$scope.regionList = $scope.onLoadRegionList;
    		$scope.input.regionId='';
    	}
    	
    }

    $scope.getCountriesByRegionId = function(regionId){
    	if(regionId!=null && regionId!=undefined){
    	editAdvHomeFactory.getCountriesByRegionId({regionid:regionId},function(response){
    		$scope.countryList = response.data.LIST;	
    	});
    	}else{
    		$scope.countryList = $scope.onLoadCountryList;
    		$scope.input.countryId='';
    	}
    }
    
    $scope.validatePrimaryEmail = function(primaryEmail){
		//var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
    	var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(primaryEmail === undefined || primaryEmail == '' || primaryEmail == null){
			return true;
		}else if (reg.test(primaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_primary_email_id'),jQuery.i18n.prop('common_message'),function(){
				$scope.input.primaryEmail = '';
			});
			return false;
		}else{
			return true;
		}
	};
    
    $scope.validateSecondaryEmail = function(secondaryEmail){
		//var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
    	var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(secondaryEmail === undefined || secondaryEmail == '' || secondaryEmail == null){
			return true;
		}else if (reg.test(secondaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_secondary_email_id'));
			$scope.input.secondaryEmail = '';
			return false;
		}else{
			return true;
		}
	};
	
	$scope.baRadioButtonClick = function(radioButtonStatus){
		if(radioButtonStatus=='radiobrandadvocate'){
			$scope.input.brandAdvocateStatus = "Brand Advocate";
		}else if(radioButtonStatus=='radiocba'){
			$scope.input.brandAdvocateStatus = "Certified Brand Advocate (CBA)";
		}else if(radioButtonStatus=='radiocbainstructor'){
			$scope.input.brandAdvocateStatus = "CBA Instructor";
		}else{
			$scope.input.brandAdvocateStatus = "Brand Advocate";
		}
	}
	
	/**new code changes for subscription preferences starts*/
	
	 $scope.checkboxModel = {
			 webinarCheckbox : true,
		     brandEventCheckbox : true,
		     newsletterCheckbox : true
	 };

	$scope.preferencesCheckboxChange = function(selectedCheckBoxValue,prefCheckBoxValue){
		if(!prefCheckBoxValue){
		if(selectedCheckBoxValue=='webinarCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":1,"preferenceName":"Webinar invitations"});
		}else if(selectedCheckBoxValue=='brandEventCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":2,"preferenceName":"Brand event communications"});
		}else if(selectedCheckBoxValue=='newsletterCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":3,"preferenceName":"Newsletters"});
		}
		}else{
			var index;
			if(selectedCheckBoxValue=='webinarCheckbox'){
				index = $scope.getIndex("Webinar invitations");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='brandEventCheckbox'){
				index = $scope.getIndex("Brand event communications");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='newsletterCheckbox'){
				index = $scope.getIndex("Newsletters");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}
		}
	}
	
	$scope.getIndex = function(val){
		var index = -1;
		var filteredObj = $scope.subscriptionPreferencesList.find(function(item, i){
    	  if(item.preferenceName === val){
    		index = i;
    	  }
    	});
		return index;
	}
	
	/**new code changes for subscription preferences ends*/
	
	$scope.updateDetails = function(){
		//get toggle value
		/*console.log("Toggle Value :"+$scope.toggleValue);
		angular.forEach($scope.val,function(value,key){
    		$scope.input.preferences.push({"preferenceId" : value.id});
		})*/
		/*angular.forEach($scope.preferences,function(value,key){
			if(value.i)
		}*/
		
		$scope.preferencesToSave = [];
		angular.forEach($scope.preferences,function(value,key){
			angular.forEach($scope.preferencesList,function(valuePref,keyPref){
				if(value.id == valuePref.preferenceId){
					$scope.preferencesToSave.push({"preferenceId":valuePref.preferenceId,"preferenceName":valuePref.preferenceName});
				}
 			});
		});
		//$scope.input.preferences = $scope.preferencesToSave;
		$scope.input.preferences = $scope.subscriptionPreferencesList;
		
		if($scope.registerForm.$valid){
			if($scope.validateRegistrationDetails()){
				var saveMsg ;
					saveMsg = 'user_update_success';
		
		$scope.input.loggedInUserName = $scope.loggedInUserName;
		$scope.input.loggedInUserEmailId = $scope.loggedInUserEmailId;
		$scope.input.isAdmin = $scope.isAdmin;
		
		editAdvHomeFactory.saveAdminInformation($scope.input,function(response){
			jAlert(jQuery.i18n.prop(saveMsg),jQuery.i18n.prop('common_success'),function(){
					 $location.path('/brandInfo').search('');
					 $route.reload();
			});
		});
	}
	}else{
			angular.element("[name='" + $scope.registerForm.$name + "']").find('.ng-invalid:visible:first').focus();
  	        return false;
  		}

	}
	
	
	/** validation for User fields */
	$scope.validateRegistrationDetails = function(){
			/*if($scope.input.buildingName == '' || $scope.input.buildingName == undefined){
				jAlert(jQuery.i18n.prop('validate_building'));
				return false;
			}else{
				return true;
			}*/
		return true;
	}
	
	
	$scope.cancel = function(urlPath){
		$location.path(urlPath);
	}
	
	
}]);




