'use strict';

baControllers.controller('advReportsCtrl',['$scope','$http','$location','$rootScope', '$route','localStorageService', 'ngTableParams','advReportFactory','$timeout', function($scope, $http, $location, $rootScope, $route, localStorageService, ngTableParams,advReportFactory,$timeout){

	$scope.lAmericasN = jQuery.i18n.prop('report_americas_north');
	$scope.lAmericasS = jQuery.i18n.prop('report_americas_south');
	$scope.lEame = jQuery.i18n.prop('report_eame');
	$scope.lAp = jQuery.i18n.prop('report_ap');
	$scope.lTotal = jQuery.i18n.prop('common_total');
	
	
	$scope.input = new advReportFactory();
	$scope.inputRequest = new advReportFactory();
	
	$scope.isDataSearchedForTab1 = false;
	$scope.isDataSearchedForTab2 = false;
	$scope.isDataSearchedForTab3 = false;
	
	 $scope.firstDropDownValueSelected = false;
	 $scope.secondDropDownValueSelected = false;
	 
	 $scope.ytdQtdNameToFind = '';
	 $scope.compareNameToFind = '';
	 $scope.againstNameToFind = '';
	 
	 $scope.tooltipForExportToExcel = "Export to Excel";
	
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	 /**Logic to switch between tabs start*/
	 this.tab = 1;

    this.setTab = function (tabId) {
        this.tab = tabId;
        $scope.isDataSearchedForTab1 = false;
    	$scope.isDataSearchedForTab2 = false;
    	$scope.isDataSearchedForTab3 = false;
    	$scope.selectedDate = '';
    	$scope.selectedFromDate = '';
    	$scope.selectedToDate = '';
    	$scope.input = [];
    	$scope.firstDropDownValueSelected = false;
    	$scope.secondDropDownValueSelected = false;
    };

    this.isSet = function (tabId) {
        return this.tab === tabId;
    };
    /**Logic to switch between tabs end*/
	
    $scope.monthNames = ["January", "February", "March", "April", "May", "June",
		  "July", "August", "September", "October", "November", "December"
		];
	
     
     $scope.loadData = function(){
    	 
    	 /** For Tab1 starts*/
    	 var startDate = new Date();
    	 var FromEndDate = new Date();

    	 $('.activeInactiveGridDate').datepicker1({
    	     autoclose: true,
    	     minViewMode: 1,
    	     format: 'mm/yyyy'
    	 }).on('changeDate', function(selected){
    		 
    		 /**Logic to show month & year on page start*/
    		 $scope.monthForFirstReport = $scope.monthNames[selected.date.getMonth()];
    		 $scope.yearForFirstReport = selected.date.getFullYear();
    		 /**Logic to show month & year on page end*/
    		 
    	         FromEndDate = new Date(selected.date.valueOf());
    	         FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date)));
    	         //$('.from').datepicker1('setEndDate', FromEndDate);
    	         
    	         /*$scope.firstDayOfMonth = new Date(FromEndDate.getFullYear(), FromEndDate.getMonth(), 1);
    	         $scope.lastDayOfMonth = new Date(FromEndDate.getFullYear(), FromEndDate.getMonth() + 1, 0);*/
    	         
    	         var firstDayOfMonth = new Date(FromEndDate.getFullYear(), FromEndDate.getMonth(), 1);
    	         var lastDayOfMonth = new Date(FromEndDate.getFullYear(), FromEndDate.getMonth() + 1, 0);
    	         
    	         $scope.firstDateOfMonthForActiveInactiveGrid = new Date(firstDayOfMonth).getTime();
    	         $scope.lastDateOfMonthForActiveInactiveGrid = new Date(lastDayOfMonth).getTime();
    	     });
    	 /** For Tab1 ends*/
    	 
    	 
    	 /** For Tab2 starts*/
    	 $('.gainLostGridFromDate').datepicker1({
    		    autoclose: true,
    		    minViewMode: 1,
    		    format: 'mm/yyyy'
    		}).on('changeDate', function(selected){
    			
    		 /**Logic to show month & year on page start*/	
    		 $scope.monthFromForSecondReport = $scope.monthNames[selected.date.getMonth()];
       		 $scope.yearFromForSecondReport = selected.date.getFullYear();
       		 /**Logic to show month & year on page end*/
    			
    		        startDate = new Date(selected.date.valueOf());
    		        startDate.setDate(startDate.getDate(new Date(selected.date.valueOf())));
    		        $('.gainLostGridToDate').datepicker1('setStartDate', startDate);
    		        
    		     var firstDayOfMonth = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
       	         var lastDayOfMonth = new Date(startDate.getFullYear(), startDate.getMonth() + 1, 0);
       	         
       	         $scope.firstDateOfMonthForGainLostGridFromDate = new Date(firstDayOfMonth).getTime();
       	         $scope.lastDateOfMonthForGainLostGridFromDate = new Date(lastDayOfMonth).getTime();
    		        
    		    }); 

    		$('.gainLostGridToDate').datepicker1({
    		    autoclose: true,
    		    minViewMode: 1,
    		    format: 'mm/yyyy'
    		}).on('changeDate', function(selected){
    			
    			 /**Logic to show month & year on page start*/	
    			 $scope.monthToForSecondReport = $scope.monthNames[selected.date.getMonth()];
          		 $scope.yearToForSecondReport = selected.date.getFullYear();
          		 /**Logic to show month & year on page end*/
    			
    		        FromEndDate = new Date(selected.date.valueOf());
    		        FromEndDate.setDate(FromEndDate.getDate(new Date(selected.date.valueOf())));
    		        //$('.gainLostGridFromDate').datepicker1('setEndDate', FromEndDate);
    		        
    		        var firstDayOfMonth = new Date(FromEndDate.getFullYear(), FromEndDate.getMonth(), 1);
          	        var lastDayOfMonth = new Date(FromEndDate.getFullYear(), FromEndDate.getMonth() + 1, 0);
          	         
          	        $scope.firstDateOfMonthForGainLostGridToDate = new Date(firstDayOfMonth).getTime();
          	        $scope.lastDateOfMonthForGainLostGridToDate = new Date(lastDayOfMonth).getTime();
          	        
    		    });
    		/** For Tab2 ends*/
    		
    		/** For Tab3 starts*/
    		$scope.dropDownList = [{dropDownId:1,dropDownName:"Year/Quarter to Date"},{dropDownId:2,dropDownName:"Quarter over Quarter"}];
    		$scope.ytdQtdDropDownList = [{ytdQtdId:1,ytdQtdName:"Year to Date"},{ytdQtdId:2,ytdQtdName:"Quarter to Date"}];
    		$scope.compareDropDownList = [{compareId:1,compareName:"Q4 of This Year"},{compareId:2,compareName:"Q3 of This Year"},{compareId:3,compareName:"Q2 of This Year"},{compareId:4,compareName:"Q1 of This Year"},
    			{compareId:5,compareName:"Q4 of Last Year"},{compareId:6,compareName:"Q3 of Last Year"},{compareId:7,compareName:"Q2 of Last Year"},{compareId:8,compareName:"Q1 of Last Year"}];
    		$scope.againstDropDownList = [{againstId:1,againstName:"Q4 of This Year"},{againstId:2,againstName:"Q3 of This Year"},{againstId:3,againstName:"Q2 of This Year"},{againstId:4,againstName:"Q1 of This Year"},
    			{againstId:5,againstName:"Q4 of Last Year"},{againstId:6,againstName:"Q3 of Last Year"},{againstId:7,againstName:"Q2 of Last Year"},{againstId:8,againstName:"Q1 of Last Year"}];
    		
    		/** For Tab3 ends*/
		
     }
     
     $scope.loadData();
     
     $scope.dropDownChange = function(dropdownId){
    	 $scope.input.ytdQtdId='';
    	 $scope.input.compareId = '';
    	 $scope.input.againstId = '';
    	 $scope.compareNameToFind = '';
    	 $scope.againstNameToFind = '';
    	 if(dropdownId == 1){
    		 $scope.firstDropDownValueSelected = true;
    		 $scope.secondDropDownValueSelected = false;
    		 $scope.flagForHeader1 = true;
    		 $scope.flagForHeader2 = false;
    		 $scope.isDataSearchedForTab3 = false;
    	 }else if(dropdownId == 2){
    		 $scope.secondDropDownValueSelected = true;
    		 $scope.firstDropDownValueSelected = false;
    		 $scope.flagForHeader1 = false;
    		 $scope.flagForHeader2 = true;
    		 $scope.isDataSearchedForTab3 = false;
    	 }else{
    		 $scope.secondDropDownValueSelected = false;
    		 $scope.firstDropDownValueSelected = false;
    		 $scope.isDataSearchedForTab3 = false;
    	 }
     }
     
     $scope.ytdQtdDropDownChange = function(ytdQtdId){
    	 angular.forEach($scope.ytdQtdDropDownList,function(value,key){
    		if(value.ytdQtdId == ytdQtdId){
    			$scope.ytdQtdNameToFind = value.ytdQtdName;
    			console.log($scope.ytdQtdNameToFind);
    		}
    	 });
    	 
    	 $scope.selectedXToDateForThirdReport = $scope.ytdQtdNameToFind;
    	 var currentDate = new Date();
    	 var day = currentDate.getDate();
    	 var month = $scope.monthNames[currentDate.getMonth()];
    	 var year = currentDate.getFullYear();
    	 $scope.currentDateForThirdReport = month+" "+ day+", "+ year;
    	 
    	 $scope.dropdownvalue1 = "of This Year";
         $scope.dropdownvalue2 = "of Last Year";
         $scope.isDataSearchedForTab3 = false;
     }
     
     $scope.compareDropDownChange = function(compareId){
    	 $scope.ytdQtdNameToFind = '';
    	 $scope.compareId = compareId;
    	 if($scope.againstId!='' && $scope.againstId!=null && $scope.againstId!=undefined){
    		 if($scope.compareId == $scope.againstId){
    			 jAlert(jQuery.i18n.prop('validate_compare_against_value'),jQuery.i18n.prop('common_message'),function(){
    			 $scope.input.compareId = '';
    			 $scope.$apply();
    		 });
    	 }else{
    		 angular.forEach($scope.compareDropDownList,function(value,key){
    	    		if(value.compareId == compareId){
    	    			$scope.compareNameToFind = value.compareName;
    	    			console.log($scope.compareNameToFind);
    	    		}
    	    	 });
    	 }
     }else{
    	 angular.forEach($scope.compareDropDownList,function(value,key){
	    		if(value.compareId == compareId){
	    			$scope.compareNameToFind = value.compareName;
	    			console.log($scope.compareNameToFind);
	    		}
	    	 });
     }
    	 
    	 $scope.comapreNameForGridThird = $scope.compareNameToFind;
    	 
    	 $scope.dropdownvalue1 = $scope.compareNameToFind;
    	 $scope.isDataSearchedForTab3 = false;
       
     }
     
     $scope.againstDropDownChange = function(againstId){
    	 $scope.ytdQtdNameToFind = '';
    	 $scope.againstId = againstId;
    	 if($scope.compareId!='' && $scope.compareId!=null && $scope.compareId!=undefined){
    		 if($scope.againstId == $scope.compareId){
    			 jAlert(jQuery.i18n.prop('validate_compare_against_value'),jQuery.i18n.prop('common_message'),function(){
    			 $scope.input.againstId = '';
    			 $scope.$apply();
    		 });
    	 }else{
    		 angular.forEach($scope.againstDropDownList,function(value,key){
 	    		if(value.againstId == againstId){
 	    			$scope.againstNameToFind = value.againstName;
 	    			console.log($scope.againstNameToFind);
 	    		}
 	    	 });
    	 }
     }else{
    	 angular.forEach($scope.againstDropDownList,function(value,key){
	    		if(value.againstId == againstId){
	    			$scope.againstNameToFind = value.againstName;
	    			console.log($scope.againstNameToFind);
	    		}
	    	 });
     }
    	 $scope.againstNameForGridThird = $scope.againstNameToFind;
    	 
    	  $scope.dropdownvalue2 = $scope.againstNameForGridThird;
    	  $scope.isDataSearchedForTab3 = false;
     }
     
     /** Get Active/InActive data report call **/
     $scope.getActiveInActiveDataReport = function(){
    	 if($scope.selectedDate!='' && $scope.selectedDate!=undefined){
    		 $scope.isDataSearchedForTab1 = true;	
    		 $scope.isDataSearchedForTab2 = false;	
    		 $scope.isDataSearchedForTab3 = false;	
    		 advReportFactory.getActiveInActiveDataReport({fromDate:$scope.firstDateOfMonthForActiveInactiveGrid,toDate:$scope.lastDateOfMonthForActiveInactiveGrid,isActive:true},function(response){
    			 $scope.reportsList = response.data.reportsActiveInActiveDataList;
    			 
    			 angular.forEach($scope.reportsList,function(value,key){
    				 if(value.affiliationTypeName == "Total"){
    					 $scope.totalDataCountMatrix = value.totalRegionRecordCnt;
    					 
    				 }
    			 });
    			 
    			 $scope.tableParams = new ngTableParams({count:15}, {dataset: $scope.reportsList});
    		 });
    		 
    		 advReportFactory.getActiveInActiveDataReport({fromDate:$scope.firstDateOfMonthForActiveInactiveGrid,toDate:$scope.lastDateOfMonthForActiveInactiveGrid,isActive:false},function(response){
    			 $scope.reportsInactiveList = response.data.reportsActiveInActiveDataList;
    			 
    			 angular.forEach($scope.reportsInactiveList,function(value,key){
    				 if(value.affiliationTypeName == "Total"){
    					 $scope.totalInactiveDataCountMatrix = value.totalRegionRecordCnt;
    					 
    				 }
    			 });
    			 
    			 $scope.tableParams1 = new ngTableParams({count:15}, {dataset: $scope.reportsInactiveList});
    		 });
		//var data = [{name: "Moroni", age: 50} /*,*/];
		//$scope.tableParams = new ngTableParams({}, {dataset: data});
    	 }else{
    		 $scope.isDataSearchedForTab1 = false;	
    		 $scope.isDataSearchedForTab2 = false;	
    		 $scope.isDataSearchedForTab3 = false;	
    	 }
    	 
     }
     
     /** Get Gained/Lost data report call **/
     $scope.getGainedLostDataReport = function(){
    	 if($scope.selectedFromDate!='' && $scope.selectedFromDate!=undefined && $scope.selectedToDate!='' && $scope.selectedToDate!=undefined){
    		 $scope.isDataSearchedForTab2 = true;	
    		 $scope.isDataSearchedForTab1 = false;	
    		 $scope.isDataSearchedForTab3 = false;	
    		 advReportFactory.getGainedLostDataReport({fromDate:$scope.firstDateOfMonthForGainLostGridFromDate,toDate:$scope.lastDateOfMonthForGainLostGridToDate,isActive:true},function(response){
    			 $scope.gainedDataList = response.data.reportsGainedLostDataList;
    			 
    			 angular.forEach($scope.gainedDataList,function(value,key){
    				 if(value.affiliationTypeName == "Total"){
    					 $scope.totalDataCountMatrix = value.totalRegionRecordCnt;
    					 
    				 }
    			 });
    			 
    			 $scope.tableParams = new ngTableParams({count:15}, {dataset: $scope.gainedDataList});
    		 });
    		 
    		 advReportFactory.getGainedLostDataReport({fromDate:$scope.firstDateOfMonthForGainLostGridFromDate,toDate:$scope.lastDateOfMonthForGainLostGridToDate,isActive:false},function(response){
    			 $scope.lostDataList = response.data.reportsGainedLostDataList;
    			 
    			 angular.forEach($scope.lostDataList,function(value,key){
    				 if(value.affiliationTypeName == "Total"){
    					 $scope.totalInactiveDataCountMatrix = value.totalRegionRecordCnt;
    					 
    				 }
    			 });
    			 
    			 $scope.tableParams1 = new ngTableParams({count:15}, {dataset: $scope.lostDataList});
    		 });
    	 }else{
    		 $scope.isDataSearchedForTab2 = false;	
    		 $scope.isDataSearchedForTab1 = false;	
    		 $scope.isDataSearchedForTab3 = false;	
    	 }
    	 
     }
     
     
     $scope.callForGetYearQTDDataReport = function(){
    	 advReportFactory.getYearQTDDataReport({xtodate:$scope.ytdQtdNameToFind,qoqfrom:$scope.compareNameToFind,qoqto:$scope.againstNameToFind,isActive:true,dropdownvalue1:$scope.dropdownvalue1,dropdownvalue2:$scope.dropdownvalue2},function(response){
			 $scope.reportsTYLYGainedList = response.data.reportsTYLYGainedDataList;
			 
			 angular.forEach($scope.reportsTYLYGainedList,function(value,key){
				 if(value.affiliationTypeName == "Total"){
					 $scope.totalDataCountMatrix = value.totalRegionRecordCnt;
					 
				 }
				 if(value.affiliationTypeName == "% Change"){
					 value.anCnt = value.anCnt+"%";
					 value.apCnt = value.apCnt+"%";
					 value.asCnt = value.asCnt+"%";
					 value.eameCnt = value.eameCnt+"%";
					 value.totalRegionRecordCnt = value.totalRegionRecordCnt+"%";
				 }
			 });
			 
			 $scope.tableParams = new ngTableParams({count:15}, {dataset: $scope.reportsTYLYGainedList});
		 });
		 
		 advReportFactory.getYearQTDDataReport({xtodate:$scope.ytdQtdNameToFind,qoqfrom:$scope.compareNameToFind,qoqto:$scope.againstNameToFind,isActive:false,dropdownvalue1:$scope.dropdownvalue1,dropdownvalue2:$scope.dropdownvalue2},function(response){
			 $scope.reportsTYLYGainedList2 = response.data.reportsTYLYGainedDataList;
			 
			 angular.forEach($scope.reportsTYLYGainedList2,function(value,key){
				 if(value.affiliationTypeName == "Total"){
					 $scope.totalInactiveDataCountMatrix = value.totalRegionRecordCnt;
					 
				 }
				 if(value.affiliationTypeName == "% Change"){
					 value.anCnt = value.anCnt+"%";
					 value.apCnt = value.apCnt+"%";
					 value.asCnt = value.asCnt+"%";
					 value.eameCnt = value.eameCnt+"%";
					 value.totalRegionRecordCnt = value.totalRegionRecordCnt+"%";
				 }
			 });
			 
			 $scope.tableParams1 = new ngTableParams({count:15}, {dataset: $scope.reportsTYLYGainedList2});
		 });
		 /* change background color of %change & total rows of COMPARE GAINED Vs.LOST  tab */
		 $timeout( function(){
			 $("td:contains(% Change)").parent().addClass('total');
			 var tdList = document.getElementById("activate-inactivate-brand-report1").getElementsByTagName("td");
			 angular.forEach(tdList,function(value,key){
				 if(value.textContent.includes("-")){
					 //value.style.backgroundColor = "red";
					 value.style.color = "red";
				 }
			 });
			 var tdList = document.getElementById("activate-inactivate-brand-report2").getElementsByTagName("td");
			 angular.forEach(tdList,function(value,key){
				 if(value.textContent.includes("-")){
					 //value.style.backgroundColor = "red";    
					 value.style.color = "red";
				 }
			 })
			 //$("td:contains(Total TY)").parent().addClass('total');
			 //$("td:contains(Total LY)").parent().addClass('total');
			 /*var table = document.getElementById("activate-inactivate-brand-report");
			 var rows = table.getElementsByTagName("tr");
			 for (var z = 0; z < rows.length; z++) {
			     console.log(rows[z].cells.length)
			     rows[z].cells[0].style.backgroundColor = "red"; 
			     rows[z].cells[4].style.backgroundColor = "red";
			 }*/
			 /*var tdList = document.getElementById("activate-inactivate-brand-report").getElementsByTagName("td");
			 angular.forEach(tdList,function(value,key){
				 value.style.backgroundColor = "yellow";    
			 })*/
	        },1000);
     }
     
     
     /** Get YTD/QTD data report call **/
     $scope.getYearQTDDataReport = function(){
    	 $scope.isDataSearchedForTab2 = false;	
		 $scope.isDataSearchedForTab1 = false;	
		 $scope.isDataSearchedForTab3 = true;
		 if($scope.input.dropDownId!='' && $scope.input.dropDownId!= undefined){
			 if($scope.secondDropDownValueSelected){
				 if($scope.input.compareId=='' || $scope.input.compareId==null || $scope.input.compareId==undefined){
					 jAlert(jQuery.i18n.prop('validate_compare_value'));
		    		 $scope.isDataSearchedForTab3 = false;
				 }else if($scope.input.againstId=='' || $scope.input.againstId==null || $scope.input.againstId==undefined){
					 jAlert(jQuery.i18n.prop('validate_against_value'));
		    		 $scope.isDataSearchedForTab3 = false;
				 }else{
					 $scope.callForGetYearQTDDataReport();
				 }
			 }else{
				 if($scope.input.ytdQtdId!='' && $scope.input.ytdQtdId!=undefined){
					 $scope.callForGetYearQTDDataReport();
				 }else{
					 $scope.isDataSearchedForTab3 = false;
				 }
			 }
			 
		 }else{
			 $scope.isDataSearchedForTab3 = false;
		 }
    		 
     }
     
     $scope.exportToExcel = function(report){
 			$scope.inputRequest = {};
 			/** set parameters if wants to get limited data*/
 			//$scope.inputRequest.pageNumber = $scope.offset;
 			//$scope.inputRequest.records = $scope.count;
 			//$scope.inputRequest.sortOrder = 'desc';
 			/**---------------------------------------------*/
 			$scope.inputRequest.lang = 'en';
 			
 			if(report=='firstReport'){
 				$scope.inputRequest.firstDataList = $scope.reportsList;
 	 			$scope.inputRequest.secondDataList = $scope.reportsInactiveList;
 	 			$scope.inputRequest.reportName = 'firstReport';
 	 			
 	 			$scope.inputRequest.monthForFirstReport = $scope.monthForFirstReport;
 	 			$scope.inputRequest.yearForFirstReport = $scope.yearForFirstReport;
 	 			
 			}else if(report=='secondReport'){
 				$scope.inputRequest.firstDataList = $scope.gainedDataList;
 	 			$scope.inputRequest.secondDataList = $scope.lostDataList;
 	 			$scope.inputRequest.reportName = 'secondReport';
 	 			
 	 			$scope.inputRequest.monthFromForSecondReport = $scope.monthFromForSecondReport;
 	 			$scope.inputRequest.yearFromForSecondReport = $scope.yearFromForSecondReport;
 	 			$scope.inputRequest.monthToForSecondReport = $scope.monthToForSecondReport;
 	 			$scope.inputRequest.yearToForSecondReport = $scope.yearToForSecondReport;
 	 			
 			}else if(report=='thirdReport'){
 				$scope.inputRequest.reportName = 'thirdReport';
 				
 				if($scope.flagForHeader1){
 					$scope.inputRequest.flagForHeader1ThirdReport = $scope.flagForHeader1;
 					$scope.inputRequest.selectedXToDateForThirdReport = $scope.selectedXToDateForThirdReport;
 					$scope.inputRequest.currentDateForThirdReport = $scope.currentDateForThirdReport;
 				}
 				if($scope.flagForHeader2){
 					$scope.inputRequest.flagForHeader2ThirdReport = $scope.flagForHeader2;
 					$scope.inputRequest.comapreNameForGridThird = $scope.comapreNameForGridThird;
 					$scope.inputRequest.againstNameForGridThird = $scope.againstNameForGridThird;
 				}
 				
 				$scope.reportsTYLYGainedListForExportToExcel = angular.copy($scope.reportsTYLYGainedList);
 				$scope.reportsTYLYGainedList2ForExportToExcel = angular.copy($scope.reportsTYLYGainedList2);
 				
 				angular.forEach($scope.reportsTYLYGainedListForExportToExcel,function(value,key){
 					if(value.affiliationTypeName=="% Change"){
 						value.anCnt = value.anCnt.replace(/\%/g,'');
 						value.apCnt = value.apCnt.replace(/\%/g,'');
 						value.asCnt = value.asCnt.replace(/\%/g,'');
 						value.eameCnt = value.eameCnt.replace(/\%/g,'');
 						value.totalRegionRecordCnt = value.totalRegionRecordCnt.replace(/\%/g,'');
 					}
 				});
 				angular.forEach($scope.reportsTYLYGainedList2ForExportToExcel,function(value,key){
 					if(value.affiliationTypeName=="% Change"){
 						value.anCnt = value.anCnt.replace(/\%/g,'');
 						value.apCnt = value.apCnt.replace(/\%/g,'');
 						value.asCnt = value.asCnt.replace(/\%/g,'');
 						value.eameCnt = value.eameCnt.replace(/\%/g,'');
 						value.totalRegionRecordCnt = value.totalRegionRecordCnt.replace(/\%/g,'');
 					}
 				});
 				$scope.inputRequest.firstDataList = $scope.reportsTYLYGainedListForExportToExcel;
 	 			$scope.inputRequest.secondDataList = $scope.reportsTYLYGainedList2ForExportToExcel;
 			}
 			
 			//window.location.href = $rootScope.urlContext+'/brandadvocate/manage/details/v1/exporttoexcelforactiveinactiveasofgivendate?reportsrequest='+angular.toJson($scope.inputRequest);
			$http({
			    url: '/brandadvocate/reports/details/v1/exporttoexcel',
			    method: "POST",
			    data: angular.toJson($scope.inputRequest), //this is your json data string
			    headers: {
			       'Content-type': 'application/json'
			    },
			    responseType: 'arraybuffer'
			}).success(function (data, status, headers, config) {
			    var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"});
			    var todaysDate = new Date();
			    saveAs(blob, "BrandAdvocateDetails_"+todaysDate+".xlsx");
			    //var objectUrl = URL.createObjectURL(blob);
			    //window.open(objectUrl);
			}).error(function (data, status, headers, config) {
			    //upload failed
			});
 			
 		
 	};
     
}]);
