'use strict';

baControllers.controller('editAdvRegisterUserCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'editAdvRegisterUserFactory','filterFilter','localStorageService','Idle','$cookieStore','loggedInUserService','$window', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, editAdvRegisterUserFactory,filterFilter,localStorageService,Idle,$cookieStore,loggedInUserService,$window){

	$scope.preferencesArray = [];
	$scope.preferencesList = [];
	$scope.preferences = [];
	$scope.preferencesData = [];
	$scope.preferencesTemp = [];
	$scope.preferencesToSave = [];
	
	$scope.subscriptionPreferencesList = [];
	
	$scope.input = new editAdvRegisterUserFactory();
	
	$scope.input.preferences = [];

	$scope.validateRegisterQue = jQuery.i18n.prop('validate_register_que');
	$scope.enterEmail = jQuery.i18n.prop('enter_email');
	$scope.validateBuilding = jQuery.i18n.prop('validate_building');
	
	$scope.validateClueField = jQuery.i18n.prop('clue_populated_value_modify');
	
	$scope.isClueField = true;
	$scope.checkboxUncheckFlag = false;
	
	var searchObject = $location.search();
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	$rootScope.baExistInPortal  = localStorageService.get("baexistinportal");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName;
	
	$scope.brandAdvocateIdFromLoginForEditPage = localStorageService.get("brandAdvocateIdFromLoginForEditPage");
	
    $scope.onLoad = function(){
    	
    	var lineHeight = $('.col-md-6').height();
		console.log('lineHeight',lineHeight);
		$('.vertical-divider').height(lineHeight+60);
    	
    	$scope.radiobrandadvocate = true; //default radio button check.
    	/** Code for preferences dropdown start*/
    	 $scope.preferencesSettings = {
    		      scrollableHeight: '170px',
    		      scrollable: true,
    		      enableSearch: false
    		    };
    	 
    		    $scope.getData = function() {
    		    	$scope.$watch('preferences', function(val) {
    		    		$scope.val = val;
    		    		
    		    });
    		    };
    		    
    		    angular.element(document).on('click', function () {
    		    	if(!isEmpty($scope.val)){
    		    	$scope.getData();
    		    	}
    		    });
    		    
    	  /** Code for preferences dropdown end*/
    		    
    		editAdvRegisterUserFactory.getCountries(function(response){
    				$scope.countryList = response.data.LIST;	
    				$scope.onLoadCountryList = angular.copy($scope.countryList);
    		});

    		editAdvRegisterUserFactory.getRegions(function(response){
    			$scope.regionList = response.data.LIST;	
    			$scope.onLoadRegionList = angular.copy($scope.regionList);
    		});
    		
    		$scope.userRegisterQueList = [{registerId:1 ,registerVia:"Manual entry"},{registerId:2 ,registerVia:"Took a brand class"},
    			{registerId:3 ,registerVia:"Participated in other training"},{registerId:4 ,registerVia:"Completed Big Yellow Quiz"},{registerId:5 ,registerVia:"Registered through the portal"}];
    		
    		$scope.brandAdvocateStatusList = [{brandAdvocateStatusId:1 ,brandAdvocateStatus:"Brand Advocate"},{brandAdvocateStatusId:2 ,brandAdvocateStatus:"CBA"},{brandAdvocateStatusId:3 ,brandAdvocateStatus:"CBA Instructor"}];
    		$scope.input.brandAdvocateStatus = "Brand Advocate"; //default value
    		
    }
    
    $scope.onLoad();
    
    $scope.getBAUserDetailsById = function(brandAdvocateId){
    	editAdvRegisterUserFactory.getBAUserDetailsById({brandadvocateid:brandAdvocateId},function(result){
			$scope.resultData = result.data.userMasterDto;
			$scope.input.brandAdvocateId = $scope.resultData.brandAdvocateId; 
			$scope.input.cwsUserId = $scope.resultData.cwsUserId; 
			$scope.input.cupId = $scope.resultData.cupId;
			//$scope.baSince =  $filter('date')($scope.resultData.baSince, "MM/dd/yyyy");
			//$scope.input.workLocation = $scope.resultData.workLocation;
			$scope.input.registeredVia = $scope.resultData.registeredVia;
			$scope.input.affiliationDescription = $scope.resultData.affiliationDescription;
			$scope.input.mappedAffiliationName = $scope.resultData.mappedAffiliationName;
			$scope.input.lastName = $scope.resultData.lastName;
			$scope.input.firstName = $scope.resultData.firstName;
			$scope.input.preferredFirstName = $scope.resultData.preferredFirstName;
			$scope.input.organizationName = $scope.resultData.organizationName;
			$scope.input.facilityName = $scope.resultData.facilityName;
			$scope.input.buildingName = $scope.resultData.buildingName;
			$scope.input.jobKeywords = $scope.resultData.jobKeywords;
			$scope.input.countryId = $scope.resultData.countryId;
			$scope.input.regionId = $scope.resultData.regionId;
			$scope.input.primaryEmail = $scope.resultData.primaryEmail;
			$scope.input.secondaryEmail = $scope.resultData.secondaryEmail;
			$scope.input.brandAdvocateStatus = $scope.resultData.brandAdvocateStatus;
			$scope.input.notes = $scope.resultData.notes;
			//extra values send values at the time of save not used on UI.
			$scope.input.countryName = $scope.resultData.countryName;
			$scope.input.countryCode = $scope.resultData.countryCode;
			$scope.input.regionName = $scope.resultData.regionName;
			$scope.previousComments = $scope.resultData.comments;
			if($scope.previousComments == null){
				$scope.previousComments = '';
			}
			$scope.input.registrationDate = $scope.resultData.registrationDate;
			$scope.input.secondaryEmail = $scope.resultData.secondaryEmail;

			$scope.input.registrationDate = $scope.resultData.registrationDate;
			$scope.input.registeredBy = $scope.resultData.registeredBy;
			
			$scope.brandAdvocateStatusDb = $scope.resultData.brandAdvocateStatus;
			if($scope.brandAdvocateStatusDb == "Brand Advocate"){
				$scope.radiobrandadvocate = true;
				$scope.radiocba = false;
				$scope.radiocbainstructor = false;
			}else if($scope.brandAdvocateStatusDb == "Certified Brand Advocate (CBA)"){
				$scope.radiocba = true;
				$scope.radiobrandadvocate = false;
				$scope.radiocbainstructor = false;
			}else if($scope.brandAdvocateStatusDb == "CBA Instructor"){
				$scope.radiocbainstructor = true;
				$scope.radiobrandadvocate = false;
				$scope.radiocba = false;
			}
			
			/**new code changes for subscription preferences starts*/
			
			$scope.subscriptionPreferencesList = [];
			$scope.checkboxModel=[];
			angular.forEach($scope.resultData.preferences,function(value,key){
				$scope.subscriptionPreferencesList.push({"preferenceId":value[0],"preferenceName":value[1].trim()});
 			});

			angular.forEach($scope.subscriptionPreferencesList,function(value,key){
				if(value.preferenceName == "Webinar invitations"){
					$scope.checkboxModel.webinarCheckbox = true;
				}else if(value.preferenceName == "Brand event communications"){
					$scope.checkboxModel.brandEventCheckbox = true;
				}else if(value.preferenceName == "Newsletters"){
					$scope.checkboxModel.newsletterCheckbox = true;
				}
			});
			
			/**new code changes for subscription preferences ends*/
			
			//$scope.preferences = [$scope.preferencesData[0]]; //dummy Data need to replace with actual value
			$scope.preferencesTemp = [];
			 editAdvRegisterUserFactory.getPreferences(function(response){
		 			$scope.preferencesList = response.data.LIST;
		 			angular.forEach($scope.preferencesList,function(value,key){
		 				$scope.preferencesData.push({"label":value.preferenceName,"id":value.preferenceId});
		 				console.log($scope.preferencesData);
		 			});
		 			angular.forEach($scope.resultData.preferences,function(value,key){
		 				$scope.preferencesTemp.push({"label":value[1],"id":value[0]});
		 				console.log($scope.preferencesTemp);
		 			});
		 			$scope.preferences = $scope.preferencesTemp;
		 		});
			
 			
			if($scope.input.cwsUserId!=''){
				$scope.isClueField = true;
			}

		});

	}
	
    
    if (searchObject.brandAdvocateId!=undefined && searchObject.brandAdvocateId !='') {
		var brandAdvocateId = searchObject.brandAdvocateId;
				$scope.getBAUserDetailsById(brandAdvocateId);
		}else{
			$scope.getBAUserDetailsById($scope.brandAdvocateIdFromLoginForEditPage);
		}
    
    
    $scope.getRegionsByCountryId = function(countryId){
    	if(countryId!=null && countryId!=undefined){
    	editAdvRegisterUserFactory.getRegionsByCountryId({countryid:countryId},function(response){
    		$scope.regionList = response.data.LIST;	
    	});
    	}else{
    		$scope.regionList = $scope.onLoadRegionList;
    		$scope.input.regionId='';
    	}
    	
    }

    $scope.getCountriesByRegionId = function(regionId){
    	if(regionId!=null && regionId!=undefined){
    	editAdvRegisterUserFactory.getCountriesByRegionId({regionid:regionId},function(response){
    		$scope.countryList = response.data.LIST;	
    	});
    	}else{
    		$scope.countryList = $scope.onLoadCountryList;
    		$scope.input.countryId='';
    	}
    }
    
	/*$scope.validatePrimaryEmail = function(primaryEmail){
		var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
		if(primaryEmail === undefined || primaryEmail == '' || primaryEmail == null){
			return true;
		}else if (reg.test(primaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_email_id'));
			$scope.input.primaryEmail = '';
			return false;
		}else{
			return true;
		}
	};*/
    
    $scope.validateSecondaryEmail = function(secondaryEmail){
		//var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
    	var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(secondaryEmail === undefined || secondaryEmail == '' || secondaryEmail == null){
			return true;
		}else if (reg.test(secondaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_secondary_email_id'));
			$scope.input.secondaryEmail = '';
			return false;
		}else{
			return true;
		}
	};
	
	/**new code changes for subscription preferences starts*/
	
	 $scope.checkboxModel = {
			 webinarCheckbox : true,
		     brandEventCheckbox : true,
		     newsletterCheckbox : true
	 };

	$scope.preferencesCheckboxChange = function(selectedCheckBoxValue,prefCheckBoxValue){
		if(!prefCheckBoxValue){
		if(selectedCheckBoxValue=='webinarCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":1,"preferenceName":"Webinar invitations"});
		}else if(selectedCheckBoxValue=='brandEventCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":2,"preferenceName":"Brand event communications"});
		}else if(selectedCheckBoxValue=='newsletterCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":3,"preferenceName":"Newsletters"});
		}
		}else{
			var index;
			if(selectedCheckBoxValue=='webinarCheckbox'){
				index = $scope.getIndex("Webinar invitations");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='brandEventCheckbox'){
				index = $scope.getIndex("Brand event communications");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='newsletterCheckbox'){
				index = $scope.getIndex("Newsletters");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}
		}
	}
	
	$scope.getIndex = function(val){
		var index = -1;
		var filteredObj = $scope.subscriptionPreferencesList.find(function(item, i){
     	  if(item.preferenceName === val){
     		index = i;
     	  }
     	});
		return index;
	}
	
	/**new code changes for subscription preferences ends*/
	
	$scope.updateDetails = function(){
		//get toggle value
		/*console.log("Toggle Value :"+$scope.toggleValue);
		angular.forEach($scope.val,function(value,key){
    		$scope.input.preferences.push({"preferenceId" : value.id});
		})*/
		/*angular.forEach($scope.preferences,function(value,key){
			if(value.i)
		}*/
		$scope.input.managedBy = "System";
		$scope.input.loggedInUserName = $scope.loggedInUserName;
		
		$scope.preferencesToSave = [];
		angular.forEach($scope.preferences,function(value,key){
			angular.forEach($scope.preferencesList,function(valuePref,keyPref){
				if(value.id == valuePref.preferenceId){
					$scope.preferencesToSave.push({"preferenceId":valuePref.preferenceId,"preferenceName":valuePref.preferenceName});
				}
 			});
		});
		//$scope.input.preferences = $scope.preferencesToSave;
		$scope.input.preferences = $scope.subscriptionPreferencesList;
		
		if($scope.registerForm.$valid){
			if($scope.validateRegistrationDetails()){
				var saveMsg ;
					saveMsg = 'user_update_as_ba_success';
		
		if($scope.commentsQue !='' && $scope.commentsQue != undefined && $scope.previousComments!=''){
			var allComments = $scope.previousComments+", "+$scope.commentsQue;
		}else if($scope.commentsQue !='' && $scope.commentsQue != undefined && $scope.previousComments==''){
			var allComments = $scope.commentsQue;
		}else{
			var allComments = $scope.previousComments;
		}
		$scope.input.comments = allComments;
		
		editAdvRegisterUserFactory.saveAdminInformation($scope.input,function(response){
			jAlert(jQuery.i18n.prop(saveMsg),jQuery.i18n.prop('common_success'),function(){
				if(response.statusCode == false){
					jAlert(response.msg);
				}if(response.statusCode == "OK"){
					$window.location.href = 'https://brand.cat.com/en/education.html';
				}
			});
		});
	}
	}else{
			angular.element("[name='" + $scope.registerForm.$name + "']").find('.ng-invalid:visible:first').focus();
  	        return false;
  		}

	}
	
	
	/** validation for User fields */
	$scope.validateRegistrationDetails = function(){
			if($scope.input.buildingName == '' || $scope.input.buildingName == undefined){
				jAlert(jQuery.i18n.prop('validate_building'));
				return false;
			}else{
				return true;
			}
	}
	
	/**default check checkbox*/
	//$scope.checkBoxValue=true;
	
	/*$scope.checkBoxChange = function(checkBoxValue){
		if(checkBoxValue){
			$scope.isClueField = true;
			$scope.checkboxUncheckFlag = false;
		}else{
			$scope.isClueField = false;
			$scope.checkboxUncheckFlag = true;
			$scope.input.cwsUserId = '';
		}
	}*/
	
	
	$scope.resetDetails = function(){
		/*$scope.input.buildingName = '';
		$scope.input.jobKeywords = '';
		$scope.input.comments = '';
		$scope.input.secondaryEmail = '';
		$scope.commentsQue = '';*/
		$route.reload();
	}
	
	var myVideo = document.getElementById("video1");
	$scope.playPause = function() { 
	    if (myVideo.paused) 
	        myVideo.play(); 
	    else 
	        myVideo.pause(); 
	} 

	$scope.makeBig = function() { 
	    myVideo.width = 450; 
	    myVideo.height = 250;
	} 

	$scope.makeSmall = function() { 
	    myVideo.width = 350;
	    myVideo.height = 250;
	} 

	$scope.makeNormal = function() { 
	    myVideo.width = 420;
	    myVideo.height = 250;
	} 
	
	$('.play').on('click', function () {
		  $(this).toggleClass('pause');
		});
    
}]);

