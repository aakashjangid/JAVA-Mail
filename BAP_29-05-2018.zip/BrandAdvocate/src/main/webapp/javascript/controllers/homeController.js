'use strict';

baControllers.controller('homeCtrl',['$scope', '$window', '$rootScope','localStorageService','Idle','$cookieStore',function($scope,$window, $rootScope, localStorageService,Idle,$cookieStore){
	
	
}]);