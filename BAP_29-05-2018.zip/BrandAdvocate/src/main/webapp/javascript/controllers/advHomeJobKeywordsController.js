'use strict';

baControllers.controller('advHomeJobKeywordsCtrl',['$scope','$http','$location','$rootScope', '$route','ngDialog', '$filter', function($scope, $http, $location, $rootScope, $route, ngDialog, $filter){
	
	$scope.input.jobKeywords = $scope.jobKeywords;
	
	
}]);
