'use strict';

baControllers.controller('advBulkUploadResponseCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter','filterFilter','localStorageService','Idle','$cookieStore', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter,filterFilter,localStorageService,Idle,$cookieStore){

	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	$scope.reponseUploadData = $scope.response;
	
	$scope.nonExistingUsers = $scope.reponseUploadData.strValidCluesUsers;
	$scope.inActiveUsers = $scope.reponseUploadData.strExistingNonActiveUsers;
	$scope.activeUsers = $scope.reponseUploadData.strExistingActiveUsers;
	$scope.inValidClueUsers = $scope.reponseUploadData.strInValidCluesUsers;
	
	$scope.cancel = function(){
		$location.path('/bulkUpload').search('');
		$route.reload();
	}
	
}]);