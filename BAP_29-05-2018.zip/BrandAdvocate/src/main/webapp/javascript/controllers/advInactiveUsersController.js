'use strict';

baControllers.controller('advInactiveUsersCtrl',['$scope','$http','$location','$rootScope', '$route', 'ngTableParams','ngDialog', '$filter', 'advInactiveUsersFactory','filterFilter','localStorageService', function($scope, $http, $location, $rootScope, $route, ngTableParams, ngDialog, $filter, advInactiveUsersFactory,filterFilter,localStorageService){

	/**Global Variables*/
	$scope.input = new advInactiveUsersFactory();
	$scope.finalInput = new advInactiveUsersFactory();
	$scope.baList = [];
	$scope.inputRequest = new advInactiveUsersFactory();
	$scope.offset = 0;
	$scope.count = 10;
	$scope.srtng = "desc";
	$scope.IsVisible_nodata = true;
	$scope.allDataCount = 0;
	$scope.countForToggle = 0;
	$scope.allSearchDataCount = '';
	$scope.search = "";
	$rootScope.urlChange = false;
	$scope.isEnable = false;
	
	$scope.preferencesArray = [];
	$scope.preferencesList = [];
	$scope.preferences = [];
	$scope.preferencesData = [];
	$scope.preferencesTemp = [];
	$scope.preferencesToSave = [];
	
	
	/**Table headers i18N*/
	$scope.lCupId = jQuery.i18n.prop('user_cup_id');
	$scope.lCwsUserId = jQuery.i18n.prop('cws_user_id');
	$scope.lLastName = jQuery.i18n.prop('last_name');
	$scope.lFirstName = jQuery.i18n.prop('first_name');
	$scope.lPreferredFirstName = jQuery.i18n.prop('preferred_first_name');
	$scope.lDivision = jQuery.i18n.prop('org_unit');
	$scope.lEmail = jQuery.i18n.prop('common_email');
	$scope.lSecondaryEmail = jQuery.i18n.prop('secondary_email');
	$scope.lRegion = jQuery.i18n.prop('region');
	$scope.lCountry = jQuery.i18n.prop('country');
	$scope.lFacilityName = jQuery.i18n.prop('facility_name');
	$scope.lBuildingName = jQuery.i18n.prop('common_building');
	$scope.lJobKeywords = jQuery.i18n.prop('job_keywords');
	$scope.lAffiliationDescription = jQuery.i18n.prop('affiliation_description');
	$scope.lBrandAdvocateStatus = jQuery.i18n.prop('brand_advocate_status');
	$scope.lBaStatus = jQuery.i18n.prop('common_ba_status');
	$scope.lComments = jQuery.i18n.prop('questions_comments');
	$scope.lNotes = jQuery.i18n.prop('common_notes');
	$scope.lRegisteredVia = jQuery.i18n.prop('common_registered_via'); 
	$scope.lRegistrationDate = jQuery.i18n.prop('common_registration_date');  
	$scope.lRegisteredBy = jQuery.i18n.prop('common_registered_by');  
	$scope.lModifiedDate = jQuery.i18n.prop('common_modified_date');  
	$scope.lInactiveDate = jQuery.i18n.prop('common_inactive_date');  
	$scope.lModifiedBy = jQuery.i18n.prop('common_modified_by'); 
	$scope.lManagedBy = jQuery.i18n.prop('common_managed_by');  
	$scope.lSubscription = jQuery.i18n.prop('sub_preferences');  
	
	
	$scope.lAction = jQuery.i18n.prop('common_action');
	$scope.lNext = jQuery.i18n.prop('common_next');
	$scope.lPrevious = jQuery.i18n.prop('common_previous');
	$scope.lAll = jQuery.i18n.prop('common_all');
	$scope.lPage = jQuery.i18n.prop('common_page');
	$scope.lFirstPage = jQuery.i18n.prop('common_first_page');
	$scope.lLastPage = jQuery.i18n.prop('common_last_page');
	$scope.lPreviousPage = jQuery.i18n.prop('common_previous_page');
	$scope.lNextPage = jQuery.i18n.prop('common_next_page');
	

	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName;
	
	
	$scope.loadData = function(){
		
		//$scope.inputRequest.pageNumber = $scope.offset;
		//$scope.inputRequest.records = $scope.count;
		$scope.inputRequest.sortOrder = 'desc';
		$scope.inputRequest.globalSearch = $scope.search;
		$scope.inputRequest.isActive = 'N';
		$scope.inputRequest.criteriaFlag = false;
		advInactiveUsersFactory.getAllAdminDetails({manageadminrequest:$scope.inputRequest}, function(result){
			$scope.baListTemp = result.data.LIST;
			var data = $scope.baListTemp;
			
			/** Logic to get values in multiselect dropdown of grid start*/
			advInactiveUsersFactory.getPreferences(function(response){
		 			$scope.preferencesList = response.data.LIST;
		 			angular.forEach($scope.preferencesList,function(value,key){
		 				$scope.preferencesData.push({"label":value.preferenceName,"id":value.preferenceId});
		 				console.log($scope.preferencesData);
		 			});
		 			
		 			angular.forEach($scope.baListTemp,function(value,key){
		 				$scope.preferencesTemp = [];
		 				angular.forEach(value.preferences,function(value,key){
			 				$scope.preferencesTemp.push({"label":value[1],"id":value[0]});
			 				console.log($scope.preferencesTemp);
			 			});
		 				$scope.preferences = $scope.preferencesTemp;
		 				
		 				value.preferences = $scope.preferences; // set preferences of each record in original list from database
		 		});
			});
			/** Logic to get values in multiselect dropdown of grid end*/
			
			
			$scope.baList = $scope.baListTemp;   //set list to iterate on UI.
			
			angular.forEach($scope.baList, function(value, key){
				if(value.baSince){
					value.baSince = $filter('date')(value.baSince, "MM/dd/yyyy");
				}
			});
		
			if ($scope.baList != null && $scope.baList.length > 0) {
	             $scope.IsVisible_nodata = false;
	    }else{
	             $scope.IsVisible_nodata = true;
	    }
		
		var length = result.data.COUNT;
		$scope.totalDataCount = result.data.COUNT;
		$scope.total = Math.ceil(length/$scope.count);
		if ($scope.count < 0) 
		{
			$scope.total = 1;
           $scope.allDataCount=result.data.COUNT;
       } else
       {
       	$scope.allDataCount=$scope.count;
       }
		$scope.currentPage = $scope.offset+1;
		//** Sorting and Filtering *//*
		$scope.tableParams = new ngTableParams(
			{
				page : 1,
				count : $scope.allDataCount,
				sorting: {
					customModifiedDate: 'desc'     // initial sorting
		        }
			},
			{
				 filterSwitch: true,
		         total: 0, //data.length, // length of data
				// filterDelay : 0,
			      getData: function($defer, params) {
			    	// use build-in angular filter
			    	  //var data = angular.copy($scope.baList);
	                    var filteredData = params.filter() ?  $filter('filter')(data, params.filter()) : $scope.baList;
	                    var orderedData = params.sorting() ? $filter('orderBy')(filteredData, params.orderBy()) : filteredData;
	                    params.total(orderedData.length);
	                    // set total for recalc pagination
	                    $defer.resolve(orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count()));
			      },
		});
	});
		
	};
	
	$scope.loadData();
	
	
	/**No. of records(5,10,20,All) changed*/
	$scope.updateRecords = function(){
		$scope.offset = 0;
		$scope.currentPage = 1;
		$scope.selectedAll = false;
		$scope.countForToggle = 0;
		$scope.loadData();
	};

	/**Pagination action*/
	$scope.PagingAct = function(page) {
		$scope.selectedAll = false;
		$scope.countForToggle = 0;
		$scope.offset = page-1;
		$scope.loadData();		
	}
	
	/** Common Search */
    $scope.baSearchChange = function(){
		$scope.offset = 0;
		$scope.selectedAll = false;
		$scope.countForToggle = 0;
		$scope.loadData();
	};
	
	/**Select-Unselect all checkboxes*/
	$scope.selectAllCheckbox = function () {
		
		if ($scope.selectedAll) {
			$scope.countForToggle = 0;
			$scope.selectedAll = false;		
		}else {
			$scope.countForToggle = $scope.totalDataCount;
			$scope.selectedAll = true;	
			
		}	
		
			angular.forEach($scope.baList, function (item) {
				item.Selected = $scope.selectedAll;
			});
	};
	
	
	$scope.changeToggleStatus = function(itemSelected, index, baData){
		 var primaryEmailFromToggle = baData.primaryEmail;
		 var secondaryEmailFromToggle = baData.secondaryEmail;
		 var firstNameFromToggle = baData.firstName;
		 var lastNameFromToggle = baData.lastName;
		
		if(itemSelected){
			$scope.countForToggle-- ;
			
			
		}else{
			$scope.countForToggle++ ;
			
		}
		
		$scope.finalList = angular.copy($scope.baList);
		$scope.finalList = filterFilter($scope.finalList,$scope.search);
		if($scope.finalList.length != 0 && $scope.countForToggle>=$scope.finalList.length && !itemSelected){
			$scope.selectedAll = true;
		}else{
			$scope.selectedAll = false;
		}
	}
	
	
	
	/*$scope.editAdvInfo = function(viewMode, brandAdvocateId){
		$location.path('/editBrandInfo').search({
			brandAdvocateId : brandAdvocateId,
			mode : viewMode
		});
	}*/
	
	$scope.addAdvocateNotes = function(brandAdvocateId,notes){
		$scope.brandAdvocateId = brandAdvocateId;
		$scope.notes = notes;
		$scope.activeGridRequest = false;
		$rootScope.dialog = ngDialog.open({
		    template: 'html/home/advocate_home_notes.html',
		    controller: 'advHomeNotesCtrl',
		    closeByDocument: false,
		    showClose: false,
		    scope : $scope
		});
	};

	$scope.addAdvocateComments = function(brandAdvocateId,comments){
		$scope.brandAdvocateId = brandAdvocateId;
		$scope.comments = comments;
		$scope.activeGridRequest = false;
		$rootScope.dialog = ngDialog.open({
			template: 'html/home/advocate_home_comments.html',
			controller: 'advHomeCommentsCtrl',
			closeByDocument: false,
			showClose: false,
			scope : $scope
		});
	};
	
	$scope.onSecondaryEmail=function(secEmail,index,baData){
		$scope.input=baData;
		$scope.input.secondaryEmail=secEmail;
		
		advInactiveUsersFactory.updateSecondaryMail($scope.input);
	};
	
	
	/*$scope.deleteAdvInfo = function(recordId){
		advInactiveUsersFactory.deleteUserInfo({recordid:recordId},function(result){
			$route.reload();
		});
	}*/
	
	$scope.changeActiveStatus = function(brandAdvocateId){
		
		jConfirm(jQuery.i18n.prop('ba_active'), jQuery.i18n.prop('common_confirmation_dialog'), function(r) {
			 if(r)
		     {
				 var activeStatus = true;
				 advInactiveUsersFactory.changeActiveStatus({brandadvocateid:brandAdvocateId,activestatus:activeStatus,loggedinusername:$scope.loggedInUserName},function(result){
						$route.reload();
					});
		     }else {
		    	 //$route.reload();
                   return;
             }
		});
		
	}
	
	
	$scope.selectCss='checked';
    $scope.toggle=function(selectCss){
      
        if(selectCss==='checked'){
        
            $scope.selectCss='unchecked';
        }else{
         
         $scope.selectCss='checked';
        }
    }
    
    
    /** Code for preferences dropdown start*/
	 $scope.preferencesSettings = {
		      scrollableHeight: '85px',
		      scrollable: true,
		      enableSearch: false,
		      showUncheckAll: false,
		      showCheckAll:false
		    };
	 
	 $scope.getPreferencesData = function(baData,preferences){
		 console.log('Brand Advocate Id for selected preference:'+baData.brandAdvocateId);
		 $scope.brandAdvocateIdForMultiSelect = baData.brandAdvocateId;
		 $scope.baDataForMultiSelect = baData;
		 $scope.prefForMultiSelect = preferences;
	 }
	 
	 
	 /**Logic to change subscription preferences dropdown values start*/
	 
	 $scope.changeEvents = {
              onItemDeselect: function(item) {
            	  console.log($scope.brandAdvocateIdForMultiSelect);
            	  console.log($scope.prefForMultiSelect);
            	  
            	  $scope.updateCallForPreferences();
                    
               },
              onItemSelect: function(item) {
            	  console.log($scope.brandAdvocateIdForMultiSelect);
            	  console.log($scope.prefForMultiSelect);
            	  var tempList = [];
            	  angular.forEach($scope.prefForMultiSelect,function(value,key){
            		  if(value.id==1){
            			  tempList.push({label: "Webinar invitations", id: 1});
            		  }else if(value.id==2){
            			  tempList.push({label: "Brand event communications", id: 2});
            		  }else if(value.id==3){
            			  tempList.push({label: "Newsletters", id: 3});
            		  }
            	  });
            	  $scope.prefForMultiSelect = tempList;
            	  console.log($scope.prefForMultiSelect);
            	  
            	  $scope.updateCallForPreferences();
            	  
              },
              onSelectAll: function(item) {
            	  console.log($scope.brandAdvocateIdForMultiSelect);
            	  $scope.prefForMultiSelect.push({label: "Webinar invitations", id: 1},{label: "Brand event communications", id: 2},{label: "Newsletters", id: 3});
            	  console.log($scope.prefForMultiSelect);
            	  
            	  $scope.updateCallForPreferences();
            	  
              },
              onDeselectAll: function(item) {
            	  console.log($scope.brandAdvocateIdForMultiSelect);
            	  $scope.prefForMultiSelect = [];
            	  
            	  $scope.updateCallForPreferences();
            	  
              }
   };
	 
	 
	 $scope.updateCallForPreferences = function(){
		 
	  $scope.preferencesToSave = [];
   	  $scope.baDataForMultiSelect.preferences = [];
		 angular.forEach($scope.prefForMultiSelect,function(valuePref,keyPref){
				$scope.preferencesToSave.push({"preferenceId":valuePref.id,"preferenceName":valuePref.label});
			});
 	  
 	  $scope.baDataForMultiSelect.preferences = $scope.preferencesToSave;
 	  
 	  console.log($scope.baDataForMultiSelect);
 	  $scope.baDataForMultiSelect.loggedInUserName = $scope.loggedInUserName;
 	  advInactiveUsersFactory.saveAdminInformation($scope.baDataForMultiSelect,function(response){
 		var saveMsg ;
			saveMsg = 'user_preferences_update_success';
			jAlert(jQuery.i18n.prop(saveMsg),jQuery.i18n.prop('common_success'),function(){
				if(response.statusCode == false){
					jAlert(response.msg);
				}if(response.statusCode == "OK"){
					$route.reload();
				}
			});
		});
	 }
	 
	 /**Logic to change subscription preferences dropdown values end*/
	
	 
	 $scope.deleteAdvInfo = function(brandAdvocateId){
		 
		 jConfirm(jQuery.i18n.prop('ba_delete'), jQuery.i18n.prop('common_confirmation_dialog'), function(r) {
			 if(r)
		     {
				 advInactiveUsersFactory.deleteUserInfo({brandadvocateid:brandAdvocateId},function(result){
						$route.reload();
					});
		     }else {
		    	 //$route.reload();
                   return;
             }
		});
		
	 }
			
	
}]);
