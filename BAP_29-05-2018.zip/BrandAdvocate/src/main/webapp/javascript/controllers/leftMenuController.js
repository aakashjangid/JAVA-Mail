baControllers.controller('leftMenuCtrl', [
		'$scope',
		'$rootScope',
		'$http',
		'$route',
		'$templateCache',
		'$timeout',
		'$compile',
		'$location',
		'$window',
		'i18n',

		function($scope, $rootScope, $http, $route,$templateCache, $timeout, $compile,
				$location, $window, i18n) {
			
			$scope.navigateUrl = function(url) {
				var newUrl = '/' + url;
				if(url === 'sales') {
					$('div#leftNav li').removeClass('active');
					$('div#leftNav ul.has-sub').slideUp('normal');
				}
				$rootScope.ispreferencesActive = false;
				$location.url($location.path());
				$location.path(newUrl);
				$route.reload();
			}
			
			$scope.init = function() {
				$rootScope.showLeftMenu = 'hide';
				$timeout(function(){
					$rootScope.showLeftMenu = 'show';
				},200);
			}

		} ]);
