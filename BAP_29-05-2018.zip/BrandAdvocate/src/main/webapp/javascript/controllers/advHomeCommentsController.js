'use strict';

baControllers.controller('advHomeCommentsCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'advHomeCommentsFactory','filterFilter', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, advHomeCommentsFactory,filterFilter){
	
	$scope.input = new advHomeCommentsFactory();
	$scope.input.comments = $scope.comments;
	
	$scope.addAdvocateComments = function(newComments){
		$scope.input.brandAdvocateId = $scope.brandAdvocateId;
		$scope.input.comments = newComments;
		$scope.input.loggedInUserName=$scope.loggedInUserName;
		
		advHomeCommentsFactory.addCommentsQuestions($scope.input,function(response){
			console.log(response.data);
			ngDialog.close();
			$route.reload();
		})/*.error(function(result) { 
			location.href = "#/brandInfo";
		}); */
	};
	
}]);
