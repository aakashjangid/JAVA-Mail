'use strict';

baControllers.controller('advHomeMailTemplateCtrl',['$scope',
                                    		'$filter',
                                    		'$route',
                                    		'$http',
                                    		'$location',
                                    		'$rootScope',
                                    		'$window',
                                    		'ngDialog','fileUploadService','localStorageService', function($scope, $filter, $route, $http, $location, $rootScope, $window, ngDialog,fileUploadService,localStorageService){

	
	var formData = $scope.formData;
	
	$scope.saveMailTemplate = function(templateName){
		if(templateName!='' && templateName!=undefined){
			formData.append("templatename",templateName);
			
			fileUploadService.uploadFiles('/brandadvocate/manage/details/v1/savemailtemplatedata', formData).success(function(response){
				if(response.statusCode=="OK"){
					jAlert(jQuery.i18n.prop('template_saved_successfully'),jQuery.i18n.prop('common_success'),function(r){
					if(r){
					ngDialog.close();
					window.location.reload(true)
					}
					});
				}
			}).error(function(result){
			    jAlert(response.msg);
			});		
		}else{
			jAlert(jQuery.i18n.prop('enter_template_name_error'));
		}
	}
		
	
	
}]);

