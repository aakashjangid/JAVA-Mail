'use strict';

baControllers.controller('advRegisterAdminCtrl',['$scope','$http','$location','$rootScope', '$route', 'NgTableParams','ngDialog', '$filter', 'advRegisterAdminFactory','filterFilter','localStorageService','Idle','$cookieStore','loggedInUserService','$anchorScroll', function($scope, $http, $location, $rootScope, $route, NgTableParams, ngDialog, $filter, advRegisterAdminFactory,filterFilter,localStorageService,Idle,$cookieStore,loggedInUserService,$anchorScroll){

	$scope.preferencesArray = [];
	$scope.preferencesList = [];
	$scope.preferences = [];
	$scope.preferencesData = [];
	$scope.preferencesTemp = [];
	$scope.preferencesToSave = [];
	
	$scope.subscriptionPreferencesList = [];
	
	$scope.input = new advRegisterAdminFactory();
	
	$scope.input.preferences = [];

	$scope.validateRegisterQue = jQuery.i18n.prop('validate_register_que');
	$scope.validateRegisteredVia = jQuery.i18n.prop('validate_registered_via');
	$scope.validatePriEmail = jQuery.i18n.prop('validate_primary_email');
	$scope.enterEmail = jQuery.i18n.prop('enter_email');
	
	$scope.validateClueField = jQuery.i18n.prop('clue_populated_value_modify');
	
	$scope.validateCwsId = jQuery.i18n.prop('validate_cws_id');
	$scope.validateCupId = jQuery.i18n.prop('validate_cup_id');
	$scope.validateEmailId = jQuery.i18n.prop('enter_valid_email_id');
	
	$scope.isClueField = true;
	$scope.checkboxUncheckFlag = false;
	$scope.isCwsClickedDropdown = true;
	$scope.isCupClickedDropdown = false;
	$scope.isEmailClickedDropdown = false;
	$scope.isEditPage = false;
	$scope.onOff = true;
	
	/**Mandatory on every screen*/
	$rootScope.isAdminEditPage = false;
	$rootScope.isAdminPerson = localStorageService.get("userrole"); 
	$rootScope.userName = localStorageService.get("userlogin"); 
	$rootScope.brandAdvocateRole = localStorageService.get("brandadvocaterole");
	$rootScope.response  = localStorageService.get("userresponse");
	/**------------------------*/
	
	$scope.loggedInUserName = $rootScope.userName; 
	$scope.loggedInUserEmailId = $rootScope.response.primaryEmail;
	$scope.isAdmin = $rootScope.isAdminPerson;
	
	
	$scope.getMasterData = function(){
		/** Code for preferences dropdown start*/
    	
   	 $scope.preferencesSettings = {
   		      scrollableHeight: '170px',
   		      scrollable: true,
   		      enableSearch: false
   		    };
   	 
   	 advRegisterAdminFactory.getPreferences(function(response){
 			$scope.preferencesList = response.data.LIST;
 			$scope.subscriptionPreferencesList = $scope.preferencesList; 
 			angular.forEach($scope.preferencesList,function(value,key){
 				$scope.preferencesData.push({"label":value.preferenceName,"id":value.preferenceId});
 				console.log($scope.preferencesData);
 			});
 			angular.forEach($scope.preferencesData,function(value,key){
 				$scope.preferencesTemp.push({"label":value.label,"id":value.id});
 				console.log($scope.preferencesTemp);
 			});
 			$scope.preferences = $scope.preferencesTemp;
 		});
   		    
   		    $scope.getData = function() {
   		    	$scope.$watch('preferences', function(val) {
   		    		$scope.val = val;
   		    		
   		    });
   		    };
   		    
   		    angular.element(document).on('click', function () {
   		    	if(!isEmpty($scope.val)){
   		    	$scope.getData();
   		    	}
   		    });
   		    
   	  /** Code for preferences dropdown end*/
   		    
   	
   		advRegisterAdminFactory.getCountries(function(response){
   				$scope.countryList = response.data.LIST;	
   				$scope.onLoadCountryList = angular.copy($scope.countryList);
   		});

   		advRegisterAdminFactory.getRegions(function(response){
   			$scope.regionList = response.data.LIST;	
   			$scope.onLoadRegionList = angular.copy($scope.regionList);
   		});
   		
   		$scope.userRegisterQueList = [{registerId:1 ,registerVia:"Manual entry"},{registerId:2 ,registerVia:"Took a brand class"},
			{registerId:3 ,registerVia:"Participated in other training"},{registerId:4 ,registerVia:"Completed Big Yellow Quiz"},{registerId:5 ,registerVia:"Registered through the portal"}];
   		
   		
   		advRegisterAdminFactory.getAllAffiliationNameUI(function(response){
   				$scope.affiliationDescriptionList = response.data.LIST;	
   		});
   		
	$scope.input.brandAdvocateStatus = "Brand Advocate"; //default value
		
	$scope.findViaList = [{findViaId:1 ,findViaName:"CWS ID"},{findViaId:2 ,findViaName:"CUPID"},{findViaId:3 ,findViaName:"Email"}];
	}
	
	
    $scope.onLoad = function(){
    	
    	var lineHeight = $('.col-md-6').height();
		console.log('lineHeight',lineHeight);
		$('.vertical-divider').height(lineHeight+200);
    	
    	$scope.radiobrandadvocate = true; //default radio button check.
    	
    	$scope.getMasterData();   // get all master data.
    		
    	$scope.findViaName = "CWS ID";  //default checked
    	$scope.findViaListChange = function(findViaName){
    			if(findViaName=="CWS ID"){
        			$scope.isCwsClickedDropdown = true;
        			$scope.isEmailClickedDropdown = false;
        			$scope.isCupClickedDropdown = false;
        			$scope.input.registeredVia = '';
        			$scope.input.affiliationDescription = '';
        			$scope.input.mappedAffiliationName='';
        			$scope.input.lastName = '';
        			$scope.input.firstName = '';
        			$scope.input.preferredFirstName = '';
        			$scope.input.organizationName = '';
        			$scope.input.facilityName = '';
        			$scope.input.buildingName = '';
        			$scope.input.jobKeywords = '';
        			$scope.input.countryId = '';
        			$scope.input.regionId = '';
        			$scope.input.primaryEmail = '';
        			$scope.input.secondaryEmail = '';
        			$scope.input.notes = '';
        			$scope.input.comments = '';
        			$scope.input.cupId = '';
        			$scope.input.cwsUserId = '';
        			$scope.input.email = '';
        			$scope.input.findViaName = "CWS ID"; 
        		}else if(findViaName=="Email"){
        			$scope.isEmailClickedDropdown = true;
        			$scope.isCwsClickedDropdown = false;
        			$scope.isCupClickedDropdown = false;
        			$scope.isClueField = true;
        			$scope.input.registeredVia = '';
        			$scope.input.affiliationDescription = '';
        			$scope.input.mappedAffiliationName='';
        			$scope.input.lastName = '';
        			$scope.input.firstName = '';
        			$scope.input.preferredFirstName = '';
        			$scope.input.organizationName = '';
        			$scope.input.facilityName = '';
        			$scope.input.buildingName = '';
        			$scope.input.jobKeywords = '';
        			$scope.input.countryId = '';
        			$scope.input.regionId = '';
        			$scope.input.primaryEmail = '';
        			$scope.input.secondaryEmail = '';
        			$scope.input.notes = '';
        			$scope.input.comments = '';
        			$scope.input.cupId = '';
        			$scope.input.cwsUserId = '';
        			$scope.input.email = '';
        			$scope.input.findViaName = "Email"; 
        		}else if(findViaName=="CUPID"){
        			$scope.isCupClickedDropdown = true;
        			$scope.isEmailClickedDropdown = false;
        			$scope.isCwsClickedDropdown = false;
        			$scope.isClueField = true;
        			$scope.input.registeredVia = '';
        			$scope.input.affiliationDescription = '';
        			$scope.input.mappedAffiliationName='';
        			$scope.input.lastName = '';
        			$scope.input.firstName = '';
        			$scope.input.preferredFirstName = '';
        			$scope.input.organizationName = '';
        			$scope.input.facilityName = '';
        			$scope.input.buildingName = '';
        			$scope.input.jobKeywords = '';
        			$scope.input.countryId = '';
        			$scope.input.regionId = '';
        			$scope.input.primaryEmail = '';
        			$scope.input.secondaryEmail = '';
        			$scope.input.notes = '';
        			$scope.input.comments = '';
        			$scope.input.cupId = '';
        			$scope.input.cwsUserId = '';
        			$scope.input.email = '';
        			$scope.input.findViaName = "CUPID"; 
        		}
    		}
    }
    
    $scope.onLoad();
    
    
    $scope.getRegionsByCountryId = function(countryId){
    	if(countryId!=null && countryId!=undefined){
    	advRegisterAdminFactory.getRegionsByCountryId({countryid:countryId},function(response){
    		$scope.regionListResponse = response.data.LIST;
    		angular.forEach($scope.regionListResponse,function(value,key){
    			$scope.input.regionId=value.regionId;
    		});
    	});
    	}else{
    		$scope.regionList = $scope.onLoadRegionList;
    		$scope.input.regionId='';
    	}
    	
    }

    $scope.getCountriesByRegionId = function(regionId){
    	if(regionId!=null && regionId!=undefined){
    	advRegisterAdminFactory.getCountriesByRegionId({regionid:regionId},function(response){
    		$scope.countryList = response.data.LIST;	
    	});
    	}else{
    		$scope.countryList = $scope.onLoadCountryList;
    		$scope.input.countryId='';
    	}
    }
    
    $scope.validatePrimaryEmail = function(primaryEmail){
		//var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
    	var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(primaryEmail === undefined || primaryEmail == '' || primaryEmail == null){
			return true;
		}else if (reg.test(primaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_primary_email_id'),jQuery.i18n.prop('common_message'),function(){
				$scope.input.primaryEmail = '';
			});
			return false;
		}else{
			return true;
		}
	};
    
	$scope.validateSecondaryEmail = function(secondaryEmail){
		//var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
		var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(secondaryEmail === undefined || secondaryEmail == '' || secondaryEmail == null){
			return true;
		}else if (reg.test(secondaryEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('enter_valid_secondary_email_id'),jQuery.i18n.prop('common_message'),function(){
				$scope.input.secondaryEmail = '';
			});
			return false;
		}else{
			return true;
		}
	};
	
	$scope.checkFindViaEmail = function(findViaEmail){
		//var reg = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
		var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(findViaEmail === undefined || findViaEmail == '' || findViaEmail == null){
			return true;
		}else if (reg.test(findViaEmail) == false) 
		{
			jAlert(jQuery.i18n.prop('validate_email'),jQuery.i18n.prop('common_message'),function(){
				$scope.input.email='';
			});
			return false;
		}else{
			return true;
		}
	}
	
	/**default check checkbox*/
	$scope.checkBoxValue=true;
	$scope.input.managedBy = "System"; //default managed by field value
	$scope.managedByToSave = $scope.input.managedBy;
	$scope.checkBoxChange = function(checkBoxValue){
		if(checkBoxValue){
			$scope.isClueField = true;
			$scope.checkboxUncheckFlag = false;
			$scope.input.registeredVia = '';
			$scope.input.affiliationDescription = '';
			$scope.input.mappedAffiliationName='';
			$scope.input.lastName = '';
			$scope.input.firstName = '';
			$scope.input.preferredFirstName = '';
			$scope.input.organizationName = '';
			$scope.input.facilityName = '';
			$scope.input.buildingName = '';
			$scope.input.jobKeywords = '';
			$scope.input.countryId = '';
			$scope.input.regionId = '';
			$scope.input.primaryEmail = '';
			$scope.input.secondaryEmail = '';
			$scope.input.notes = '';
			$scope.input.comments = '';
			$scope.input.cupId = '';
			$scope.input.cwsUserId = '';
			$scope.input.email = '';
			$scope.input.managedBy = "System";	
			$scope.managedByToSave = $scope.input.managedBy; 
			
			$scope.checkboxModel = {
					 webinarCheckbox : true,
				     brandEventCheckbox : true,
				     newsletterCheckbox : true
			 };
			
		}else{
			$scope.isClueField = false;
			$scope.checkboxUncheckFlag = true;
			$scope.input.lastName = '';
			$scope.input.firstName = '';
			$scope.input.preferredFirstName = '';
			$scope.input.organizationName = '';
			$scope.input.primaryEmail = '';
			$scope.input.secondaryEmail = '';
			$scope.input.regionId = '';
			$scope.input.countryId = '';
			$scope.input.facilityName = '';
			$scope.input.buildingName = '';
			$scope.input.jobKeywords = '';
			$scope.input.affiliationDescription = '';
			$scope.input.mappedAffiliationName='';
			$scope.input.comments = '';
			$scope.input.notes = '';
			$scope.input.registeredVia = '';
			$scope.input.cupId = '';
			$scope.input.cwsUserId = '';
			$scope.input.email = '';
			$scope.input.managedBy = "Admin";	
			$scope.managedByToSave = $scope.input.managedBy;
			
			$scope.checkboxModel = {
					 webinarCheckbox : true,
				     brandEventCheckbox : true,
				     newsletterCheckbox : true
			 };
			
		}
	}
	
	
	$scope.resetDetails = function(){
		if($scope.isEditPage){
			$scope.input.brandAdvocateId = '';
			$scope.input.lastName = '';
			$scope.input.firstName = '';
			$scope.input.preferredFirstName = '';
			$scope.input.organizationName = '';
			$scope.input.primaryEmail = '';
			$scope.input.secondaryEmail = '';
			$scope.input.regionId = '';
			$scope.input.countryId = '';
			$scope.input.facilityName = '';
			$scope.input.buildingName = '';
			$scope.input.jobKeywords = '';
			$scope.input.affiliationDescription = '';
			$scope.input.comments = '';
			$scope.input.notes = '';
			$scope.input.registeredVia = '';
			$scope.input.cupId = '';
			$scope.input.cwsUserId = '';
			$scope.input.email = '';
			$scope.input.mappedAffiliationName='';

			$scope.preferences = [];
			
			$scope.checkboxModel = {
					 webinarCheckbox : true,
				     brandEventCheckbox : true,
				     newsletterCheckbox : true
			 };
			$scope.radiobrandadvocate = true; 
			$scope.radiocba = false;
			$scope.radiocbainstructor = false;
			
			$scope.toggleValue="radiobrandadvocate";
			$rootScope.isAdminEditPage = false;
		}else{
			$scope.input.brandAdvocateId = '';
			$scope.input.lastName = '';
			$scope.input.firstName = '';
			$scope.input.preferredFirstName = '';
			$scope.input.organizationName = '';
			$scope.input.primaryEmail = '';
			$scope.input.secondaryEmail = '';
			$scope.input.regionId = '';
			$scope.input.countryId = '';
			$scope.input.facilityName = '';
			$scope.input.buildingName = '';
			$scope.input.jobKeywords = '';
			$scope.input.affiliationDescription = '';
			$scope.input.comments = '';
			$scope.input.notes = '';
			$scope.input.registeredVia = '';
			$scope.input.cupId = '';
			$scope.input.cwsUserId = '';
			$scope.enteredEmail = $scope.input.email;
			$scope.input.email = '';
			$scope.input.mappedAffiliationName='';
			
			$scope.checkboxModel = {
					 webinarCheckbox : true,
				     brandEventCheckbox : true,
				     newsletterCheckbox : true
			 };
			$scope.radiobrandadvocate = true; 
			$scope.radiocba = false;
			$scope.radiocbainstructor = false;
			
			$scope.toggleValue="radiobrandadvocate";
		}
		
	}
	
	$scope.cancel = function(){
		$route.reload();
	}
	
	$scope.checkBaExistInPortalOrClue = function(cwsUserId,cupId,email){
		$scope.resetDetails();
    	//$scope.input.cwsUserId = cwsUserId;
		$scope.isValidCwsId = false;
		$scope.isValidCupId = false;
		$scope.isValidEmailId = false;
		
		if(cwsUserId!='' && cwsUserId!=undefined){
			$scope.isValidCwsId = true;
		}else if(cupId!='' && cupId!=undefined){
			$scope.isValidCupId = true;	
		}else if($scope.checkFindViaEmail(email) && email!='' && email!=undefined){
			$scope.isValidEmailId = true;
		}
		
		if($scope.isValidCwsId || $scope.isValidCupId || $scope.isValidEmailId){
			advRegisterAdminFactory.getPortalUserDetailsByIds({cwsuserid : cwsUserId, emailid : email, cupid : cupId},function(result){
				if(!isEmpty(result.data.LIST) && null!=result.data.LIST){
					$scope.isEditPage = true;
					$rootScope.isAdminEditPage = $scope.isEditPage;
        			$scope.baDetailsList = result.data.LIST;
        			console.log("BA Details DB :"+$scope.baDetailsList);
        			$scope.input.email = $scope.enteredEmail;
        			$scope.input.affiliationDescription = $scope.baDetailsList.affiliationDescription;
        			$scope.input.mappedAffiliationName=   $scope.baDetailsList.mappedAffiliationName;
        			$scope.input.lastName = $scope.baDetailsList.lastName;
        			$scope.input.firstName = $scope.baDetailsList.firstName;
        			$scope.input.preferredFirstName = $scope.baDetailsList.preferredFirstName;
        			$scope.input.organizationName = $scope.baDetailsList.organizationName;
        			$scope.input.facilityName = $scope.baDetailsList.facilityName;
        			$scope.input.buildingName = $scope.baDetailsList.buildingName;
        			$scope.input.jobKeywords = $scope.baDetailsList.jobKeywords;
        			$scope.input.countryId = $scope.baDetailsList.countryId;
        			//$scope.input.regionId = $scope.baDetailsList.regionId;
        			$scope.input.primaryEmail = $scope.baDetailsList.primaryEmail;
        			$scope.input.brandAdvocateId = $scope.baDetailsList.brandAdvocateId;
        			$scope.input.notes = $scope.baDetailsList.notes;
        			$scope.input.secondaryEmail = $scope.baDetailsList.secondaryEmail;
        			$scope.input.registeredVia = $scope.baDetailsList.registeredVia;
        			$scope.input.cupId = $scope.baDetailsList.cupId;
        			$scope.input.cwsUserId = $scope.baDetailsList.cwsUserId;
        			$scope.input.comments = $scope.baDetailsList.comments;
        			
        			$scope.input.registrationDate = $scope.baDetailsList.registrationDate;
        			$scope.input.registeredBy = $scope.baDetailsList.registeredBy;
        			
        			$scope.brandAdvocateStatusDb = $scope.baDetailsList.brandAdvocateStatus;
        			if($scope.brandAdvocateStatusDb == "Brand Advocate"){
        				$scope.radiobrandadvocate = true;
        				$scope.radiocba = false;
        				$scope.radiocbainstructor = false;
        			}else if($scope.brandAdvocateStatusDb == "Certified Brand Advocate (CBA)"){
        				$scope.radiocba = true;
        				$scope.radiobrandadvocate = false;
        				$scope.radiocbainstructor = false;
        			}else if($scope.brandAdvocateStatusDb == "CBA Instructor"){
        				$scope.radiocbainstructor = true;
        				$scope.radiobrandadvocate = false;
        				$scope.radiocba = false;
        			}
        			
        			/**new code changes for subscription preferences starts*/
        			
        			$scope.subscriptionPreferencesList = [];
        			$scope.checkboxModel=[];
        			angular.forEach($scope.baDetailsList.preferences,function(value,key){
        				$scope.subscriptionPreferencesList.push({"preferenceId":value[0],"preferenceName":value[1]});
		 			});

        			angular.forEach($scope.subscriptionPreferencesList,function(value,key){
        				if(value.preferenceName == "Webinar invitations"){
        					$scope.checkboxModel.webinarCheckbox = true;
        				}else if(value.preferenceName == "Brand event communications"){
        					$scope.checkboxModel.brandEventCheckbox = true;
        				}else if(value.preferenceName == "Newsletters"){
        					$scope.checkboxModel.newsletterCheckbox = true;
        				}
        			});
        			
        			/**new code changes for subscription preferences ends*/
        			
        			//populate preferences for update page start
        			$scope.preferencesTemp = [];
    		 			angular.forEach($scope.baDetailsList.preferences,function(value,key){
    		 				$scope.preferencesTemp.push({"label":value[1],"id":value[0]});
    		 				console.log($scope.preferencesTemp);
    		 			});
    		 			$scope.preferences = $scope.preferencesTemp;
        			//populate preferences for update page end
    		 			
        			/** populate region based on country id*/
        			if($scope.input.countryId!=null && $scope.input.countryId!=undefined){
        				advRegisterAdminFactory.getRegionsByCountryId({countryid:$scope.input.countryId},function(response){
				    		$scope.input.regionId = response.data.LIST[0].regionId;	
				    	});
				    	}
        			/***/
        		}else{
        			advRegisterAdminFactory.getCluesUserDetailsByIds({cwsuserid : cwsUserId, emailid : email, cupid : cupId},function(result){
        				//$scope.getMasterData();   // get all master data.
                		if(!isEmpty(result.data.LIST) && null!=result.data.LIST){
                			console.log($scope.input);
                			$scope.input = {}; //clear all old data of edit page.
                			$scope.isEditPage = false;
                			$rootScope.isAdminEditPage = $scope.isEditPage;
                			$scope.clueResponse = result.data.LIST;
                			console.log("Clue Rsponse :"+$scope.clueResponse);
                			
                			$scope.input.email = $scope.enteredEmail;
                			$scope.input.affiliationDescription = $scope.clueResponse.affiliationDescription;
                			$scope.input.lastName = $scope.clueResponse.lastName;
                			$scope.input.firstName = $scope.clueResponse.firstName;
                			$scope.input.preferredFirstName = $scope.clueResponse.preferredFirstName;
                			$scope.input.organizationName = $scope.clueResponse.organizationName;
                			$scope.input.facilityName = $scope.clueResponse.facilityName;
                			$scope.input.buildingName = $scope.clueResponse.buildingName;
                			$scope.input.jobKeywords = $scope.clueResponse.jobKeywords;
                			$scope.input.countryId = $scope.clueResponse.countryId;
                			//$scope.input.regionId = $scope.clueResponse.regionId;
                			$scope.input.primaryEmail = $scope.clueResponse.primaryEmail;
                			$scope.clueCountryCode = $scope.clueResponse.countryCode; 
                			$scope.input.cupId =  $scope.clueResponse.cupId;
                			$scope.input.cwsUserId =  $scope.clueResponse.cwsUserId;
                			$scope.input.mappedAffiliationName = $scope.clueResponse.mappedAffiliationName;
                			
                			$scope.getMasterData();   // get all master data.
                			
                			/*if($scope.input.notes == undefined || $scope.input.notes == null){
                				$scope.input.notes = '';
                			}
                			if($scope.input.secondaryEmail == undefined || $scope.input.secondaryEmail == null){
                				$scope.input.secondaryEmail = '';
                			}
                			if($scope.input.registeredVia == undefined || $scope.input.registeredVia == null){
                				$scope.input.registeredVia = '';
                			}
                			if($scope.input.comments == undefined || $scope.input.comments == null){
                				$scope.input.comments = '';
                			}
                			if($scope.input.buildingName == undefined || $scope.input.buildingName == null){
                				$scope.input.buildingName = '';
                			}
                			$scope.input.brandAdvocateStatus = "Brand Advocate"; //default value
                			*/                			
                			angular.forEach($scope.countryList,function(value,key){
                				if($scope.clueCountryCode == value.countryCode){
                					$scope.input.countryId = value.countryId;    //populate country on the basis of country code.
                					//$scope.input.regionId = value.regionId;
                					if($scope.input.countryId!=null && $scope.input.countryId!=undefined){
                						advRegisterAdminFactory.getRegionsByCountryId({countryid:$scope.input.countryId},function(response){
                				    		$scope.input.regionId = response.data.LIST[0].regionId;	
                				    	});
                				    	}
                				}
                 			});
                			
                			
                			/**make fields to there original state(which are not coming from clue) starts*/
                			/*$scope.radiobrandadvocate = true; 
                			$scope.radiocba = false;
                			$scope.radiocbainstructor = false;
                			$scope.checkboxModel = {
               					 webinarCheckbox : true,
               				     brandEventCheckbox : true,
               				     newsletterCheckbox : true
                			};*/
                			//$scope.input.brandAdvocateId = '';
                			/**make fields to there original state(which are not coming from clue) ends*/
                			
                			
                		}else{
                			$scope.isEditPage = false;
                			if($scope.isValidCwsId){
                				jAlert(jQuery.i18n.prop('validate_cws_id'),jQuery.i18n.prop('common_message'),function(){
                					$scope.makeFieldsEmpty();
                				});
                			}else if($scope.isValidCupId){
                				jAlert(jQuery.i18n.prop('validate_cup_id'),jQuery.i18n.prop('common_message'),function(){
                					$scope.makeFieldsEmpty();
                				});
                			}else if($scope.isValidEmailId){
                				jAlert(jQuery.i18n.prop('enter_valid_email_id'),jQuery.i18n.prop('common_message'),function(){
                					$scope.makeFieldsEmpty();
                				});
                			}
                		
                			$scope.makeFieldsEmpty = function(){
                				$scope.input.cwsUserId='';
                				$scope.input.cupId='';
                				$scope.input.affiliationDescription = '';
                				$scope.input.lastName = '';
                				$scope.input.firstName = '';
                				$scope.input.preferredFirstName = '';
                				$scope.input.organizationName = '';
                				$scope.input.facilityName = '';
                				$scope.input.buildingName = '';
                				$scope.input.jobKeywords = '';
                				$scope.input.countryId = '';
                				$scope.input.regionId = '';
                				$scope.input.primaryEmail = '';
                				$scope.input.secondaryEmail='';
                				$scope.input.email='';
                				$scope.input.mappedAffiliationName='';
                			}
                			
                		}
                	});
        		}
			});
		}else{
			$route.reload();
		}
			
		}
	
	$scope.baRadioButtonClick = function(radioButtonStatus){
		if(radioButtonStatus=='radiobrandadvocate'){
			$scope.input.brandAdvocateStatus = "Brand Advocate";
		}else if(radioButtonStatus=='radiocba'){
			$scope.input.brandAdvocateStatus = "Certified Brand Advocate (CBA)";
		}else if(radioButtonStatus=='radiocbainstructor'){
			$scope.input.brandAdvocateStatus = "CBA Instructor";
		}else{
			$scope.input.brandAdvocateStatus = "Brand Advocate";
		}
	}
	
	/**new code changes for subscription preferences starts*/
	
	 $scope.checkboxModel = {
			 webinarCheckbox : true,
		     brandEventCheckbox : true,
		     newsletterCheckbox : true
	 };

	$scope.preferencesCheckboxChange = function(selectedCheckBoxValue,prefCheckBoxValue){
		if(!prefCheckBoxValue){
		if(selectedCheckBoxValue=='webinarCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":1,"preferenceName":"Webinar invitations"});
		}else if(selectedCheckBoxValue=='brandEventCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":2,"preferenceName":"Brand event communications"});
		}else if(selectedCheckBoxValue=='newsletterCheckbox'){
			$scope.subscriptionPreferencesList.push({"preferenceId":3,"preferenceName":"Newsletters"});
		}
		}else{
			var index;
			if(selectedCheckBoxValue=='webinarCheckbox'){
				index = $scope.getIndex("Webinar invitations");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='brandEventCheckbox'){
				index = $scope.getIndex("Brand event communications");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}else if(selectedCheckBoxValue=='newsletterCheckbox'){
				index = $scope.getIndex("Newsletters");
				$scope.subscriptionPreferencesList.splice(index, 1);
			}
		}
	}
	
	$scope.getIndex = function(val){
		var index = -1;
		var filteredObj = $scope.subscriptionPreferencesList.find(function(item, i){
      	  if(item.preferenceName === val){
      		index = i;
      	  }
      	});
		return index;
	}
	
	/**new code changes for subscription preferences ends*/
	
	$scope.saveDetails = function(){
		//get toggle value
		/*console.log($scope.toggleValue);
		angular.forEach($scope.val,function(value,key){
    		$scope.input.preferences.push({"preferenceId" : value.id});
		})*/
		$scope.preferencesToSave = [];
		angular.forEach($scope.preferences,function(value,key){
			angular.forEach($scope.preferencesList,function(valuePref,keyPref){
				if(value.id == valuePref.preferenceId){
					$scope.preferencesToSave.push({"preferenceId":valuePref.preferenceId,"preferenceName":valuePref.preferenceName});
				}
 			});
		});
		//$scope.input.preferences = $scope.preferencesToSave;
		$scope.input.preferences = $scope.subscriptionPreferencesList;
		
		$scope.input.managedBy = $scope.managedByToSave;
		
		if($scope.registerForm.$valid){
			if($scope.validateRegistrationDetails()){
				var saveMsg ;
				if($scope.isEditPage){
					saveMsg = 'admin_update_user_as_ba';
				}else{
					saveMsg = 'admin_register_user_as_ba';
				}
		
		
		$scope.input.loggedInUserName = $scope.loggedInUserName;
		$scope.input.loggedInUserEmailId = $scope.loggedInUserEmailId;
		$scope.input.isAdmin = $scope.isAdmin;
		
		advRegisterAdminFactory.saveAdminInformation($scope.input,function(response){
			jConfirmCustom(jQuery.i18n.prop(saveMsg), jQuery.i18n.prop('common_confirmation_dialog'), function(r) {
					 if(r)
				     {
						 $location.path('/brandInfo').search('');
						 $route.reload();
							//$route.reload();
				     }else {
				    	 //$scope.input=[];
				    	 $route.reload();
				    	 $anchorScroll();   // used to go to top of the page.
		                 //   return;
		              }
				});
			
			
			/*jConfirm(jQuery.i18n.prop(saveMsg),jQuery.i18n.prop('common_message'),function(){
				if(response.statusCode == false){
					jAlert(response.msg);
				}if(response.statusCode == "OK"){
				$rootScope.$apply(function() {
					$location.path("/brandInfo").search('');
					//$route.reload();
				 });
				}
			});*/
		});
	}
	}else{
			angular.element("[name='" + $scope.registerForm.$name + "']").find('.ng-invalid:visible:first').focus();
  	        return false;
  		}

	}
	
	
	/** validation for User fields */
	$scope.validateRegistrationDetails = function(){
			if((isEmpty($scope.input.registeredVia) || $scope.input.registeredVia == undefined) && !$scope.isEditPage){
				jAlert(jQuery.i18n.prop('validate_registered_via'));
				return false;
			}
			if(($scope.isCwsClickedDropdown && !$scope.checkboxUncheckFlag) && ($scope.input.cwsUserId == '' || $scope.input.cwsUserId == undefined)){
				jAlert(jQuery.i18n.prop('validate_cws_user_id'));
				return false;
			}
			if(($scope.isCupClickedDropdown && !$scope.checkboxUncheckFlag) && ($scope.input.cupId == '' || $scope.input.cupId == undefined)){
				jAlert(jQuery.i18n.prop('validate_cup_user_id'));
				return false;
			}
			if($scope.isEmailClickedDropdown && ($scope.input.email == ''||$scope.input.email == undefined)){
				jAlert(jQuery.i18n.prop('enter_email'));
				return false;
			}
			else{
				return true;
			}
	}
	
	var myVideo = document.getElementById("video1");
	$scope.playPause = function() { 
	    if (myVideo.paused) 
	        myVideo.play(); 
	    else 
	        myVideo.pause(); 
	} 

	$scope.makeBig = function() { 
	    myVideo.width = 450; 
	    myVideo.height = 250;
	} 

	$scope.makeSmall = function() { 
	    myVideo.width = 350;
	    myVideo.height = 250;
	} 

	$scope.makeNormal = function() { 
	    myVideo.width = 420;
	    myVideo.height = 250;
	} 
	
	$('.play').on('click', function () {
		  $(this).toggleClass('pause');
		});
    
}]);

