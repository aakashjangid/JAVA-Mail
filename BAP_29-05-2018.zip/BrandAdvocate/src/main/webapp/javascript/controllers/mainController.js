'use strict';

baControllers.controller('mainCtrl',['$scope', '$rootScope', '$http', '$compile', '$location','$window', 'i18n','$route',
                                         function($scope,$rootScope, $http,$compile,$location,$window,i18n,$route){

	$scope.langValue={};
	
	$scope.init = function() {
		
	}
	
	
}]);