'use strict';
var brandAdvocate = angular.module('brandAdvocate',
				['ngRoute', 
				 'ui.bootstrap',
				 'baControllers',
				 'baServices', 
				 'baDirectives',
				 'ngResource',
				 'ngDialog',
				 'ngTable',
				 'ngCookies',
				 '720kb.datepicker',
				 'app.properties',
				 'ab-base64',
				 'LocalStorageModule',
				 'angularjs-dropdown-multiselect',
				 'ngIdle',
				 'uiSwitch',
				 'ngSanitize',
				 'ui.select',
				 'anguFixedHeaderTable',
				 'scrollLock'
				 ]);


/* Controllers */
var baControllers = angular.module('baControllers', []);

/* Services */
var baServices = angular.module('baServices', []);

/* Directives */
var baDirectives = angular.module('baDirectives', []);

var isEmpty = function(inputStr) {
	if ( null == inputStr || "" == inputStr || undefined == inputStr || "NaN" == inputStr) { return true; } return false;
};

brandAdvocate.run(['$rootScope', '$location', '$cookieStore', '$http','i18n','localStorageService','Idle',function ($rootScope, $location, $cookieStore, $http,i18n,localStorageService,Idle) {
	var currentUrl = $location.url();
	console.log("Current URL for run function ::::::::"+currentUrl);
	$rootScope.$on('IdleStart', function() {
        // the user appears to have gone idle
    });

	$rootScope.$on('IdleTimeout', function() {
		localStorageService.remove('userlogin');
		localStorageService.clearAll();
		$location.path('/login').search({session: false});
		jHide();
		if($rootScope.dialog){
			$rootScope.dialog.close();
		}
	});
	// keep user logged in after page refresh
          $rootScope.globals = $cookieStore.get('globals') || {};
          if ($rootScope.globals.currentUser) {
              $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
              $rootScope.userName = $rootScope.globals.currentUser.userName;
          }
          
          var userLang = $cookieStore.get('globalLanguage');
      		if(userLang != undefined && userLang != ''){
      			i18n.setLanguage(userLang);
      		}else{
      			i18n.setLanguage('en');
      		}
      		
      		$rootScope.title = jQuery.i18n.prop('common_project_title');
         /* $rootScope.$on('$locationChangeStart', function (event, next, current) {
        	  // redirect to login page if not logged in
        	  if(($location.path() == '/login' || $location.path() == '' || $location.path()=='/forgetpassword') && localStorageService.get("userlogin")){
        		  $location.path('/home').search('');
        	  }else if ($location.path() != '/login' && $location.path()!='/forgetpassword' && !localStorageService.get("userlogin")) {
            	  $rootScope.globals = {};
//                  $rootScope.userName = "testUser";
                  $cookieStore.remove('globals');
                  localStorageService.clearAll();
                  $location.path('/login').search('');
              }
              
              if ($location.path() == '/login' || $location.path() == ''){
            	  $rootScope.userName = "";
              } 
              window.history.forward();
          });
          
          $rootScope.$watch(function() {
        	  return localStorageService.get("userlogin");
          }, function() {
        	  if($location.path() != '/login' && $location.path()!='/forgetpassword' && localStorageService.get("userlogin")==null){
        		  $rootScope.globals = {};
        		  Idle.unwatch();
        		  $cookieStore.remove('globals');
        		  localStorageService.clearAll();
        		  $location.path('/login').search('');
        	  }
        	  if(($location.path() == '/login' || $location.path() == '' || $location.path()=='/forgetpassword') && localStorageService.get("userlogin")!=null){
            		$rootScope.globals = localStorageService.get("userloginglobals");
            		$rootScope.showmenu = false;
            		Idle.watch();
  	      			$rootScope.userName = localStorageService.get("userlogin");
			        $location.path('/home').search('');
      	    }
          });*/
          
          $rootScope.showModal = false;
          
          var userRole = $cookieStore.get('userRole');
    		if(userRole!=undefined && userRole!=''){
    			$rootScope.userRole = userRole;
    		}
    		
      }]);
brandAdvocate.config(function($httpProvider) {
	$httpProvider.interceptors.push('APIInterceptor');
});

brandAdvocate.service('i18n',function () {
    var self = this;
    this.setLanguage = function (language) {
    	$.i18n.properties({
            name: 'locale',
            path: 'i18n/',
            mode: 'map',
            language: language,
            callback: function () {
                self.language = language;
            }
        });
    };
   
});

brandAdvocate.directive('msg', function () {
    return {
        restrict: 'EA',
        link: function (scope, element, attrs) {
            var key = attrs.key;
            if (attrs.keyExpr) {
                scope.$watch(attrs.keyExpr, function (value) {
                    key = value;
                    element.text($.i18n.prop(value));
                });
            }
            scope.$watch('language()', function (value) {
                element.text($.i18n.prop(key));
            });
        }
    };
});

brandAdvocate.config(function(IdleProvider, KeepaliveProvider,TitleProvider) {
    // configure Idle settings
	 IdleProvider.idle(20); // in seconds
	 IdleProvider.timeout(14400); // in seconds
	 KeepaliveProvider.interval(30); // in seconds
	 TitleProvider.enabled(false);
});

brandAdvocate.config(function (localStorageServiceProvider) {
	  localStorageServiceProvider
	    .setPrefix('brandadvocate');
	});
