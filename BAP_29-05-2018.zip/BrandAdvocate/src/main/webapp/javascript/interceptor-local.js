brandAdvocate.service('APIInterceptor', function($rootScope,$location,$window,properties) {
	var service = this;
	var urlContext = $location.protocol() + "://" + properties.contextIP + ":"+ properties.contextPort;
	/*var urlContext = $window.location.origin;*/
	console.log(urlContext);
    $rootScope.urlContext = urlContext;
    $rootScope.serviceDown = false;
    $rootScope.internalError = false;
    $rootScope.findError = false;
    
    service.request = function(config) {
    	//Add context root in url, before sending ajax request
		if(!config.cache){
    		config.url = urlContext + config.url;
    	}
		if($rootScope.requestCount!=undefined){
    		$rootScope.requestCount = $rootScope.requestCount+1;
    	}else{
    		$rootScope.requestCount = 0;
    	}
		
		if(!$rootScope.isSyncService){  	//do not show please wait dialoguebox when CLUE sync service is there; 
			$rootScope.showModal = true;
		}
    	
    	return config;
    };

    service.responseError = function(response) {
    	// This will handle the scenario in case of rest server is down 
    	if(response.status == 0 && response.data == ''){
    		$rootScope.internalError = false;
    		$rootScope.findError = true;
    		$rootScope.serviceDown = true;
    		$rootScope.requestCount=-1;
    		$rootScope.showModal = false;
    		$location.path('/error');
    	}
    	return response;
    };
    
    service.response = function(response) {
       	if(response.config.url.indexOf('html') <= -1 && response.data.statusCode == 'INTERNAL_SERVER_ERROR'){
    		$rootScope.internalError = true;
    		$rootScope.findError = true;
    		$rootScope.serviceDown = false;
    		$location.path('/error');
    		$rootScope.requestCount=-1;
    		$rootScope.showModal = false;
    	}else{
    		$rootScope.requestCount = $rootScope.requestCount-1;
        	if($rootScope.requestCount==-1){
        		$rootScope.showModal = false;
        	}
    	}
        return response;
    };
});