 'use strict';

baServices.factory('advHomeFactory',['$resource', function($resource){
	
	var baseURL = '/brandadvocate/manage/details/v1';
	var masterDataURL = '/brandadvocate/masterdata/v1';
	
	return $resource(baseURL, {}, {
		
		/**Getting data initially*/
		'getAllAdminDetails' : {
			method : 'GET',
			url : baseURL + '/getallbauserdetails'
		},

		/*'deleteUserInfo' : {
			method : 'DELETE',
			url : baseURL + '/deleteuserinfo'
		},*/
		'changeActiveStatus' : {
			method : 'GET',
			url : baseURL + '/dobastatusinactive'
		},
		
		'getPreferences' : {
			method : 'GET',
			url : masterDataURL + '/getpreferences'
		},
		
		'saveAdminInformation' : {
			method : 'POST',
			url : baseURL + '/saveuserinformation'
		},
		'updateSecondaryMail' : {
			method : 'POST',
			url : baseURL + '/updateSecondaryMail'
		},
		'syncBADataWithClues' : {
			method : 'GET',
			url : baseURL + '/synccluesdata'
		},
		'getMailIdListByBaId' : {
			method : 'POST',
			url : baseURL + '/getmaillidlistbybaid'
		},
		'getLastSyncOperationDate' : {
			method : 'GET',
			url : baseURL + '/getlastsyncoperationdate'
		},
		
	});    
}]);
