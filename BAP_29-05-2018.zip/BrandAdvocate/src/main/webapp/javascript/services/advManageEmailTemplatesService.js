 'use strict';

baServices.factory('advManageEmailTemplatesFactory',['$resource', function($resource){
	
	var baseURL = '/brandadvocate/manage/details/v1';
	
	return $resource(baseURL, {}, {
		
		'getAllTemplates' : {
			method : 'GET',
			url : baseURL + '/getalltemplates'
		},
		'getTemplateDetails' : {
			method : 'GET',
			url : baseURL + '/gettemplatedetails'
		},

	});    
}]);
