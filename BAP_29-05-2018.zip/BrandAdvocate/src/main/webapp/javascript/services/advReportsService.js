 'use strict';

baServices.factory('advReportFactory',['$resource', function($resource){
	
	var baseURL = '/brandadvocate/reports/details/v1';
	
	return $resource(baseURL, {}, {
		
		/**Getting data initially*/
		'getActiveInActiveDataReport' : {
			method : 'GET',
			   url : baseURL + '/getactiveinactivedatareport'
		},
		/**Getting data initially*/
		'getGainedLostDataReport' : {
			method : 'GET',
			   url : baseURL + '/getgainedlostdatareport'
		},
		/**Getting data initially*/
		'getYearQTDDataReport' : {
			method : 'GET',
			   url : baseURL + '/getyearqtddatareport'
		},
	});
	
}]);
