 'use strict';

baServices.factory('advHomeCommentsFactory',['$resource', function($resource){
var baseURL = '/brandadvocate/manage/details/v1';
	
	return $resource(baseURL, {}, {
		
		'addCommentsQuestions' : {
			method : 'POST',
			url : baseURL + '/addCommentsQuestions'
		},
		
	});    
}]);