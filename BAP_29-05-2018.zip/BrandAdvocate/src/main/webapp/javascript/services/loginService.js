'use strict';

baServices.factory('loginFactory',[ '$resource',function($resource) {
	
	var userMasterURL = '/brandadvocate/manage/details/v1';
	return $resource(userMasterURL, {}, {
		
		'checkBAExistInPortal' :{
			method : 'POST',
			url : userMasterURL + '/checkbaexistinportal'
		}
	
	});
}]);