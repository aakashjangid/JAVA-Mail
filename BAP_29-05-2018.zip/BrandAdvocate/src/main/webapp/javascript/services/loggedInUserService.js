'use strict';

baServices.service("loggedInUserService",[ '$http', function($http) {
	
	this.serverCall = function(url) {
		var response = $http({
			method	:	"GET",
			headers	: 	{ 'Content-Type': undefined },
	        transformRequest	: angular.identity,
			url		:	url,
	     });
		return response;
		}
	
		this.loggedInUserCall = function(urlPath) {
			return this.serverCall(urlPath);
		}
}]);