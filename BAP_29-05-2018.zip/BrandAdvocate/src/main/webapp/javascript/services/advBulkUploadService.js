 'use strict';

baServices.factory('advBulkUploadFactory',['$resource', function($resource){
	
	var baseURL = '/brandadvocate/manage/clue/v1';
	
	return $resource(baseURL, {}, {
		
		'bulkUploadForEmailsOrCWSIds' : {
			method : 'GET',
			url : baseURL + '/bulkuploadcwsoremailids'
		},
		
	});    
}]);