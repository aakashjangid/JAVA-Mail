 'use strict';

baServices.factory('advFindOtherBaFactory',['$resource', function($resource){
	
	var baseURL = '/brandadvocate/manage/details/v1';
	var masterDataURL = '/brandadvocate/masterdata/v1';
	
	
	return $resource(baseURL, {}, {
		
		/**Getting data initially*/
		'getAllAdminDetails' : {
			method : 'GET',
			url : baseURL + '/getallbauserdetails'
		},
		
		'getRegions' : {
			method : 'GET',
			url : masterDataURL + '/getregions'
		},
		
		'getCountries' : {
			method : 'GET',
			url : masterDataURL + '/getcountries'
		},
		
		'getRegionsByCountryId' : {
			method : 'GET',
			url : masterDataURL + '/getregionsbycountryid'
		},
		
		'getCountriesByRegionId' : {
			method : 'GET',
			url : masterDataURL + '/getcountriesbyregionid'
		},

		'getInitialDataForFindBA' : {
			method : 'GET',
			url : baseURL + '/getinitialdataforfindba'
		},
		
	});    
	
}]);
