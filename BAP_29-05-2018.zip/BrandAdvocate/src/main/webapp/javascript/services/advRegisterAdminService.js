 'use strict';

baServices.factory('advRegisterAdminFactory',['$resource', function($resource){
	
	var baseURL = '/';
	var userMasterURL = '/brandadvocate/manage/details/v1';
	var masterDataURL = '/brandadvocate/masterdata/v1';
	var clueURL = '/brandadvocate/manage/clue/v1';
	
	return $resource(baseURL, {}, {
		
		'getCountries' : {
			method : 'GET',
			url : masterDataURL + '/getcountries'
		},
		
		'getRegions' : {
			method : 'GET',
			url : masterDataURL + '/getregions'
		},

		'getPreferences' : {
			method : 'GET',
			url : masterDataURL + '/getpreferences'
		},
		
		'getRegionsByCountryId' : {
			method : 'GET',
			url : masterDataURL + '/getregionsbycountryid'
		},
		
		'getCountriesByRegionId' : {
			method : 'GET',
			url : masterDataURL + '/getcountriesbyregionid'
		},
		
		/** Check Existing Email */
		/*'findUserEmail' : {
			method : 'GET',
			url : userMasterURL + '/finduseremail'
		},*/
		
		'saveAdminInformation' : {
			method : 'POST',
			url : userMasterURL + '/saveuserinformation'
		},
		
		'getPortalUserDetailsByIds' :{
			method : 'GET',
			url : userMasterURL + '/getbauserdetailsbyids'
		},
		'getCluesUserDetailsByIds' :{
			method : 'GET',
			url : clueURL + '/getcluesuserdetailsbyids'
		},
		'getAllAffiliationNameUI' :{
			method : 'GET',
			url : masterDataURL + '/getallaffiliationnameui'
		},
		
	});    
}]);
