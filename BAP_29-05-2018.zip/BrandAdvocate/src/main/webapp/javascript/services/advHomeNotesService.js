 'use strict';

baServices.factory('advHomeNotesFactory',['$resource', function($resource){
var baseURL = '/brandadvocate/manage/details/v1';
	
	return $resource(baseURL, {}, {
		
		'addNotes' : {
			method : 'POST',
			url : baseURL + '/addNotes'
		},
		
	});    
}]);