 'use strict';

baServices.factory('editAdvHomeFactory',['$resource', function($resource){
	
	var userMasterURL = '/brandadvocate/manage/details/v1';
	var masterDataURL = '/brandadvocate/masterdata/v1';
	
	return $resource(userMasterURL, {}, {
		
		'getCountries' : {
			method : 'GET',
			url : masterDataURL + '/getcountries'
		},
		
		'getRegions' : {
			method : 'GET',
			url : masterDataURL + '/getregions'
		},

		'getPreferences' : {
			method : 'GET',
			url : masterDataURL + '/getpreferences'
		},
		
		'getRegionsByCountryId' : {
			method : 'GET',
			url : masterDataURL + '/getregionsbycountryid'
		},
		
		'getCountriesByRegionId' : {
			method : 'GET',
			url : masterDataURL + '/getcountriesbyregionid'
		},
		
		/** Check Existing Email */
		/*'findUserEmail' : {
			method : 'GET',
			url : userMasterURL + '/finduseremail'
		},*/
		
		'saveAdminInformation' : {
			method : 'POST',
			url : userMasterURL + '/saveuserinformation'
		},
		
		/**Getting data initially*/
		'getBAUserDetailsById' : {
			method : 'GET',
			url : userMasterURL + '/getbauserdetailsbyid'
		},
		
	});    
}]);
