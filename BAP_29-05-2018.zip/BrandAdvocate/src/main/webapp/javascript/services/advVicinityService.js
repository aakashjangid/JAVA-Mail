 'use strict';

baServices.factory('advVicinityFactory',['$resource', function($resource){
	
	var baseURL = '/';
	
	return $resource(baseURL, {}, {
		
	});    
}]);
