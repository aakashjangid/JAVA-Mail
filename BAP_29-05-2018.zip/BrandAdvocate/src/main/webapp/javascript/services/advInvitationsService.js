 'use strict';

baServices.factory('advInvitationsFactory',['$resource', function($resource){
	
	var baseURL = '/brandadvocate/manage/details/v1';
	
	return $resource(baseURL, {}, {
		
		/**Getting data initially*/
		'getInvitationsDetails' : {
			method : 'GET',
			url : baseURL + '/getallinvitations'
		},
		
	});    
}]);
