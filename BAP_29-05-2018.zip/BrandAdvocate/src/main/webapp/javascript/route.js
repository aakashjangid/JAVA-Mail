'use strict';

brandAdvocate.config([ '$routeProvider', function($routeProvider) {

	/** Login */
	/*$routeProvider.when('/login', {
		templateUrl : 'html/login/login.html',
		controller : 'loginCtrl',
	});*/
	$routeProvider.when('/login', {
		templateUrl : 'html/login/login.html',
		controller : 'loginCtrl',
	});
	$routeProvider.when('/baRegisterUser', {
		templateUrl : 'html/home/advocate_register_user.html',
		controller : 'advRegisterUserCtrl',
	});
	$routeProvider.when('/editBARegisterUser', {
		templateUrl : 'html/home/edit_advocate_register_user.html',
		controller : 'editAdvRegisterUserCtrl',
	});
	
	$routeProvider.when('/baRegisterAdmin', {
		templateUrl : 'html/home/advocate_register_admin.html',
		controller : 'advRegisterAdminCtrl',
	});

	$routeProvider.when('/home', {
		templateUrl : 'html/home/home.html',
		controller : 'homeCtrl',
	});
	
	$routeProvider.when('/brandInfo', {
		templateUrl : 'html/home/advocate_home.html',
		controller : 'advHomeCtrl',
	});

	$routeProvider.when('/editBrandInfo', {
		templateUrl : 'html/home/edit_advocate_home.html',
		controller : 'editAdvHomeCtrl',
	});

	$routeProvider.when('/homeMail', {
		templateUrl : 'html/home/advocate_home_email.html',
		controller : 'advHomeMailCtrl',
	});

	$routeProvider.when('/webinarHomeMail', {
		templateUrl : 'html/home/advocate_home_webinar_email.html',
		controller : 'advWebinarHomeMailCtrl',
	});

	$routeProvider.when('/bulkUpload', {
		templateUrl : 'html/home/advocate_bulk_upload.html',
		controller : 'advBulkUploadCtrl',
	});

	$routeProvider.when('/inactiveUsers', {
		templateUrl : 'html/home/advocate_inactive_users.html',
		controller : 'advInactiveUsersCtrl',
	});

	/*$routeProvider.when('/baRegister', {
		templateUrl : 'html/home/advocate_register.html',
		controller : 'advRegisterCtrl',
	});*/

	$routeProvider.when('/findOtherBa', {
		templateUrl : 'html/home/advocate_find_other_ba.html',
		controller : 'advFindOtherBaCtrl',
	});

	$routeProvider.when('/reports', {
		templateUrl : 'html/home/advocate_reports.html',
		controller : 'advReportsCtrl',
	});

	$routeProvider.when('/manageEmailTemplates', {
		templateUrl : 'html/home/advocate_manage_email_templates.html',
		controller : 'advManageEmailTemplatesCtrl',
	});
	
	$routeProvider.when('/invitations', {
		templateUrl : 'html/home/advocate_invitations.html',
		controller : 'advInvitationsCtrl',
	});

	$routeProvider.when('/error', {
		templateUrl : 'html/error/error.html',
	});	

	/** Otherwise */
	$routeProvider.otherwise({
		redirectTo : '/login'
		
	});
}]);