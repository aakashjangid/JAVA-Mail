brandAdvocate.directive('selectedLeftMenuLinkDir', function ($window,$timeout,$location) {
	return {
	restrict: 'A',
	//template: 'Name: KULDEEP Address: 2598',
	link : function(scope, element, attrs) {
		
		//TO show selected
		var currentUrl = $location.url();
		if( currentUrl.charAt( 0 ) === '/' )
			currentUrl = currentUrl.slice( 1 );
		var currentUrl = currentUrl.split("?")[0];
		if(currentUrl.length > 0) {
			//check if url is of leftmenu type
			$(element).closest("li").each(function(i){
				var selectedChild = $(this);
				var childLinkVal = $(this).attr('selected-left-menu-link-dir'); // This is your rel value
				if(currentUrl === childLinkVal) {
					selectedChild.addClass('active');
		
				}
			});
			
		}
	//End : show left menu item selected based on current URL
		
		//To reload directive
		scope.$on("$locationChangeSuccess",function handleLocationChange() {
			var currentUrl = $location.url();
			
			/** to get tinymce (no need to do ctrl+f5)  Start */
			if(currentUrl.includes('/homeMail') || currentUrl.includes('/manageEmailTemplates') || currentUrl.includes('/webinarHomeMail')){
				console.log("Location change started for TinyMce");
	        	//tinymce.remove();
	        	//tinymce.init({selector:'#texteditor'});
	        	window.location.reload(true);  // to get tinymce (no need to do ctrl+f5)       
			}
        	/** to get tinymce (no need to do ctrl+f5)  End */			
			
        	//TO show selected
			
			if( currentUrl.charAt( 0 ) === '/' )
				currentUrl = currentUrl.slice( 1 );
			var currentUrl = currentUrl.split("?")[0];
			if(currentUrl.length > 0) {
				//check if url is of leftmenu type
				$(element).closest("li").each(function(i){
					var selectedChild = $(this);
					var childLinkVal = $(this).attr('selected-left-menu-link-dir'); // This is your rel value
					if(currentUrl === childLinkVal) {
						selectedChild.addClass('active');
			
					}else{
						selectedChild.removeClass('active');
					}
				});
				
			}
		});
		//END : To reload directive
		
		$(element).click(function() {
			$(element).parent().closest("div").removeClass("in");
			var linkText = attrs.selectedLeftMenuLinkDir;
			var index =$(element).index();
			//$(element).parent().closest("ul").find("li.active").removeClass('active');
			$(element).parent().closest("ul.nav").find("li.active").removeClass('active');
			
			$(element).addClass('active');
		});
	}
  };
});

brandAdvocate.directive('fileUpload', function () {
    return {
        scope: true,
        link: function (scope, el, attrs) {
            el.bind('change', function (event) {  
            	var item = event.target.files[0];
        		var invalidFileExtensions = ["exe", "apk", "app", "bat", "bin", "cmd", "com", "command", "ipa", "isu", "job", "msi", "run", "vbs", "wsf"]; 
    			if (item != undefined) {
    				var fsize = item.size/1024/1024;
    				var fname = item.name;
    				var basename = fname.split(/[\\/]/).pop();
    				var pos = basename.lastIndexOf(".");
    				var fext;
    				if (basename === "" || pos < 1){
    					fext = "";
    				}
    				fext = basename.slice(pos + 1);
    				
    				/**If file size is >5.0 MB*/
    				if(fsize !== undefined && fsize > 5.0){
    					jAlert(jQuery.i18n.prop('validate_document_size_check'),  jQuery.i18n.prop('common_message'));
    					el.val(null);
    				}
    				
    				/**If file ext doesn't match array element than condition is true*/
    				if($.inArray(fext.toLowerCase(), invalidFileExtensions) == -1) {
    					var files=event.target.files;
    					  for (var i = 0;i<files.length;i++) {
    						  scope.$emit("fileSelected", { file: files[i] ,index:attrs["myIndexes"]});
    	                    }
    				}
    				else{
    					jAlert(jQuery.i18n.prop('validate_document_format_check'),  jQuery.i18n.prop('common_message'));
    					el.val(null);
    				}
    			}
    			
            });
        }
    };
});

brandAdvocate.directive('onlyDigits', function () {
	  return {
	      restrict: 'A',
	      require: '?ngModel',
	      link: function (scope, element, attrs, ngModel) {
	          if (!ngModel) return;
	          ngModel.$parsers.unshift(function (inputValue) {
	              var digits = inputValue.split('').filter(function (s) { return (!isNaN(s) && s != ' '); }).join('');
	              ngModel.$viewValue = digits;
	              ngModel.$render();
	              return digits;
	          });
	      }
	  };
});
/** directive for only alphabets in the text field*/
brandAdvocate.directive('onlyAlphabets', function () {
	return {
	    require: 'ngModel',
	    link: function(scope, element, attr, ngModelCtrl) {
	      function fromUser(text) {
	        var transformedInput = text.replace(/[^0-9a-zA-Z\-\s]/g, '');
	        if (transformedInput !== text) {
	          ngModelCtrl.$setViewValue(transformedInput);
	          ngModelCtrl.$render();
	        }
	        return transformedInput; // or return Number(transformedInput)
	      }
	      ngModelCtrl.$parsers.push(fromUser);
	    }
	  };
	function isALetter(charVal)
   {
       if( charVal.toUpperCase() != charVal.toLowerCase() ) {
           return true;
       }
       else {
           return false;
       }
   }
});
/** directive for only alphabets without Number in the text field*/
brandAdvocate.directive('onlyAlphabetsAllow', function () {
	return {
	    require: 'ngModel',
	    link: function(scope, element, attr, ngModelCtrl) {
	      function fromUser(text) {
	        var transformedInput = text.replace(/[^a-zA-Z\-\s]/g, '');
	        if (transformedInput !== text) {
	          ngModelCtrl.$setViewValue(transformedInput);
	          ngModelCtrl.$render();
	        }
	        return transformedInput; // or return Number(transformedInput)
	      }
	      ngModelCtrl.$parsers.push(fromUser);
	    }
	  };
	function isALetter(charVal)
   {
       if( charVal.toUpperCase() != charVal.toLowerCase() ) {
           return true;
       }
       else {
           return false;
       }
   }
});
/** directive for only number and dot in the text field*/
brandAdvocate.directive('onlyNum', function () {
	return function(scope, element, attrs) {

            var keyCode = [8,9,13,37,39,48,49,50,51,52,53,54,55,56,57,96,97,98,99,100,101,102,103,104,105,110];
            element.bind("keydown", function(event) {
                if($.inArray(event.which,keyCode) == -1) {
                    scope.$apply(function(){
                        scope.$eval(attrs.onlyNum);
                        event.preventDefault();
                    });
                    event.preventDefault();
                }

            });
        };
});

/*directive to allow only numbers*/
brandAdvocate.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }            
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});

/** directive for validate email address and also add code .warning in style.css*/
brandAdvocate.directive('validateEmail', function () {
 var EMAIL_REGEXP = /^[_a-z0-9]+(\.[_a-z0-9]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
  return {
    link: function(scope, elm) {
      elm.on("keyup",function(){
            var isMatchRegex = EMAIL_REGEXP.test(elm.val());
            if( isMatchRegex&& elm.hasClass('warning') || elm.val() == ''){
              elm.removeClass('warning');
            }else if(isMatchRegex == false && !elm.hasClass('warning')){
              elm.addClass('warning');
            }
      });
    }
  }
});

brandAdvocate.directive('ValidateAlphaNumeric', function() {
	return {
		require : 'ngModel',
		restrict : 'A',
		link : function(scope, elem, attr, ngModel) {
			var validator = function(value) {
				if (/^[a-zA-Z0-9]*$/.test(value)) {
					ngModel.$setValidity('alphanumeric', true);
					return value;
				} else {
					ngModel.$setValidity('alphanumeric', false);
					return undefined;
				}
			};
			ngModel.$parsers.unshift(validator);
			ngModel.$formatters.unshift(validator);
		}
	};
});

brandAdvocate.directive('validNumber', function() {
    return {
      require: '?ngModel',
      link: function(scope, element, attrs, ngModelCtrl) {
        if(!ngModelCtrl) {
          return; 
        }

        ngModelCtrl.$parsers.push(function(val) {
          if (angular.isUndefined(val)) {
              var val = '';
          }
          
          var clean = val.replace(/[^-0-9\.]/g, '');
          var negativeCheck = clean.split('-');
			var decimalCheck = clean.split('.');
          if(!angular.isUndefined(negativeCheck[1])) {
              negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
              clean =negativeCheck[0] + '-' + negativeCheck[1];
              if(negativeCheck[0].length > 0) {
              	clean =negativeCheck[0];
              }
              
          }
            
          if(!angular.isUndefined(decimalCheck[1])) {
              decimalCheck[1] = decimalCheck[1].slice(0,2);
              clean =decimalCheck[0] + '.' + decimalCheck[1];
          }

          if (val !== clean) {
            ngModelCtrl.$setViewValue(clean);
            ngModelCtrl.$render();
          }
          return clean;
        });

        element.bind('keypress', function(event) {
          if(event.keyCode === 32) {
            event.preventDefault();
          }
        });
      }
    };
  });

brandAdvocate.directive('dropdownMultiselect', function($filter){
	   return {
	       restrict: 'E',
	       scope:{           
	            model: '=',
	            options: '=',
	            pre_selected: '=preSelected',
	            selectedItemsChanged: '&'
	       },
	       /*template: "<div class='btn-group' data-ng-class='{open: open}'>"+
	        "<button class='btn btn-small'>Select</button>"+
	                "<button class='btn btn-small dropdown-toggle' data-ng-click='open=!open;openDropdown()'><span class='caret'></span></button>"+
	                "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" + 
	                    "<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
	                    "<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +                    
	                    "<li class='divider'></li>" +
	                    "<li data-ng-repeat="option in options | filter"> <a data-ng-click='setSelectedItem()'>{{option.name}}<span data-ng-class='isChecked(option.id)'></span></a></li>" +                                        
	                "</ul>" +
	            "</div>" ,*/
	            template: "<div class='btn-group' id='bolExtraColumnParent' data-ng-class='{open: open}' height='200px'>" +
	            		"<a class='showHideLink' data-ng-click='open=!open;openDropdown()'>" +
	            		"<msg key='bol_show_column' /> " +
	            		"<span	class='glyphicon glyphicon-triangle-bottom'></span> </a>" +
	            		"<h5 class='pull-left bol-grid-links' ></h5>"+
//		                "<button class='btn btn-small dropdown-toggle' data-ng-click='open=!open;openDropdown()'><span class='caret'></span></button>"+
		        		
		                "<ul  id='bolExtraColumn' class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
		                	"<li><a data-ng-click='selectAll()'><i class='icon-ok-sign'></i>  Check All</a></li>" +
		        			"<li><a data-ng-click='deselectAll();'><i class='icon-remove-sign'></i>  Uncheck All</a></li>" +
		        			"<li class='divider'></li>" +
		        	        "<li data-ng-repeat='option in options' ng-if='option.assignable'> <a data-ng-click='setSelectedItem()'>{{option.name}}<span data-ng-class='isChecked(option.id)'></span></a></li>" +
		        	     "</ul>" +
		                 
		                 "<div  class='dropdown-menu' id='btnExtraCol' aria-labelledby='dropdownMenu'>" +
		                 "<button type='button' class='callToAction' ng-click='open=!open;selectedItemsChanged()'><msg key='bol_done'/></button>"+
		                 "</div>" +
		                 
		                 
		                 
		            "</div>" ,
		           
		           
	       controller: function($scope){
	           
	           $scope.openDropdown = function(){        
	                    $scope.selected_items = [];
	                    for(var i=0; i<$scope.pre_selected.length; i++){                        
	                    	$scope.selected_items.push($scope.pre_selected[i].id);
	                    }                                        
	            };
	           
	            $scope.selectAll = function () {
	                $scope.model = _.pluck($scope.options, 'id');
	                
	            };            
	            $scope.deselectAll = function() {
	                $scope.model=[];
	            };
	            $scope.setSelectedItem = function(){
	                var id = this.option.id;
	                if (_.contains($scope.model, id)) {
	                    $scope.model = _.without($scope.model, id);
	                } else {
	                    $scope.model.push(id);
	                }
	                return false;
	            };
	            $scope.isChecked = function (id) {                 
	                if (_.contains($scope.model, id)) {
	                    return 'icon-ok pull-right';
	                }
	                return false;
	            };                                 
	       }
	   } 
	});


brandAdvocate.directive('baMenuSelected', function ($window,$timeout,$location) {
	return {
	restrict: 'A',
	link : function(scope, element, attrs) {
		
		element.on('mouseenter',function(){
		 	if(element.find('ul.dropdown-menu').css('display') == 'block')
		 		element.addClass("menu-open");
		});
		element.on('mouseleave',function(){
		 		element.removeClass("menu-open");
		});
	}
  };
});

brandAdvocate.directive('logoutUser', function ($window,$timeout,$location,$rootScope,$cookieStore,localStorageService,Idle) {
	return {
	restrict: 'A',
	link : function(scope, element, attrs) {
		
		element.on('click',function(){
			console.log("on click",scope.username)
		 	scope.username = '';
		 	$rootScope.username = '';
		 	$rootScope.globals = {};
	        $cookieStore.remove('globals');
	        localStorageService.remove('userrole');
	        localStorageService.remove('userlogin');
	        localStorageService.remove('brandadvocaterole');
	        localStorageService.remove('userresponse');
	        
			localStorageService.clearAll();
			Idle.unwatch();
		 	//$location.path("/login")
		 	scope.$apply();
		 	$window.location.href = 'https://login.cat.com/cgi-bin/logout'
		});
	}
  };
});

brandAdvocate.directive('pressEnter', function () {
    return function (scope, element, attrs) {
        element.bind("keydown", function (event) {
            if(event.which === 13) {
                scope.$apply(function (){
                    scope.$eval(attrs.pressEnter);
                });
                event.preventDefault();
            }
        });
    };
});

//console.log("in directie",username)



brandAdvocate.directive('colResizeable', function() {
	  return {
	    restrict: 'A',
	    link: function(scope, elem) {
	      setTimeout(function() {
	        elem.colResizable({
	          liveDrag: true,
	          gripInnerHtml: "<div class='grip'></div>",
	          draggingClass: "dragging",
	          onDrag: function() {
	            //trigger a resize event, so paren-witdh directive will be updated
	            //$(window).trigger('resize');
	          }
	        });
	      });
	    }
	  };
	});


brandAdvocate.directive('tinyMce', ['$timeout','$http','$rootScope', function ($timeout,$http,$rootScope) {
  return {
    link: function ($scope, element, attrs) {
        $timeout(function () { 
        	tinymce.init({ selector:'#texteditor', 
        		plugins: 'paste textcolor colorpicker print preview fullpage searchreplace save			 autolink directionality visualblocks visualchars fullscreen image code link media template			 codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists textcolor			  imagetools  contextmenu colorpicker textpattern help',
        		paste_data_images: true,
        		toolbar: ' undo redo  link  image  print  preview  forecolor  backcolor  insertdatetime  media  fullscreen  bullist  numlist | styleselect  bold  italic alignleft aligncenter alignright outdent indent code  help',
        		 branding: false,
        		 elementpath: false,
        		 advlist_bullet_styles: 'square',
        		 images_upload_url: $rootScope.urlContext+'/brandadvocate/manage/details/v1/uploadinlineimage',
        		 relative_urls : false,
        		 remove_script_host : false,
        		  advlist_number_styles: 'lower-alpha,lower-roman,upper-alpha,upper-roman',
        		 mobile: {
        			    theme: 'mobile',
        			    plugins: [ 'autosave', 'lists', 'autolink' ],
        			    toolbar: [ 'undo', 'bold', 'italic', 'styleselect' ]
        			  },
        		 menu: {
        			    file: {title: 'File', items: 'newdocument'},
        			    edit: {title: 'Edit', items: 'undo redo | cut copy paste pastetext | selectall'},
        			    insert: {title: 'Insert', items: 'link media | template hr'},
        			    view: {title: 'View', items: 'visualaid'},
        			    format: {title: 'Format', items: 'bold italic underline strikethrough superscript subscript | formats | removeformat'},
        			    table: {title: 'Table', items: 'inserttable tableprops deletetable | cell row column'},
        			    tools: {title: 'Tools', items: 'spellchecker code'}
        			  },
        		  // enable title field in the Image dialog
        		  image_title: true, 
        		  // enable automatic uploads of images represented by blob or data URIs
        		  automatic_uploads: true,
        		  // URL of our upload handler (for more details check: https://www.tinymce.com/docs/configure/file-image-upload/#images_upload_url)
        		  // images_upload_url: 'postAcceptor.php',
        		  // here we add custom filepicker only to Image dialog
        		  //file_picker_types: 'file image media',
        		  file_picker_types: 'image media',
        		  // and here's our custom image picker
        		  file_picker_callback: function(cb, value, meta) {
        		    var input = document.createElement('input');
        		    input.setAttribute('type', 'file');
        		    input.setAttribute('accept', 'image/*');
        		    
        		    // Note: In modern browsers input[type="file"] is functional without 
        		    // even adding it to the DOM, but that might not be the case in some older
        		    // or quirky browsers like IE, so you might want to add it to the DOM
        		    // just in case, and visually hide it. And do not forget do remove it
        		    // once you do not need it anymore.

        		    input.onchange = function() {
        		      var file = this.files[0];
        		      
        		      var reader = new FileReader();
        		      reader.onload = function () {
        		        // Note: Now we need to register the blob in TinyMCEs image blob
        		        // registry. In the next release this part hopefully won't be
        		        // necessary, as we are looking to handle it internally.
        		        var id = 'blobid' + (new Date()).getTime();
        		        var blobCache =  tinymce.activeEditor.editorUpload.blobCache;
        		        var base64 = reader.result.split(',')[1];
        		        var blobInfo = blobCache.create(id, file, base64);
        		        blobCache.add(blobInfo);

        		        // call the callback and populate the Title field with the file name
        		        cb(blobInfo.blobUri(), { title: file.name });
        		      };
        		      reader.readAsDataURL(file);
        		    };
        		    
        		    input.click();
        		  },
        		save_onsavecallback: function () {
        			var data = tinyMCE.get('texteditor').getContent();
        			console.log('Saved',data); 
        			/*$scope.data = data;
        			 $http.post('/brandadvocate/manage/details/v1/savetinymcedata',$scope.data).success(function () {
                               jAlert('Data saved successfully.')
                           });	*/
        		}
        	});
        });
    }
  };
}]);

brandAdvocate.directive('restrictField', function () {
    return {
        restrict: 'AE',
        scope: {
            restrictField: '='
        },
        link: function (scope) {
          // this will match spaces, tabs, line feeds etc
          // you can change this regex as you want
          var regex = /[`~,?!#$%^&*<>;':"/[\]|{}()=+]/;

          scope.$watch('restrictField', function (newValue, oldValue) {
              if (newValue != oldValue && regex.test(newValue)) {
                scope.restrictField = newValue.replace(regex, '');
              }
          });
        }
    };
  });


/*brandAdvocate.directive('timePicker', function() {
	  return {
	    restrict: 'E',
	    require: 'ngModel',
	    replace: true,
	    link: function(scope, element, attrs) {
	      scope.timings = ['7:00 AM', '7:15 AM', '7:30 AM', '7:45 AM', '8:00 AM', '8:15 AM',
	        '8:30 AM', '8:45 AM', '9:00 AM', '9:15 AM', '9:30 AM', '9:45 AM',
	        '10:00 AM', '10:15 AM', '10:30 AM', '10:45 AM', '11:00 AM', '11:15 AM', '11:30 AM', '11:45 AM',
	        '12:00 PM', '12:15 PM', '12:30 PM', '12:45 PM', '1:00 PM', '1:15 PM',
	        '1:30 PM', '1:45 PM', '2:00 PM', '2:15 PM', '2:30 PM', '2:45 PM',
	        '3:00 PM', '3:15 PM', '3:30 PM', '3:45 PM', '4:00 PM', '4:15 PM',
	        '4:30 PM', '4:45 PM', '5:00 PM', '5:15 PM', '5:30 PM', '5:45 PM',
	        '6:00 PM', '6:15 PM', '6:30 PM', '6:45 PM', '7:00 PM', '7:15 PM',
	        '7:30 PM', '7:45 PM', '8:00 PM', '8:15 PM', '8:30 PM', '8:45 PM',
	        '9:00 PM', '9:15 PM', '9:30 PM', '9:45 PM', '10:00 PM', '10:15 PM',
	        '10:30 PM', '10:45 PM', '11:00 PM', '11:15 PM', '11:30 PM', '11:45PM',
	        '12:00 AM', '12:15 AM', '12:30 AM', '12:45 AM', '1:00 AM', '1:15 AM',
	        '1:30 AM', '1:45 AM', '2:00 AM', '2:15 AM', '2:30 AM', '2:45 AM',
	        '3:00 AM', '3:15 AM', '3:30 AM', '3:45 AM', '4:00 AM', '4:15 AM',
	        '4:30 AM', '4:45 AM', '5:00 AM', '5:15 AM', '5:30 AM', '5:45 AM',
	        '6:00 AM', '6:15 AM', '6:30 AM', '6:45 AM'
	      ];

	    },
	    template: '<select name="timepicker" id="timePicker" ng-options="time for time in timings">\
	    	<option value="" selected>Please Select Time</option>\
	    </select>'
	  };
	});*/