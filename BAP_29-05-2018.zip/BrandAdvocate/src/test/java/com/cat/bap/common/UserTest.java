/**
 * 
 */
package com.cat.bap.common;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 18-Mar-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class UserTest {
	
	
	private User user;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		user = new User("11", "123", "12", "90");
	}

		
	/**
	 * Test method for {@link com.cat.bap.common.User#getCwsId()}.
	 */
	@Test
	public void testGetCwsId() {
		String cwsid ="123";
		cwsid=user.getCwsId();
		assertEquals("123", cwsid);
	}

	/**
	 * Test method for {@link com.cat.bap.common.User#getIpAddress()}.
	 */
	@Test
	public void testGetIpAddress() {
		String ip ="12";
		ip=user.getIpAddress();
		assertEquals("12", ip);
	}

	

	/**
	 * Test method for {@link com.cat.bap.common.User#getRemoteHost()}.
	 */
	@Test
	public void testGetRemoteHost() {
		String host ="90";
		host=user.getRemoteHost();
		assertEquals("90", host);
	}

}
