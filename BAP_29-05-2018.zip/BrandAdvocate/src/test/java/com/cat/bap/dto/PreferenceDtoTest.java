/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class PreferenceDtoTest {
	
	PreferenceDto preferenceDto;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {

		MockitoAnnotations.initMocks(this);
		preferenceDto = new PreferenceDto();
	}

	
	/**
	 * Test method for {@link com.cat.bap.dto.PreferenceDto#getPreferenceId()}.
	 */
	@Test
	public void testGetPreferenceId() {
		preferenceDto.setPreferenceId(1L);
		long pId= preferenceDto.getPreferenceId();
		assertEquals(1L, pId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.PreferenceDto#getPreferenceName()}.
	 */
	@Test
	public void testGetPreferenceName() {
		preferenceDto.setPreferenceName("abc");
		String pName= preferenceDto.getPreferenceName();
		assertEquals("abc", pName);
	}

}
