/**
 * 
 */
package com.cat.bap.common;

import static org.junit.Assert.*;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 18-Mar-2018
 */

@RunWith(MockitoJUnitRunner.class)
public class RejectValuesTest {
	
	
	private RejectValues rejectValues;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		rejectValues= new RejectValues("asd", "qwe","fdd");
	}

	

	/**
	 * Test method for {@link com.cat.bap.common.RejectValues#getField()}.
	 */
	@Test
	public void testGetField() {
		rejectValues.setField("field");
		String reject=rejectValues.getField();
		assertEquals("field", reject);
	}

	/**
	 * Test method for {@link com.cat.bap.common.RejectValues#getReasionHeader()}.
	 */
	@Test
	public void testGetReasionHeader() {
		rejectValues.setReasionHeader("reasionHeader");
		String reason=rejectValues.getReasionHeader();
		assertEquals("reasionHeader", reason);
	}

	/**
	 * Test method for {@link com.cat.bap.common.RejectValues#getReason()}.
	 */
	@Test
	public void testGetReason() {
		rejectValues.setReason("reason");
		String r=rejectValues.getReason();
		assertEquals("reason", r);
	}

}
