/**
 * 
 */
package com.cat.bap.common;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;

import com.ibm.db2.jcc.am.re;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 18-Mar-2018
 */
public class ResponseWrapperTest {
	
	ResponseWrapper responseWrapper;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		responseWrapper=new ResponseWrapper<>();
	}

	/**
	 * Test method for {@link com.cat.bap.common.ResponseWrapper#getStatusCode()}.
	 */
	@Test
	public void testGetStatusCode() {
		HttpStatus statusCode = null;
		responseWrapper.setStatusCode(statusCode);
		HttpStatus statusCode1 = responseWrapper.getStatusCode();
	Assert.assertEquals(statusCode1, statusCode);
	}

	/**
	 * Test method for {@link com.cat.bap.common.ResponseWrapper#getMessage()}.
	 */
	@Test
	public void testGetMessage() {
		responseWrapper.setMessage("Hii");
		String msg= responseWrapper.getMessage();
		assertEquals("Hii", msg);
	}

	

}
