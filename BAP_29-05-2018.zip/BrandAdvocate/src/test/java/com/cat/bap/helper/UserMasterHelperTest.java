package com.cat.bap.helper;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.util.PropertyFileUtility;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class UserMasterHelperTest {

	@InjectMocks
	UserMasterHelper userMasterHelper;

	@Mock
	private Logger logger;

	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	private Properties props;

	private java.util.Date date;

	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");

	private List<BAUserDetailsDto> bAUserDetailsDtoList = new ArrayList<BAUserDetailsDto>();
	private List<BAUserDetails> userMasterList = new ArrayList<BAUserDetails>();

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		Mockito.mock(Logger.class);
		Mockito.doNothing().when(logger).info(any(String.class));

		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
		bAUserDetailsDtoList = getBAUserDetailsDto();
		userMasterList = getBAUserDetailsEntity();
	}

	@Test
	public void testConvertEntityToDto() throws ParseException {
		assertNotNull(UserMasterHelper.convertDtoToEntity(bAUserDetailsDtoList.get(0)));
	}

	@Test
	public void testConvertDtoToEntity() {
		assertNotNull(UserMasterHelper.convertEntityToDto(userMasterList.get(0)));
	}

	private List<BAUserDetails> getBAUserDetailsEntity() throws ParseException {
		BAUserDetails bAUserDetails = new BAUserDetails();
		List<BAUserDetails> listBAUserDetails = new ArrayList<BAUserDetails>();
		bAUserDetails.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		bAUserDetails.setCwsUserId(props.getProperty("cwsUserId"));
		bAUserDetails.setLastName(props.getProperty("lastName"));
		bAUserDetails.setFirstName(props.getProperty("firstName"));
		bAUserDetails.setPreferredFirstName(props.getProperty("preferredFirstName"));
		bAUserDetails.setOrganizationName(props.getProperty("organizationName"));
		bAUserDetails.setPrimaryEmail(props.getProperty("primaryEmail"));
		bAUserDetails.setSecondaryEmail(props.getProperty("secondaryEmail"));
		bAUserDetails.setFacilityName(props.getProperty("facilityName"));
		bAUserDetails.setBuildingName(props.getProperty("buildingName"));
		bAUserDetails.setJobKeywords(props.getProperty("jobKeywords"));
		bAUserDetails.setAffiliationDescription(props.getProperty("affiliationDescription"));
		bAUserDetails.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		bAUserDetails.setComments(props.getProperty("comments"));
		bAUserDetails.setNotes(props.getProperty("notes"));
		bAUserDetails.setRegisteredVia(props.getProperty("registeredVia"));
		date = formatter.parse(props.getProperty("registrationDate"));
		bAUserDetails.setRegistrationDate(date);
		bAUserDetails.setRegisteredBy(props.getProperty("registeredBy"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		bAUserDetails.setModifiedDate(date);
		bAUserDetails.setIsActive(Boolean.parseBoolean(props.getProperty("isActive")));
		bAUserDetails.setCupId(props.getProperty("cupId"));
		bAUserDetails.setModifiedBy(props.getProperty("modifiedBy"));
		bAUserDetails.setManagedBy(props.getProperty("managedBy"));
		listBAUserDetails.add(bAUserDetails);
		return listBAUserDetails;
	}

	private List<BAUserDetailsDto> getBAUserDetailsDto() throws ParseException {
		List<BAUserDetailsDto> listBAUserDetailsDto = new ArrayList<BAUserDetailsDto>();
		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		bAUserDetailsDto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		bAUserDetailsDto.setCwsUserId(props.getProperty("cwsUserId"));
		bAUserDetailsDto.setLastName(props.getProperty("lastName"));
		bAUserDetailsDto.setFirstName(props.getProperty("firstName"));
		bAUserDetailsDto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		bAUserDetailsDto.setOrganizationName(props.getProperty("organizationName"));
		bAUserDetailsDto.setWorkLocation(props.getProperty("workLocation"));
		bAUserDetailsDto.setPrimaryEmail(props.getProperty("primaryEmail"));
		bAUserDetailsDto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		bAUserDetailsDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		bAUserDetailsDto.setCountryName(props.getProperty("countryName"));
		bAUserDetailsDto.setCountryCode(props.getProperty("countryCode"));
		bAUserDetailsDto.setFacilityName(props.getProperty("facilityName"));
		bAUserDetailsDto.setBuildingName(props.getProperty("buildingName"));
		bAUserDetailsDto.setJobKeywords(props.getProperty("jobKeywords"));
		bAUserDetailsDto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		bAUserDetailsDto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		bAUserDetailsDto.setComments(props.getProperty("comments"));
		bAUserDetailsDto.setNotes(props.getProperty("notes"));
		bAUserDetailsDto.setRegisteredVia(props.getProperty("registeredVia"));
		date = formatter.parse(props.getProperty("registrationDate"));
		bAUserDetailsDto.setRegistrationDate(date);
		bAUserDetailsDto.setRegisteredBy(props.getProperty("registeredBy"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		bAUserDetailsDto.setModifiedDate(date);
		bAUserDetailsDto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		bAUserDetailsDto.setRegionName(props.getProperty("regionName"));
		bAUserDetailsDto.setIsActive(Boolean.parseBoolean(props.getProperty("isActive")));
		bAUserDetailsDto.setIsAdmin(Boolean.parseBoolean(props.getProperty("isAdmin")));
		bAUserDetailsDto.setCupId(props.getProperty("cupId"));
		bAUserDetailsDto.setPreferencesStr(props.getProperty("preferencesStr"));
		bAUserDetailsDto.setModifiedBy(props.getProperty("modifiedBy"));
		bAUserDetailsDto.setManagedBy(props.getProperty("managedBy"));
		listBAUserDetailsDto.add(bAUserDetailsDto);
		return listBAUserDetailsDto;
	}
}
