/**
 * 
 */
package com.cat.bap.helper;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.cat.bap.dto.BARegistrationViaDto;
import com.cat.bap.dto.CountryDto;
import com.cat.bap.dto.PreferenceDto;
import com.cat.bap.dto.RegionDto;
import com.cat.bap.entity.BARegistrationVia;
import com.cat.bap.entity.Country;
import com.cat.bap.entity.Preferences;
import com.cat.bap.entity.Region;
import com.cat.bap.util.PropertyFileUtility;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */

public class MasterDataHelperTest {

	@Mock
	private Logger logger;

	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	@InjectMocks
	MasterDataHelper masterDataHelper;

	private Properties props;

	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws IOException, ParseException {
		MockitoAnnotations.initMocks(this);
		Mockito.mock(Logger.class);
		Mockito.doNothing().when(logger).info(any(String.class));

		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");

	}

	/**
	 * Test method for
	 * {@link com.cat.bap.helper.MasterDataHelper#convertEntityListToDtoListForCountry(java.util.List)}.
	 * 
	 * @throws ParseException
	 */
	@Test
	public void testConvertEntityListToDtoListForCountry() throws ParseException {

		assertNotNull(MasterDataHelper.convertEntityListToDtoListForCountry(getCountry()));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.helper.MasterDataHelper#convertEntityListToDtoListForRegion(java.util.List)}.
	 * 
	 * @throws ParseException
	 */
	@Test
	public void testConvertEntityListToDtoListForRegion() throws ParseException {

		assertNotNull(MasterDataHelper.convertEntityListToDtoListForRegion(getRegion()));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.helper.MasterDataHelper#convertEntityListToDtoListForPreference(java.util.List)}.
	 * 
	 * @throws ParseException
	 */
	@Test
	public void testConvertEntityListToDtoListForPreference() throws ParseException {
		assertNotNull(MasterDataHelper.convertEntityListToDtoListForPreference(getPreference()));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.helper.MasterDataHelper#convertEntityListToDtoListForRegistrationReason(java.util.List)}.
	 * 
	 * @throws ParseException
	 */
	@Test
	public void testConvertEntityListToDtoListForRegistrationReason() throws ParseException {
		assertNotNull(MasterDataHelper.convertEntityListToDtoListForRegistrationReason(getBARegistrationVia()));

	}

	private List<Country> getCountry() throws ParseException {
		List<Country> listCountry = new ArrayList<Country>();
		Country country = new Country();
		country.setCountryId(Long.parseLong(props.getProperty("countryId")));
		country.setCountryName(props.getProperty("countryName"));
		country.setCountryCode(props.getProperty("countryCode"));
		listCountry.add(country);
		return listCountry;
	}

	private List<Region> getRegion() throws ParseException {
		List<Region> listRegion = new ArrayList<Region>();
		Region region = new Region();
		region.setRegionId(Long.parseLong(props.getProperty("regionId")));
		region.setRegionName(props.getProperty("regionName"));
		listRegion.add(region);
		return listRegion;
	}

	private List<Preferences> getPreference() throws ParseException {
		List<Preferences> listPreferences = new ArrayList<Preferences>();
		Preferences preference = new Preferences();
		preference.setPreferenceId(Long.parseLong(props.getProperty("registrationId")));
		preference.setPreferenceName(props.getProperty("registrationStatusName"));
		listPreferences.add(preference);
		return listPreferences;
	}

	private List<BARegistrationVia> getBARegistrationVia() throws ParseException {
		List<BARegistrationVia> listBARegistrationVia = new ArrayList<BARegistrationVia>();
		BARegistrationVia bARegistrationVia = new BARegistrationVia();
		bARegistrationVia.setRegistrationId(Long.parseLong(props.getProperty("registrationId")));
		bARegistrationVia.setRegistrationStatusName(props.getProperty("registrationStatusName"));
		listBARegistrationVia.add(bARegistrationVia);
		return listBARegistrationVia;
	}

}
