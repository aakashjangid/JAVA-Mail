/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.cat.bap.util.PropertyFileUtility;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class CluesDataDetailDtoTest {
	
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	private Properties props;
	CluesDataDetailDto dto;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		dto = new CluesDataDetailDto();
		props = propertyFileUtility.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
	}

	
	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getBrandAdvocateId()}.
	 */
	@Test
	public void testGetBrandAdvocateId() {
		dto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		long brandId = dto.getBrandAdvocateId();
		assertEquals(Long.parseLong(props.getProperty("brandAdvocateId")), brandId);
		
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getCwsUserId()}.
	 */
	@Test
	public void testGetCwsUserId() {
		dto.setCwsUserId(props.getProperty("cwsUserId"));
		String cwsId = dto.getCwsUserId();
		assertEquals(props.getProperty("cwsUserId"), cwsId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getLastName()}.
	 */
	@Test
	public void testGetLastName() {
		dto.setLastName(props.getProperty("lastName"));
		String lastName = dto.getLastName();
		assertEquals(props.getProperty("lastName"), lastName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getFirstName()}.
	 */
	@Test
	public void testGetFirstName() {
		dto.setFirstName(props.getProperty("firstName"));
		String firstName = dto.getFirstName();
		assertEquals(props.getProperty("firstName"), firstName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getPreferredFirstName()}.
	 */
	@Test
	public void testGetPreferredFirstName() {
		dto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		String preFName = dto.getPreferredFirstName();
		assertEquals(props.getProperty("preferredFirstName"), preFName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getOrganizationName()}.
	 */
	@Test
	public void testGetOrganizationName() {
		dto.setOrganizationName(props.getProperty("organizationName"));
		String organizationName = dto.getOrganizationName();
		assertEquals(props.getProperty("organizationName"), organizationName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getWorkLocation()}.
	 */
	@Test
	public void testGetWorkLocation() {
		dto.setWorkLocation(props.getProperty("workLocation"));
		String workLocation = dto.getWorkLocation();
		assertEquals(props.getProperty("workLocation"), workLocation);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getPrimaryEmail()}.
	 */
	@Test
	public void testGetPrimaryEmail() {
		dto.setPrimaryEmail(props.getProperty("primaryEmail"));
		String primaryEmail = dto.getPrimaryEmail();
		assertEquals(props.getProperty("primaryEmail"), primaryEmail);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getSecondaryEmail()}.
	 */
	@Test
	public void testGetSecondaryEmail() {
		dto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		String secondaryEmail = dto.getSecondaryEmail();
		assertEquals(props.getProperty("secondaryEmail"), secondaryEmail);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getCountryId()}.
	 */
	@Test
	public void testGetCountryId() {
		dto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		long countryId = dto.getCountryId();
		assertEquals(Long.parseLong(props.getProperty("countryId")), countryId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getCountryName()}.
	 */
	@Test
	public void testGetCountryName() {
		dto.setCountryName(props.getProperty("countryName"));
		String countryName = dto.getCountryName();
		assertEquals(props.getProperty("countryName"), countryName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getCountryCode()}.
	 */
	@Test
	public void testGetCountryCode() {
		dto.setCountryCode(props.getProperty("countryCode"));
		String countryCode = dto.getCountryCode();
		assertEquals(props.getProperty("countryCode"), countryCode);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getFacilityName()}.
	 */
	@Test
	public void testGetFacilityName() {
		dto.setFacilityName(props.getProperty("facilityName"));
		String facilityName = dto.getFacilityName();
		assertEquals(props.getProperty("facilityName"), facilityName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getAffiliationDescription()}.
	 */
	@Test
	public void testGetAffiliationDescription() {
		dto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		String affiliationDescription = dto.getAffiliationDescription();
		assertEquals(props.getProperty("affiliationDescription"), affiliationDescription);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getBrandAdvocateStatus()}.
	 */
	@Test
	public void testGetBrandAdvocateStatus() {
		dto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		String brandAdvocateStatus = dto.getBrandAdvocateStatus();
		assertEquals(props.getProperty("brandAdvocateStatus"), brandAdvocateStatus);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getRegionId()}.
	 */
	@Test
	public void testGetRegionId() {
		dto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		long regionId = dto.getRegionId();
		assertEquals(Long.parseLong(props.getProperty("regionId")), regionId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getRegionName()}.
	 */
	@Test
	public void testGetRegionName() {
		dto.setRegionName(props.getProperty("regionName"));
		String regionName = dto.getRegionName();
		assertEquals(props.getProperty("regionName"), regionName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CluesDataDetailDto#getCupId()}.
	 */
	@Test
	public void testGetCupId() {
		dto.setCupId(props.getProperty("cupId"));
		String cupId = dto.getCupId();
		assertEquals(props.getProperty("cupId"), cupId);
	}

	
}
