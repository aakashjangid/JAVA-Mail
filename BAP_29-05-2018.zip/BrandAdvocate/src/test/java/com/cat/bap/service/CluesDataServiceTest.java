/**
 * 
 */
package com.cat.bap.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.repository.BAUserDetailsRepositoryCustom;
import com.cat.bap.repository.CluesUserDetailsRepositoryCustom;
import com.cat.bap.repository.CountryRepository;
import com.cat.bap.util.BrandAdvocateEmailUtility;
import com.cat.bap.util.BrandAdvocateUtility;
import com.cat.bap.util.PropertyFileUtility;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({CluesDataService.class,BrandAdvocateUtility.class})
public class CluesDataServiceTest {
	
	@Mock
	private BAUserDetailsRepositoryCustom bAUserDetailsRepositoryCustom;

	@Mock
	private BAUserDetailsService baUserDetailsService;

	@Mock
	private BrandAdvocateEmailUtility brandAdvocateEmailUtility;

	@Mock
	private CluesUserDetailsRepositoryCustom cluesUserDetailsRepositoryCustom;

	@Mock
	private CountryRepository countryRepository;

	@Mock
	private Logger lOGGER;
	
	@InjectMocks
	private CluesDataService cluesDataService;
	
	@Mock
	private CluesDataDetailDto cluesDataDetailDto;
	
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;
	
	private Properties props;
	private java.util.Date date;
	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		
		MockitoAnnotations.initMocks(this);

		Mockito.mock(Logger.class);
		Mockito.doNothing().when(lOGGER).info(any(String.class));

		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
		cluesDataDetailDto = getCluesDataDetailDto();
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(httpSession.getAttribute(any(String.class))).thenReturn(cluesDataDetailDto);
	}

	
	/**
	 * Test method for {@link com.cat.bap.service.CluesDataService#getCluesUserDetailsByCupId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsByCupId() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(cluesUserDetailsRepositoryCustom.getCluesUserDetailsByCupId(any(String.class))).thenReturn(map);
		Map<String, Object> result = cluesDataService.getCluesUserDetailsByCupId(any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for {@link com.cat.bap.service.CluesDataService#getCluesUserDetailsByCwsUserId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsByCwsUserId() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(cluesUserDetailsRepositoryCustom.getCluesUserDetailsByCwsUserId(any(String.class))).thenReturn(map);
		Map<String, Object> result = cluesDataService.getCluesUserDetailsByCwsUserId(any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for {@link com.cat.bap.service.CluesDataService#getCluesUserDetailsByEmailId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsByEmailId() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(cluesUserDetailsRepositoryCustom.getCluesUserDetailsByEmailId(any(String.class))).thenReturn(map);
		Map<String, Object> result = cluesDataService.getCluesUserDetailsByEmailId(any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for {@link com.cat.bap.service.CluesDataService#getCluesUserDetailsBasedOnCwsIdOrEmailId(java.lang.String, java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsBasedOnCwsIdOrEmailId() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(cluesUserDetailsRepositoryCustom.getCluesUserDetailsBasedOnCwsIdOrEmailId(any(String.class),any(String.class))).thenReturn(map);
		Map<String, Object> result = cluesDataService.getCluesUserDetailsBasedOnCwsIdOrEmailId(any(String.class),any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for {@link com.cat.bap.service.CluesDataService#getCluesUserDetailsBasedOnIds(java.lang.String, java.lang.String, java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsBasedOnIds() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(cluesUserDetailsRepositoryCustom.getCluesUserDetailsBasedOnIds(any(String.class),any(String.class),any(String.class))).thenReturn(map);
		Map<String, Object> result = cluesDataService.getCluesUserDetailsBasedOnIds(any(String.class),any(String.class),any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for {@link com.cat.bap.service.CluesDataService#bulkUploadForEmailsOrCWSIds(java.lang.String, boolean, java.lang.String, java.lang.String)}.
	 * @throws Exception 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testBulkUploadForEmailsOrCWSIds() throws Exception {
		//Map<String, String> mapOfSummaryRecords = new HashMap<>();
		Map<String,String> mapOfSummaryRecords = Mockito.mock(Map.class);
		String strInValidCluesUsers = "";
		String strValidCluesUsers = "";
		List<String> stringValidCluesUsers =null;
		List<String> stringValidCluesUsersEmails=null;
		List<String> stringValidCluesUsersFirstNames=null;
		List<String> stringValidCluesUsersLastNames=null;
		StringTokenizer tokenString = new StringTokenizer("agrawr");
		List<String> listOfAllPassed = new ArrayList<>();
		
		while (tokenString.hasMoreTokens()) {
			listOfAllPassed.add(tokenString.nextToken());
			assertNotNull(listOfAllPassed);
		}
		
		List<BAUserDetailsDto> allExistingBAUsersList = new ArrayList<>();
		Mockito.when(cluesUserDetailsRepositoryCustom.getAllBAUsersList(any(String.class),any(Boolean.class))).thenReturn(allExistingBAUsersList);
		
		Map<String, List<BAUserDetailsDto>> mapOfNewAndExistingUsers =new HashMap<>();

		CluesDataService service = PowerMockito.spy(new CluesDataService());
		PowerMockito.when(service,"getAllBAsFiltered",allExistingBAUsersList).thenReturn(mapOfNewAndExistingUsers);
		/** Get list of Active & In-Active BA users. **/
		List<String> spyList = Mockito.spy(new ArrayList<String>());
		List<BAUserDetailsDto> existingActiveUsers=new ArrayList();
		/** prepare string and set to mao - strExistingActiveUsers **/
		Map<String, List<BAUserDetailsDto>> mock = org.mockito.Mockito.mock(HashMap.class);
		Mockito.when(mock.get("existingActiveUsers")).thenReturn(existingActiveUsers);
		
		String strExistingActiveUsers = null;
		PowerMockito.mockStatic(BrandAdvocateUtility.class);
		PowerMockito.when(BrandAdvocateUtility.getCommaSeparatedString(spyList)).thenReturn(strExistingActiveUsers);
		Mockito.when(mapOfSummaryRecords.put(any(String.class),any(String.class))).thenReturn(any(String.class));
		/******************** EXIST NON ACTIVE USER - START *******************/
		//Map<String, List<BAUserDetailsDto>> existingNonActiveUsers = org.mockito.Mockito.mock(HashMap.class);
		//List<BAUserDetailsDto> existingNonActiveUsersList=new ArrayList();
		//Mockito.when(existingNonActiveUsers.get("existingNonActiveUsers")).thenReturn(existingNonActiveUsersList);
		//String strExistingNonActiveUsers =null;
		//PowerMockito.when(BrandAdvocateUtility.getCommaSeparatedString(spyList)).thenReturn(strExistingNonActiveUsers);
		//Mockito.when(mapOfSummaryRecords.put(any(String.class),any(String.class))).thenReturn(any(String.class));
		
		/*Map<String, String> result = new HashMap<>();
		result = cluesDataService.bulkUploadForEmailsOrCWSIds(any(String.class),any(Boolean.class),any(String.class),any(String.class));
		assertNotNull(result);*/
	}

	/**
	 * Test method for {@link com.cat.bap.service.CluesDataService#getValidCluesUsers(java.util.List, boolean)}.
	 * @throws SQLException 
	 */
	
	private CluesDataDetailDto getCluesDataDetailDto() throws ParseException {
		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		cluesDataDetailDto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		cluesDataDetailDto.setCwsUserId(props.getProperty("cwsUserId"));
		cluesDataDetailDto.setLastName(props.getProperty("lastName"));
		cluesDataDetailDto.setFirstName(props.getProperty("firstName"));
		cluesDataDetailDto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		cluesDataDetailDto.setOrganizationName(props.getProperty("organizationName"));
		cluesDataDetailDto.setWorkLocation(props.getProperty("workLocation"));
		cluesDataDetailDto.setPrimaryEmail(props.getProperty("primaryEmail"));
		cluesDataDetailDto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		cluesDataDetailDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		cluesDataDetailDto.setCountryName(props.getProperty("countryName"));
		cluesDataDetailDto.setCountryCode(props.getProperty("countryCode"));
		cluesDataDetailDto.setFacilityName(props.getProperty("facilityName"));
		cluesDataDetailDto.setJobKeywords(props.getProperty("jobKeywords"));
		cluesDataDetailDto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		cluesDataDetailDto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		date = formatter.parse(props.getProperty("registrationDate"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		cluesDataDetailDto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		cluesDataDetailDto.setRegionName(props.getProperty("regionName"));
		cluesDataDetailDto.setCupId(props.getProperty("cupId"));
		return cluesDataDetailDto;
	}
}
