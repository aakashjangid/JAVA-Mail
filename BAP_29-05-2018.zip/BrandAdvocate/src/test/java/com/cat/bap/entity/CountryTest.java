/**
 * 
 */
package com.cat.bap.entity;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class CountryTest {

	Country country;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		country = new Country();
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Country#getCountryId()}.
	 */
	@Test
	public void testGetCountryId() {
		country.setCountryId(1L);
		long id = country.getCountryId();
		assertEquals(1L, id);
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Country#getCountryCode()}.
	 */
	@Test
	public void testGetCountryCode() {
		country.setCountryCode("abc");
		String code = country.getCountryCode();
		assertEquals("abc", code);
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Country#getCountryName()}.
	 */
	@Test
	public void testGetCountryName() {
		country.setCountryName("india");
		String name = country.getCountryName();
		assertEquals("india", name);
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Country#getRegion()}.
	 */

}
