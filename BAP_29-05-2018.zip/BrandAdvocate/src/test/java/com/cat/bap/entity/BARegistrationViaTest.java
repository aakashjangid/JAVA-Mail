/**
 * 
 */
package com.cat.bap.entity;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BARegistrationViaTest {


	private BARegistrationVia bARegistrationVia;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		bARegistrationVia = new BARegistrationVia();
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.entity.BARegistrationVia#getRegistrationId()}.
	 */
	@Test
	public void testGetRegistrationId() {
		bARegistrationVia.setRegistrationId(1L);
		long id=bARegistrationVia.getRegistrationId();
		assertEquals(1L, id);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.entity.BARegistrationVia#getRegistrationStatusName()}.
	 */
	@Test
	public void testGetRegistrationStatusName() {
		bARegistrationVia.setRegistrationStatusName("abc");
		String name=bARegistrationVia.getRegistrationStatusName();
		assertEquals("abc", name);
	}

}
