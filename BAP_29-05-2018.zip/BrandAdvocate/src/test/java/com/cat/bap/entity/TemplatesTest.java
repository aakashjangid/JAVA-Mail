/**
 * 
 */
package com.cat.bap.entity;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class TemplatesTest {

	Templates templates;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		templates = new Templates();
	}

	

	/**
	 * Test method for {@link com.cat.bap.entity.Templates#getTemplateId()}.
	 */
	@Test
	public void testGetTemplateId() {
		templates.setTemplateId(1L);
		long id = templates.getTemplateId();
		assertEquals(1L, id);
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Templates#getTemplateName()}.
	 */
	@Test
	public void testGetTemplateName() {
		templates.setTemplateName("abc");
		String name = templates.getTemplateName();
		assertEquals("abc",name);
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Templates#getTemplatePath()}.
	 */
	@Test
	public void testGetTemplatePath() {
		templates.setTemplatePath("path");
		String path = templates.getTemplatePath();
		assertEquals("path", path);
	}

	
}
