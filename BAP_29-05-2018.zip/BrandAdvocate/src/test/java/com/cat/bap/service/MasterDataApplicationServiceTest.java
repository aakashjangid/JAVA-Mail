/**
 * 
 */
package com.cat.bap.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.cat.bap.dto.BARegistrationViaDto;
import com.cat.bap.dto.CountryDto;
import com.cat.bap.dto.PreferenceDto;
import com.cat.bap.dto.RegionDto;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class MasterDataApplicationServiceTest {
	
	@Mock
	private MasterDataDomainService masterDataDomainService;
	@InjectMocks
	private MasterDataApplicationService masterDataApplicationService;
	
	List<CountryDto> countriesDtoList = new ArrayList<>();

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataApplicationService#getAllCountries()}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetAllCountries() {
		Map<String, Object> countryMap = new HashMap<>();
		List<CountryDto> countriesDtoList = new ArrayList();
		Mockito.when(masterDataDomainService.getAllCountries()).thenReturn(countriesDtoList);
		countryMap = masterDataApplicationService.getAllCountries();
		assertNotNull(countryMap);
		
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataApplicationService#getAllRegions()}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetAllRegions() {
		Map<String, Object> regionMap = new HashMap<>();
		List<RegionDto> regionDtoList =  new ArrayList();
		Mockito.when(masterDataDomainService.getAllRegions()).thenReturn(regionDtoList);
		regionMap = masterDataApplicationService.getAllRegions();
		assertNotNull(regionMap);
		
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataApplicationService#getAllPreferences()}.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetAllPreferences() {
		Map<String, Object> preferenceMap = new HashMap<>();
		List<PreferenceDto> preferenceDtoList =  new ArrayList();
		Mockito.when(masterDataDomainService.getAllPreferences()).thenReturn(preferenceDtoList);
		preferenceMap = masterDataApplicationService.getAllPreferences();
		assertNotNull(preferenceMap);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataApplicationService#getRegionsByCountryId(java.lang.Long)}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetRegionsByCountryId() {
		Map<String, Object> regionMap = new HashMap<>();
		List<RegionDto> regionDtos = new ArrayList();
		Mockito.when(masterDataDomainService.getRegionsByCountryId(1L)).thenReturn(regionDtos);
		regionMap = masterDataApplicationService.getRegionsByCountryId(1L);
		assertNotNull(regionMap);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataApplicationService#getCountriesByRegionId(java.lang.Long)}.
	 */
	@Test
	public void testGetCountriesByRegionId() {
		Map<String, Object> countryMap = new HashMap<>();
		List<CountryDto> countryDtos = new ArrayList();
		Mockito.when(masterDataDomainService.getCountriesByRegionId(1L)).thenReturn(countryDtos);
		countryMap = masterDataApplicationService.getCountriesByRegionId(1L);
		assertNotNull(countryMap);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataApplicationService#getListRegistrationReason()}.
	 */
	@Test
	public void testGetListRegistrationReason() {
		Map<String, Object> countryMap = new HashMap<>();
		List<BARegistrationViaDto> regReasonDto = new ArrayList();
		Mockito.when(masterDataDomainService.getListRegistrationReason()).thenReturn(regReasonDto);
		countryMap = masterDataApplicationService.getListRegistrationReason();
		assertNotNull(countryMap);
	}

}
