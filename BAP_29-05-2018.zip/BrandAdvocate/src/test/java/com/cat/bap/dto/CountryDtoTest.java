/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.cat.bap.util.PropertyFileUtility;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class CountryDtoTest {
	
	CountryDto dto;
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	private Properties props;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		dto=new CountryDto();
		props = propertyFileUtility.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
	}

	
	/**
	 * Test method for {@link com.cat.bap.dto.CountryDto#getCountryId()}.
	 */
	@Test
	public void testGetCountryId() {
		dto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		long countryId=dto.getCountryId();
		assertEquals(Long.parseLong(props.getProperty("countryId")), countryId);
		
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CountryDto#getCountryName()}.
	 */
	@Test
	public void testGetCountryName() {
		dto.setCountryName(props.getProperty("countryName"));
		String cName=dto.getCountryName();
		assertEquals(props.getProperty("countryName"), cName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CountryDto#getCountryCode()}.
	 */
	@Test
	public void testGetCountryCode() {
		dto.setCountryCode(props.getProperty("countryCode"));
		String code=dto.getCountryCode();
		assertEquals(props.getProperty("countryCode"), code);
	}

}
