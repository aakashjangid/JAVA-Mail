package com.cat.bap.dto;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;

import java.util.List;
import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.cat.bap.entity.Preferences;
import com.cat.bap.util.PropertyFileUtility;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BAUserDetailsDtoTest {

	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	private Properties props;
	BAUserDetailsDto dto;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {

		MockitoAnnotations.initMocks(this);
		dto = new BAUserDetailsDto();
		props = propertyFileUtility.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
	}

	
	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getBrandAdvocateId()}.
	 */
	@Test
	public void testGetBrandAdvocateId() {
		dto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		long brandId = dto.getBrandAdvocateId();
		assertEquals(Long.parseLong(props.getProperty("brandAdvocateId")), brandId);

	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getCwsUserId()}.
	 */
	@Test
	public void testGetCwsUserId() {
		dto.setCwsUserId(props.getProperty("cwsUserId"));
		String cwsId = dto.getCwsUserId();
		assertEquals(props.getProperty("cwsUserId"), cwsId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getLastName()}.
	 */
	@Test
	public void testGetLastName() {
		dto.setLastName(props.getProperty("lastName"));
		String lastName = dto.getLastName();
		assertEquals(props.getProperty("lastName"), lastName);

	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getFirstName()}.
	 */
	@Test
	public void testGetFirstName() {
		dto.setFirstName(props.getProperty("firstName"));
		String firstName = dto.getFirstName();
		assertEquals(props.getProperty("firstName"), firstName);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getPreferredFirstName()}.
	 */
	@Test
	public void testGetPreferredFirstName() {
		dto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		String preFName = dto.getPreferredFirstName();
		assertEquals(props.getProperty("preferredFirstName"), preFName);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getOrganizationName()}.
	 */
	@Test
	public void testGetOrganizationName() {
		dto.setOrganizationName(props.getProperty("organizationName"));
		String organizationName = dto.getOrganizationName();
		assertEquals(props.getProperty("organizationName"), organizationName);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getWorkLocation()}.
	 */
	@Test
	public void testGetWorkLocation() {
		dto.setWorkLocation(props.getProperty("workLocation"));
		String workLocation = dto.getWorkLocation();
		assertEquals(props.getProperty("workLocation"), workLocation);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getPrimaryEmail()}.
	 */
	@Test
	public void testGetPrimaryEmail() {
		dto.setPrimaryEmail(props.getProperty("primaryEmail"));
		String primaryEmail = dto.getPrimaryEmail();
		assertEquals(props.getProperty("primaryEmail"), primaryEmail);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getSecondaryEmail()}.
	 */
	@Test
	public void testGetSecondaryEmail() {
		dto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		String secondaryEmail = dto.getSecondaryEmail();
		assertEquals(props.getProperty("secondaryEmail"), secondaryEmail);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getCountryId()}.
	 */
	@Test
	public void testGetCountryId() {
		dto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		long countryId = dto.getCountryId();
		assertEquals(Long.parseLong(props.getProperty("countryId")), countryId);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getCountryName()}.
	 */
	@Test
	public void testGetCountryName() {
		dto.setCountryName(props.getProperty("countryName"));
		String countryName = dto.getCountryName();
		assertEquals(props.getProperty("countryName"), countryName);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getCountryCode()}.
	 */
	@Test
	public void testGetCountryCode() {
		dto.setCountryCode(props.getProperty("countryCode"));
		String countryCode = dto.getCountryCode();
		assertEquals(props.getProperty("countryCode"), countryCode);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getFacilityName()}.
	 */
	@Test
	public void testGetFacilityName() {
		dto.setFacilityName(props.getProperty("facilityName"));
		String facilityName = dto.getFacilityName();
		assertEquals(props.getProperty("facilityName"), facilityName);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getBuildingName()}.
	 */
	@Test
	public void testGetBuildingName() {
		dto.setBuildingName(props.getProperty("buildingName"));
		String buildingName = dto.getBuildingName();
		assertEquals(props.getProperty("buildingName"), buildingName);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getJobKeywords()}.
	 */
	@Test
	public void testGetJobKeywords() {
		dto.setJobKeywords(props.getProperty("jobKeywords"));
		String jobKeywords = dto.getJobKeywords();
		assertEquals(props.getProperty("jobKeywords"), jobKeywords);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getAffiliationDescription()}.
	 */
	@Test
	public void testGetAffiliationDescription() {
		dto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		String affiliationDescription = dto.getAffiliationDescription();
		assertEquals(props.getProperty("affiliationDescription"), affiliationDescription);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getBrandAdvocateStatus()}.
	 */
	@Test
	public void testGetBrandAdvocateStatus() {
		dto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		String brandAdvocateStatus = dto.getBrandAdvocateStatus();
		assertEquals(props.getProperty("brandAdvocateStatus"), brandAdvocateStatus);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getComments()}.
	 */
	@Test
	public void testGetComments() {
		dto.setComments(props.getProperty("comments"));
		String comments = dto.getComments();
		assertEquals(props.getProperty("comments"), comments);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getNotes()}.
	 */
	@Test
	public void testGetNotes() {
		dto.setNotes(props.getProperty("notes"));
		String notes = dto.getNotes();
		assertEquals(props.getProperty("notes"), notes);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getPreferences()}.
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testGetPreferences() {
		List<Preferences> preferencesList = new ArrayList();
		Preferences preferences = new Preferences();
		preferences.setPreferenceId(1L);
		preferences.setPreferenceName("abc");
		preferencesList.add(preferences);

		dto.setPreferences(preferencesList);
		List<Preferences> list = dto.getPreferences();
		assertEquals(preferencesList, list);

	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getRegisteredVia()}.
	 */
	@Test
	public void testGetRegisteredVia() {
		dto.setRegisteredVia(props.getProperty("registeredVia"));
		String registeredVia = dto.getRegisteredVia();
		assertEquals(props.getProperty("registeredVia"), registeredVia);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getRegisteredBy()}.
	 */
	@Test
	public void testGetRegisteredBy() {
		dto.setRegisteredBy(props.getProperty("registeredBy"));
		String registeredBy = dto.getRegisteredBy();
		assertEquals(props.getProperty("registeredBy"), registeredBy);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getModifiedBy()}.
	 */
	@Test
	public void testGetModifiedBy() {
		dto.setModifiedBy(props.getProperty("modifiedBy"));
		String modifiedBy = dto.getModifiedBy();
		assertEquals(props.getProperty("modifiedBy"), modifiedBy);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getManagedBy()}.
	 */
	@Test
	public void testGetManagedBy() {
		dto.setManagedBy(props.getProperty("managedBy"));
		String managedBy = dto.getManagedBy();
		assertEquals(props.getProperty("managedBy"), managedBy);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getRegionId()}.
	 */
	@Test
	public void testGetRegionId() {
		dto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		long regionId = dto.getRegionId();
		assertEquals(Long.parseLong(props.getProperty("regionId")), regionId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getRegionName()}.
	 */
	@Test
	public void testGetRegionName() {
		dto.setRegionName(props.getProperty("regionName"));
		String regionName = dto.getRegionName();
		assertEquals(props.getProperty("regionName"), regionName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getIsActive()}.
	 */
	@Test
	public void testGetIsActive() {
		dto.setIsActive(Boolean.parseBoolean(props.getProperty("isActive")));
		boolean isActive = dto.getIsActive();
		assertEquals(Boolean.parseBoolean(props.getProperty("isActive")), isActive);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getIsAdmin()}.
	 */
	@Test
	public void testGetIsAdmin() {
		dto.setIsAdmin(Boolean.parseBoolean(props.getProperty("isAdmin")));
		boolean isAdmin = dto.getIsAdmin();
		assertEquals(Boolean.parseBoolean(props.getProperty("isAdmin")), isAdmin);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BAUserDetailsDto#getCupId()}.
	 */
	@Test
	public void testGetCupId() {
		dto.setCupId(props.getProperty("cupId"));
		String cupId = dto.getCupId();
		assertEquals(props.getProperty("cupId"), cupId);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getPreferencesStr()}.
	 */
	@Test
	public void testGetPreferencesStr() {
		dto.setPreferencesStr(props.getProperty("preferencesStr"));
		String preferencesStr = dto.getPreferencesStr();
		assertEquals(props.getProperty("preferencesStr"), preferencesStr);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.dto.BAUserDetailsDto#getLoggedInUserName()}.
	 */
	@Test
	public void testGetLoggedInUserName() {
		dto.setLoggedInUserName(props.getProperty("loggedInUserName"));
		String loggedInUserName = dto.getLoggedInUserName();
		assertEquals(props.getProperty("loggedInUserName"), loggedInUserName);
	}

}
