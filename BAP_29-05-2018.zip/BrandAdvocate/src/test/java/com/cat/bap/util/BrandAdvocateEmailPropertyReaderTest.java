/**
 * 
 */
package com.cat.bap.util;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BrandAdvocateEmailPropertyReaderTest {
	
	BrandAdvocateEmailPropertyReader reader;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		reader = new BrandAdvocateEmailPropertyReader();
	}

	/**
	 * Test method for {@link com.cat.bap.util.BrandAdvocateEmailPropertyReader#getHost()}.
	 */
	@Test
	public void testGetHost() {
		reader.setHost("abc");
		String host=reader.getHost();
		assertEquals("abc", host);
	}

	/**
	 * Test method for {@link com.cat.bap.util.BrandAdvocateEmailPropertyReader#getPort()}.
	 */
	@Test
	public void testGetPort() {
		reader.setPort("80");
		String port=reader.getPort();
		assertEquals("80", port);
		
	}

	/**
	 * Test method for {@link com.cat.bap.util.BrandAdvocateEmailPropertyReader#getEmailid()}.
	 */
	@Test
	public void testGetEmailid() {
		reader.setEmailid("abc@cat.com");
		String email=reader.getEmailid();
		assertEquals("abc@cat.com", email);
	}

	/**
	 * Test method for {@link com.cat.bap.util.BrandAdvocateEmailPropertyReader#getUsername()}.
	 */
	@Test
	public void testGetUsername() {
		reader.setUsername("test");
		String uName=reader.getUsername();
		assertEquals("test", uName);
	}

	/**
	 * Test method for {@link com.cat.bap.util.BrandAdvocateEmailPropertyReader#getPassword()}.
	 */
	@Test
	public void testGetPassword() {
		reader.setPassword("pass");
		String pass=reader.getPassword();
		assertEquals("pass", pass);
	}

	/**
	 * Test method for {@link com.cat.bap.util.BrandAdvocateEmailPropertyReader#getDoNotReply()}.
	 */
	@Test
	public void testGetDoNotReply() {
		reader.setDoNotReply("noReply");
		String noreply=reader.getDoNotReply();
		assertEquals("noReply", noreply);
	}

}
