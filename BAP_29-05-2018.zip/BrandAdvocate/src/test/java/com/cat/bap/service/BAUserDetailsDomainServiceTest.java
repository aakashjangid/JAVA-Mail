/**
 * 
 */
package com.cat.bap.service;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.UserMasterRequest;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.repository.BAUserDetailsRepository;
import com.cat.bap.repository.BAUserDetailsRepositoryCustom;
import com.cat.bap.repository.DocumentsRepository;
import com.cat.bap.repository.TemplatesRepository;
import com.cat.bap.repository.UserPreferencesRepository;
import com.cat.bap.util.PropertyFileUtility;
import com.ibm.db2.jcc.am.u;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BAUserDetailsDomainServiceTest {
	
	@Mock
	private BAUserDetailsRepositoryCustom detailsRepositoryCustom;

	@Mock
	private DocumentsRepository documentsRepository;

	@Mock
	private TemplatesRepository templatesRepository;

	@Mock
	private BAUserDetailsRepository userMasterRepository;

	@Mock
	private UserPreferencesRepository userPreferencesRepository;
	
	@Mock
	private Logger lOGGER;
	
	@Mock
	private BAUserDetailsDto bAUserDetailsDto;
	
	@InjectMocks
	private BAUserDetailsDomainService bAUserDetailsDomainService;
	
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;
	
	private Properties props;
	private java.util.Date date;
	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	

	/**
	 * @throws IOException
	 * @throws ParseException
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws ClassNotFoundException, SQLException, IOException, ParseException {
		MockitoAnnotations.initMocks(this);

		Mockito.mock(Logger.class);
		Mockito.doNothing().when(lOGGER).info(any(String.class));

		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
		bAUserDetailsDto = getBAUserDetailsDto();
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(httpSession.getAttribute(any(String.class))).thenReturn(bAUserDetailsDto);

	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.cat.bap.service.BAUserDetailsDomainService#getAllAdminDetails(com.cat.bap.dto.UserMasterRequest)}.
	 */
	@Test
	public void testGetAllAdminDetails() {
		Map<String, Object> userMasterMap = new HashMap<>();
		when(detailsRepositoryCustom.getAllAdminDetails(any(UserMasterRequest.class))).thenReturn(userMasterMap);
		Map<String, Object> result = bAUserDetailsDomainService.getAllAdminDetails(any(UserMasterRequest.class));
		assertNotNull(result);
	}

	/**
	 * Test method for {@link com.cat.bap.service.BAUserDetailsDomainService#findRecordBasedOnId(java.lang.Long)}.
	 */
	@Test
	public void testFindRecordBasedOnId() {
		BAUserDetails bAUserDetails= new BAUserDetails();
		when(userMasterRepository.findOne(any(Long.class))).thenReturn(bAUserDetails);
		when(bAUserDetailsDomainService.findRecordBasedOnId(any(Long.class))).thenReturn(bAUserDetails);
		assertNotNull(bAUserDetails);
	}

	/**
	 * Test method for {@link com.cat.bap.service.BAUserDetailsDomainService#findBADetails(com.cat.bap.dto.BAUserDetailsDto)}.
	 */
	@Test
	public void testFindBADetails_ifCupIdIsNull() {
		BAUserDetailsDto baDto = new BAUserDetailsDto();
		baDto.setCupId(null);
		baDto.setCwsUserId(null);
		baDto.setPrimaryEmail(null);
		BAUserDetails bAUserDetails = bAUserDetailsDomainService.findBADetails(baDto);
		assertNull(bAUserDetails);
	}
	
	@Test
	public void testFindBADetails_ifCupIdIsNotNull() {
		BAUserDetailsDto baDto = new BAUserDetailsDto();
		baDto.setCupId(bAUserDetailsDto.getCupId());
		baDto.setCwsUserId(null);
		baDto.setPrimaryEmail(null);
		BAUserDetails bAUserDetails = bAUserDetailsDomainService.findBADetails(baDto);
		assertNull(bAUserDetails);
		
	}

	/**
	 * Test method for {@link com.cat.bap.service.BAUserDetailsDomainService#addOrUpdateAdminDetails(com.cat.bap.dto.BAUserDetailsDto)}.
	 * @throws ParseException 
	 */
	@Test
	public void testAddOrUpdateAdminDetails_IfBrandAdvocateIdIsNull() throws ParseException {
		BAUserDetailsDto baDto = new BAUserDetailsDto();
		baDto.setBrandAdvocateId(bAUserDetailsDto.getBrandAdvocateId());
		baDto.setRegistrationDate(bAUserDetailsDto.getRegistrationDate());
		BAUserDetails bAUserDetails =bAUserDetailsDomainService.addOrUpdateAdminDetails(baDto);
		assertNull(bAUserDetails);
	}
	
	/**
	 * Test method for {@link com.cat.bap.service.BAUserDetailsDomainService#addOrUpdateAdminDetails(com.cat.bap.dto.BAUserDetailsDto)}.
	 * @throws ParseException 
	 */
	@Test
	public void testAddOrUpdateAdminDetails_IfBrandAdvocateIdIsNotNull() throws ParseException {
		BAUserDetailsDto baDto = new BAUserDetailsDto();
		baDto.setBrandAdvocateId(bAUserDetailsDto.getBrandAdvocateId());
		//baDto.setBrandAdvocateId(null);
		baDto.setRegistrationDate(bAUserDetailsDto.getRegistrationDate());
		BAUserDetails bAUserDetails =bAUserDetailsDomainService.addOrUpdateAdminDetails(baDto);
		assertNull(bAUserDetails);
	}

	/**
	 * Test method for {@link com.cat.bap.service.BAUserDetailsDomainService#addNotes(com.cat.bap.dto.BAUserDetailsDto)}.
	 */
	@Test
	public void testAddNotes() {
		BAUserDetailsDto userMasterDTO = new BAUserDetailsDto();
		userMasterDTO.setNotes("Hello");
		userMasterDTO.setBrandAdvocateId(1L);
		long brandAdvocateId = userMasterDTO.getBrandAdvocateId();
		String notes= userMasterDTO.getNotes();
		assertEquals("Hello", notes);
		assertEquals(1L, brandAdvocateId);
		
	}

	
	private BAUserDetailsDto getBAUserDetailsDto() throws ParseException {
		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		bAUserDetailsDto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		bAUserDetailsDto.setCwsUserId(props.getProperty("cwsUserId"));
		bAUserDetailsDto.setLastName(props.getProperty("lastName"));
		bAUserDetailsDto.setFirstName(props.getProperty("firstName"));
		bAUserDetailsDto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		bAUserDetailsDto.setOrganizationName(props.getProperty("organizationName"));
		bAUserDetailsDto.setWorkLocation(props.getProperty("workLocation"));
		bAUserDetailsDto.setPrimaryEmail(props.getProperty("primaryEmail"));
		bAUserDetailsDto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		bAUserDetailsDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		bAUserDetailsDto.setCountryName(props.getProperty("countryName"));
		bAUserDetailsDto.setCountryCode(props.getProperty("countryCode"));
		bAUserDetailsDto.setFacilityName(props.getProperty("facilityName"));
		bAUserDetailsDto.setBuildingName(props.getProperty("buildingName"));
		bAUserDetailsDto.setJobKeywords(props.getProperty("jobKeywords"));
		bAUserDetailsDto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		bAUserDetailsDto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		bAUserDetailsDto.setComments(props.getProperty("comments"));
		bAUserDetailsDto.setNotes(props.getProperty("notes"));
		bAUserDetailsDto.setRegisteredVia(props.getProperty("registeredVia"));
		date = formatter.parse(props.getProperty("registrationDate"));
		bAUserDetailsDto.setRegistrationDate(date);
		bAUserDetailsDto.setRegisteredBy(props.getProperty("registeredBy"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		bAUserDetailsDto.setModifiedDate(date);
		bAUserDetailsDto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		bAUserDetailsDto.setRegionName(props.getProperty("regionName"));
		bAUserDetailsDto.setIsActive(Boolean.parseBoolean(props.getProperty("isActive")));
		bAUserDetailsDto.setIsAdmin(Boolean.parseBoolean(props.getProperty("isAdmin")));
		bAUserDetailsDto.setCupId(props.getProperty("cupId"));
		bAUserDetailsDto.setPreferencesStr(props.getProperty("preferencesStr"));
		return bAUserDetailsDto;
	}
}
