/**
 * 
 */
package com.cat.bap.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.service.MasterDataApplicationService;


/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 18-Mar-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class MasterDataControllerTest {

	@Mock
	private Logger lOGGER;

	@Mock
	private MasterDataApplicationService masterDataApplicationService;

	@InjectMocks
	private MasterDataController masterDataController;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.controller.MasterDataController#getAllCountries()}.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetAllCountries() {

		Map response = new HashMap();
		when(masterDataApplicationService.getAllCountries()).thenReturn(response);
		ResponseWrapper<Map<String, Object>> result = masterDataController.getAllCountries();
		assertNotNull(result.getData());
		assertEquals(response, result.getData());
		assertEquals(result.getStatusCode(), HttpStatus.OK);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.controller.MasterDataController#getAllRegions()}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetAllRegions() {
		
		Map response = new HashMap();
		when(masterDataApplicationService.getAllRegions()).thenReturn(response);
		ResponseWrapper<Map<String, Object>> result = masterDataController.getAllRegions();
		assertNotNull(result.getData());
		assertEquals(response, result.getData());
		assertEquals(result.getStatusCode(), HttpStatus.OK);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.controller.MasterDataController#getAllPreferences()}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetAllPreferences() {
		
		Map response = new HashMap();
		when(masterDataApplicationService.getAllPreferences()).thenReturn(response);
		ResponseWrapper<Map<String, Object>> result = masterDataController.getAllPreferences();
		assertNotNull(result.getData());
		assertEquals(response, result.getData());
		assertEquals(result.getStatusCode(), HttpStatus.OK);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.controller.MasterDataController#getRegionsByCountryId(java.lang.Long)}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetRegionsByCountryId() {
		
		Map response = new HashMap();
	    when(masterDataApplicationService.getRegionsByCountryId(any(Long.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = masterDataController.getRegionsByCountryId(any(Long.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.controller.MasterDataController#getCountriesByRegionId(java.lang.Long)}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetCountriesByRegionId() {
		
		Map response = new HashMap();
	    when(masterDataApplicationService.getCountriesByRegionId(any(Long.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = masterDataController.getCountriesByRegionId(any(Long.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

}
