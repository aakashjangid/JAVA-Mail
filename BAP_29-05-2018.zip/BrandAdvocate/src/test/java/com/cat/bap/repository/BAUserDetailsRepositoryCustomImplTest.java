/**
 * 
 */
package com.cat.bap.repository;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.dto.UserMasterRequest;
import com.cat.bap.entity.Preferences;
import com.cat.bap.persistence.util.TufConnectionProvider;
import com.cat.bap.service.UserPreferencesDomainService;
import com.cat.bap.util.PropertyFileUtility;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(/* TODO specify classes to prepare for test */)
public class BAUserDetailsRepositoryCustomImplTest {
	
	@Mock
	private BAUserDetailsRepository baUserDetailsRepository;

	@Mock
	private EntityManagerFactory emf;

	@Mock
	private EntityManager entityManager;

	@Mock
	private TufConnectionProvider tufConnectionProvider;

	@Mock
	private UserPreferencesDomainService userPreferencesDomainService;
	
	@Mock
	Query query;
	
	@Mock
	UserMasterRequest userMasterRequest;
	
	@InjectMocks
	private BAUserDetailsRepositoryCustomImpl bAUserDetailsRepositoryCustomImpl;
	
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;
	
	private Properties props;
	private java.util.Date date;
	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	private BAUserDetailsDto bAUserDetailsDto;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		 MockitoAnnotations.initMocks(this);
		 props = propertyFileUtility
					.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getAllAdminDetails(com.cat.bap.dto.UserMasterRequest)}.
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testGetAllAdminDetails() {
		Map<String, Object> response = new HashMap<>();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		List<Object[]> dataList = new ArrayList(); 
		Mockito.when(query.getResultList()).thenReturn(dataList);
		response=bAUserDetailsRepositoryCustomImpl.getAllAdminDetails(userMasterRequest);
		assertNotNull(response);
		
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getPreferencesDataString(java.lang.Long, com.cat.bap.dto.BAUserDetailsDto, java.lang.String)}.
	 */
	@Test
	public void testGetPreferencesDataString() {
		StringBuilder prefencesCreateQuery = new StringBuilder();
		List<String> dataListForPreferences = new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dataListForPreferences);
		StringBuffer preferencesStr = new StringBuffer();
		String prefix = "";
		for(String str : dataListForPreferences){
			preferencesStr.append(prefix);
			prefix = ",";
			preferencesStr.append(str);
		}
		String result = bAUserDetailsRepositoryCustomImpl.getPreferencesDataString(1L, bAUserDetailsDto, "xyz");
		assertNotNull(dataListForPreferences);
		assertNotNull(result);
		
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getAllActiveBADetails()}.
	 */
	@Test
	public void testGetAllActiveBADetails() {
		List<BAUserDetailsDto> baUserDtoList = new ArrayList<>();
		List<Object[]> dataList = new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dataList);
		baUserDtoList=bAUserDetailsRepositoryCustomImpl.getAllActiveBADetails();
		assertNotNull(dataList);
		assertNotNull(baUserDtoList);
		
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getCWSIDFromBADetils()}.
	 */
	@Test
	public void testGetCWSIDFromBADetils() {
		List<CluesDataDetailDto>  cluesDataList= new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(cluesDataList);
		cluesDataList=bAUserDetailsRepositoryCustomImpl.getCWSIDFromBADetils();
		assertNotNull(cluesDataList);
		
		
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getBAUserDetailsBasedOnCwsIdOrEmailId(java.lang.String, java.lang.String)}.
	 */
/*	@Test
	public void testGetBAUserDetailsBasedOnCwsIdOrEmailId() {
		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();
		List<Object[]> dataList = new ArrayList();
		List<Preferences> preferences= new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dataList);
		Mockito.when(userPreferencesDomainService.getPreferencesDetailsById(1L)).thenReturn(preferences);
		response=bAUserDetailsRepositoryCustomImpl.getBAUserDetailsBasedOnCwsIdOrEmailId("agrawr","abc@cat.com");
		assertNotNull(response);
		
	}*/

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getBAUserDetailsBasedOnIds(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetBAUserDetailsBasedOnIds() {
		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();
		List<Object[]> dataList = new ArrayList();
		List<Preferences> preferences= new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dataList);
		Mockito.when(userPreferencesDomainService.getPreferencesDetailsById(1L)).thenReturn(preferences);
		response=bAUserDetailsRepositoryCustomImpl.getBAUserDetailsBasedOnIds("agrawr","abc@cat.com","123");
		assertNotNull(response);
		
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getBAUserDetailsByCupId(java.lang.String)}.
	 */
	@Test
	public void testGetBAUserDetailsByCupId() {
		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> bAUserDetailsDtos = new ArrayList<>();
		List<Object[]> dataList = new ArrayList();
		List<Preferences> preferences= new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dataList);
		Mockito.when(userPreferencesDomainService.getPreferencesDetailsById(1L)).thenReturn(preferences);
		response=bAUserDetailsRepositoryCustomImpl.getBAUserDetailsByCupId("agrawr");
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getBAUserDetailsByCwsUserId(java.lang.String)}.
	 */
	@Test
	public void testGetBAUserDetailsByCwsUserId() {
		Map<String, Object> response = new HashMap<>();
		List<Object[]> dataList = new ArrayList();
		List<Preferences> preferences= new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dataList);
		Mockito.when(userPreferencesDomainService.getPreferencesDetailsById(1L)).thenReturn(preferences);
		response=bAUserDetailsRepositoryCustomImpl.getBAUserDetailsByCwsUserId("agrawr");
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.repository.BAUserDetailsRepositoryCustomImpl#getBAUserDetailsByEmailId(java.lang.String)}.
	 */
	@Test
	public void testGetBAUserDetailsByEmailId() {
		Map<String, Object> response = new HashMap<>();
		List<Object[]> dataList = new ArrayList();
		List<Preferences> preferences= new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		Mockito.when(query.getResultList()).thenReturn(dataList);
		Mockito.when(userPreferencesDomainService.getPreferencesDetailsById(1L)).thenReturn(preferences);
		response=bAUserDetailsRepositoryCustomImpl.getBAUserDetailsByEmailId("agrawr@cat.com");
		assertNotNull(response);
	}


	
	
}
