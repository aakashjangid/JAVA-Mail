/**
 * 
 */
package com.cat.bap.common;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 18-Mar-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BrandAdvocateExceptionTest {
	
	@InjectMocks
	private BrandAdvocateException brandAdvocateException;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test method for {@link com.cat.bap.common.BrandAdvocateException#getRejectValues()}.
	 */
	@Test
	public void testGetRejectValues() {
		List<RejectValues>  list = new ArrayList();
		RejectValues rejectValues = new RejectValues("abc","xyz","asd");
		rejectValues.setField("123");
		rejectValues.setReasionHeader("abc");
		rejectValues.setReason("wew");
		list.add(rejectValues);
		Assert.assertNotNull(list);
		
		
		
	}

	

}
