/**
 * 
 */
package com.cat.bap.service;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.cat.bap.entity.Preferences;
import com.cat.bap.repository.UserPreferencesRepository;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class UserPreferencesDomainServiceTest {
	@Mock
	private UserPreferencesRepository preferencesAccessRepository;
	
	@InjectMocks
	private UserPreferencesDomainService userPreferencesDomainService;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	
	
	/**
	 * Test method for {@link com.cat.bap.service.UserPreferencesDomainService#getPreferencesDetailsById(java.lang.Long)}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public final void testGetPreferencesDetailsById() {
		List<Preferences> preferencesList = new ArrayList();
		Mockito.when(preferencesAccessRepository.getPreferencesDetailsById(1L)).thenReturn(preferencesList);
		preferencesList= userPreferencesDomainService.getPreferencesDetailsById(1L);
		assertNotNull(preferencesList);
	}

}
