package com.cat.bap.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.core.classloader.annotations.PrepareForTest;

import org.slf4j.Logger;
import org.springframework.http.HttpStatus;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.service.BAUserDetailsService;
import com.cat.bap.service.MasterDataDomainService;
import com.cat.bap.service.SchedulerCluesUpdateService;
import com.cat.bap.util.PersonUtil;
import com.cat.bap.util.PropertyFileUtility;

import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.persistence.PersistenceException;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 30-Mar-2018
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(PersonUtil.class)
public class UserAuthenticationControllerTest{
	
	@Mock
	private MasterDataDomainService masterDataDomainService;
	
	@InjectMocks
	private UserAuthenticationController userAuthenticationController;
	
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;
	
	@Mock
	private PersonUtil personUtil;

	@Mock
	private Logger logger;
	
	@Mock
	private Person person;

	@Mock
	private BAUserDetailsService baUserDetailsService;
	
	@Mock
	private SchedulerCluesUpdateService schedulerCluesUpdateService;

	private BAUserDetailsDto bAUserDetailsDto;

	private Properties props;

	private java.util.Date date;

	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	
	 private static final String STRINGVALUE="xyz";
	 private static final Boolean BOOLEANVALUE=true;
	 
	@Before
	public void initMocks() throws IOException, ParseException {
		MockitoAnnotations.initMocks(this);
		PowerMockito.mock(Logger.class);
		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
		bAUserDetailsDto = getBAUserDetailsDto();
		HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
		HttpSession httpSession = PowerMockito.mock(HttpSession.class);
		PowerMockito.when(request.getSession()).thenReturn(httpSession);
		PowerMockito.when(httpSession.getAttribute(STRINGVALUE)).thenReturn(bAUserDetailsDto);

	}
	
	/**
	 * Test method for {@link com.cat.bap.controller.UserAuthenticationController#login(javax.servlet.http.HttpServletRequest)}.
	 * @throws ParseException 
	 * @throws PersistenceException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testLogin() throws ParseException, PersistenceException {
		
		//Map response = new HashMap();
		HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
		PowerMockito.mockStatic(PersonUtil.class);
		Mockito.when(PersonUtil.getCurrentUserCupid(request)).thenReturn(STRINGVALUE);
		Mockito.when(PersonUtil.getPerson(STRINGVALUE)).thenReturn(person);
		Mockito.when(PersonUtil.isAdminPerson(request)).thenReturn(BOOLEANVALUE);
		  ResponseWrapper<Map<String, BAUserDetailsDto>> result =
	    		userAuthenticationController.login(request);
	        assertNotNull(result.getData());
	        assertEquals(result.getStatusCode(), HttpStatus.OK);
	}
	private BAUserDetailsDto getBAUserDetailsDto() throws ParseException {
		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		bAUserDetailsDto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		bAUserDetailsDto.setCwsUserId(props.getProperty("cwsUserId"));
		bAUserDetailsDto.setLastName(props.getProperty("lastName"));
		bAUserDetailsDto.setFirstName(props.getProperty("firstName"));
		bAUserDetailsDto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		bAUserDetailsDto.setOrganizationName(props.getProperty("organizationName"));
		bAUserDetailsDto.setWorkLocation(props.getProperty("workLocation"));
		bAUserDetailsDto.setPrimaryEmail(props.getProperty("primaryEmail"));
		bAUserDetailsDto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		bAUserDetailsDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		bAUserDetailsDto.setCountryName(props.getProperty("countryName"));
		bAUserDetailsDto.setCountryCode(props.getProperty("countryCode"));
		bAUserDetailsDto.setFacilityName(props.getProperty("facilityName"));
		bAUserDetailsDto.setBuildingName(props.getProperty("buildingName"));
		bAUserDetailsDto.setJobKeywords(props.getProperty("jobKeywords"));
		bAUserDetailsDto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		bAUserDetailsDto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		bAUserDetailsDto.setComments(props.getProperty("comments"));
		bAUserDetailsDto.setNotes(props.getProperty("notes"));
		bAUserDetailsDto.setRegisteredVia(props.getProperty("registeredVia"));
		date = formatter.parse(props.getProperty("registrationDate"));
		bAUserDetailsDto.setRegistrationDate(date);
		bAUserDetailsDto.setRegisteredBy(props.getProperty("registeredBy"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		bAUserDetailsDto.setModifiedDate(date);
		bAUserDetailsDto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		bAUserDetailsDto.setRegionName(props.getProperty("regionName"));
		bAUserDetailsDto.setIsActive(Boolean.parseBoolean(props.getProperty("isActive")));
		bAUserDetailsDto.setIsAdmin(Boolean.parseBoolean(props.getProperty("isAdmin")));
		bAUserDetailsDto.setCupId(props.getProperty("cupId"));
		bAUserDetailsDto.setPreferencesStr(props.getProperty("preferencesStr"));
		return bAUserDetailsDto;
	}

	
}
