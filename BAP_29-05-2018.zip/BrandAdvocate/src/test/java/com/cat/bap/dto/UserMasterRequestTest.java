/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ibm.db2.jcc.am.u;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class UserMasterRequestTest {
	
	UserMasterRequest userMasterRequest;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {

		MockitoAnnotations.initMocks(this);
		userMasterRequest = new UserMasterRequest();
	}

	

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getPageNumber()}.
	 */
	@Test
	public void testGetPageNumber() {
		userMasterRequest.setPageNumber(Integer.parseInt("123"));
		int pageNo=userMasterRequest.getPageNumber();
		assertEquals(Integer.parseInt("123"), pageNo);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getRecords()}.
	 */
	@Test
	public void testGetRecords() {
		userMasterRequest.setRecords(Integer.parseInt("123"));
		int record=userMasterRequest.getRecords();
		assertEquals(Integer.parseInt("123"), record);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getSortOrder()}.
	 */
	@Test
	public void testGetSortOrder() {
		userMasterRequest.setSortOrder("order");
		String order=userMasterRequest.getSortOrder();
		assertEquals("order", order);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getGlobalSearch()}.
	 */
	@Test
	public void testGetGlobalSearch() {
		userMasterRequest.setGlobalSearch("serach");
		String search = userMasterRequest.getGlobalSearch();
		assertEquals("serach", search);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getLang()}.
	 */
	@Test
	public void testGetLang() {
		userMasterRequest.setLang("lang");
		String lang=userMasterRequest.getLang();
		assertEquals("lang", lang);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getIsActive()}.
	 */
	@Test
	public void testGetIsActive() {
		userMasterRequest.setIsActive("Y");
		String active=userMasterRequest.getIsActive();
		assertEquals("Y", active);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getCriteriaFlag()}.
	 */
	@Test
	public void testGetCriteriaFlag() {
	userMasterRequest.setCriteriaFlag(Boolean.parseBoolean("Y"));
	boolean flag=userMasterRequest.getCriteriaFlag();
	assertEquals(Boolean.parseBoolean("Y"), flag);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getRegionId()}.
	 */
	@Test
	public void testGetRegionId() {
		userMasterRequest.setRegionId(Long.parseLong("123"));
		long regionId=userMasterRequest.getRegionId();
		assertEquals(Long.parseLong("123"), regionId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getCountryId()}.
	 */
	@Test
	public void testGetCountryId() {
		userMasterRequest.setCountryId(Long.parseLong("123"));
		long countryId=userMasterRequest.getCountryId();
		assertEquals(Long.parseLong("123"), countryId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getPreferenceName()}.
	 */
	@Test
	public void testGetPreferenceName() {
		userMasterRequest.setPreferenceName("name");
		String pName=userMasterRequest.getPreferenceName();
		assertEquals("name", pName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getEmailId()}.
	 */
	@Test
	public void testGetEmailId() {
		userMasterRequest.setEmailId("abc@cat.com");
		String email=userMasterRequest.getEmailId();
		assertEquals("abc@cat.com", email);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getFullName()}.
	 */
	@Test
	public void testGetFullName() {
		userMasterRequest.setFullName("fullName");
		String fullName=userMasterRequest.getFullName();
		assertEquals("fullName", fullName);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.UserMasterRequest#getOrganizationName()}.
	 */
	@Test
	public void testGetOrganizationName() {
		userMasterRequest.setOrganizationName("orgName");
		String orgName=userMasterRequest.getOrganizationName();
		assertEquals("orgName", orgName);
	}


}
