/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;


/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class MasterDataDtoTest {
	
	private MasterDataDto masterDataDto;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		masterDataDto = new MasterDataDto();
	}

	/**
	 * Test method for {@link com.cat.bap.dto.MasterDataDto#getListRegion()}.
	 */
	@Test
	public void testGetListRegion() {
		List<RegionDto> listRegion =new ArrayList<>();
		masterDataDto.setListRegion(listRegion);
		List<RegionDto> list = masterDataDto.getListRegion();
		assertEquals(listRegion, list);
		
	}

	/**
	 * Test method for {@link com.cat.bap.dto.MasterDataDto#getListCountry()}.
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testGetListCountry() {
		@SuppressWarnings("unchecked")
		List<CountryDto> listCountry= new ArrayList();
		masterDataDto.setListCountry(listCountry);
		List<CountryDto> list = masterDataDto.getListCountry();
		assertEquals(listCountry, list);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.MasterDataDto#getListPreferences()}.
	 */
	@SuppressWarnings("rawtypes")
	@Test
	public void testGetListPreferences() {
		@SuppressWarnings("unchecked")
		List<PreferenceDto> listPreferences = new ArrayList();
		masterDataDto.setListPreferences(listPreferences);
		List<PreferenceDto> list = masterDataDto.getListPreferences();
		assertEquals(listPreferences, list);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.MasterDataDto#getListBARegistraionStatus()}.
	 */
	@Test
	public void testGetListBARegistraionStatus() {
		List<BARegistrationViaDto> listBARegistraionStatus = new ArrayList();
		masterDataDto.setListBARegistraionStatus(listBARegistraionStatus);
		List<BARegistrationViaDto> list= masterDataDto.getListBARegistraionStatus();
		assertEquals(listBARegistraionStatus, list);
	}

}
