/**
 * 
 */
package com.cat.bap.entity;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class UserPreferencesTest {

	UserPreferences userPreferences;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		userPreferences = new UserPreferences();
	}

	/**
	 * Test method for {@link com.cat.bap.entity.UserPreferences#getUpaId()}.
	 */
	@Test
	public void testGetUpaId() {
		userPreferences.setUpaId(1L);
		long id = userPreferences.getUpaId();
		assertEquals(1L, id);
	}

}
