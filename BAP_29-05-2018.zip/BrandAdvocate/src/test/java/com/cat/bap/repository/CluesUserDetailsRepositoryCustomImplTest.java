/**
 * 
 */
package com.cat.bap.repository;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.persistence.util.TufConnectionProvider;
import com.cat.bap.util.PropertyFileUtility;
import com.mysql.jdbc.PreparedStatement;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(PowerMockRunner.class)
public class CluesUserDetailsRepositoryCustomImplTest {
	@Mock
	private EntityManager entityManager;

	@Mock
	private Logger logger;

	@Mock
	private TufConnectionProvider tufConnectionProvider;

	@Mock
	Query query;

	@InjectMocks
	private CluesUserDetailsRepositoryCustomImpl cluesUserDetailsRepositoryCustomImpl;

	@InjectMocks
	private PropertyFileUtility propertyFileUtility;
	
	@Mock
	private AffilationDescRepository  affilationDescRepository;

	private Properties props;
	private java.util.Date date;
	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	@Mock
	private CluesDataDetailDto cluesDataDetailDto;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		props = propertyFileUtility.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");

	}

	
	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#getCluesUserDetailsByEmailId(java.lang.String)}.
	 * 
	 * @throws SQLException
	 */
	@Test
	public void testGetCluesUserDetailsByEmailId() throws SQLException {
		Map<String, Object> response = new HashMap<>();
		Connection con = Mockito.mock(Connection.class);
		ResultSet rs = Mockito.mock(ResultSet.class);
		PreparedStatement ps = Mockito.mock(PreparedStatement.class);

		Mockito.when(con.prepareStatement(any(String.class))).thenReturn(ps);
		Mockito.when(tufConnectionProvider.getConnection()).thenReturn(con);
		Mockito.when(ps.executeQuery()).thenReturn(rs);
		Mockito.when(rs.next()).thenReturn(true).thenReturn(false);
		response = cluesUserDetailsRepositoryCustomImpl.getCluesUserDetailsByEmailId("agrawr@cat.com");
		assertNotNull(response);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#getCluesUserDetailsByCwsUserId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsByCwsUserId() throws SQLException {
		Map<String, Object> response = new HashMap<>();
		Connection con = Mockito.mock(Connection.class);
		ResultSet rs = Mockito.mock(ResultSet.class);
		PreparedStatement ps = Mockito.mock(PreparedStatement.class);

		Mockito.when(con.prepareStatement(any(String.class))).thenReturn(ps);
		Mockito.when(tufConnectionProvider.getConnection()).thenReturn(con);
		Mockito.when(ps.executeQuery()).thenReturn(rs);
		Mockito.when(rs.next()).thenReturn(true).thenReturn(false);
		response = cluesUserDetailsRepositoryCustomImpl.getCluesUserDetailsByCwsUserId("agrawr");
		assertNotNull(response);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#getCluesUserDetailsByCupId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsByCupId() throws SQLException {
		Map<String, Object> response = new HashMap<>();
		Connection con = Mockito.mock(Connection.class);
		ResultSet rs = Mockito.mock(ResultSet.class);
		PreparedStatement ps = Mockito.mock(PreparedStatement.class);

		Mockito.when(con.prepareStatement(any(String.class))).thenReturn(ps);
		Mockito.when(tufConnectionProvider.getConnection()).thenReturn(con);
		Mockito.when(ps.executeQuery()).thenReturn(rs);
		Mockito.when(rs.next()).thenReturn(true).thenReturn(false);
		response = cluesUserDetailsRepositoryCustomImpl.getCluesUserDetailsByCupId("agrawr");
		assertNotNull(response);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#getCluesUserDetailsBasedOnCwsIdOrEmailId(java.lang.String, java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsBasedOnCwsIdOrEmailId() throws SQLException {
		Map<String, Object> response = new HashMap<>();
		Connection con = Mockito.mock(Connection.class);
		ResultSet rs = Mockito.mock(ResultSet.class);
		PreparedStatement ps = Mockito.mock(PreparedStatement.class);

		Mockito.when(con.prepareStatement(any(String.class))).thenReturn(ps);
		Mockito.when(tufConnectionProvider.getConnection()).thenReturn(con);
		Mockito.when(ps.executeQuery()).thenReturn(rs);
		Mockito.when(rs.next()).thenReturn(true).thenReturn(false);
		response = cluesUserDetailsRepositoryCustomImpl.getCluesUserDetailsBasedOnCwsIdOrEmailId("agrawr","agraw@cat.com");
		assertNotNull(response);
		
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#getCluesUserDetailsBasedOnIds(java.lang.String, java.lang.String, java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetCluesUserDetailsBasedOnIds() throws SQLException {
		List<CluesDataDetailDto> userMasterDTOs = new ArrayList<>();
		Map<String, Object> response = new HashMap<>();
		Connection con = Mockito.mock(Connection.class);
		ResultSet rs = Mockito.mock(ResultSet.class);
		PreparedStatement ps = Mockito.mock(PreparedStatement.class);

		Mockito.when(con.prepareStatement(any(String.class))).thenReturn(ps);
		Mockito.when(tufConnectionProvider.getConnection()).thenReturn(con);
		Mockito.when(ps.executeQuery()).thenReturn(rs);
		Mockito.when(rs.next()).thenReturn(true).thenReturn(false);
		userMasterDTOs.add(cluesDataDetailDto);
		Mockito.when(cluesDataDetailDto.getAffiliationDescription()).thenReturn("abs");
		//affilationDescRepository.getAffiliationNameByDesc(cluesDataDetailDto2.getAffiliationDescription())
		Mockito.when(affilationDescRepository.getAffiliationNameByDesc(cluesDataDetailDto.getAffiliationDescription())).thenReturn("abc");
		response = cluesUserDetailsRepositoryCustomImpl.getCluesUserDetailsBasedOnIds("agrawr","agraw@cat.com","123");
		assertNotNull(response);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#uploadBulkUploadForEmailsOrCWSIds(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testUploadBulkUploadForEmailsOrCWSIds() throws SQLException {
		Map<String, List<BAUserDetailsDto>> response = new HashMap<>();
		Connection con = Mockito.mock(Connection.class);
		ResultSet rs = Mockito.mock(ResultSet.class);
		PreparedStatement ps = Mockito.mock(PreparedStatement.class);

		Mockito.when(con.prepareStatement(any(String.class))).thenReturn(ps);
		Mockito.when(tufConnectionProvider.getConnection()).thenReturn(con);
		Mockito.when(ps.executeQuery()).thenReturn(rs);
		Mockito.when(rs.next()).thenReturn(true).thenReturn(false);
		response = cluesUserDetailsRepositoryCustomImpl.uploadBulkUploadForEmailsOrCWSIds("agrawr");
		assertNull(response);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#getValidCluesUsers(java.util.List, boolean)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetValidCluesUsers() throws SQLException {
		List<CluesDataDetailDto> cluesDetailDtoList =  new ArrayList<CluesDataDetailDto>();
		List<String> newBAObject = new ArrayList();
		Connection con = Mockito.mock(Connection.class);
		ResultSet rs = Mockito.mock(ResultSet.class);
		PreparedStatement ps = Mockito.mock(PreparedStatement.class);

		Mockito.when(con.prepareStatement(any(String.class))).thenReturn(ps);
		Mockito.when(tufConnectionProvider.getConnection()).thenReturn(con);
		Mockito.when(ps.executeQuery()).thenReturn(rs);
		Mockito.when(rs.next()).thenReturn(true).thenReturn(false);
		cluesDetailDtoList = cluesUserDetailsRepositoryCustomImpl.getValidCluesUsers(newBAObject,true);
		assertNotNull(cluesDetailDtoList);
	}

	

	

	/**
	 * Test method for
	 * {@link com.cat.bap.repository.CluesUserDetailsRepositoryCustomImpl#getAllBAUsersList(java.lang.String, boolean)}.
	 */
	@Test
	public void testGetAllBAUsersList() {
		Map<String, Object> response = new HashMap<>();
		List<BAUserDetailsDto> BAList= new ArrayList();
		Mockito.when(entityManager.createNativeQuery(any())).thenReturn(query);
		List<Object[]> dataList = new ArrayList(); 
		Mockito.when(query.getResultList()).thenReturn(dataList);
		BAList=cluesUserDetailsRepositoryCustomImpl.getAllBAUsersList("abc",true);
		assertNotNull(BAList);
	}

	

	public List<CluesDataDetailDto> getCluesData() {
		List<CluesDataDetailDto> cluesList = new ArrayList<>();
		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		cluesDataDetailDto.setAffiliationDescription(("USER_CUPID"));
		cluesDataDetailDto.setAffiliationDescription(("AFLTN_DESC"));
		cluesDataDetailDto.setLastName(("PS_EMP_LAST_NM"));
		cluesDataDetailDto.setFirstName(("PS_EMP_FST_NM"));
		cluesDataDetailDto.setPreferredFirstName(("PERS_PREF_FST_NM"));
		cluesDataDetailDto.setOrganizationName(("PS_ADMN_CD_DESC"));
		cluesDataDetailDto.setFacilityName(("WRK_LOC_DESC"));
		cluesDataDetailDto.setPrimaryEmail(("BUS_EMAIL_ADR"));
		cluesDataDetailDto.setJobKeywords(("JOB_KEYWORD"));
		cluesDataDetailDto.setCountryCode(("CTRY_CD"));
		cluesList.add(cluesDataDetailDto);
		return cluesList;
	}
}
