/**
 * 
 */
package com.cat.bap.util;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class EmailOnlyPersonTest {

	EmailOnlyPerson emailOnlyPerson;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		emailOnlyPerson = new EmailOnlyPerson("abc@cat.com");
	}

	/**
	 * Test method for {@link com.cat.bap.util.EmailOnlyPerson#getLogonId()}.
	 */
	@Test
	public void testGetLogonId() {
		emailOnlyPerson.setLogonId("xyz");
		String logonId = emailOnlyPerson.getLogonId();
		assertNull(logonId);
	}

}
