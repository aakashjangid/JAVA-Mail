/**
 * 
 */
package com.cat.bap.service;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.cat.bap.dto.BARegistrationViaDto;
import com.cat.bap.dto.CountryDto;
import com.cat.bap.dto.PreferenceDto;
import com.cat.bap.dto.RegionDto;
import com.cat.bap.entity.Country;
import com.cat.bap.helper.MasterDataHelper;
import com.cat.bap.repository.BARegistrationViaRepository;
import com.cat.bap.repository.CountryRepository;
import com.cat.bap.repository.PreferenceRepository;
import com.cat.bap.repository.RegionRepository;
import com.cat.bap.util.PropertyFileUtility;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class MasterDataDomainServiceTest {
	
	@Mock
	private CountryRepository countryRepository;

	@Mock
	private PreferenceRepository preferenceRepository;

	@Mock
	private RegionRepository regionRepository;

	@Mock
	private BARegistrationViaRepository regReasonRepository;
	
	@InjectMocks
	private MasterDataDomainService masterDataDomainService;
	
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	private Properties props;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataDomainService#getAllCountries()}.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public  void testGetAllCountries() {
		List<CountryDto> countryDtoList = new ArrayList();
		Mockito.when(MasterDataHelper.convertEntityListToDtoListForCountry(countryRepository.findAll())).thenReturn(countryDtoList);
		countryDtoList=masterDataDomainService.getAllCountries();
		assertNotNull(countryDtoList);
		
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataDomainService#getAllRegions()}.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public  void testGetAllRegions() {
		List<RegionDto> regionDtoList = new ArrayList();
		Mockito.when(MasterDataHelper.convertEntityListToDtoListForRegion(regionRepository.findAll())).thenReturn(regionDtoList);
		regionDtoList=masterDataDomainService.getAllRegions();
		assertNotNull(regionDtoList);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataDomainService#getAllPreferences()}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public  void testGetAllPreferences() {
		List<PreferenceDto> preferenceDtoList = new ArrayList();
		Mockito.when(MasterDataHelper.convertEntityListToDtoListForPreference(preferenceRepository.findAll())).thenReturn(preferenceDtoList);
		preferenceDtoList=masterDataDomainService.getAllPreferences();
		assertNotNull(preferenceDtoList);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataDomainService#getRegionsByCountryId(java.lang.Long)}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetRegionsByCountryId() {
		List<RegionDto> regionDtoList = new ArrayList();
		Mockito.when(MasterDataHelper.convertEntityListToDtoListForRegion(countryRepository.getRegionsByCountryId(1L))).thenReturn(regionDtoList);
		regionDtoList=masterDataDomainService.getRegionsByCountryId(1L);
		assertNotNull(regionDtoList);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataDomainService#getCountryByCountryCode(java.lang.String)}.
	 */
	@Test
	public  void testGetCountryByCountryCode() {
		CountryDto countryDto = new CountryDto();
		Country countryEntity= new Country();
		Mockito.when(countryRepository.getCountryByCountryCode("xyz")).thenReturn(countryEntity);
		countryDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		countryDto.setCountryName(props.getProperty("countryName"));
		countryDto.setCountryCode(props.getProperty("countryCode"));
		countryDto=masterDataDomainService.getCountryByCountryCode("xyz");
		assertNotNull(countryDto);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataDomainService#getCountriesByRegionId(java.lang.Long)}.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetCountriesByRegionId() {
		List<CountryDto> countryDtoList = new ArrayList();
		Mockito.when(MasterDataHelper.convertEntityListToDtoListForCountry(regionRepository.getCountriesByRegionId(1L))).thenReturn(countryDtoList);
		countryDtoList=masterDataDomainService.getCountriesByRegionId(1L);
		assertNotNull(countryDtoList);
	}

	/**
	 * Test method for {@link com.cat.bap.service.MasterDataDomainService#getListRegistrationReason()}.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetListRegistrationReason() {
		List<BARegistrationViaDto> bARegistrationViaDto = new ArrayList();
		Mockito.when(MasterDataHelper.convertEntityListToDtoListForRegistrationReason(regReasonRepository.findAll())).thenReturn(bARegistrationViaDto);
		bARegistrationViaDto=masterDataDomainService.getListRegistrationReason();
		assertNotNull(bARegistrationViaDto);
	}

}
