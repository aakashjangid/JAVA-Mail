/**
 * 
 */
package com.cat.bap.entity;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BAStatusTest {
	
	BAStatus bAStatus;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		bAStatus = new BAStatus();
	}

	/**
	 * Test method for {@link com.cat.bap.entity.BAStatus#getStatusId()}.
	 */
	@Test
	public void testGetStatusId() {
		bAStatus.setStatusId(1L);
		long id = bAStatus.getStatusId();
		assertEquals(1L, id);
	}

	/**
	 * Test method for {@link com.cat.bap.entity.BAStatus#getStatusName()}.
	 */
	@Test
	public void testGetStatusName() {
		bAStatus.setStatusName("abc");
		String name= bAStatus.getStatusName();
		assertEquals("abc", name);
	}

}
