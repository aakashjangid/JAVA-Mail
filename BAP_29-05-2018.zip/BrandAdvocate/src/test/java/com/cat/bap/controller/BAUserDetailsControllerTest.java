package com.cat.bap.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.velocity.exception.VelocityException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.persistence.util.TufConnectionProvider;
import com.cat.bap.service.BAUserDetailsService;
import com.cat.bap.service.EmailUtilityService;
import com.cat.bap.service.SchedulerCluesUpdateService;
import com.cat.bap.util.BrandAdvocateEmailUtility;
import com.cat.bap.util.PersonUtil;
import com.cat.bap.util.PropertyFileUtility;
import com.cat.bap.util.SchedulerCLUES;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.Gson;

import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.email.EMailException;
import cat.cis.tuf.common.persistence.PersistenceException;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 18-Mar-2018
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest(PersonUtil.class)
public class BAUserDetailsControllerTest {

	@InjectMocks
	private BAUserDetailsController bAUserDetailsController;

	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	@Mock
	private BrandAdvocateEmailUtility brandAdvocateEmailUtility;

	@Mock
	private SchedulerCLUES schedulerCLUES;

	@Mock
	private TufConnectionProvider tufConnectionProvider;

	@Mock
	private HttpHeaders httpHeaders;

	@Mock
	private HttpServletResponse response;

	@Mock
	private Logger logger;

	@Mock
	private BAUserDetailsService baUserDetailsService;
	
	@Mock
	private SchedulerCluesUpdateService schedulerCluesUpdateService;
	
	@Mock
	private EmailUtilityService emailUtilityService;

	private BAUserDetailsDto bAUserDetailsDto;

	private Properties props;

	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	
	private java.util.Date date;

	@Before
	public void initMocks() throws IOException, ParseException {
		MockitoAnnotations.initMocks(this);

		Mockito.mock(Logger.class);
		Mockito.doNothing().when(logger).info(any(String.class));

		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
		bAUserDetailsDto = getBAUserDetailsDto();
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(httpSession.getAttribute(any(String.class))).thenReturn(bAUserDetailsDto);

	}

	/**
	 * @throws ParseException
	 * @throws AddressException
	 * @throws EMailException
	 * @throws IOException 
	 * @throws PersistenceException 
	 */
	@Test
	public void testAddOrUpdateUserInformation()
			throws ParseException, AddressException, EMailException, IOException, PersistenceException {

		Map<String, Object> map =null;
		BAUserDetailsDto bauserDetailDto = new BAUserDetailsDto();
	    
		when(baUserDetailsService.addOrUpdateUserInformation((BAUserDetailsDto) any(Map.class)))
				.thenReturn(map);
		PowerMockito.mockStatic(PersonUtil.class);
		List<Person> adminGroupUsers = new ArrayList();
		Mockito.when(PersonUtil.getAdminGroupUsers()).thenReturn(adminGroupUsers);
		//Mockito.when(emailUtilityService.sendEmailToNewUsers(bauserDetailDto, adminGroupUsers)).thenReturn(true);
		
		ResponseWrapper<Map<String, Object>> responseWrapper = bAUserDetailsController
				.addOrUpdateUserInformation(getBAUserDetailsDto());
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);

	}
	
	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getAllBAUsersDetails(java.lang.String)}.
	 * @throws ParseException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetAllBAUsersDetails() throws ParseException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
	    String RequestJson = new Gson().toJson(getBAUserDetailsDto());
	    when(baUserDetailsService.getAllBAUsersDetailsFromJson(any(String.class)))
	        .thenReturn(response);
	    
	    ResponseWrapper<Map<String, Object>> result =
	    		bAUserDetailsController.getAllBAUsersDetails(RequestJson);
	        assertNotNull(result.getData());
	        assertEquals(response, result.getData());
		
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getBAUserDetailsById(java.lang.Long)}.
	 * @throws ParseException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetBAUserDetailsById() throws ParseException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
		when(baUserDetailsService.getBAUserDetailsById(any(Long.class)))
        .thenReturn(response);
		assertNotNull(response);
	}

		
	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#checkBAExistInPortal(com.cat.bap.dto.BAUserDetailsDto)}.
	 * @throws ParseException 
	 */
	@Test
	public void testCheckBAExistInPortal() throws ParseException {
		
		when(baUserDetailsService.checkBAExistInPortal(any(BAUserDetailsDto.class)))
        .thenReturn(bAUserDetailsDto);
		ResponseWrapper<BAUserDetailsDto> responseWrapper = bAUserDetailsController
				.checkBAExistInPortal(getBAUserDetailsDto());
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
	}

	
	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#sendMail(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, java.lang.String)}.
	 * @throws MessagingException 
	 * @throws IOException 
	 * @throws VelocityException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws EMailException 
	 */
	@Test
	public void testSendMail() throws JsonParseException, JsonMappingException, VelocityException, IOException, MessagingException, EMailException {
		
		ResponseWrapper<Boolean> responseWrapper = bAUserDetailsController.sendMail(any(MultipartHttpServletRequest.class), any(HttpHeaders.class), any(String.class));
		//assertEquals(response,responseWrapper);
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(responseWrapper);
		
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#sendCalendarInvite(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, java.lang.String)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws ParseException 
	 */
	@Test
	public void testSendCalendarInvite() throws JsonParseException, JsonMappingException, IOException, ParseException {

		ResponseWrapper<Boolean> responseWrapper = bAUserDetailsController.sendCalendarInvite(any(MultipartHttpServletRequest.class), any(HttpHeaders.class), any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(responseWrapper);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getBAUserDetailsByCwsIdOrEmailId(java.lang.String, java.lang.String)}.
	 * @throws ParseException 
	 */
/*	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetBAUserDetailsByCwsIdOrEmailIdStringString() throws ParseException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
		when(baUserDetailsService.getBAUserDetailsBasedOnCwsIdOrEmailId(any(String.class),any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = bAUserDetailsController.getBAUserDetailsByCwsIdOrEmailId(any(String.class),any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}*/

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getBAUserDetailsByIds(java.lang.String, java.lang.String, java.lang.String)}.
	 * @throws ParseException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetBAUserDetailsByIds() throws ParseException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
		when(baUserDetailsService.getBAUserDetailsBasedOnIds(any(String.class),any(String.class),any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = bAUserDetailsController.getBAUserDetailsByIds(any(String.class),any(String.class),any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	
	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getBAUserDetailsByCupId(java.lang.String)}.
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetBAUserDetailsByCupId() throws ParseException, SQLException {
	
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
		when(baUserDetailsService.getBAUserDetailsByCupId(any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = bAUserDetailsController.getBAUserDetailsByCupId(any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getBAUserDetailsByCwsId(java.lang.String)}.
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetBAUserDetailsByCwsId() throws ParseException, SQLException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
		when(baUserDetailsService.getBAUserDetailsByCwsUserId(any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = bAUserDetailsController.getBAUserDetailsByCwsId(any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getBAUserDetailsByEmailId(java.lang.String)}.
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetBAUserDetailsByEmailId() throws ParseException, SQLException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
		when(baUserDetailsService.getBAUserDetailsByEmailId(any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = bAUserDetailsController.getBAUserDetailsByEmailId(any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getAllTemplates()}.
	 * @throws ParseException 
	 * @throws IOException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes"})
	@Test
	public void testGetAllTemplates() throws ParseException, IOException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
	     when(baUserDetailsService.getAllTemplates())
	        .thenReturn(response);
	    
	    ResponseWrapper<Map<String, Object>> result =
	    		bAUserDetailsController.getAllTemplates();
	        assertNotNull(result.getData());
	        assertEquals(response, result.getData());
	}

	

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getTemplateDetailsByTemplateId(java.lang.Long, javax.servlet.http.HttpServletResponse)}.
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetTemplateDetailsByTemplateId() throws ParseException, IOException, SQLException {
		
		Map response = new HashMap();
	    response.put("LIST", getBAUserDetailsDto());
		when(baUserDetailsService.getTemplateDetailsByTemplateId(any(Long.class),any(HttpServletResponse.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = bAUserDetailsController.getTemplateDetailsByTemplateId(any(Long.class),any(HttpServletResponse.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#getBAUserDetailsByCwsIdOrEmailId()}.
	 * @throws SQLException 
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws EMailException 
	 */
	@Test
	public void testSyncCluesData() throws SQLException, EMailException, IOException, ParseException {
		
		when(schedulerCluesUpdateService.syncCluesData(any(String.class), any(String.class), any(String.class), any(String.class)))
        .thenReturn(true);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.BAUserDetailsController#saveMailTemplateData(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, java.lang.String)}.
	 * @throws IOException 
	 */
	@Test
	public void testSaveMailTemplateData() throws IOException {
		
		ResponseWrapper<Boolean> responseWrapper = bAUserDetailsController.saveMailTemplateData(any(MultipartHttpServletRequest.class), any(HttpHeaders.class) , any(String.class), any(String.class), any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(responseWrapper);
		
	}


	private BAUserDetailsDto getBAUserDetailsDto() throws ParseException {
		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		bAUserDetailsDto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		bAUserDetailsDto.setCwsUserId(props.getProperty("cwsUserId"));
		bAUserDetailsDto.setLastName(props.getProperty("lastName"));
		bAUserDetailsDto.setFirstName(props.getProperty("firstName"));
		bAUserDetailsDto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		bAUserDetailsDto.setOrganizationName(props.getProperty("organizationName"));
		bAUserDetailsDto.setWorkLocation(props.getProperty("workLocation"));
		bAUserDetailsDto.setPrimaryEmail(props.getProperty("primaryEmail"));
		bAUserDetailsDto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		bAUserDetailsDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		bAUserDetailsDto.setCountryName(props.getProperty("countryName"));
		bAUserDetailsDto.setCountryCode(props.getProperty("countryCode"));
		bAUserDetailsDto.setFacilityName(props.getProperty("facilityName"));
		bAUserDetailsDto.setBuildingName(props.getProperty("buildingName"));
		bAUserDetailsDto.setJobKeywords(props.getProperty("jobKeywords"));
		bAUserDetailsDto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		bAUserDetailsDto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		bAUserDetailsDto.setComments(props.getProperty("comments"));
		bAUserDetailsDto.setNotes(props.getProperty("notes"));
		bAUserDetailsDto.setRegisteredVia(props.getProperty("registeredVia"));
		date = formatter.parse(props.getProperty("registrationDate"));
		bAUserDetailsDto.setRegistrationDate(date);
		bAUserDetailsDto.setRegisteredBy(props.getProperty("registeredBy"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		bAUserDetailsDto.setModifiedDate(date);
		bAUserDetailsDto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		bAUserDetailsDto.setRegionName(props.getProperty("regionName"));
		bAUserDetailsDto.setIsActive(Boolean.parseBoolean(props.getProperty("isActive")));
		bAUserDetailsDto.setIsAdmin(Boolean.parseBoolean(props.getProperty("isAdmin")));
		bAUserDetailsDto.setCupId(props.getProperty("cupId"));
		bAUserDetailsDto.setPreferencesStr(props.getProperty("preferencesStr"));
		return bAUserDetailsDto;
	}
}
