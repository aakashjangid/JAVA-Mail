/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 30-Mar-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class BARegistrationViaDtoTest {
	
	BARegistrationViaDto bARegistrationViaDto;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		bARegistrationViaDto= new BARegistrationViaDto();
	}

	
	/**
	 * Test method for {@link com.cat.bap.dto.BARegistrationViaDto#getRegId()}.
	 */
	@Test
	public void testGetRegId() {
		bARegistrationViaDto.setRegId(1L);
		long bARegistration = bARegistrationViaDto.getRegId();
		assertEquals(1L, bARegistration);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.BARegistrationViaDto#getRegistrationStatusName()}.
	 */
	@Test
	public void testGetRegistrationStatusName() {
		bARegistrationViaDto.setRegistrationStatusName("test");
		String bARegistra=bARegistrationViaDto.getRegistrationStatusName();
		assertEquals("test", bARegistra);
	}

}
