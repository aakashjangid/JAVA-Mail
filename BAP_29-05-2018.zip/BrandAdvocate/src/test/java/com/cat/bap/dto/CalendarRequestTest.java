/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class CalendarRequestTest {
	
	CalendarRequest calendarRequest;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		calendarRequest = new CalendarRequest();
	}

	
	/**
	 * Test method for {@link com.cat.bap.dto.CalendarRequest#getFirstName()}.
	 */
	@Test
	public void testGetFirstName() {
		calendarRequest.setFirstName("ABC");
		String fName=calendarRequest.getFirstName();
		assertEquals("ABC", fName);
	}

/*	*//**
	 * Test method for {@link com.cat.bap.dto.CalendarRequest#getEmailList()}.
	 *//*
	@Test
	public void testGetEmailList() {
		calendarRequest.setEmailList("ABC@cat.com");
		String email=calendarRequest.getEmailList();
		assertEquals("ABC@cat.com", email);
	}*/

	/**
	 * Test method for {@link com.cat.bap.dto.CalendarRequest#getSubject()}.
	 */
	@Test
	public void testGetSubject() {
		calendarRequest.setSubject("sub");
		String sub=calendarRequest.getSubject();
		assertEquals("sub", sub);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CalendarRequest#getMessageBody()}.
	 */
	@Test
	public void testGetMessageBody() {
		calendarRequest.setMessageBody("body");
		String body=calendarRequest.getMessageBody();
		assertEquals("body", body);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CalendarRequest#getLocation()}.
	 */
	@Test
	public void testGetLocation() {
		calendarRequest.setLocation("loc");
		String loc=calendarRequest.getLocation();
		assertEquals("loc", loc);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.CalendarRequest#getLastName()}.
	 */
	@Test
	public void testGetLastName() {
		calendarRequest.setLastName("lname");
		String lname=calendarRequest.getLastName();
		assertEquals("lname", lname);
	}

	

}
