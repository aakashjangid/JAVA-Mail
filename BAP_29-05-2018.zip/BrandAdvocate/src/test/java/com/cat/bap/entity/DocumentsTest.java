/**
 * 
 */
package com.cat.bap.entity;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ibm.db2.jcc.a.d;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class DocumentsTest {

	Documents documents;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		documents = new Documents();
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Documents#getDocumentId()}.
	 */
	@Test
	public void testGetDocumentId() {
		documents.setDocumentId(1L);
		long id= documents.getDocumentId();
		assertEquals(1L, id);
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Documents#getDocumentName()}.
	 */
	@Test
	public void testGetDocumentName() {
		documents.setDocumentName("abc");
		String name = documents.getDocumentName();
		assertEquals("abc",name);
		
	}

	/**
	 * Test method for {@link com.cat.bap.entity.Documents#getDocumentPath()}.
	 */
	@Test
	public void testGetDocumentPath() {
		documents.setDocumentPath("path");
		String path = documents.getDocumentPath();
		assertEquals("path", path);
	}

}
