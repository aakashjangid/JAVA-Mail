/**
 * 
 */
package com.cat.bap.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.velocity.exception.VelocityException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.cat.bap.dto.BAUserDetailsDto;
import com.cat.bap.dto.CalendarRequest;
import com.cat.bap.dto.MailRequest;
import com.cat.bap.dto.UserMasterRequest;
import com.cat.bap.entity.BAUserDetails;
import com.cat.bap.entity.Preferences;
import com.cat.bap.entity.Templates;
import com.cat.bap.repository.BAUserDetailsRepositoryCustom;
import com.cat.bap.util.BrandAdvocateCalendarUtility;
import com.cat.bap.util.BrandAdvocateEmailUtility;
import com.cat.bap.util.PropertyFileUtility;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.Gson;

import cat.cis.tuf.common.email.EMailException;


/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */

@RunWith(PowerMockRunner.class)
@PrepareForTest({FileReader.class, BufferedReader.class})
public class BAUserDetailsServiceTest {

	@InjectMocks
	private BAUserDetailsService bAUserDetailsService;

	@InjectMocks
	private PropertyFileUtility propertyFileUtility;

	@Mock
	private BAUserDetailsRepositoryCustom bAUserDetailsRepositoryCustom;

	@Mock
	private BrandAdvocateCalendarUtility brandAdvocateCalendarUtility;

	@Mock
	private BrandAdvocateEmailUtility brandAdvocateEmailUtility;

	@Mock
	private Environment environment;

	@Mock
	private Logger lOGGER;

	@Mock
	private BAUserDetailsDomainService manageAdminDomainService;

	@Mock
	private UserPreferencesDomainService userPreferencesAccessDomainService;
	
	@Mock
	private HttpHeaders httpHeaders;

	@Mock
	private HttpServletResponse response;

	private Properties props;
	private java.util.Date date;
	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
	private BAUserDetailsDto bAUserDetailsDto;

	/**
	 * @throws IOException
	 * @throws ParseException
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws ClassNotFoundException, SQLException, IOException, ParseException {
		MockitoAnnotations.initMocks(this);

		Mockito.mock(Logger.class);
		Mockito.doNothing().when(lOGGER).info(any(String.class));

		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
		bAUserDetailsDto = getBAUserDetailsDto();
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(httpSession.getAttribute(any(String.class))).thenReturn(bAUserDetailsDto);

	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getAllBAUsersDetailsFromJson(java.lang.String)}.
	 */
	@Test
	public void testGetAllBAUsersDetailsFromJson() {

		UserMasterRequest userMasterRequest = new UserMasterRequest();
		Map<String, Object> userMasterMap = new HashMap<>();
		Gson gson = new Gson();
		when(bAUserDetailsService.getAllBAUserDetails(any(UserMasterRequest.class))).thenReturn(userMasterMap);
		bAUserDetailsService.getAllBAUsersDetailsFromJson(gson.toJson(userMasterRequest));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getBAUserDetailsById(java.lang.Long)}.
	 */
	@Test
	public void testGetBAUserDetailsById() {

		BAUserDetails bAUserDetails = new BAUserDetails();
		List<Preferences> preferences = new ArrayList<>();
		when(manageAdminDomainService.findRecordBasedOnId(any(Long.class))).thenReturn(bAUserDetails);
		when(userPreferencesAccessDomainService.getPreferencesDetailsById(any(Long.class))).thenReturn(preferences);
		Map<String, Object> result = bAUserDetailsService.getBAUserDetailsById(any(Long.class));
		assertNotNull(result);
		// assertEquals(response, result.getData());
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#addOrUpdateUserInformation(com.cat.bap.dto.BAUserDetailsDto)}.
	 * 
	 * @throws ParseException
	 */
	@Test
	public void testAddOrUpdateUserInformation() throws ParseException {
		BAUserDetails bAUserDetails = new BAUserDetails();
		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		bAUserDetailsDto.setIsActive(Boolean.TRUE);
		when(manageAdminDomainService.addOrUpdateAdminDetails(any(BAUserDetailsDto.class))).thenReturn(bAUserDetails);
		//responseMap = bAUserDetailsService.addOrUpdateUserInformation(any(BAUserDetailsDto.class));
		//assertNotNull(responseMap);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#addNotes(com.cat.bap.dto.BAUserDetailsDto)}.
	 * @throws ParseException 
	 */
	@Test
	public void testAddNotes() throws ParseException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).addNotes(bAUserDetailsDto);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#addCommentsQuestions(com.cat.bap.dto.BAUserDetailsDto)}.
	 * @throws ParseException 
	 */
	@Test
	public void testAddCommentsQuestions() throws ParseException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).addCommentsQuestions(bAUserDetailsDto);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#doBAStatusInactiveInDB(java.lang.Long, java.lang.Boolean)}.
	 * @throws IOException 
	 * @throws SQLException 
	 * @throws EMailException 
	 */
	@Test
	public void testChangeActiveStatus() throws EMailException, SQLException, IOException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).changeActiveStatus(any(Long.class),any(Boolean.class), any(BAUserDetailsDto.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#generateXLSFromJson(javax.servlet.http.HttpServletResponse, java.lang.String, org.springframework.http.HttpHeaders)}.
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws NoSuchFieldException 
	 * @throws SecurityException 
	 */
	@Test
	public void testGenerateXLSFromJson() throws SecurityException, NoSuchFieldException, IOException, ParseException {
		
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).generateXLSFromJson(any(HttpServletResponse.class),any(String.class),any(HttpHeaders.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#generateXLS(javax.servlet.http.HttpServletResponse, com.cat.bap.dto.UserMasterRequest, org.springframework.http.HttpHeaders)}.
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws NoSuchFieldException 
	 * @throws SecurityException 
	 */
	@Test
	public void testGenerateXLS() throws SecurityException, NoSuchFieldException, IOException, ParseException {
		
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).generateXLS(any(HttpServletResponse.class),any(UserMasterRequest.class),any(HttpHeaders.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#exportToExcel(com.cat.bap.dto.UserMasterRequest, java.lang.String, java.lang.String)}.
	 * @throws IOException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testExportToExcel() throws IOException {
		UserMasterRequest manageAdminRequest = Mockito.mock(UserMasterRequest.class);
		List<BAUserDetailsDto> userMasterDTOs =new ArrayList();
		when(manageAdminRequest.getSelectedRecordsListForExportToExcel()).thenReturn(userMasterDTOs);
		assertNotNull(userMasterDTOs);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#sendMailFromJsonData(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, java.lang.String)}.
	 * @throws MessagingException 
	 * @throws IOException 
	 * @throws VelocityException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws EMailException 
	 */
	@Test
	public void testSendMailFromJsonData() throws JsonParseException, JsonMappingException, VelocityException, IOException, MessagingException, EMailException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).sendMailFromJsonData(any(MultipartHttpServletRequest.class),any(HttpHeaders.class),any(String.class));
	
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#sendCalendarInviteFromJsonData(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, java.lang.String)}.
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 * @throws ParseException 
	 */
	@Test
	public void testSendCalendarInviteFromJsonData() throws JsonParseException, JsonMappingException, IOException, ParseException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).sendCalendarInviteFromJsonData(any(MultipartHttpServletRequest.class),any(HttpHeaders.class),any(String.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#sendMail(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, com.cat.bap.dto.MailRequest)}.
	 * @throws MessagingException 
	 * @throws IOException 
	 * @throws VelocityException 
	 * @throws EMailException 
	 */
	@Test
	public void testSendMail() throws VelocityException, IOException, MessagingException, EMailException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).sendMail(any(MultipartHttpServletRequest.class),any(HttpHeaders.class),any(MailRequest.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#sendCalendarInvite(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, com.cat.bap.dto.CalendarRequest)}.
	 * @throws IOException 
	 * @throws ParseException 
	 */
	@Test
	public void testSendCalendarInvite() throws IOException, ParseException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).sendCalendarInvite(any(MultipartHttpServletRequest.class),any(HttpHeaders.class),any(CalendarRequest.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#checkBAExistInPortal(com.cat.bap.dto.BAUserDetailsDto)}.
	 */
	@Test
	public void testCheckBAExistInPortal() {
		BAUserDetails bAUserDetails = new BAUserDetails();
		when(manageAdminDomainService.findBADetails(any(BAUserDetailsDto.class))).thenReturn(bAUserDetails);
		assertNotNull(bAUserDetails);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getBAUserDetailsBasedOnCwsIdOrEmailId(java.lang.String, java.lang.String)}.
	 */
/*	@Test
	public void testGetBAUserDetailsBasedOnCwsIdOrEmailId() {
		Map<String, Object> map = new HashMap<>();
		when(bAUserDetailsRepositoryCustom.getBAUserDetailsBasedOnCwsIdOrEmailId(any(String.class),any(String.class))).thenReturn(map);
		Map<String, Object> result = bAUserDetailsService.getBAUserDetailsBasedOnCwsIdOrEmailId(any(String.class),any(String.class));
		assertNotNull(result);
	}*/

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getBAUserDetailsBasedOnIds(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetBAUserDetailsBasedOnIds() {
		Map<String, Object> map = new HashMap<>();
		when(bAUserDetailsRepositoryCustom.getBAUserDetailsBasedOnIds(any(String.class),any(String.class),any(String.class))).thenReturn(map);
		Map<String, Object> result = bAUserDetailsService.getBAUserDetailsBasedOnIds(any(String.class),any(String.class),any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getBAUserDetailsByCupId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetBAUserDetailsByCupId() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(bAUserDetailsRepositoryCustom.getBAUserDetailsByCupId(any(String.class))).thenReturn(map);
		Map<String, Object> result = bAUserDetailsService.getBAUserDetailsByCupId(any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getBAUserDetailsByCwsUserId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetBAUserDetailsByCwsUserId() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(bAUserDetailsRepositoryCustom.getBAUserDetailsByCwsUserId(any(String.class))).thenReturn(map);
		Map<String, Object> result = bAUserDetailsService.getBAUserDetailsByCwsUserId(any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getBAUserDetailsByEmailId(java.lang.String)}.
	 * @throws SQLException 
	 */
	@Test
	public void testGetBAUserDetailsByEmailId() throws SQLException {
		Map<String, Object> map = new HashMap<>();
		when(bAUserDetailsRepositoryCustom.getBAUserDetailsByEmailId(any(String.class))).thenReturn(map);
		Map<String, Object> result = bAUserDetailsService.getBAUserDetailsByEmailId(any(String.class));
		assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#updateSecondaryMail(com.cat.bap.dto.BAUserDetailsDto)}.
	 * @throws ParseException 
	 */
	@Test
	public void testUpdateSecondaryMail() throws ParseException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).updateSecondaryMail(any(BAUserDetailsDto.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#deleteUserInfo(java.lang.Long)}.
	 */
	@Test
	public void testDeleteUserInfo() {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).deleteUserInfo(any(Long.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#saveMailTemplateData(org.springframework.web.multipart.MultipartHttpServletRequest, org.springframework.http.HttpHeaders, java.lang.String)}.
	 * @throws IOException 
	 */
	@Test
	public void testSaveMailTemplateData() throws IOException {
		BAUserDetailsService bAUserDetailsService=Mockito.mock(BAUserDetailsService.class);
		Mockito.doNothing().when(bAUserDetailsService).saveMailTemplateData(any(MultipartHttpServletRequest.class),any(HttpHeaders.class),any(String.class),any(String.class),any(String.class));
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getAllTemplates()}.
	 */
	@Test
	public void testGetAllTemplates() {
		List<Templates> templatesList = new ArrayList<>();
		when(manageAdminDomainService.getAllTemplates()).thenReturn(templatesList);
		Map<String, Object> result = bAUserDetailsService.getAllTemplates();
		assertNotNull(result);
	}

	/**
	 * Test method for
	 * {@link com.cat.bap.service.BAUserDetailsService#getTemplateDetailsByTemplateId(java.lang.Long, javax.servlet.http.HttpServletResponse)}.
	 * @throws Exception 
	 */
	

	private BAUserDetailsDto getBAUserDetailsDto() throws ParseException {
		BAUserDetailsDto bAUserDetailsDto = new BAUserDetailsDto();
		bAUserDetailsDto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		bAUserDetailsDto.setCwsUserId(props.getProperty("cwsUserId"));
		bAUserDetailsDto.setLastName(props.getProperty("lastName"));
		bAUserDetailsDto.setFirstName(props.getProperty("firstName"));
		bAUserDetailsDto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		bAUserDetailsDto.setOrganizationName(props.getProperty("organizationName"));
		bAUserDetailsDto.setWorkLocation(props.getProperty("workLocation"));
		bAUserDetailsDto.setPrimaryEmail(props.getProperty("primaryEmail"));
		bAUserDetailsDto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		bAUserDetailsDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		bAUserDetailsDto.setCountryName(props.getProperty("countryName"));
		bAUserDetailsDto.setCountryCode(props.getProperty("countryCode"));
		bAUserDetailsDto.setFacilityName(props.getProperty("facilityName"));
		bAUserDetailsDto.setBuildingName(props.getProperty("buildingName"));
		bAUserDetailsDto.setJobKeywords(props.getProperty("jobKeywords"));
		bAUserDetailsDto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		bAUserDetailsDto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		bAUserDetailsDto.setComments(props.getProperty("comments"));
		bAUserDetailsDto.setNotes(props.getProperty("notes"));
		bAUserDetailsDto.setRegisteredVia(props.getProperty("registeredVia"));
		date = formatter.parse(props.getProperty("registrationDate"));
		bAUserDetailsDto.setRegistrationDate(date);
		bAUserDetailsDto.setRegisteredBy(props.getProperty("registeredBy"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		bAUserDetailsDto.setModifiedDate(date);
		bAUserDetailsDto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		bAUserDetailsDto.setRegionName(props.getProperty("regionName"));
		bAUserDetailsDto.setIsActive(Boolean.parseBoolean(props.getProperty("isActive")));
		bAUserDetailsDto.setIsAdmin(Boolean.parseBoolean(props.getProperty("isAdmin")));
		bAUserDetailsDto.setCupId(props.getProperty("cupId"));
		bAUserDetailsDto.setPreferencesStr(props.getProperty("preferencesStr"));
		return bAUserDetailsDto;
	}

}
