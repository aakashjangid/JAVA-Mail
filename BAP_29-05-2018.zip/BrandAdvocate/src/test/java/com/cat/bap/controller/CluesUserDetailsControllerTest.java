/**
 * 
 */
package com.cat.bap.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.velocity.exception.VelocityException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.cat.bap.common.ResponseWrapper;
import com.cat.bap.dto.CluesDataDetailDto;
import com.cat.bap.service.CluesDataService;
import com.cat.bap.service.SchedulerCluesUpdateService;
import com.cat.bap.util.PropertyFileUtility;
import com.cat.bap.util.SchedulerCLUES;

import cat.cis.tuf.common.email.EMailException;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 18-Mar-2018
 */

@RunWith(MockitoJUnitRunner.class)
public class CluesUserDetailsControllerTest {
	
	@Mock
	private SchedulerCLUES schedulerCLUES;
	
	@InjectMocks
	private CluesUserDetailsController cluesUserDetailsController;
	
	@InjectMocks
	private PropertyFileUtility propertyFileUtility;
	
	@Mock
	private HttpHeaders httpHeaders;

	@Mock
	private HttpServletResponse response;

	@Mock
	private Logger logger;

	@Mock
	private CluesDataService cluesDataService;
	
	@Mock
	private SchedulerCluesUpdateService schedulerCluesUpdateService;

	private CluesDataDetailDto cluesDataDetailDto;

	private Properties props;

	private java.util.Date date;

	SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");

	@Before
	public void initMocks() throws IOException, ParseException {
		MockitoAnnotations.initMocks(this);

		Mockito.mock(Logger.class);
		Mockito.doNothing().when(logger).info(any(String.class));

		props = propertyFileUtility
				.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
		cluesDataDetailDto = getCluesDataDetailDto();
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpSession httpSession = Mockito.mock(HttpSession.class);
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(httpSession.getAttribute(any(String.class))).thenReturn(cluesDataDetailDto);

	}

	
	/**
	 * Test method for {@link com.cat.bap.controller.CluesUserDetailsController#getCluesUserDetailsByCupId(java.lang.String)}.
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetCluesUserDetailsByCupId() throws ParseException, SQLException {
		Map response = new HashMap();
	    response.put("LIST", getCluesDataDetailDto());
		when(cluesDataService.getCluesUserDetailsByCupId(any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = cluesUserDetailsController.getCluesUserDetailsByCupId(any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.CluesUserDetailsController#getCluesUserDetailsByCwsId(java.lang.String)}.
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetCluesUserDetailsByCwsId() throws ParseException, SQLException {
		Map response = new HashMap();
	    response.put("LIST", getCluesDataDetailDto());
		when(cluesDataService.getCluesUserDetailsByCwsUserId(any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = cluesUserDetailsController.getCluesUserDetailsByCwsId(any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.CluesUserDetailsController#getCluesUserDetailsByEmailId(java.lang.String)}.
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetCluesUserDetailsByEmailId() throws ParseException, SQLException {
		
		Map response = new HashMap();
	    response.put("LIST", getCluesDataDetailDto());
		when(cluesDataService.getCluesUserDetailsByEmailId(any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = cluesUserDetailsController.getCluesUserDetailsByEmailId(any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.CluesUserDetailsController#startCluesUpdateScheduler()}.
	 * @throws Exception 
	 */
	@Test
	public void testStartCluesUpdateScheduler() throws Exception {
		
		ResponseWrapper<Boolean> responseWrapper = cluesUserDetailsController.startCluesUpdateScheduler();
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(responseWrapper);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.CluesUserDetailsController#getCluesUserDetailsByCwsIdOrEmailId(java.lang.String, java.lang.String)}.
	 * @throws SQLException 
	 * @throws ParseException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testGetCluesUserDetailsByCwsIdOrEmailId() throws SQLException, ParseException {
		Map response = new HashMap();
	    response.put("LIST", getCluesDataDetailDto());
		when(cluesDataService.getCluesUserDetailsBasedOnCwsIdOrEmailId(any(String.class),any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = cluesUserDetailsController.getCluesUserDetailsByCwsIdOrEmailId(any(String.class),any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.CluesUserDetailsController#getCluesUserDetailsByIds(java.lang.String, java.lang.String, java.lang.String)}.
	 * @throws ParseException 
	 * @throws SQLException 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void testGetCluesUserDetailsByIds() throws ParseException, SQLException {

		Map response = new HashMap();
	    response.put("LIST", getCluesDataDetailDto());
		when(cluesDataService.getCluesUserDetailsBasedOnIds(any(String.class),any(String.class),any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, Object>> responseWrapper = cluesUserDetailsController.getCluesUserDetailsByIds(any(String.class),any(String.class),any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}

	/**
	 * Test method for {@link com.cat.bap.controller.CluesUserDetailsController#bulkUploadForEmailsOrCWSIds(java.lang.String, boolean, java.lang.String, java.lang.String)}.
	 * @throws ParseException 
	 * @throws IOException 
	 * @throws MessagingException 
	 * @throws SQLException 
	 * @throws EMailException 
	 * @throws VelocityException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testBulkUploadForEmailsOrCWSIds() throws ParseException, VelocityException, EMailException, SQLException, MessagingException, IOException {
		
		Map response = new HashMap();
	    response.put("LIST", getCluesDataDetailDto());
		when(cluesDataService.bulkUploadForEmailsOrCWSIds(any(String.class),any(boolean.class),any(String.class),any(String.class)))
        .thenReturn(response);
		ResponseWrapper<Map<String, String>> responseWrapper = cluesUserDetailsController.bulkUploadForEmailsOrCWSIds(any(String.class),any(boolean.class),any(String.class),any(String.class));
		assertEquals(responseWrapper.getStatusCode(), HttpStatus.OK);
		assertNotNull(response);
	}
	
	private CluesDataDetailDto getCluesDataDetailDto() throws ParseException {
		CluesDataDetailDto cluesDataDetailDto = new CluesDataDetailDto();
		cluesDataDetailDto.setBrandAdvocateId(Long.parseLong(props.getProperty("brandAdvocateId")));
		cluesDataDetailDto.setCwsUserId(props.getProperty("cwsUserId"));
		cluesDataDetailDto.setLastName(props.getProperty("lastName"));
		cluesDataDetailDto.setFirstName(props.getProperty("firstName"));
		cluesDataDetailDto.setPreferredFirstName(props.getProperty("preferredFirstName"));
		cluesDataDetailDto.setOrganizationName(props.getProperty("organizationName"));
		cluesDataDetailDto.setWorkLocation(props.getProperty("workLocation"));
		cluesDataDetailDto.setPrimaryEmail(props.getProperty("primaryEmail"));
		cluesDataDetailDto.setSecondaryEmail(props.getProperty("secondaryEmail"));
		cluesDataDetailDto.setCountryId(Long.parseLong(props.getProperty("countryId")));
		cluesDataDetailDto.setCountryName(props.getProperty("countryName"));
		cluesDataDetailDto.setCountryCode(props.getProperty("countryCode"));
		cluesDataDetailDto.setFacilityName(props.getProperty("facilityName"));
		cluesDataDetailDto.setJobKeywords(props.getProperty("jobKeywords"));
		cluesDataDetailDto.setAffiliationDescription(props.getProperty("affiliationDescription"));
		cluesDataDetailDto.setBrandAdvocateStatus(props.getProperty("brandAdvocateStatus"));
		date = formatter.parse(props.getProperty("registrationDate"));
		date = formatter.parse(props.getProperty("modifiedDate"));
		cluesDataDetailDto.setRegionId(Long.parseLong(props.getProperty("regionId")));
		cluesDataDetailDto.setRegionName(props.getProperty("regionName"));
		cluesDataDetailDto.setCupId(props.getProperty("cupId"));
		return cluesDataDetailDto;
	}

}
