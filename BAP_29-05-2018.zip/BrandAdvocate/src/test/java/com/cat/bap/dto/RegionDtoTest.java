/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class RegionDtoTest {

	RegionDto regionDto;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {

		MockitoAnnotations.initMocks(this);
		regionDto = new RegionDto();
	}

	
	/**
	 * Test method for {@link com.cat.bap.dto.RegionDto#getRegionId()}.
	 */
	@Test
	public void testGetRegionId() {
		regionDto.setRegionId(1L);
		long regionId=regionDto.getRegionId();
		assertEquals(1L, regionId);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.RegionDto#getRegionName()}.
	 */
	@Test
	public void testGetRegionName() {
		regionDto.setRegionName("abc");
		String regionName=regionDto.getRegionName();
		assertEquals("abc", regionName);
	}

}
