/**
 * 
 */
package com.cat.bap.dto;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import junit.framework.Assert;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 25-Apr-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class MailRequestTest {
	
	MailRequest mailRequest;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void initMocks() throws Exception {
		MockitoAnnotations.initMocks(this);
		mailRequest = new MailRequest();
		//props = propertyFileUtility.loadPropertyFile("com/cat/bap/testdata/BrandAdvocateTestData.properties");
	}

	

	/**
	 * Test method for {@link com.cat.bap.dto.MailRequest#getSubject()}.
	 */
	@Test
	public void testGetSubject() {
		mailRequest.setSubject("sub");
		String sub= mailRequest.getSubject();
		assertEquals("sub", sub);
	}

	/**
	 * Test method for {@link com.cat.bap.dto.MailRequest#getMessageBody()}.
	 */
	@Test
	public void testGetMessageBody() {
		mailRequest.setMessageBody("body");
		String body= mailRequest.getMessageBody();
		assertEquals("body", body);
	}

}
