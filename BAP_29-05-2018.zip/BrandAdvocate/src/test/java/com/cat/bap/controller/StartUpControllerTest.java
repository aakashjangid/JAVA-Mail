/**
 * 
 */
package com.cat.bap.controller;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * @author rani.agrawal
 * @copyright Yash Technologies Pvt. Ltd.
 * @email rani.agrawal@yash.com
 * @date 30-Mar-2018
 */
@RunWith(MockitoJUnitRunner.class)
public class StartUpControllerTest {
	
	@InjectMocks
	StartUpController startUpController;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	

	/**
	 * Test method for {@link com.cat.bap.controller.StartUpController#processSubmit()}.
	 */
	@Test
	public void testProcessSubmit() {
		
		assertEquals("redirect:/login", startUpController.processSubmit().getViewName());
	}

}
